#pragma once 
#include <AnimNode_XRigLogic_Module_Structs.h>
 
 
 
//Class AnimNode_XRigLogic_Module.XFaceBPLibrary Size 40
// Inherited 40 bytes 
class UXFaceBPLibrary : public UBlueprintFunctionLibrary
{

 public: 



 // Functions 
 public:
	int32_t SetDemoIndex(int32_t V); // Function AnimNode_XRigLogic_Module.XFaceBPLibrary.SetDemoIndex
	struct FString GetIPAddress(); // Function AnimNode_XRigLogic_Module.XFaceBPLibrary.GetIPAddress
	int32_t GetDemoIndex(); // Function AnimNode_XRigLogic_Module.XFaceBPLibrary.GetDemoIndex
}; 
 
 


