#pragma once 
#include <ArkPlayer_BP_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkPlayer_BP.ArkPlayer_BP_C Size 13432
// Inherited 13328 bytes 
class AArkPlayer_BP_C : public AArkPlayer
{

 public: 
	struct FPointerToUberGraphFrame UberGraphFrame;  // Offset: 13328 Size: 8
	struct UArkInteractiveWaterComponent* ArkInteractiveWater;  // Offset: 13336 Size: 8
	struct UInteractiveFieldProxyMeshComponent* MoveInteractive;  // Offset: 13344 Size: 8
	struct USphereComponent* InteractComp;  // Offset: 13352 Size: 8
	struct USphereComponent* TrickComp;  // Offset: 13360 Size: 8
	struct UPointOfInterest_Component_C* PointOfInterest_Component;  // Offset: 13368 Size: 8
	struct UDecalComponent* DecalSkill;  // Offset: 13376 Size: 8
	struct UParticleSystemComponent* TeamSignWigetParticle;  // Offset: 13384 Size: 8
	struct UParticleSystemComponent* TeamSignGuideParticle;  // Offset: 13392 Size: 8
	float FocusLocation;  // Offset: 13400 Size: 4
	char pad_13404[4];  // Offset: 13404 Size: 4
	struct UParticleSystemComponent* ShuttleIntensityParticleSystemComp;  // Offset: 13408 Size: 8
	int32_t Item_CustomInteraction_Execution_NPCPawn_01;  // Offset: 13416 Size: 4
	int32_t Item_CustomInteraction_Execution_NPCPawn_02;  // Offset: 13420 Size: 4
	int32_t Item_CustomInteraction_Execution_NPCPawn_03;  // Offset: 13424 Size: 4
	int32_t Item_CustomInteraction_Execution_NPCPawn_04;  // Offset: 13428 Size: 4



 // Functions 
 public:
	struct FString GetModuleName(); // Function ArkPlayer_BP.ArkPlayer_BP_C.GetModuleName
	void TickCameraDOF(); // Function ArkPlayer_BP.ArkPlayer_BP_C.TickCameraDOF
	void LuaBeginPlay(); // Function ArkPlayer_BP.ArkPlayer_BP_C.LuaBeginPlay
	void UserConstructionScript(); // Function ArkPlayer_BP.ArkPlayer_BP_C.UserConstructionScript
	void OnNotifyEnd_2D3C37AA4907389D46CF53BABAD925F4(struct FName NotifyName); // Function ArkPlayer_BP.ArkPlayer_BP_C.OnNotifyEnd_2D3C37AA4907389D46CF53BABAD925F4
	void OnNotifyBegin_2D3C37AA4907389D46CF53BABAD925F4(struct FName NotifyName); // Function ArkPlayer_BP.ArkPlayer_BP_C.OnNotifyBegin_2D3C37AA4907389D46CF53BABAD925F4
	void OnInterrupted_2D3C37AA4907389D46CF53BABAD925F4(struct FName NotifyName); // Function ArkPlayer_BP.ArkPlayer_BP_C.OnInterrupted_2D3C37AA4907389D46CF53BABAD925F4
	void OnBlendOut_2D3C37AA4907389D46CF53BABAD925F4(struct FName NotifyName); // Function ArkPlayer_BP.ArkPlayer_BP_C.OnBlendOut_2D3C37AA4907389D46CF53BABAD925F4
	void OnCompleted_2D3C37AA4907389D46CF53BABAD925F4(struct FName NotifyName); // Function ArkPlayer_BP.ArkPlayer_BP_C.OnCompleted_2D3C37AA4907389D46CF53BABAD925F4
	void NotifyPlayerAiming(bool inAiming); // Function ArkPlayer_BP.ArkPlayer_BP_C.NotifyPlayerAiming
	void ReceiveBeginPlay(); // Function ArkPlayer_BP.ArkPlayer_BP_C.ReceiveBeginPlay
	void NotifyAddEnergyAt(int32_t EnergyCount, struct FTransform EnergyTrans); // Function ArkPlayer_BP.ArkPlayer_BP_C.NotifyAddEnergyAt
	void DoShieldBroken(); // Function ArkPlayer_BP.ArkPlayer_BP_C.DoShieldBroken
	void NotifyPlayEquipAnim(struct UAnimMontage* inMontage, float inRate); // Function ArkPlayer_BP.ArkPlayer_BP_C.NotifyPlayEquipAnim
	void OnStealthEffectChange_2(bool bSneakyOn); // Function ArkPlayer_BP.ArkPlayer_BP_C.OnStealthEffectChange_2
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function ArkPlayer_BP.ArkPlayer_BP_C.ReceiveEndPlay
	void RestartGame(); // Function ArkPlayer_BP.ArkPlayer_BP_C.RestartGame
	void DoShieldAchieve(); // Function ArkPlayer_BP.ArkPlayer_BP_C.DoShieldAchieve
	void OnShuttleIntensityUpdate_BP(); // Function ArkPlayer_BP.ArkPlayer_BP_C.OnShuttleIntensityUpdate_BP
	void NotifyInHideAreaEffect(bool bin); // Function ArkPlayer_BP.ArkPlayer_BP_C.NotifyInHideAreaEffect
	void UpdatePlayerTargeting(bool inTargeting); // Function ArkPlayer_BP.ArkPlayer_BP_C.UpdatePlayerTargeting
	void ClientAddQuest(int32_t questID); // Function ArkPlayer_BP.ArkPlayer_BP_C.ClientAddQuest
	void ServerAddQuest(int32_t questID); // Function ArkPlayer_BP.ArkPlayer_BP_C.ServerAddQuest
	void Enter Targeting(bool bClientSimulation); // Function ArkPlayer_BP.ArkPlayer_BP_C.Enter Targeting
	void Leave Targeting(bool bClientSimulation); // Function ArkPlayer_BP.ArkPlayer_BP_C.Leave Targeting
	void Enter Aiming(bool bClientSimulation); // Function ArkPlayer_BP.ArkPlayer_BP_C.Enter Aiming
	void Leave Aiming(bool bClientSimulation); // Function ArkPlayer_BP.ArkPlayer_BP_C.Leave Aiming
	void ExecuteUbergraph_ArkPlayer_BP(int32_t EntryPoint); // Function ArkPlayer_BP.ArkPlayer_BP_C.ExecuteUbergraph_ArkPlayer_BP
}; 
 
 


