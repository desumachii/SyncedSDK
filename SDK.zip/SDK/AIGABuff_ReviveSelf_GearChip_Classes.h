#pragma once 
#include <AIGABuff_ReviveSelf_GearChip_Structs.h>
 
 
 
//BlueprintGeneratedClass AIGABuff_ReviveSelf_GearChip.AIGABuff_ReviveSelf_GearChip_C Size 2000
// Inherited 2000 bytes 
class UAIGABuff_ReviveSelf_GearChip_C : public UArkAIGABuff_ReviveSelf
{

 public: 



 // Functions 
 public:
}; 
 
 


