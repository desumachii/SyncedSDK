#pragma once 
#include <ArkPlayerCameraMgr_BP_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkPlayerCameraMgr_BP.ArkPlayerCameraMgr_BP_C Size 15732
// Inherited 12496 bytes 
class AArkPlayerCameraMgr_BP_C : public AArkPlayerCameraManager
{

 public: 
	struct FPointerToUberGraphFrame UberGraphFrame;  // Offset: 12496 Size: 8
	float AutoFocus_TL_alpha_78323E684BA9EDB31019C0BAD7B37244;  // Offset: 12504 Size: 4
	enum class ETimelineDirection AutoFocus_TL__Direction_78323E684BA9EDB31019C0BAD7B37244;  // Offset: 12508 Size: 1
	char pad_12509[3];  // Offset: 12509 Size: 3
	struct UTimelineComponent* AutoFocus_TL;  // Offset: 12512 Size: 8
	float lerpSpeed;  // Offset: 12520 Size: 4
	char pad_12524[4];  // Offset: 12524 Size: 4
	struct FPostProcessSettings configSettings;  // Offset: 12528 Size: 1600
	struct FPostProcessSettings currentSettings;  // Offset: 14128 Size: 1600
	float EnterSprintEffectTime;  // Offset: 15728 Size: 4



 // Functions 
 public:
	void AutoFocus_TL__FinishedFunc(); // Function ArkPlayerCameraMgr_BP.ArkPlayerCameraMgr_BP_C.AutoFocus_TL__FinishedFunc
	void AutoFocus_TL__UpdateFunc(); // Function ArkPlayerCameraMgr_BP.ArkPlayerCameraMgr_BP_C.AutoFocus_TL__UpdateFunc
	void PlayEnterSprintEffect(); // Function ArkPlayerCameraMgr_BP.ArkPlayerCameraMgr_BP_C.PlayEnterSprintEffect
	void PlayBlindingEffect(float Duration); // Function ArkPlayerCameraMgr_BP.ArkPlayerCameraMgr_BP_C.PlayBlindingEffect
	void ReceiveBeginPlay(); // Function ArkPlayerCameraMgr_BP.ArkPlayerCameraMgr_BP_C.ReceiveBeginPlay
	void ExecuteUbergraph_ArkPlayerCameraMgr_BP(int32_t EntryPoint); // Function ArkPlayerCameraMgr_BP.ArkPlayerCameraMgr_BP_C.ExecuteUbergraph_ArkPlayerCameraMgr_BP
}; 
 
 


