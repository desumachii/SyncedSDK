#pragma once 
#include <ArkGABuff_ReviveMaster_PVE_SeasonalArmband_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkGABuff_ReviveMaster_PVE_SeasonalArmband.ArkGABuff_ReviveMaster_PVE_SeasonalArmband_C Size 2088
// Inherited 2080 bytes 
class UArkGABuff_ReviveMaster_PVE_SeasonalArmband_C : public UArkGABuff_ReviveMaster_Lv1_C
{

 public: 
	struct FPointerToUberGraphFrame UberGraphFrame;  // Offset: 2080 Size: 8



 // Functions 
 public:
	void OnPlayerRevived_BP(struct AArkPlayer* RevivedPlayer); // Function ArkGABuff_ReviveMaster_PVE_SeasonalArmband.ArkGABuff_ReviveMaster_PVE_SeasonalArmband_C.OnPlayerRevived_BP
	void ExecuteUbergraph_ArkGABuff_ReviveMaster_PVE_SeasonalArmband(int32_t EntryPoint); // Function ArkGABuff_ReviveMaster_PVE_SeasonalArmband.ArkGABuff_ReviveMaster_PVE_SeasonalArmband_C.ExecuteUbergraph_ArkGABuff_ReviveMaster_PVE_SeasonalArmband
}; 
 
 


