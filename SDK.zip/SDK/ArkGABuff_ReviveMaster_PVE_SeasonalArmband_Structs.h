#pragma once 
#include <SDK_Engine_Objects.h> 
 
 
//Function ArkGABuff_ReviveMaster_PVE_SeasonalArmband.ArkGABuff_ReviveMaster_PVE_SeasonalArmband_C.ExecuteUbergraph_ArkGABuff_ReviveMaster_PVE_SeasonalArmband Size 17
class FExecuteUbergraph_ArkGABuff_ReviveMaster_PVE_SeasonalArmband
{

 public: 
	int32_t EntryPoint;  // Offset: 0 Size: 4
	char pad_4[4];  // Offset: 4 Size: 4
	struct AArkPlayer* K2Node_Event_RevivedPlayer;  // Offset: 8 Size: 8
	char pad_16_1 : 7;  // Offset: 16 Size: 1
	bool CallFunc_AddTag_ReturnValue : 1;  // Offset: 16 Size: 1



 // Functions 
 public:
}; 
 
 //Function ArkGABuff_ReviveMaster_PVE_SeasonalArmband.ArkGABuff_ReviveMaster_PVE_SeasonalArmband_C.OnPlayerRevived_BP Size 8
// Inherited 8 bytes 
class FOnPlayerRevived_BP : public FOnPlayerRevived_BP
{

 public: 
	struct AArkPlayer* RevivedPlayer;  // Offset: 0 Size: 8



 // Functions 
 public:
}; 
 
 