#pragma once 
#include <AnimationBudgetAllocator_Structs.h>
 
 
 
//Class AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary Size 40
// Inherited 40 bytes 
class UAnimationBudgetBlueprintLibrary : public UBlueprintFunctionLibrary
{

 public: 



 // Functions 
 public:
	void SetAnimationBudgetParameters(struct UObject* WorldContextObject, struct FAnimationBudgetAllocatorParameters& InParameters); // Function AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary.SetAnimationBudgetParameters
	void EnableAnimationBudget(struct UObject* WorldContextObject, bool bEnabled); // Function AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary.EnableAnimationBudget
}; 
 
 


//Class AnimationBudgetAllocator.SkeletalMeshComponentBudgeted Size 3792
// Inherited 3744 bytes 
class USkeletalMeshComponentBudgeted : public USkeletalMeshComponent
{

 public: 
	char pad_3744[40];  // Offset: 3744 Size: 40
	char bAutoRegisterWithBudgetAllocator : 1;  // Offset: 3784 Size: 1
	char bAutoCalculateSignificance : 1;  // Offset: 3784 Size: 1
	char bShouldUseActorRenderedFlag : 1;  // Offset: 3784 Size: 1
	char pad_3784_1 : 5;  // Offset: 3784 Size: 1
	char pad_3785[8];  // Offset: 3785 Size: 8



 // Functions 
 public:
	void SetAutoRegisterWithBudgetAllocator(bool bInAutoRegisterWithBudgetAllocator); // Function AnimationBudgetAllocator.SkeletalMeshComponentBudgeted.SetAutoRegisterWithBudgetAllocator
}; 
 
 


