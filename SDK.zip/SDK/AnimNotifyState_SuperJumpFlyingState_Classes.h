#pragma once 
#include <AnimNotifyState_SuperJumpFlyingState_Structs.h>
 
 
 
//BlueprintGeneratedClass AnimNotifyState_SuperJumpFlyingState.AnimNotifyState_SuperJumpFlyingState_C Size 50
// Inherited 48 bytes 
class UAnimNotifyState_SuperJumpFlyingState_C : public UAnimNotifyState
{

 public: 
	enum class EArkSuperJumpFlyingState EnterFlyingState;  // Offset: 48 Size: 1
	enum class EArkSuperJumpFlyingState ExitFlyingState;  // Offset: 49 Size: 1



 // Functions 
 public:
	bool Received_NotifyEnd(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function AnimNotifyState_SuperJumpFlyingState.AnimNotifyState_SuperJumpFlyingState_C.Received_NotifyEnd
	bool Received_NotifyBegin(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration); // Function AnimNotifyState_SuperJumpFlyingState.AnimNotifyState_SuperJumpFlyingState_C.Received_NotifyBegin
}; 
 
 


