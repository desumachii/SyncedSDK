#pragma once 
#include <ArkLaserChainBullet_GT_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkLaserChainBullet_GT.ArkLaserChainBullet_GT_C Size 2344
// Inherited 2344 bytes 
class AArkLaserChainBullet_GT_C : public AArkProjectile_LaserChain
{

 public: 



 // Functions 
 public:
}; 
 
 


