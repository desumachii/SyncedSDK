#pragma once 
#include <SDK_Engine_Objects.h> 
 
 
//Function AIGABfuff_Scan_Enhancement.AIGABfuff_Scan_Enhancement_C.ExecuteUbergraph_AIGABfuff_Scan_Enhancement Size 66
class FExecuteUbergraph_AIGABfuff_Scan_Enhancement
{

 public: 
	int32_t EntryPoint;  // Offset: 0 Size: 4
	char pad_4[4];  // Offset: 4 Size: 4
	struct TArray<struct AArkCharacterBase*> K2Node_MakeArray_Array;  // Offset: 8 Size: 16
	struct AArkPlayer* K2Node_Event_Player;  // Offset: 24 Size: 8
	char pad_32_1 : 7;  // Offset: 32 Size: 1
	bool CallFunc_HasAuthority_ReturnValue : 1;  // Offset: 32 Size: 1
	char pad_33[7];  // Offset: 33 Size: 7
	struct AArkNpc* CallFunc_GetSyncedAI_ReturnValue;  // Offset: 40 Size: 8
	struct AArkPlayer* CallFunc_GetOwnerAsPlayer_ReturnValue;  // Offset: 48 Size: 8
	struct UArkSoftParticleSystemComponentWithPool* CallFunc_SpawnSoftEmitterAttached_ReturnValue;  // Offset: 56 Size: 8
	char pad_64_1 : 7;  // Offset: 64 Size: 1
	bool CallFunc_IsDedicatedServer_ReturnValue : 1;  // Offset: 64 Size: 1
	char pad_65_1 : 7;  // Offset: 65 Size: 1
	bool CallFunc_IsDedicatedServer_ReturnValue_2 : 1;  // Offset: 65 Size: 1



 // Functions 
 public:
}; 
 
 //Function AIGABfuff_Scan_Enhancement.AIGABfuff_Scan_Enhancement_C.OnPeriodForPlayer Size 8
// Inherited 8 bytes 
class FOnPeriodForPlayer : public FOnPeriodForPlayer
{

 public: 
	struct AArkPlayer* Player;  // Offset: 0 Size: 8



 // Functions 
 public:
}; 
 
 