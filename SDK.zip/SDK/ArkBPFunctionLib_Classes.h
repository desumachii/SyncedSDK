#pragma once 
#include <ArkBPFunctionLib_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkBPFunctionLib.ArkBPFunctionLib_C Size 40
// Inherited 40 bytes 
class UArkBPFunctionLib_C : public UBlueprintFunctionLibrary
{

 public: 



 // Functions 
 public:
	void GFun_IsValidEnemyMonster(struct AArkNpc* InNpc, struct UObject* __WorldContext, bool& IsValid); // Function ArkBPFunctionLib.ArkBPFunctionLib_C.GFun_IsValidEnemyMonster
	void GFun_GetAttitudeColor(enum class ETeamAttitude TeamAttitude, struct UObject* __WorldContext, struct FLinearColor& Color); // Function ArkBPFunctionLib.ArkBPFunctionLib_C.GFun_GetAttitudeColor
	void GFun_GetQualityColor(struct FString ColorName, struct UObject* __WorldContext, struct FLinearColor& Color); // Function ArkBPFunctionLib.ArkBPFunctionLib_C.GFun_GetQualityColor
	void GFun_GetPlayerColor(int32_t PlayerIndex, struct UObject* __WorldContext, struct FLinearColor& Color); // Function ArkBPFunctionLib.ArkBPFunctionLib_C.GFun_GetPlayerColor
	void GFun_GetBasicColor(struct FString ColorName, struct UObject* __WorldContext, struct FLinearColor& Color); // Function ArkBPFunctionLib.ArkBPFunctionLib_C.GFun_GetBasicColor
	void GFunGetThreatTextColorByLevel(int32_t MyLevel, int32_t ThreatLevel, struct UObject* __WorldContext, struct FSlateColor& ThreatColor); // Function ArkBPFunctionLib.ArkBPFunctionLib_C.GFunGetThreatTextColorByLevel
	void GFunGetThreatIconColorByLevel(int32_t MyLevel, int32_t ThreatLevel, struct UObject* __WorldContext, struct FLinearColor& ThreatColor); // Function ArkBPFunctionLib.ArkBPFunctionLib_C.GFunGetThreatIconColorByLevel
	void GFun_GetRegistColor(enum class EShuttleWidgetRegistEventType Type, struct UObject* __WorldContext, struct FLinearColor& Color); // Function ArkBPFunctionLib.ArkBPFunctionLib_C.GFun_GetRegistColor
	void GFun_GetShuttleAlphabet(int32_t ShuttleID, struct UObject* __WorldContext, struct FText& alphabet); // Function ArkBPFunctionLib.ArkBPFunctionLib_C.GFun_GetShuttleAlphabet
	void GFun_GetShuttleStateCountDown(int32_t ShuttleID, enum class EArkShuttleStateType Type, struct UObject* __WorldContext, bool& valid, float& Seconds); // Function ArkBPFunctionLib.ArkBPFunctionLib_C.GFun_GetShuttleStateCountDown
	void GFun_GetShuttleIconColor(int32_t ShuttleID, struct UObject* __WorldContext, struct FLinearColor& Color); // Function ArkBPFunctionLib.ArkBPFunctionLib_C.GFun_GetShuttleIconColor
	void GFun_GetShuttleIcon(int32_t ShuttleID, struct UObject* __WorldContext, struct FText& icon); // Function ArkBPFunctionLib.ArkBPFunctionLib_C.GFun_GetShuttleIcon
	bool GFun_IsMeleeDamage(struct UDamageType* DamageType, struct UObject* __WorldContext); // Function ArkBPFunctionLib.ArkBPFunctionLib_C.GFun_IsMeleeDamage
	void GFun_GetMyTeamID(struct APlayerController* PlayerController, struct UObject* __WorldContext, int32_t& OutTeamID); // Function ArkBPFunctionLib.ArkBPFunctionLib_C.GFun_GetMyTeamID
	void GFun_GetGameState(struct UObject* ContextObj, struct UObject* __WorldContext, struct AArkGameStateBattle*& RetGameState); // Function ArkBPFunctionLib.ArkBPFunctionLib_C.GFun_GetGameState
	void GFun_GetPlayerStateByID(struct FString PlayerId, struct AActor* WorldContextActor, struct UObject* __WorldContext, struct AArkPlayerStateBattle*& PlayerState); // Function ArkBPFunctionLib.ArkBPFunctionLib_C.GFun_GetPlayerStateByID
}; 
 
 


