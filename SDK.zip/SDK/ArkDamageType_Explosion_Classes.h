#pragma once 
#include <ArkDamageType_Explosion_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkDamageType_Explosion.ArkDamageType_Explosion_C Size 264
// Inherited 264 bytes 
class UArkDamageType_Explosion_C : public UArkDamageType_Radial_C
{

 public: 



 // Functions 
 public:
}; 
 
 


