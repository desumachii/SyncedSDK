#pragma once 
#include <AIGABuff_DamageFixForPve_Seer_Structs.h>
 
 
 
//BlueprintGeneratedClass AIGABuff_DamageFixForPve_Seer.AIGABuff_DamageFixForPve_Seer_C Size 816
// Inherited 816 bytes 
class UAIGABuff_DamageFixForPve_Seer_C : public UArkGameBuff_BaseDamageModifier
{

 public: 



 // Functions 
 public:
}; 
 
 


