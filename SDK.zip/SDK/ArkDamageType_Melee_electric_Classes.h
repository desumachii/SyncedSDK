#pragma once 
#include <ArkDamageType_Melee_electric_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkDamageType_Melee_electric.ArkDamageType_Melee_electric_C Size 264
// Inherited 264 bytes 
class UArkDamageType_Melee_electric_C : public UArkDamageType_Melee_C
{

 public: 



 // Functions 
 public:
}; 
 
 


