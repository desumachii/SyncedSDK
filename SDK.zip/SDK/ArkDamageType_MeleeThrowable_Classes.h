#pragma once 
#include <ArkDamageType_MeleeThrowable_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkDamageType_MeleeThrowable.ArkDamageType_MeleeThrowable_C Size 264
// Inherited 264 bytes 
class UArkDamageType_MeleeThrowable_C : public UArkDamageType_Melee_PlayerHitReaction_C
{

 public: 



 // Functions 
 public:
}; 
 
 


