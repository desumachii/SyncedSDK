#pragma once 
#include <AIGABfuff_Scan_Enhancement_lv2_Structs.h>
 
 
 
//BlueprintGeneratedClass AIGABfuff_Scan_Enhancement_lv2.AIGABfuff_Scan_Enhancement_lv2_C Size 952
// Inherited 936 bytes 
class UAIGABfuff_Scan_Enhancement_lv2_C : public UArkGameBuff_Element
{

 public: 
	struct FPointerToUberGraphFrame UberGraphFrame;  // Offset: 936 Size: 8
	struct UArkSoftParticleSystemComponentWithPool* ScanEffect;  // Offset: 944 Size: 8



 // Functions 
 public:
	void C2BP_OnActive(); // Function AIGABfuff_Scan_Enhancement_lv2.AIGABfuff_Scan_Enhancement_lv2_C.C2BP_OnActive
	void C2BP_OnDeactive(); // Function AIGABfuff_Scan_Enhancement_lv2.AIGABfuff_Scan_Enhancement_lv2_C.C2BP_OnDeactive
	void OnPeriodForPlayer(struct AArkPlayer* Player); // Function AIGABfuff_Scan_Enhancement_lv2.AIGABfuff_Scan_Enhancement_lv2_C.OnPeriodForPlayer
	void ExecuteUbergraph_AIGABfuff_Scan_Enhancement_lv2(int32_t EntryPoint); // Function AIGABfuff_Scan_Enhancement_lv2.AIGABfuff_Scan_Enhancement_lv2_C.ExecuteUbergraph_AIGABfuff_Scan_Enhancement_lv2
}; 
 
 


