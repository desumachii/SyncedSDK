#pragma once 
#include <AnimNotifyState_SuperJumpDisableSlideUp_Structs.h>
 
 
 
//BlueprintGeneratedClass AnimNotifyState_SuperJumpDisableSlideUp.AnimNotifyState_SuperJumpDisableSlideUp_C Size 48
// Inherited 48 bytes 
class UAnimNotifyState_SuperJumpDisableSlideUp_C : public UAnimNotifyState
{

 public: 



 // Functions 
 public:
	bool Received_NotifyEnd(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function AnimNotifyState_SuperJumpDisableSlideUp.AnimNotifyState_SuperJumpDisableSlideUp_C.Received_NotifyEnd
	bool Received_NotifyBegin(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration); // Function AnimNotifyState_SuperJumpDisableSlideUp.AnimNotifyState_SuperJumpDisableSlideUp_C.Received_NotifyBegin
}; 
 
 


