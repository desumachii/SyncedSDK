#pragma once 
#include <SDK_Engine_Objects.h> 
 
 
//ScriptStruct ArkColor.ArkLinearColor Size 24
class FArkLinearColor
{

 public: 
	struct FLinearColor ColorValue;  // Offset: 0 Size: 16
	struct FName ColorThemeName;  // Offset: 16 Size: 8



 // Functions 
 public:
}; 
 
 //ScriptStruct ArkColor.ArkPresetColorNew Size 40
// Inherited 8 bytes 
class FArkPresetColorNew : public FTableRowBase
{

 public: 
	struct FString ColorDescription;  // Offset: 8 Size: 16
	struct FLinearColor ColorTheme;  // Offset: 24 Size: 16



 // Functions 
 public:
}; 
 
 //ScriptStruct ArkColor.ArkSlateColor Size 48
class FArkSlateColor
{

 public: 
	struct FSlateColor ColorValue;  // Offset: 0 Size: 40
	struct FName ColorThemeName;  // Offset: 40 Size: 8



 // Functions 
 public:
}; 
 
 //ScriptStruct ArkColor.ArkColor Size 12
class FArkColor
{

 public: 
	struct FColor ColorValue;  // Offset: 0 Size: 4
	struct FName ColorThemeName;  // Offset: 4 Size: 8



 // Functions 
 public:
}; 
 
 