#pragma once 
#include <ArkKunaiBullet_GT_LV1_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkKunaiBullet_GT_LV1.ArkKunaiBullet_GT_LV1_C Size 2008
// Inherited 2000 bytes 
class AArkKunaiBullet_GT_LV1_C : public AArkProjectile_Kunai
{

 public: 
	struct FPointerToUberGraphFrame UberGraphFrame;  // Offset: 2000 Size: 8



 // Functions 
 public:
	void BP_OnBulletInit(); // Function ArkKunaiBullet_GT_LV1.ArkKunaiBullet_GT_LV1_C.BP_OnBulletInit
	void ExecuteUbergraph_ArkKunaiBullet_GT_LV1(int32_t EntryPoint); // Function ArkKunaiBullet_GT_LV1.ArkKunaiBullet_GT_LV1_C.ExecuteUbergraph_ArkKunaiBullet_GT_LV1
}; 
 
 


