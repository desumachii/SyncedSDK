#pragma once 
#include <ArkDamageType_2doTs_CauseByRange_Flame_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkDamageType_2doTs_CauseByRange_Flame.ArkDamageType_2doTs_CauseByRange_Flame_C Size 264
// Inherited 264 bytes 
class UArkDamageType_2doTs_CauseByRange_Flame_C : public UArkDamageType_2doTs_CauseByRange_C
{

 public: 



 // Functions 
 public:
}; 
 
 


