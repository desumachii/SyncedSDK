#pragma once 
#include <AmmoPickup338LM_Lite_Structs.h>
 
 
 
//BlueprintGeneratedClass AmmoPickup338LM_Lite.AmmoPickup338LM_Lite_C Size 2416
// Inherited 2416 bytes 
class AAmmoPickup338LM_Lite_C : public AAmmoPickupBase_C
{

 public: 



 // Functions 
 public:
}; 
 
 


