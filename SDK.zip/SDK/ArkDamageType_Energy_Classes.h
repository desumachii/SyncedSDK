#pragma once 
#include <ArkDamageType_Energy_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkDamageType_Energy.ArkDamageType_Energy_C Size 264
// Inherited 264 bytes 
class UArkDamageType_Energy_C : public UArkDamageType
{

 public: 



 // Functions 
 public:
}; 
 
 


