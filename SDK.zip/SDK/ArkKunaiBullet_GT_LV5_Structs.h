#pragma once 
#include <SDK_Engine_Objects.h> 
 
 
//Function ArkKunaiBullet_GT_LV5.ArkKunaiBullet_GT_LV5_C.ExecuteUbergraph_ArkKunaiBullet_GT_LV5 Size 120
class FExecuteUbergraph_ArkKunaiBullet_GT_LV5
{

 public: 
	int32_t EntryPoint;  // Offset: 0 Size: 4
	struct FDelegate Temp_delegate_Variable;  // Offset: 4 Size: 16
	char pad_20[4];  // Offset: 20 Size: 4
	struct TMap<struct FString, float> Temp_string_Variable;  // Offset: 24 Size: 80
	struct TArray<struct FString> Temp_string_Variable_2;  // Offset: 104 Size: 16



 // Functions 
 public:
}; 
 
 