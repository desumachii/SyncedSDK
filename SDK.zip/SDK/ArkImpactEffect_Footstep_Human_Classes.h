#pragma once 
#include <ArkImpactEffect_Footstep_Human_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkImpactEffect_Footstep_Human.ArkImpactEffect_Footstep_Human_C Size 504
// Inherited 504 bytes 
class UArkImpactEffect_Footstep_Human_C : public UArkImpactEffect
{

 public: 



 // Functions 
 public:
}; 
 
 


