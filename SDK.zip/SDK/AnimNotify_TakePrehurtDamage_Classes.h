#pragma once 
#include <AnimNotify_TakePrehurtDamage_Structs.h>
 
 
 
//BlueprintGeneratedClass AnimNotify_TakePrehurtDamage.AnimNotify_TakePrehurtDamage_C Size 64
// Inherited 56 bytes 
class UAnimNotify_TakePrehurtDamage_C : public UAnimNotify
{

 public: 
	float MinDistance;  // Offset: 56 Size: 4
	float MaxDistance;  // Offset: 60 Size: 4



 // Functions 
 public:
	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function AnimNotify_TakePrehurtDamage.AnimNotify_TakePrehurtDamage_C.Received_Notify
}; 
 
 


