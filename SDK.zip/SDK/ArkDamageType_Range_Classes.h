#pragma once 
#include <ArkDamageType_Range_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkDamageType_Range.ArkDamageType_Range_C Size 264
// Inherited 264 bytes 
class UArkDamageType_Range_C : public UArkDamageType
{

 public: 



 // Functions 
 public:
}; 
 
 


