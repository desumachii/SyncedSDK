#pragma once 
#include <SDK_Engine_Objects.h> 
 
 
//Function AIGABuff_DeathTimer_PVE.AIGABuff_DeathTimer_PVE_C.ExecuteUbergraph_AIGABuff_DeathTimer_PVE Size 18
class FExecuteUbergraph_AIGABuff_DeathTimer_PVE
{

 public: 
	int32_t EntryPoint;  // Offset: 0 Size: 4
	char pad_4[4];  // Offset: 4 Size: 4
	struct AArkNpc* CallFunc_OwnerNpc_ReturnValue;  // Offset: 8 Size: 8
	char pad_16_1 : 7;  // Offset: 16 Size: 1
	bool CallFunc_IsValid_ReturnValue : 1;  // Offset: 16 Size: 1
	char pad_17_1 : 7;  // Offset: 17 Size: 1
	bool CallFunc_HasAuthority_ReturnValue : 1;  // Offset: 17 Size: 1



 // Functions 
 public:
}; 
 
 