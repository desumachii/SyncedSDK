#pragma once 
#include <ArkImpactEffect_SprintCharge_ThrowableWeapon_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkImpactEffect_SprintCharge_ThrowableWeapon.ArkImpactEffect_SprintCharge_ThrowableWeapon_C Size 504
// Inherited 504 bytes 
class UArkImpactEffect_SprintCharge_ThrowableWeapon_C : public UArkImpactEffect
{

 public: 



 // Functions 
 public:
}; 
 
 


