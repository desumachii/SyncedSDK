#pragma once 
#include <ArkBlackHoleBullet_GT_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkBlackHoleBullet_GT.ArkBlackHoleBullet_GT_C Size 1880
// Inherited 1872 bytes 
class AArkBlackHoleBullet_GT_C : public AArkProjectile_BlackHole
{

 public: 
	struct FPointerToUberGraphFrame UberGraphFrame;  // Offset: 1872 Size: 8



 // Functions 
 public:
	void BP_OnBulletInit(); // Function ArkBlackHoleBullet_GT.ArkBlackHoleBullet_GT_C.BP_OnBulletInit
	void ExecuteUbergraph_ArkBlackHoleBullet_GT(int32_t EntryPoint); // Function ArkBlackHoleBullet_GT.ArkBlackHoleBullet_GT_C.ExecuteUbergraph_ArkBlackHoleBullet_GT
}; 
 
 


