#pragma once 
#include <ArkImpactEffect_Proj_Erosion_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkImpactEffect_Proj_Erosion.ArkImpactEffect_Proj_Erosion_C Size 504
// Inherited 504 bytes 
class UArkImpactEffect_Proj_Erosion_C : public UArkImpactEffect_Proj_Common_C
{

 public: 



 // Functions 
 public:
}; 
 
 


