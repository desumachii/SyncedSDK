#pragma once 
#include <ArkDefaultSwarmEntityController_BP_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkDefaultSwarmEntityController_BP.ArkDefaultSwarmEntityController_BP_C Size 1112
// Inherited 1112 bytes 
class AArkDefaultSwarmEntityController_BP_C : public AArkSwarmEntityController
{

 public: 



 // Functions 
 public:
}; 
 
 


