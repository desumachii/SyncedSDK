#pragma once 
#include <ArkDamageType_ApplyKnockFly_CrashDamage_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkDamageType_ApplyKnockFly_CrashDamage.ArkDamageType_ApplyKnockFly_CrashDamage_C Size 264
// Inherited 264 bytes 
class UArkDamageType_ApplyKnockFly_CrashDamage_C : public UArkDamageType_KnockFlyingCrash_C
{

 public: 



 // Functions 
 public:
}; 
 
 


