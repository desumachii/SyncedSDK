#pragma once 
#include <ArkImpactEffect_NanoPunch_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkImpactEffect_NanoPunch.ArkImpactEffect_NanoPunch_C Size 504
// Inherited 504 bytes 
class UArkImpactEffect_NanoPunch_C : public UArkImpactEffect
{

 public: 



 // Functions 
 public:
}; 
 
 


