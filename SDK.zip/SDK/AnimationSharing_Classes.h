#pragma once 
#include <AnimationSharing_Structs.h>
 
 
 
//Class AnimationSharing.AnimSharingTransitionInstance Size 688
// Inherited 672 bytes 
class UAnimSharingTransitionInstance : public UAnimInstance
{

 public: 
	struct TWeakObjectPtr<USkeletalMeshComponent> FromComponent;  // Offset: 664 Size: 8
	struct TWeakObjectPtr<USkeletalMeshComponent> ToComponent;  // Offset: 672 Size: 8
	float BlendTime;  // Offset: 680 Size: 4
	char pad_692_1 : 7;  // Offset: 692 Size: 1
	bool bBlendBool : 1;  // Offset: 684 Size: 1



 // Functions 
 public:
}; 
 
 


//Class AnimationSharing.AnimSharingStateInstance Size 704
// Inherited 672 bytes 
class UAnimSharingStateInstance : public UAnimInstance
{

 public: 
	struct UAnimSequence* AnimationToPlay;  // Offset: 664 Size: 8
	float PermutationTimeOffset;  // Offset: 672 Size: 4
	float PlayRate;  // Offset: 676 Size: 4
	char pad_688_1 : 7;  // Offset: 688 Size: 1
	bool bStateBool : 1;  // Offset: 680 Size: 1
	struct UAnimSharingInstance* Instance;  // Offset: 688 Size: 8
	char pad_697[7];  // Offset: 697 Size: 7



 // Functions 
 public:
	void GetInstancedActors(struct TArray<struct AActor*>& Actors); // Function AnimationSharing.AnimSharingStateInstance.GetInstancedActors
}; 
 
 


//Class AnimationSharing.AnimationSharingSetup Size 72
// Inherited 40 bytes 
class UAnimationSharingSetup : public UObject
{

 public: 
	struct TArray<struct FPerSkeletonAnimationSharingSetup> SkeletonSetups;  // Offset: 40 Size: 16
	struct FAnimationSharingScalability ScalabilitySettings;  // Offset: 56 Size: 16



 // Functions 
 public:
}; 
 
 


//Class AnimationSharing.AnimSharingAdditiveInstance Size 688
// Inherited 672 bytes 
class UAnimSharingAdditiveInstance : public UAnimInstance
{

 public: 
	struct TWeakObjectPtr<USkeletalMeshComponent> BaseComponent;  // Offset: 664 Size: 8
	struct TWeakObjectPtr<UAnimSequence> AdditiveAnimation;  // Offset: 672 Size: 8
	float Alpha;  // Offset: 680 Size: 4
	char pad_692_1 : 7;  // Offset: 692 Size: 1
	bool bStateBool : 1;  // Offset: 684 Size: 1



 // Functions 
 public:
}; 
 
 


//Class AnimationSharing.AnimSharingInstance Size 312
// Inherited 40 bytes 
class UAnimSharingInstance : public UObject
{

 public: 
	struct TArray<struct AActor*> RegisteredActors;  // Offset: 40 Size: 16
	char pad_56[112];  // Offset: 56 Size: 112
	struct UAnimationSharingStateProcessor* StateProcessor;  // Offset: 168 Size: 8
	char pad_176[56];  // Offset: 176 Size: 56
	struct TArray<struct UAnimSequence*> UsedAnimationSequences;  // Offset: 232 Size: 16
	char pad_248[16];  // Offset: 248 Size: 16
	struct UEnum* StateEnum;  // Offset: 264 Size: 8
	struct AActor* SharingActor;  // Offset: 272 Size: 8
	char pad_280[32];  // Offset: 280 Size: 32



 // Functions 
 public:
}; 
 
 


//Class AnimationSharing.AnimationSharingStateProcessor Size 80
// Inherited 40 bytes 
class UAnimationSharingStateProcessor : public UObject
{

 public: 
	struct TSoftObjectPtr<UEnum> AnimationStateEnum;  // Offset: 40 Size: 40



 // Functions 
 public:
	void ProcessActorState(int32_t& OutState, struct AActor* InActor, char CurrentState, char OnDemandState, bool& bShouldProcess); // Function AnimationSharing.AnimationSharingStateProcessor.ProcessActorState
	struct UEnum* GetAnimationStateEnum(); // Function AnimationSharing.AnimationSharingStateProcessor.GetAnimationStateEnum
}; 
 
 


//Class AnimationSharing.AnimationSharingManager Size 152
// Inherited 40 bytes 
class UAnimationSharingManager : public UObject
{

 public: 
	struct TArray<struct USkeleton*> Skeletons;  // Offset: 40 Size: 16
	struct TArray<struct UAnimSharingInstance*> PerSkeletonData;  // Offset: 56 Size: 16
	char pad_72[80];  // Offset: 72 Size: 80



 // Functions 
 public:
	void RegisterActorWithSkeletonBP(struct AActor* InActor, struct USkeleton* SharingSkeleton); // Function AnimationSharing.AnimationSharingManager.RegisterActorWithSkeletonBP
	struct UAnimationSharingManager* GetAnimationSharingManager(struct UObject* WorldContextObject); // Function AnimationSharing.AnimationSharingManager.GetAnimationSharingManager
	bool CreateAnimationSharingManager(struct UObject* WorldContextObject, struct UAnimationSharingSetup* Setup); // Function AnimationSharing.AnimationSharingManager.CreateAnimationSharingManager
	bool AnimationSharingEnabled(); // Function AnimationSharing.AnimationSharingManager.AnimationSharingEnabled
}; 
 
 


