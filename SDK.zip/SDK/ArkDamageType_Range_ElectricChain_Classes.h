#pragma once 
#include <ArkDamageType_Range_ElectricChain_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkDamageType_Range_ElectricChain.ArkDamageType_Range_ElectricChain_C Size 264
// Inherited 264 bytes 
class UArkDamageType_Range_ElectricChain_C : public UArkDamageType_Range_C
{

 public: 



 // Functions 
 public:
}; 
 
 


