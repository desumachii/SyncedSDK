#pragma once 
#include <AmmoPickup762_Lite_Structs.h>
 
 
 
//BlueprintGeneratedClass AmmoPickup762_Lite.AmmoPickup762_Lite_C Size 2416
// Inherited 2416 bytes 
class AAmmoPickup762_Lite_C : public AAmmoPickupBase_C
{

 public: 



 // Functions 
 public:
}; 
 
 


