#pragma once 
#include <ArkDamageType_SR_Electric_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkDamageType_SR_Electric.ArkDamageType_SR_Electric_C Size 264
// Inherited 264 bytes 
class UArkDamageType_SR_Electric_C : public UArkDamageType_Range_C
{

 public: 



 // Functions 
 public:
}; 
 
 


