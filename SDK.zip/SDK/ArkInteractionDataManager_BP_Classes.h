#pragma once 
#include <ArkInteractionDataManager_BP_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkInteractionDataManager_BP.ArkInteractionDataManager_BP_C Size 344
// Inherited 344 bytes 
class UArkInteractionDataManager_BP_C : public UArkInteractionDataManager
{

 public: 



 // Functions 
 public:
}; 
 
 


