#pragma once 
#include <AmmoPickup45_Structs.h>
 
 
 
//BlueprintGeneratedClass AmmoPickup45.AmmoPickup45_C Size 2416
// Inherited 2416 bytes 
class AAmmoPickup45_C : public AAmmoPickupBase_C
{

 public: 



 // Functions 
 public:
}; 
 
 


