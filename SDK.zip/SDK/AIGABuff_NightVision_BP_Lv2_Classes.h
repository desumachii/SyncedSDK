#pragma once 
#include <AIGABuff_NightVision_BP_Lv2_Structs.h>
 
 
 
//BlueprintGeneratedClass AIGABuff_NightVision_BP_Lv2.AIGABuff_NightVision_BP_Lv2_C Size 1244
// Inherited 1244 bytes 
class UAIGABuff_NightVision_BP_Lv2_C : public UAIGABuff_NightVision_BP_C
{

 public: 



 // Functions 
 public:
}; 
 
 


