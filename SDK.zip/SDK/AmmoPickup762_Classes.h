#pragma once 
#include <AmmoPickup762_Structs.h>
 
 
 
//BlueprintGeneratedClass AmmoPickup762.AmmoPickup762_C Size 2416
// Inherited 2416 bytes 
class AAmmoPickup762_C : public AAmmoPickupBase_C
{

 public: 



 // Functions 
 public:
}; 
 
 


