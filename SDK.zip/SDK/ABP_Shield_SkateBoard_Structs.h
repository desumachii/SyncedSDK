#pragma once 
#include <SDK_Engine_Objects.h> 
 
 
//Function ABP_Shield_SkateBoard.ABP_Shield_SkateBoard_C.ExecuteUbergraph_ABP_Shield_SkateBoard Size 4
class FExecuteUbergraph_ABP_Shield_SkateBoard
{

 public: 
	int32_t EntryPoint;  // Offset: 0 Size: 4



 // Functions 
 public:
}; 
 
 //Function ABP_Shield_SkateBoard.ABP_Shield_SkateBoard_C.AnimGraph Size 16
class FAnimGraph
{

 public: 
	struct FPoseLink AnimGraph;  // Offset: 0 Size: 16



 // Functions 
 public:
}; 
 
 