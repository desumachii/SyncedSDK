#pragma once 
#include <ArkDamageType_KnockFlyingCrash_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkDamageType_KnockFlyingCrash.ArkDamageType_KnockFlyingCrash_C Size 264
// Inherited 264 bytes 
class UArkDamageType_KnockFlyingCrash_C : public UArkDamageType
{

 public: 



 // Functions 
 public:
}; 
 
 


