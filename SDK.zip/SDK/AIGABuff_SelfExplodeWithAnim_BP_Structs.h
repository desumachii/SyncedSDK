#pragma once 
#include <SDK_Engine_Objects.h> 
 
 
//Function AIGABuff_SelfExplodeWithAnim_BP.AIGABuff_SelfExplodeWithAnim_BP_C.ExecuteUbergraph_AIGABuff_SelfExplodeWithAnim_BP Size 145
class FExecuteUbergraph_AIGABuff_SelfExplodeWithAnim_BP
{

 public: 
	int32_t EntryPoint;  // Offset: 0 Size: 4
	char pad_4[4];  // Offset: 4 Size: 4
	struct AArkNpc* CallFunc_OwnerNpc_ReturnValue;  // Offset: 8 Size: 8
	int32_t Temp_int_Array_Index_Variable;  // Offset: 16 Size: 4
	char pad_20_1 : 7;  // Offset: 20 Size: 1
	bool CallFunc_IsValid_ReturnValue : 1;  // Offset: 20 Size: 1
	char pad_21[3];  // Offset: 21 Size: 3
	struct AArkPlayer* CallFunc_GetSyncOwner_ReturnValue;  // Offset: 24 Size: 8
	struct FName K2Node_Event_NotifyName;  // Offset: 32 Size: 8
	struct UAnimNotify* K2Node_Event_Notify;  // Offset: 40 Size: 8
	char pad_48_1 : 7;  // Offset: 48 Size: 1
	bool K2Node_SwitchName_CmpSuccess : 1;  // Offset: 48 Size: 1
	char pad_49[7];  // Offset: 49 Size: 7
	struct AArkNpc* CallFunc_OwnerNpc_ReturnValue_2;  // Offset: 56 Size: 8
	int32_t Temp_int_Loop_Counter_Variable;  // Offset: 64 Size: 4
	int32_t CallFunc_GetTeamID_ReturnValue;  // Offset: 68 Size: 4
	int32_t CallFunc_Add_IntInt_ReturnValue;  // Offset: 72 Size: 4
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // Offset: 76 Size: 12
	struct AArkNpc* CallFunc_OwnerNpc_ReturnValue_3;  // Offset: 88 Size: 8
	char pad_96_1 : 7;  // Offset: 96 Size: 1
	bool CallFunc_HasEquippedChip_ReturnValue : 1;  // Offset: 96 Size: 1
	char pad_97[3];  // Offset: 97 Size: 3
	struct FName CallFunc_MakeLiteralName_ReturnValue;  // Offset: 100 Size: 8
	char pad_108[4];  // Offset: 108 Size: 4
	struct TArray<struct AArkNpc*> CallFunc_SpawnAIAtRadiusWithPattern_ReturnValue;  // Offset: 112 Size: 16
	int32_t CallFunc_Array_Length_ReturnValue;  // Offset: 128 Size: 4
	char pad_132[4];  // Offset: 132 Size: 4
	struct AArkNpc* CallFunc_Array_Get_Item;  // Offset: 136 Size: 8
	char pad_144_1 : 7;  // Offset: 144 Size: 1
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // Offset: 144 Size: 1



 // Functions 
 public:
}; 
 
 //Function AIGABuff_SelfExplodeWithAnim_BP.AIGABuff_SelfExplodeWithAnim_BP_C.OnAnimNotify_BP Size 16
// Inherited 16 bytes 
class FOnAnimNotify_BP : public FOnAnimNotify_BP
{

 public: 
	struct FName NotifyName;  // Offset: 0 Size: 8
	struct UAnimNotify* Notify;  // Offset: 8 Size: 8



 // Functions 
 public:
}; 
 
 