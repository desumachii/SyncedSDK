#pragma once 
#include <ArkImpactEffect_GadgetBounce_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkImpactEffect_GadgetBounce.ArkImpactEffect_GadgetBounce_C Size 504
// Inherited 504 bytes 
class UArkImpactEffect_GadgetBounce_C : public UArkImpactEffect
{

 public: 



 // Functions 
 public:
}; 
 
 


