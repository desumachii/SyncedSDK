#pragma once 
#include <AIGABuff_DeathDetect_Structs.h>
 
 
 
//BlueprintGeneratedClass AIGABuff_DeathDetect.AIGABuff_DeathDetect_C Size 1224
// Inherited 1224 bytes 
class UAIGABuff_DeathDetect_C : public UArkAIGABuff_DeathDetect
{

 public: 



 // Functions 
 public:
}; 
 
 


