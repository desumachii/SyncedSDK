#pragma once 
#include <SDK_Engine_Objects.h> 
 
 
//Function AIGABuff_NightVision_BP.AIGABuff_NightVision_BP_C.ExecuteUbergraph_AIGABuff_NightVision_BP Size 40
class FExecuteUbergraph_AIGABuff_NightVision_BP
{

 public: 
	int32_t EntryPoint;  // Offset: 0 Size: 4
	char pad_4[4];  // Offset: 4 Size: 4
	struct AArkNpc* CallFunc_OwnerNpc_ReturnValue;  // Offset: 8 Size: 8
	struct AArkNpc* CallFunc_OwnerNpc_ReturnValue_2;  // Offset: 16 Size: 8
	struct UBlackboardComponent* CallFunc_GetBlackboard_ReturnValue;  // Offset: 24 Size: 8
	struct UBlackboardComponent* CallFunc_GetBlackboard_ReturnValue_2;  // Offset: 32 Size: 8



 // Functions 
 public:
}; 
 
 