#pragma once 
#include <ArkHavenRPCServer_BP_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkHavenRPCServer_BP.ArkHavenRPCServer_BP_C Size 1272
// Inherited 1272 bytes 
class UArkHavenRPCServer_BP_C : public UArkHavenRPCServer
{

 public: 



 // Functions 
 public:
	struct FString GetModuleName(); // Function ArkHavenRPCServer_BP.ArkHavenRPCServer_BP_C.GetModuleName
}; 
 
 


