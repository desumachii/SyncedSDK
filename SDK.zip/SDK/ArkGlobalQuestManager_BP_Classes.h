#pragma once 
#include <ArkGlobalQuestManager_BP_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkGlobalQuestManager_BP.ArkGlobalQuestManager_BP_C Size 728
// Inherited 728 bytes 
class UArkGlobalQuestManager_BP_C : public UArkGlobalQuestManager
{

 public: 



 // Functions 
 public:
}; 
 
 


