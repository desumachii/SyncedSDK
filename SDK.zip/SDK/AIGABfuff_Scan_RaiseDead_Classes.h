#pragma once 
#include <AIGABfuff_Scan_RaiseDead_Structs.h>
 
 
 
//BlueprintGeneratedClass AIGABfuff_Scan_RaiseDead.AIGABfuff_Scan_RaiseDead_C Size 1008
// Inherited 936 bytes 
class UAIGABfuff_Scan_RaiseDead_C : public UArkGameBuff_Element
{

 public: 
	struct FPointerToUberGraphFrame UberGraphFrame;  // Offset: 936 Size: 8
	struct UDecalComponent* Decal;  // Offset: 944 Size: 8
	struct TSoftObjectPtr<UMaterialInterface> NewVar_2;  // Offset: 952 Size: 40
	float Radius;  // Offset: 992 Size: 4
	char pad_996[4];  // Offset: 996 Size: 4
	struct UArkSoftParticleSystemComponentWithPool* ScanEffect;  // Offset: 1000 Size: 8



 // Functions 
 public:
	void C2BP_OnActive(); // Function AIGABfuff_Scan_RaiseDead.AIGABfuff_Scan_RaiseDead_C.C2BP_OnActive
	void C2BP_OnDeactive(); // Function AIGABfuff_Scan_RaiseDead.AIGABfuff_Scan_RaiseDead_C.C2BP_OnDeactive
	void OnPeriodForPlayer(struct AArkPlayer* Player); // Function AIGABfuff_Scan_RaiseDead.AIGABfuff_Scan_RaiseDead_C.OnPeriodForPlayer
	void C2BP_OnTick(float DeltaTime); // Function AIGABfuff_Scan_RaiseDead.AIGABfuff_Scan_RaiseDead_C.C2BP_OnTick
	void ExecuteUbergraph_AIGABfuff_Scan_RaiseDead(int32_t EntryPoint); // Function AIGABfuff_Scan_RaiseDead.AIGABfuff_Scan_RaiseDead_C.ExecuteUbergraph_AIGABfuff_Scan_RaiseDead
}; 
 
 


