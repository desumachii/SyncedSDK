#pragma once 
#include <AnimNotifyState_SuperJumpFlyingRotate_Structs.h>
 
 
 
//BlueprintGeneratedClass AnimNotifyState_SuperJumpFlyingRotate.AnimNotifyState_SuperJumpFlyingRotate_C Size 48
// Inherited 48 bytes 
class UAnimNotifyState_SuperJumpFlyingRotate_C : public UAnimNotifyState
{

 public: 



 // Functions 
 public:
	bool Received_NotifyBegin(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration); // Function AnimNotifyState_SuperJumpFlyingRotate.AnimNotifyState_SuperJumpFlyingRotate_C.Received_NotifyBegin
	bool Received_NotifyEnd(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function AnimNotifyState_SuperJumpFlyingRotate.AnimNotifyState_SuperJumpFlyingRotate_C.Received_NotifyEnd
}; 
 
 


