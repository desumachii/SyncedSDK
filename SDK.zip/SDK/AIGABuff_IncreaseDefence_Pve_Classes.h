#pragma once 
#include <AIGABuff_IncreaseDefence_Pve_Structs.h>
 
 
 
//BlueprintGeneratedClass AIGABuff_IncreaseDefence_Pve.AIGABuff_IncreaseDefence_Pve_C Size 1224
// Inherited 1224 bytes 
class UAIGABuff_IncreaseDefence_Pve_C : public UArkAIGameplayAbilityBuff
{

 public: 



 // Functions 
 public:
}; 
 
 


