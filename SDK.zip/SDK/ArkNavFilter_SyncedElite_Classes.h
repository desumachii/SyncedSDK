#pragma once 
#include <ArkNavFilter_SyncedElite_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkNavFilter_SyncedElite.ArkNavFilter_SyncedElite_C Size 152
// Inherited 152 bytes 
class UArkNavFilter_SyncedElite_C : public UArkNavFilter_Base
{

 public: 



 // Functions 
 public:
}; 
 
 


