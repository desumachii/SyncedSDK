#pragma once 
#include <ArkImpactEffect_NanoProj_Common_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkImpactEffect_NanoProj_Common.ArkImpactEffect_NanoProj_Common_C Size 504
// Inherited 504 bytes 
class UArkImpactEffect_NanoProj_Common_C : public UArkImpactEffect_RangeWeapon_C
{

 public: 



 // Functions 
 public:
}; 
 
 


