#pragma once 
#include <SDK_Engine_Objects.h> 
 
 
//Function AIGABfuff_Scan_RaiseDead.AIGABfuff_Scan_RaiseDead_C.ExecuteUbergraph_AIGABfuff_Scan_RaiseDead Size 505
class FExecuteUbergraph_AIGABfuff_Scan_RaiseDead
{

 public: 
	int32_t EntryPoint;  // Offset: 0 Size: 4
	char pad_4[4];  // Offset: 4 Size: 4
	struct AActor* CallFunc_GetOwner_ReturnValue;  // Offset: 8 Size: 8
	int32_t Temp_int_Array_Index_Variable;  // Offset: 16 Size: 4
	char pad_20[4];  // Offset: 20 Size: 4
	struct TArray<struct AArkCharacterBase*> K2Node_MakeArray_Array;  // Offset: 24 Size: 16
	struct AArkPlayer* K2Node_Event_Player;  // Offset: 40 Size: 8
	char pad_48_1 : 7;  // Offset: 48 Size: 1
	bool CallFunc_HasAuthority_ReturnValue : 1;  // Offset: 48 Size: 1
	char pad_49[7];  // Offset: 49 Size: 7
	struct AArkNpc* CallFunc_GetSyncedAI_ReturnValue;  // Offset: 56 Size: 8
	struct AArkPlayer* CallFunc_GetOwnerAsPlayer_ReturnValue;  // Offset: 64 Size: 8
	float K2Node_Event_DeltaTime;  // Offset: 72 Size: 4
	char pad_76[4];  // Offset: 76 Size: 4
	struct UArkSceneQueryUtility* CallFunc_Get_ReturnValue;  // Offset: 80 Size: 8
	struct AActor* CallFunc_GetOwner_ReturnValue_2;  // Offset: 88 Size: 8
	float CallFunc_DegCos_ReturnValue;  // Offset: 96 Size: 4
	struct FRotator CallFunc_K2_GetActorRotation_ReturnValue;  // Offset: 100 Size: 12
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // Offset: 112 Size: 12
	struct FVector CallFunc_Conv_RotatorToVector_ReturnValue;  // Offset: 124 Size: 12
	char pad_136_1 : 7;  // Offset: 136 Size: 1
	bool CallFunc_IsDedicatedServer_ReturnValue : 1;  // Offset: 136 Size: 1
	char pad_137_1 : 7;  // Offset: 137 Size: 1
	bool CallFunc_IsDedicatedServer_ReturnValue_2 : 1;  // Offset: 137 Size: 1
	char pad_138[6];  // Offset: 138 Size: 6
	struct AArkPlayer* CallFunc_GetOwnerAsPlayer_ReturnValue_2;  // Offset: 144 Size: 8
	struct FRotator CallFunc_K2_GetActorRotation_ReturnValue_2;  // Offset: 152 Size: 12
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // Offset: 164 Size: 12
	float CallFunc_BreakRotator_Roll;  // Offset: 176 Size: 4
	float CallFunc_BreakRotator_Pitch;  // Offset: 180 Size: 4
	float CallFunc_BreakRotator_Yaw;  // Offset: 184 Size: 4
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // Offset: 188 Size: 12
	struct UArkSoftParticleSystemComponentWithPool* CallFunc_SpawnSoftEmitterAttached_ReturnValue;  // Offset: 200 Size: 8
	int32_t Temp_int_Loop_Counter_Variable;  // Offset: 208 Size: 4
	char pad_212[4];  // Offset: 212 Size: 4
	struct TArray<struct AArkPickUp*> CallFunc_GetPickUpsInRange_ReturnValue;  // Offset: 216 Size: 16
	struct AArkPickUp* CallFunc_Array_Get_Item;  // Offset: 232 Size: 8
	int32_t CallFunc_Array_Length_ReturnValue;  // Offset: 240 Size: 4
	char pad_244[4];  // Offset: 244 Size: 4
	struct ABP_gravestone_C* K2Node_DynamicCast_AsBP_Grave_Stone;  // Offset: 248 Size: 8
	char pad_256_1 : 7;  // Offset: 256 Size: 1
	bool K2Node_DynamicCast_bSuccess : 1;  // Offset: 256 Size: 1
	char pad_257_1 : 7;  // Offset: 257 Size: 1
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // Offset: 257 Size: 1
	char pad_258[6];  // Offset: 258 Size: 6
	struct AActor* CallFunc_GetOwner_ReturnValue_3;  // Offset: 264 Size: 8
	char pad_272_1 : 7;  // Offset: 272 Size: 1
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // Offset: 272 Size: 1
	char pad_273_1 : 7;  // Offset: 273 Size: 1
	bool CallFunc_IsValid_ReturnValue : 1;  // Offset: 273 Size: 1
	char pad_274_1 : 7;  // Offset: 274 Size: 1
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // Offset: 274 Size: 1
	char pad_275[1];  // Offset: 275 Size: 1
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_3;  // Offset: 276 Size: 12
	char pad_288_1 : 7;  // Offset: 288 Size: 1
	bool CallFunc_BooleanOR_ReturnValue : 1;  // Offset: 288 Size: 1
	char pad_289[3];  // Offset: 289 Size: 3
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // Offset: 292 Size: 12
	int32_t CallFunc_Add_IntInt_ReturnValue;  // Offset: 304 Size: 4
	float CallFunc_Vector_CosineAngle2D_ReturnValue;  // Offset: 308 Size: 4
	char pad_312_1 : 7;  // Offset: 312 Size: 1
	bool CallFunc_Greater_FloatFloat_ReturnValue : 1;  // Offset: 312 Size: 1
	char pad_313_1 : 7;  // Offset: 313 Size: 1
	bool CallFunc_BooleanAND_ReturnValue : 1;  // Offset: 313 Size: 1
	char pad_314_1 : 7;  // Offset: 314 Size: 1
	bool CallFunc_IsDedicatedServer_ReturnValue_3 : 1;  // Offset: 314 Size: 1
	char pad_315[5];  // Offset: 315 Size: 5
	struct AArkPlayer* CallFunc_GetOwnerAsPlayer_ReturnValue_3;  // Offset: 320 Size: 8
	float CallFunc_CurrentControlYaw_ReturnValue;  // Offset: 328 Size: 4
	char pad_332_1 : 7;  // Offset: 332 Size: 1
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // Offset: 332 Size: 1
	char pad_333[3];  // Offset: 333 Size: 3
	struct FRotator CallFunc_MakeRotator_ReturnValue_2;  // Offset: 336 Size: 12
	struct FHitResult CallFunc_K2_SetWorldRotation_SweepHitResult;  // Offset: 348 Size: 136
	struct FVector CallFunc_MakeVector_ReturnValue;  // Offset: 484 Size: 12
	struct UArkSoftDecalComponentWithPool* CallFunc_SpawnSoftDecalAtLocation_ReturnValue;  // Offset: 496 Size: 8
	char pad_504_1 : 7;  // Offset: 504 Size: 1
	bool CallFunc_K2_AttachToComponent_ReturnValue : 1;  // Offset: 504 Size: 1



 // Functions 
 public:
}; 
 
 //Function AIGABfuff_Scan_RaiseDead.AIGABfuff_Scan_RaiseDead_C.C2BP_OnTick Size 4
// Inherited 4 bytes 
class FC2BP_OnTick : public FC2BP_OnTick
{

 public: 
	float DeltaTime;  // Offset: 0 Size: 4



 // Functions 
 public:
}; 
 
 //Function AIGABfuff_Scan_RaiseDead.AIGABfuff_Scan_RaiseDead_C.OnPeriodForPlayer Size 8
// Inherited 8 bytes 
class FOnPeriodForPlayer : public FOnPeriodForPlayer
{

 public: 
	struct AArkPlayer* Player;  // Offset: 0 Size: 8



 // Functions 
 public:
}; 
 
 