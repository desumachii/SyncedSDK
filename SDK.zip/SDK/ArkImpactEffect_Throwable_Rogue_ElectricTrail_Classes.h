#pragma once 
#include <ArkImpactEffect_Throwable_Rogue_ElectricTrail_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkImpactEffect_Throwable_Rogue_ElectricTrail.ArkImpactEffect_Throwable_Rogue_ElectricTrail_C Size 504
// Inherited 504 bytes 
class UArkImpactEffect_Throwable_Rogue_ElectricTrail_C : public UArkImpactEffect
{

 public: 



 // Functions 
 public:
}; 
 
 


