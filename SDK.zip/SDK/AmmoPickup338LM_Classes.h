#pragma once 
#include <AmmoPickup338LM_Structs.h>
 
 
 
//BlueprintGeneratedClass AmmoPickup338LM.AmmoPickup338LM_C Size 2416
// Inherited 2416 bytes 
class AAmmoPickup338LM_C : public AAmmoPickupBase_C
{

 public: 



 // Functions 
 public:
}; 
 
 


