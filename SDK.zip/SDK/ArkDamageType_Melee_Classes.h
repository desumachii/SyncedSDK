#pragma once 
#include <ArkDamageType_Melee_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkDamageType_Melee.ArkDamageType_Melee_C Size 264
// Inherited 264 bytes 
class UArkDamageType_Melee_C : public UArkDamageTypeMelee
{

 public: 



 // Functions 
 public:
}; 
 
 


