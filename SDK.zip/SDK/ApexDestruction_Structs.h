#pragma once 
#include <SDK_Engine_Objects.h> 
 
 
//DelegateFunction ApexDestruction.ActorFractureSignature__DelegateSignature Size 24
class FActorFractureSignature__DelegateSignature
{

 public: 
	struct FVector HitPoint;  // Offset: 0 Size: 12
	struct FVector HitDirection;  // Offset: 12 Size: 12



 // Functions 
 public:
}; 
 
 //DelegateFunction ApexDestruction.ComponentFractureSignature__DelegateSignature Size 24
class FComponentFractureSignature__DelegateSignature
{

 public: 
	struct FVector HitPoint;  // Offset: 0 Size: 12
	struct FVector HitDirection;  // Offset: 12 Size: 12



 // Functions 
 public:
}; 
 
 //ScriptStruct ApexDestruction.DestructibleComponentInstanceData Size 256
// Inherited 240 bytes 
class FDestructibleComponentInstanceData : public FPrimitiveComponentInstanceData
{

 public: 
	int32_t UID;  // Offset: 240 Size: 4
	char pad_244[12];  // Offset: 244 Size: 12



 // Functions 
 public:
}; 
 
 //Function ApexDestruction.DestructibleComponent.GetDestructibleMesh Size 8
class FGetDestructibleMesh
{

 public: 
	struct UDestructibleMesh* ReturnValue;  // Offset: 0 Size: 8



 // Functions 
 public:
}; 
 
 //ScriptStruct ApexDestruction.DestructibleChunkParameters Size 4
class FDestructibleChunkParameters
{

 public: 
	char pad_0_1 : 7;  // Offset: 0 Size: 1
	bool bIsSupportChunk : 1;  // Offset: 0 Size: 1
	char pad_1_1 : 7;  // Offset: 1 Size: 1
	bool bDoNotFracture : 1;  // Offset: 1 Size: 1
	char pad_2_1 : 7;  // Offset: 2 Size: 1
	bool bDoNotDamage : 1;  // Offset: 2 Size: 1
	char pad_3_1 : 7;  // Offset: 3 Size: 1
	bool bDoNotCrumble : 1;  // Offset: 3 Size: 1



 // Functions 
 public:
}; 
 
 //ScriptStruct ApexDestruction.DestructibleDamageParameters Size 28
class FDestructibleDamageParameters
{

 public: 
	float DamageThreshold;  // Offset: 0 Size: 4
	float DamageSpread;  // Offset: 4 Size: 4
	char pad_8_1 : 7;  // Offset: 8 Size: 1
	bool bEnableImpactDamage : 1;  // Offset: 8 Size: 1
	char pad_9[3];  // Offset: 9 Size: 3
	float ImpactDamage;  // Offset: 12 Size: 4
	int32_t DefaultImpactDamageDepth;  // Offset: 16 Size: 4
	char pad_20_1 : 7;  // Offset: 20 Size: 1
	bool bCustomImpactResistance : 1;  // Offset: 20 Size: 1
	char pad_21[3];  // Offset: 21 Size: 3
	float ImpactResistance;  // Offset: 24 Size: 4



 // Functions 
 public:
}; 
 
 //ScriptStruct ApexDestruction.FractureMaterial Size 36
class FFractureMaterial
{

 public: 
	struct FVector2D UVScale;  // Offset: 0 Size: 8
	struct FVector2D UVOffset;  // Offset: 8 Size: 8
	struct FVector Tangent;  // Offset: 16 Size: 12
	float UAngle;  // Offset: 28 Size: 4
	int32_t InteriorElementIndex;  // Offset: 32 Size: 4



 // Functions 
 public:
}; 
 
 //ScriptStruct ApexDestruction.DestructibleParameters Size 136
class FDestructibleParameters
{

 public: 
	struct FDestructibleDamageParameters DamageParameters;  // Offset: 0 Size: 28
	struct FDestructibleDebrisParameters DebrisParameters;  // Offset: 28 Size: 44
	struct FDestructibleAdvancedParameters AdvancedParameters;  // Offset: 72 Size: 16
	struct FDestructibleSpecialHierarchyDepths SpecialHierarchyDepths;  // Offset: 88 Size: 20
	char pad_108[4];  // Offset: 108 Size: 4
	struct TArray<struct FDestructibleDepthParameters> DepthParameters;  // Offset: 112 Size: 16
	struct FDestructibleParametersFlag Flags;  // Offset: 128 Size: 4
	char pad_132[4];  // Offset: 132 Size: 4



 // Functions 
 public:
}; 
 
 //ScriptStruct ApexDestruction.DestructibleParametersFlag Size 4
class FDestructibleParametersFlag
{

 public: 
	char bAccumulateDamage : 1;  // Offset: 0 Size: 1
	char bAssetDefinedSupport : 1;  // Offset: 0 Size: 1
	char bWorldSupport : 1;  // Offset: 0 Size: 1
	char bDebrisTimeout : 1;  // Offset: 0 Size: 1
	char bDebrisMaxSeparation : 1;  // Offset: 0 Size: 1
	char bCrumbleSmallestChunks : 1;  // Offset: 0 Size: 1
	char bAccurateRaycasts : 1;  // Offset: 0 Size: 1
	char bUseValidBounds : 1;  // Offset: 0 Size: 1
	char bFormExtendedStructures : 1;  // Offset: 1 Size: 1
	char pad_1_1 : 7;  // Offset: 1 Size: 1
	char pad_2[3];  // Offset: 2 Size: 3



 // Functions 
 public:
}; 
 
 //ScriptStruct ApexDestruction.DestructibleDepthParameters Size 1
class FDestructibleDepthParameters
{

 public: 
	enum class EImpactDamageOverride ImpactDamageOverride;  // Offset: 0 Size: 1



 // Functions 
 public:
}; 
 
 //ScriptStruct ApexDestruction.DestructibleSpecialHierarchyDepths Size 20
class FDestructibleSpecialHierarchyDepths
{

 public: 
	int32_t SupportDepth;  // Offset: 0 Size: 4
	int32_t MinimumFractureDepth;  // Offset: 4 Size: 4
	char pad_8_1 : 7;  // Offset: 8 Size: 1
	bool bEnableDebris : 1;  // Offset: 8 Size: 1
	char pad_9[3];  // Offset: 9 Size: 3
	int32_t DebrisDepth;  // Offset: 12 Size: 4
	int32_t EssentialDepth;  // Offset: 16 Size: 4



 // Functions 
 public:
}; 
 
 //ScriptStruct ApexDestruction.DestructibleAdvancedParameters Size 16
class FDestructibleAdvancedParameters
{

 public: 
	float DamageCap;  // Offset: 0 Size: 4
	float ImpactVelocityThreshold;  // Offset: 4 Size: 4
	float MaxChunkSpeed;  // Offset: 8 Size: 4
	float FractureImpulseScale;  // Offset: 12 Size: 4



 // Functions 
 public:
}; 
 
 //ScriptStruct ApexDestruction.DestructibleDebrisParameters Size 44
class FDestructibleDebrisParameters
{

 public: 
	float DebrisLifetimeMin;  // Offset: 0 Size: 4
	float DebrisLifetimeMax;  // Offset: 4 Size: 4
	float DebrisMaxSeparationMin;  // Offset: 8 Size: 4
	float DebrisMaxSeparationMax;  // Offset: 12 Size: 4
	struct FBox ValidBounds;  // Offset: 16 Size: 28



 // Functions 
 public:
}; 
 
 //Function ApexDestruction.DestructibleComponent.ApplyDamage Size 32
class FApplyDamage
{

 public: 
	float DamageAmount;  // Offset: 0 Size: 4
	struct FVector HitLocation;  // Offset: 4 Size: 12
	struct FVector ImpulseDir;  // Offset: 16 Size: 12
	float ImpulseStrength;  // Offset: 28 Size: 4



 // Functions 
 public:
}; 
 
 //Function ApexDestruction.DestructibleComponent.ApplyRadiusDamage Size 28
class FApplyRadiusDamage
{

 public: 
	float BaseDamage;  // Offset: 0 Size: 4
	struct FVector HurtOrigin;  // Offset: 4 Size: 12
	float DamageRadius;  // Offset: 16 Size: 4
	float ImpulseStrength;  // Offset: 20 Size: 4
	char pad_24_1 : 7;  // Offset: 24 Size: 1
	bool bFullDamage : 1;  // Offset: 24 Size: 1
	char pad_25[3];  // Offset: 25 Size: 3



 // Functions 
 public:
}; 
 
 //Function ApexDestruction.DestructibleComponent.SetDestructibleMesh Size 8
class FSetDestructibleMesh
{

 public: 
	struct UDestructibleMesh* NewMesh;  // Offset: 0 Size: 8



 // Functions 
 public:
}; 
 
 