#pragma once 
#include <ArkDamageType_Detector_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkDamageType_Detector.ArkDamageType_Detector_C Size 264
// Inherited 264 bytes 
class UArkDamageType_Detector_C : public UArkDamageType_Range_C
{

 public: 



 // Functions 
 public:
}; 
 
 


