#pragma once 
#include <SDK_Engine_Objects.h> 
 
 
//Function ArkPlayerCameraMgr_BP.ArkPlayerCameraMgr_BP_C.ExecuteUbergraph_ArkPlayerCameraMgr_BP Size 32
class FExecuteUbergraph_ArkPlayerCameraMgr_BP
{

 public: 
	int32_t EntryPoint;  // Offset: 0 Size: 4
	enum class ECharacterState CallFunc_GetCharacterState_ReturnValue;  // Offset: 4 Size: 1
	char pad_5_1 : 7;  // Offset: 5 Size: 1
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // Offset: 5 Size: 1
	char pad_6_1 : 7;  // Offset: 6 Size: 1
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_2 : 1;  // Offset: 6 Size: 1
	char pad_7[1];  // Offset: 7 Size: 1
	float K2Node_Event_Duration;  // Offset: 8 Size: 4
	char pad_12_1 : 7;  // Offset: 12 Size: 1
	bool CallFunc_BooleanOR_ReturnValue : 1;  // Offset: 12 Size: 1
	char pad_13[3];  // Offset: 13 Size: 3
	struct FString CallFunc_Conv_FloatToString_ReturnValue;  // Offset: 16 Size: 16



 // Functions 
 public:
}; 
 
 //Function ArkPlayerCameraMgr_BP.ArkPlayerCameraMgr_BP_C.PlayBlindingEffect Size 4
// Inherited 4 bytes 
class FPlayBlindingEffect : public FPlayBlindingEffect
{

 public: 
	float Duration;  // Offset: 0 Size: 4



 // Functions 
 public:
}; 
 
 