#pragma once 
#include <ArkDamageType_LMG_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkDamageType_LMG.ArkDamageType_LMG_C Size 264
// Inherited 264 bytes 
class UArkDamageType_LMG_C : public UArkDamageType_Range_C
{

 public: 



 // Functions 
 public:
}; 
 
 


