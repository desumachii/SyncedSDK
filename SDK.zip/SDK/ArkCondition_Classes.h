#pragma once 
#include <ArkCondition_Structs.h>
 
 
 
//Class ArkCondition.ArkSubConditionManager Size 200
// Inherited 200 bytes 
class UArkSubConditionManager : public UArkConditionManager
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkCondition.ArkCondition_BuffStack Size 64
// Inherited 40 bytes 
class UArkCondition_BuffStack : public UArkCondition
{

 public: 
	UArkGameBuff* BuffClass;  // Offset: 40 Size: 8
	int32_t BuffID;  // Offset: 48 Size: 4
	enum class EBuffCondition_Op Op;  // Offset: 52 Size: 1
	char pad_53[3];  // Offset: 53 Size: 3
	float Value;  // Offset: 56 Size: 4
	char pad_60[4];  // Offset: 60 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkCondition.ArkCondition_CharTagInclude Size 48
// Inherited 40 bytes 
class UArkCondition_CharTagInclude : public UArkCondition
{

 public: 
	struct FName Tag;  // Offset: 40 Size: 8



 // Functions 
 public:
}; 
 
 


//Class ArkCondition.ArkCondition_ScopeType Size 48
// Inherited 40 bytes 
class UArkCondition_ScopeType : public UArkCondition
{

 public: 
	char pad_40[8];  // Offset: 40 Size: 8



 // Functions 
 public:
}; 
 
 


//Class ArkCondition.ArkCondition_PlayerStateExclude Size 48
// Inherited 40 bytes 
class UArkCondition_PlayerStateExclude : public UArkCondition
{

 public: 
	enum class EPlayerActionState State;  // Offset: 40 Size: 1
	char pad_41[7];  // Offset: 41 Size: 7



 // Functions 
 public:
}; 
 
 


//Class ArkCondition.ArkCondition_CharTagExclude Size 48
// Inherited 40 bytes 
class UArkCondition_CharTagExclude : public UArkCondition
{

 public: 
	struct FName Tag;  // Offset: 40 Size: 8



 // Functions 
 public:
}; 
 
 


//Class ArkCondition.ArkCondition_PlayerState Size 48
// Inherited 40 bytes 
class UArkCondition_PlayerState : public UArkCondition
{

 public: 
	enum class EPlayerActionState State;  // Offset: 40 Size: 1
	enum class EArkGameBuff_BoolParam Empty;  // Offset: 41 Size: 1
	char pad_42[6];  // Offset: 42 Size: 6



 // Functions 
 public:
}; 
 
 


//Class ArkCondition.ArkCondition_WeaponAmmo Size 48
// Inherited 40 bytes 
class UArkCondition_WeaponAmmo : public UArkCondition
{

 public: 
	enum class EBuffCondition_Op Op;  // Offset: 40 Size: 1
	char pad_41[3];  // Offset: 41 Size: 3
	float Value;  // Offset: 44 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkCondition.ArkCondition_NanoPossessing Size 40
// Inherited 40 bytes 
class UArkCondition_NanoPossessing : public UArkCondition
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkCondition.ArkCondition_PlayerHP Size 48
// Inherited 40 bytes 
class UArkCondition_PlayerHP : public UArkCondition
{

 public: 
	float LtPercent;  // Offset: 40 Size: 4
	float LtAbsolute;  // Offset: 44 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkCondition.ArkCondition_SyncShieldFly Size 40
// Inherited 40 bytes 
class UArkCondition_SyncShieldFly : public UArkCondition
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkCondition.ArkCondition_WeaponEquip Size 56
// Inherited 40 bytes 
class UArkCondition_WeaponEquip : public UArkCondition
{

 public: 
	struct TArray<enum class EWeaponDetailType> DetailType;  // Offset: 40 Size: 16



 // Functions 
 public:
}; 
 
 


