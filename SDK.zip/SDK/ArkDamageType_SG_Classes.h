#pragma once 
#include <ArkDamageType_SG_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkDamageType_SG.ArkDamageType_SG_C Size 264
// Inherited 264 bytes 
class UArkDamageType_SG_C : public UArkDamageType_Range_C
{

 public: 



 // Functions 
 public:
}; 
 
 


