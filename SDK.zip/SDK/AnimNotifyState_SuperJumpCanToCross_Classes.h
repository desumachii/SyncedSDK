#pragma once 
#include <AnimNotifyState_SuperJumpCanToCross_Structs.h>
 
 
 
//BlueprintGeneratedClass AnimNotifyState_SuperJumpCanToCross.AnimNotifyState_SuperJumpCanToCross_C Size 49
// Inherited 48 bytes 
class UAnimNotifyState_SuperJumpCanToCross_C : public UAnimNotifyState
{

 public: 
	char pad_48_1 : 7;  // Offset: 48 Size: 1
	bool ForceEnd : 1;  // Offset: 48 Size: 1



 // Functions 
 public:
	bool Received_NotifyEnd(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function AnimNotifyState_SuperJumpCanToCross.AnimNotifyState_SuperJumpCanToCross_C.Received_NotifyEnd
	bool Received_NotifyBegin(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration); // Function AnimNotifyState_SuperJumpCanToCross.AnimNotifyState_SuperJumpCanToCross_C.Received_NotifyBegin
}; 
 
 


