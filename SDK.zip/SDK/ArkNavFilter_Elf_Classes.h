#pragma once 
#include <ArkNavFilter_Elf_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkNavFilter_Elf.ArkNavFilter_Elf_C Size 152
// Inherited 152 bytes 
class UArkNavFilter_Elf_C : public UArkNavFilter_Base
{

 public: 



 // Functions 
 public:
}; 
 
 


