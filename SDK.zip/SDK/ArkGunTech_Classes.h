#pragma once 
#include <ArkGunTech_Structs.h>
 
 
 
//Class ArkGunTech.ArkGunTech_Equalizer Size 1568
// Inherited 1568 bytes 
class UArkGunTech_Equalizer : public UArkGunTechBase
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkGunTech.ArkBlackHole Size 1160
// Inherited 744 bytes 
class AArkBlackHole : public AActor
{

 public: 
	char pad_744[32];  // Offset: 744 Size: 32
	float BlackHoleLifeTimeSec;  // Offset: 776 Size: 4
	float DamageIntervalSec;  // Offset: 780 Size: 4
	float UpdateTargetsIntervalSec;  // Offset: 784 Size: 4
	float BlackHoleRadius;  // Offset: 788 Size: 4
	struct FArkAIDamageConfig DamageConfig;  // Offset: 792 Size: 64
	float BlackHoleDamageMultiplier;  // Offset: 856 Size: 4
	char pad_860_1 : 7;  // Offset: 860 Size: 1
	bool bDragNpcs : 1;  // Offset: 860 Size: 1
	char pad_861[3];  // Offset: 861 Size: 3
	float BlackHoleDragLerpParam;  // Offset: 864 Size: 4
	char pad_868_1 : 7;  // Offset: 868 Size: 1
	bool bExplodeWhenEnd : 1;  // Offset: 868 Size: 1
	char pad_869[3];  // Offset: 869 Size: 3
	struct TSoftObjectPtr<UParticleSystem> ExplodeParticleTemplate;  // Offset: 872 Size: 40
	struct TSoftObjectPtr<UAkAudioEvent> ExplodeSound;  // Offset: 912 Size: 40
	float ExplodeDamageMultiplier;  // Offset: 952 Size: 4
	char pad_956[4];  // Offset: 956 Size: 4
	struct AArkRangeWeapon* OwnerWeapon;  // Offset: 960 Size: 8
	struct AArkCharacterBase* OwnerPlayer;  // Offset: 968 Size: 8
	struct TArray<struct AActor*> TargetActors;  // Offset: 976 Size: 16
	float BlackHoleDamage_Npc;  // Offset: 992 Size: 4
	float BlackHoleDamage_SyncAI;  // Offset: 996 Size: 4
	float BlackHoleDamage_Player;  // Offset: 1000 Size: 4
	float tempDamageSec;  // Offset: 1004 Size: 4
	float tempUpdateTargetsSec;  // Offset: 1008 Size: 4
	float tempLifeTimeSec;  // Offset: 1012 Size: 4
	char pad_1016_1 : 7;  // Offset: 1016 Size: 1
	bool bIsParamSet : 1;  // Offset: 1016 Size: 1
	char pad_1017[3];  // Offset: 1017 Size: 3
	int32_t CachePackedFireAmmoInfo;  // Offset: 1020 Size: 4
	struct FHitResult HitResult;  // Offset: 1024 Size: 136



 // Functions 
 public:
	void UpdateTargets(); // Function ArkGunTech.ArkBlackHole.UpdateTargets
	void PlayHitEffect(struct FHitResult Hit, struct AArkRangeWeapon* InWeapon); // Function ArkGunTech.ArkBlackHole.PlayHitEffect
	void PlayExplodeEffect(); // Function ArkGunTech.ArkBlackHole.PlayExplodeEffect
	void BlackHoleInit(struct FHitResult& Hit, int32_t HitFireID, struct AArkRangeWeapon* Weapon); // Function ArkGunTech.ArkBlackHole.BlackHoleInit
}; 
 
 


//Class ArkGunTech.ArkGunTech_BulletSplit Size 1624
// Inherited 1568 bytes 
class UArkGunTech_BulletSplit : public UArkGunTechBase
{

 public: 
	char MaxSplitTimes;  // Offset: 1568 Size: 1
	char pad_1569[3];  // Offset: 1569 Size: 3
	float SplitHalfAngleYaw;  // Offset: 1572 Size: 4
	float SplitDamageDecreasePercent;  // Offset: 1576 Size: 4
	char pad_1580[4];  // Offset: 1580 Size: 4
	struct TSoftObjectPtr<UParticleSystem> SplitParticleTemplate;  // Offset: 1584 Size: 40



 // Functions 
 public:
	void DoBulletSplit(struct FVector ShootDir, struct FVector Origin, int32_t FireID, struct FVector InitialLoc, char SplitTimes, struct TArray<struct AActor*> IgnoreActors); // Function ArkGunTech.ArkGunTech_BulletSplit.DoBulletSplit
	void ApplySplitDamage(struct AActor* DamagedActor, struct FHitResult Hit, int32_t HitFireID, struct FVector InitialLoc, struct FVector SpeedDir, char SplitTimes, struct TArray<struct AActor*> IgnoreActors); // Function ArkGunTech.ArkGunTech_BulletSplit.ApplySplitDamage
}; 
 
 


//Class ArkGunTech.ArkGunTech_Bubble Size 1568
// Inherited 1568 bytes 
class UArkGunTech_Bubble : public UArkGunTechBase
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkGunTech.ArkProjectile_Spikes Size 2040
// Inherited 1872 bytes 
class AArkProjectile_Spikes : public AArkProjectileBulletSimulate
{

 public: 
	struct UArkSoftStaticMeshComponent* BulletMesh;  // Offset: 1872 Size: 8
	float LifeTime;  // Offset: 1880 Size: 4
	float ReboundSpeed;  // Offset: 1884 Size: 4
	float ReboundScale_Character;  // Offset: 1888 Size: 4
	float ReboundScale_Static;  // Offset: 1892 Size: 4
	float BackingSpeed;  // Offset: 1896 Size: 4
	int32_t MaxSpikesInWorld;  // Offset: 1900 Size: 4
	float MinFallingSec;  // Offset: 1904 Size: 4
	float MaxFallingSec;  // Offset: 1908 Size: 4
	char pad_1912_1 : 7;  // Offset: 1912 Size: 1
	bool ReboundDisableGravity : 1;  // Offset: 1912 Size: 1
	char pad_1913[7];  // Offset: 1913 Size: 7
	struct TSoftObjectPtr<UAkAudioEvent> FlyBackSound;  // Offset: 1920 Size: 40
	enum class E_SpikesState CurrState;  // Offset: 1960 Size: 1
	char pad_1961[3];  // Offset: 1961 Size: 3
	uint32_t SpikesID;  // Offset: 1964 Size: 4
	char pad_1968_1 : 7;  // Offset: 1968 Size: 1
	bool bIsSpinning : 1;  // Offset: 1968 Size: 1
	char pad_1969[15];  // Offset: 1969 Size: 15
	struct UArkSoftParticleSystemComponent* SpinParticleComp;  // Offset: 1984 Size: 8
	struct TArray<struct AArkNpc*> SpinnedNpcs;  // Offset: 1992 Size: 16
	struct AArkPlayer* Player;  // Offset: 2008 Size: 8
	struct UBoxComponent* BoxComp;  // Offset: 2016 Size: 8
	float SpinDamageInterval;  // Offset: 2024 Size: 4
	float SpinDamageMultiplier;  // Offset: 2028 Size: 4
	float tempTickSec;  // Offset: 2032 Size: 4
	int32_t CachePackedFireAmmoInfo;  // Offset: 2036 Size: 4



 // Functions 
 public:
	void PlayFlyBackSound(struct AArkRangeWeapon* Weapon); // Function ArkGunTech.ArkProjectile_Spikes.PlayFlyBackSound
	void OnRangeWeaponReloaded(struct AArkRangeWeapon* Weapon); // Function ArkGunTech.ArkProjectile_Spikes.OnRangeWeaponReloaded
}; 
 
 


//Class ArkGunTech.ArkGunTech_PosionLauncher Size 1616
// Inherited 1568 bytes 
class UArkGunTech_PosionLauncher : public UArkGunTechBase
{

 public: 
	float SpawnOffset_HitNormal;  // Offset: 1568 Size: 4
	char pad_1572[4];  // Offset: 1572 Size: 4
	struct TSoftObjectPtr<UAkAudioEvent> AkHitSound;  // Offset: 1576 Size: 40



 // Functions 
 public:
	void PlayHitSound(struct FVector_NetQuantize ImpactPoint); // Function ArkGunTech.ArkGunTech_PosionLauncher.PlayHitSound
}; 
 
 


//Class ArkGunTech.ArkGunTech_DeepBreath Size 1632
// Inherited 1568 bytes 
class UArkGunTech_DeepBreath : public UArkGunTechBase
{

 public: 
	float RecoverInterval;  // Offset: 1568 Size: 4
	float RecoverPercentage;  // Offset: 1572 Size: 4
	float RecoverHUDTipsDuration;  // Offset: 1576 Size: 4
	char pad_1580[4];  // Offset: 1580 Size: 4
	struct TSoftObjectPtr<UAkAudioEvent> MagazineFullSound;  // Offset: 1584 Size: 40
	char pad_1624[8];  // Offset: 1624 Size: 8



 // Functions 
 public:
	void CallMagzineFullHUDTips(struct AArkRangeWeapon* Weapon, float Duration); // Function ArkGunTech.ArkGunTech_DeepBreath.CallMagzineFullHUDTips
}; 
 
 


//Class ArkGunTech.ArkPlasmaBall Size 1032
// Inherited 744 bytes 
class AArkPlasmaBall : public AActor
{

 public: 
	float PlasmaBallLifeTimeSec;  // Offset: 744 Size: 4
	float DamageIntervalSec;  // Offset: 748 Size: 4
	float UpdateTargetsIntervalSec;  // Offset: 752 Size: 4
	float PlasmaBallRadius;  // Offset: 756 Size: 4
	struct FArkAIDamageConfig DamageConfig;  // Offset: 760 Size: 64
	float PlasmaBallDamageMultiplier;  // Offset: 824 Size: 4
	char pad_828[4];  // Offset: 828 Size: 4
	struct AArkRangeWeapon* OwnerWeapon;  // Offset: 832 Size: 8
	struct AArkCharacterBase* OwnerPlayer;  // Offset: 840 Size: 8
	struct TArray<struct AActor*> TargetActors;  // Offset: 848 Size: 16
	float PlasmaBallDamage_Npc;  // Offset: 864 Size: 4
	float PlasmaBallDamage_SyncAI;  // Offset: 868 Size: 4
	float PlasmaBallDamage_Player;  // Offset: 872 Size: 4
	float tempDamageSec;  // Offset: 876 Size: 4
	float tempUpdateTargetsSec;  // Offset: 880 Size: 4
	float tempLifeTimeSec;  // Offset: 884 Size: 4
	char pad_888_1 : 7;  // Offset: 888 Size: 1
	bool bIsParamSet : 1;  // Offset: 888 Size: 1
	char pad_889[3];  // Offset: 889 Size: 3
	int32_t CachePackedFireAmmoInfo;  // Offset: 892 Size: 4
	struct FHitResult HitResult;  // Offset: 896 Size: 136



 // Functions 
 public:
	void UpdateTargets(); // Function ArkGunTech.ArkPlasmaBall.UpdateTargets
	void PlayHitEffect(struct FHitResult Hit, struct AArkRangeWeapon* InWeapon); // Function ArkGunTech.ArkPlasmaBall.PlayHitEffect
	void PlasmaBallInit(struct FHitResult& Hit, int32_t HitFireID, struct AArkRangeWeapon* Weapon); // Function ArkGunTech.ArkPlasmaBall.PlasmaBallInit
}; 
 
 


//Class ArkGunTech.ArkGunTech_AutoAiming Size 1776
// Inherited 1568 bytes 
class UArkGunTech_AutoAiming : public UArkGunTechBase
{

 public: 
	struct AArkPlayer* m_OwnerPlayer;  // Offset: 1568 Size: 8
	struct AArkPlayerControllerBattle* m_OwnerPC;  // Offset: 1576 Size: 8
	struct TArray<struct AArkNpc*> ArkNPCArray;  // Offset: 1584 Size: 16
	struct TArray<struct AArkCharacterBase*> ArkCharacterArray;  // Offset: 1600 Size: 16
	char pad_1616[124];  // Offset: 1616 Size: 124
	struct FName SwarmSocketToAim;  // Offset: 1740 Size: 8
	float MaxTraceDistance;  // Offset: 1748 Size: 4
	float MinTraceDistance;  // Offset: 1752 Size: 4
	float TargetFindingRadius;  // Offset: 1756 Size: 4
	char pad_1760_1 : 7;  // Offset: 1760 Size: 1
	bool bEnableAutoAimingWhenADS : 1;  // Offset: 1760 Size: 1
	char pad_1761[3];  // Offset: 1761 Size: 3
	struct FVector2D BaseViewportSize;  // Offset: 1764 Size: 8
	char pad_1772[4];  // Offset: 1772 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkGunTech.ArkGunTech_BlackHole Size 1656
// Inherited 1568 bytes 
class UArkGunTech_BlackHole : public UArkGunTechBase
{

 public: 
	float SpawnOffset_HitNormal;  // Offset: 1568 Size: 4
	char pad_1572[4];  // Offset: 1572 Size: 4
	struct TSoftObjectPtr<UParticleSystem> BlackHoleParticleTemplate;  // Offset: 1576 Size: 40
	struct TSoftObjectPtr<UAkAudioEvent> AkBlackHoleSound;  // Offset: 1616 Size: 40



 // Functions 
 public:
	void ClientOnBlackHoleSpawn(struct FTransform SpawnTrans); // Function ArkGunTech.ArkGunTech_BlackHole.ClientOnBlackHoleSpawn
}; 
 
 


//Class ArkGunTech.ArkGunTech_DoubleDown Size 1576
// Inherited 1568 bytes 
class UArkGunTech_DoubleDown : public UArkGunTechBase
{

 public: 
	float DoubleDownCD;  // Offset: 1568 Size: 4
	char pad_1572[4];  // Offset: 1572 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkGunTech.ArkGunTechUpdateBuffEffect Size 1688
// Inherited 1568 bytes 
class UArkGunTechUpdateBuffEffect : public UArkGunTechBase
{

 public: 
	float CurrentFiringTime;  // Offset: 1568 Size: 4
	float CurrentNotFiringTime;  // Offset: 1572 Size: 4
	float NotFiringTimeTolerance;  // Offset: 1576 Size: 4
	char pad_1580_1 : 7;  // Offset: 1580 Size: 1
	bool bUseFireRateCurve : 1;  // Offset: 1580 Size: 1
	char pad_1581[3];  // Offset: 1581 Size: 3
	struct UCurveFloat* FireRateCurve;  // Offset: 1584 Size: 8
	char pad_1592_1 : 7;  // Offset: 1592 Size: 1
	bool bUseRecoilPitchCurve : 1;  // Offset: 1592 Size: 1
	char pad_1593[7];  // Offset: 1593 Size: 7
	struct UCurveFloat* RecoilPitchCurve;  // Offset: 1600 Size: 8
	char pad_1608_1 : 7;  // Offset: 1608 Size: 1
	bool bUseRecoilYawCurve : 1;  // Offset: 1608 Size: 1
	char pad_1609[7];  // Offset: 1609 Size: 7
	struct UCurveFloat* RecoilYawCurve;  // Offset: 1616 Size: 8
	char pad_1624_1 : 7;  // Offset: 1624 Size: 1
	bool bUseBulletSpreadCurve : 1;  // Offset: 1624 Size: 1
	char pad_1625[7];  // Offset: 1625 Size: 7
	struct UCurveFloat* BulletSpreadCurve;  // Offset: 1632 Size: 8
	char pad_1640_1 : 7;  // Offset: 1640 Size: 1
	bool bUseDamageCurve : 1;  // Offset: 1640 Size: 1
	char pad_1641[7];  // Offset: 1641 Size: 7
	struct UCurveFloat* DamageCurve;  // Offset: 1648 Size: 8
	char pad_1656_1 : 7;  // Offset: 1656 Size: 1
	bool bUseCriticalDamageCurve : 1;  // Offset: 1656 Size: 1
	char pad_1657[7];  // Offset: 1657 Size: 7
	struct UCurveFloat* CriticalDamageCurve;  // Offset: 1664 Size: 8
	char pad_1672_1 : 7;  // Offset: 1672 Size: 1
	bool bUseMoveSpeedCurve : 1;  // Offset: 1672 Size: 1
	char pad_1673[7];  // Offset: 1673 Size: 7
	struct UCurveFloat* MoveSpeedCurve;  // Offset: 1680 Size: 8



 // Functions 
 public:
}; 
 
 


//Class ArkGunTech.ArkGunTech_FirePluse Size 1912
// Inherited 1688 bytes 
class UArkGunTech_FirePluse : public UArkGunTechUpdateBuffEffect
{

 public: 
	struct UCurveFloat* BulletSizeCurve;  // Offset: 1688 Size: 8
	struct UCurveFloat* BulletColorCurve;  // Offset: 1696 Size: 8
	float EnergyIncreasePerSecond;  // Offset: 1704 Size: 4
	float EnergyDecreasePerSecond;  // Offset: 1708 Size: 4
	float OverloadEnergy;  // Offset: 1712 Size: 4
	float MaxEnergy;  // Offset: 1716 Size: 4
	char pad_1720_1 : 7;  // Offset: 1720 Size: 1
	bool bExplodeOnContinuousHit : 1;  // Offset: 1720 Size: 1
	char ExplodeHitTimes;  // Offset: 1721 Size: 1
	char ClearHitTimesSecond;  // Offset: 1722 Size: 1
	char ExplodeDamageMultiplier;  // Offset: 1723 Size: 1
	char pad_1724[4];  // Offset: 1724 Size: 4
	struct TSoftObjectPtr<UParticleSystem> ExplodeParticleTemplate;  // Offset: 1728 Size: 40
	struct TSoftObjectPtr<UAkAudioEvent> AkExplodeSound;  // Offset: 1768 Size: 40
	char pad_1808_1 : 7;  // Offset: 1808 Size: 1
	bool RecoverAmmoWhenKill : 1;  // Offset: 1808 Size: 1
	char pad_1809[3];  // Offset: 1809 Size: 3
	float RecoverPercentage;  // Offset: 1812 Size: 4
	AArkGunTechAmmoFlyEffect* RecoverFlyEffect;  // Offset: 1816 Size: 8
	struct TMap<struct AArkCharacterBase*, struct FArkGunTechFirePlusHitInfo> HitCharacterMap;  // Offset: 1824 Size: 80
	char pad_1904[8];  // Offset: 1904 Size: 8



 // Functions 
 public:
	void ClientSpawnExplodeEffect(struct FTransform SpawnTrans); // Function ArkGunTech.ArkGunTech_FirePluse.ClientSpawnExplodeEffect
	void ClientSpawnDrawAmmoEffect(struct FVector spawnLoc); // Function ArkGunTech.ArkGunTech_FirePluse.ClientSpawnDrawAmmoEffect
}; 
 
 


//Class ArkGunTech.ArkGunTech_FireRocket Size 1808
// Inherited 1776 bytes 
class UArkGunTech_FireRocket : public UArkGunTech_AutoAiming
{

 public: 
	float ExplodeDamageMultiplier;  // Offset: 1776 Size: 4
	float ExplodeRange;  // Offset: 1780 Size: 4
	AArkProjectile_FireRocket* FireRocketClass;  // Offset: 1784 Size: 8
	float RocketFlyingSpeed;  // Offset: 1792 Size: 4
	float RocketLifeSpan;  // Offset: 1796 Size: 4
	int32_t ShootIntervalForFireRocket;  // Offset: 1800 Size: 4
	char pad_1804[4];  // Offset: 1804 Size: 4



 // Functions 
 public:
	void SimulatedSpawnBullet(struct FVector ShootDir, struct FVector Origin, int32_t FireID); // Function ArkGunTech.ArkGunTech_FireRocket.SimulatedSpawnBullet
	void CallServerNotifySpawnBullet(struct FVector ShootDir, struct FVector Origin, int32_t FireID); // Function ArkGunTech.ArkGunTech_FireRocket.CallServerNotifySpawnBullet
}; 
 
 


//Class ArkGunTech.ArkGunTech_GrenadeLauncher Size 1584
// Inherited 1568 bytes 
class UArkGunTech_GrenadeLauncher : public UArkGunTechBase
{

 public: 
	UDamageType* ExplodeDamageType;  // Offset: 1568 Size: 8
	float ExplodeRange;  // Offset: 1576 Size: 4
	float ExplodeDamageMultiplier;  // Offset: 1580 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkGunTech.ArkProjectile_FireRocket Size 1928
// Inherited 1872 bytes 
class AArkProjectile_FireRocket : public AArkProjectileBulletSimulate
{

 public: 
	struct FVector ExplodeEmitterScale;  // Offset: 1872 Size: 12
	char pad_1884[4];  // Offset: 1884 Size: 4
	struct TSoftObjectPtr<UParticleSystem> ParticleTemplate;  // Offset: 1888 Size: 40



 // Functions 
 public:
}; 
 
 


//Class ArkGunTech.ArkGunTech_Homeward Size 1632
// Inherited 1568 bytes 
class UArkGunTech_Homeward : public UArkGunTechBase
{

 public: 
	struct TArray<int32_t> PendingFireIDList;  // Offset: 1568 Size: 16
	float AddBulletTime;  // Offset: 1584 Size: 4
	char pad_1588[4];  // Offset: 1588 Size: 4
	struct TSoftObjectPtr<UAkAudioEvent> BackToMagazineSound;  // Offset: 1592 Size: 40



 // Functions 
 public:
	void PlayBackToMagazineSound(); // Function ArkGunTech.ArkGunTech_Homeward.PlayBackToMagazineSound
	void InternalHandleAfterFire(int32_t FireID); // Function ArkGunTech.ArkGunTech_Homeward.InternalHandleAfterFire
}; 
 
 


//Class ArkGunTech.ArkGunTech_HummingBird Size 1568
// Inherited 1568 bytes 
class UArkGunTech_HummingBird : public UArkGunTechBase
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkGunTech.ArkProjectile_Shockwave Size 2008
// Inherited 1872 bytes 
class AArkProjectile_Shockwave : public AArkProjectileBulletSimulate
{

 public: 
	float LifeTime;  // Offset: 1872 Size: 4
	float MaxFlyDistance;  // Offset: 1876 Size: 4
	int32_t MaxPenetrateNum;  // Offset: 1880 Size: 4
	char pad_1884_1 : 7;  // Offset: 1884 Size: 1
	bool bIsAdditionalWave : 1;  // Offset: 1884 Size: 1
	char pad_1885[3];  // Offset: 1885 Size: 3
	struct FVector SpawnPosition;  // Offset: 1888 Size: 12
	char pad_1900[4];  // Offset: 1900 Size: 4
	struct TArray<struct AActor*> TracedSwarms;  // Offset: 1904 Size: 16
	struct FVector InitScale;  // Offset: 1920 Size: 12
	float MaxSizeDistance;  // Offset: 1932 Size: 4
	struct TArray<struct AActor*> TracedObstacles;  // Offset: 1936 Size: 16
	int32_t tempPenetrateNum;  // Offset: 1952 Size: 4
	char pad_1956[4];  // Offset: 1956 Size: 4
	struct TSoftObjectPtr<UParticleSystem> FadeOutParticleTemplate;  // Offset: 1960 Size: 40
	struct UCapsuleComponent* WaveHitBox;  // Offset: 2000 Size: 8



 // Functions 
 public:
}; 
 
 


//Class ArkGunTech.ArkGunTech_SoundWave Size 2104
// Inherited 1568 bytes 
class UArkGunTech_SoundWave : public UArkGunTechBase
{

 public: 
	char pad_1568[8];  // Offset: 1568 Size: 8
	struct UDataTable* MusicBeatConfigTable;  // Offset: 1576 Size: 8
	char BeatGroupID;  // Offset: 1584 Size: 1
	char pad_1585[3];  // Offset: 1585 Size: 3
	float BeatEarlierSpawnTime;  // Offset: 1588 Size: 4
	float ToleranceSecond;  // Offset: 1592 Size: 4
	char pad_1596[4];  // Offset: 1596 Size: 4
	struct TMap<char, float> LevelToLeastScore;  // Offset: 1600 Size: 80
	char LeastLevel_MusicPhase1;  // Offset: 1680 Size: 1
	char LeastLevel_MusicPhase2;  // Offset: 1681 Size: 1
	char LeastLevel_MusicPhase3;  // Offset: 1682 Size: 1
	char pad_1683[1];  // Offset: 1683 Size: 1
	float ScoreDecreasePerSecond;  // Offset: 1684 Size: 4
	float MaxScore;  // Offset: 1688 Size: 4
	char pad_1692[4];  // Offset: 1692 Size: 4
	struct UAkAudioEvent* AkEvent_StartMusic;  // Offset: 1696 Size: 8
	struct UAkAudioEvent* AkEvent_EndMusic;  // Offset: 1704 Size: 8
	struct UAkAudioEvent* AkEvent_Lv1;  // Offset: 1712 Size: 8
	struct UAkAudioEvent* AkEvent_Lv2;  // Offset: 1720 Size: 8
	struct UAkAudioEvent* AkEvent_Lv3;  // Offset: 1728 Size: 8
	float MusicLoopLength;  // Offset: 1736 Size: 4
	char pad_1740[4];  // Offset: 1740 Size: 4
	struct TMap<char, int32_t> LevelToBuffID;  // Offset: 1744 Size: 80
	AArkProjectileBulletBase* OnBeat_Projectile;  // Offset: 1824 Size: 8
	struct UAnimMontage* OnBeat_ReloadAnim;  // Offset: 1832 Size: 8
	struct UAnimMontage* OnBeat_ReloadAnimFpp;  // Offset: 1840 Size: 8
	struct UAnimMontage* OnBeat_RollAnim;  // Offset: 1848 Size: 8
	struct TMap<enum class EArkTriggerBeatType, bool> TriggeredBeatType;  // Offset: 1856 Size: 80
	struct TMap<int32_t, struct FArkGunTechMusicBeatConfig> BeatMap;  // Offset: 1936 Size: 80
	struct FArkGunTechMusicBeatConfig NextBeat;  // Offset: 2016 Size: 32
	struct FArkGunTechMusicBeatConfig NextShowingBeat;  // Offset: 2048 Size: 32
	char pad_2080[16];  // Offset: 2080 Size: 16
	struct UArkGunTechCrosshair_SoundWave* CurrentCrosshair;  // Offset: 2096 Size: 8



 // Functions 
 public:
	void TryTriggerBeat(enum class EArkTriggerBeatType Type); // Function ArkGunTech.ArkGunTech_SoundWave.TryTriggerBeat
	void StartMusicTimer(enum class EAkCallbackType CallbackType, struct UAkCallbackInfo* CallbackInfo); // Function ArkGunTech.ArkGunTech_SoundWave.StartMusicTimer
	void StartMusic(); // Function ArkGunTech.ArkGunTech_SoundWave.StartMusic
	void SimulatedSpawnBullet(struct FVector ShootDir, struct FVector Origin, int32_t FireID); // Function ArkGunTech.ArkGunTech_SoundWave.SimulatedSpawnBullet
	void Server_SetTriggeredType(enum class EArkTriggerBeatType Type, bool bAdd); // Function ArkGunTech.ArkGunTech_SoundWave.Server_SetTriggeredType
	void NetMulticast_SetTriggeredType(enum class EArkTriggerBeatType Type, bool bAdd); // Function ArkGunTech.ArkGunTech_SoundWave.NetMulticast_SetTriggeredType
	void LoadBeatTable(); // Function ArkGunTech.ArkGunTech_SoundWave.LoadBeatTable
	void EndMusic(); // Function ArkGunTech.ArkGunTech_SoundWave.EndMusic
	void ChangeLevel(char inLevel); // Function ArkGunTech.ArkGunTech_SoundWave.ChangeLevel
	void CallServerNotifySpawnBullet(struct FVector ShootDir, struct FVector Origin, int32_t FireID); // Function ArkGunTech.ArkGunTech_SoundWave.CallServerNotifySpawnBullet
}; 
 
 


//Class ArkGunTech.ArkGunTech_LaserChain Size 1656
// Inherited 1568 bytes 
class UArkGunTech_LaserChain : public UArkGunTechBase
{

 public: 
	UArkGameBuff* BuffOnHit;  // Offset: 1568 Size: 8
	char pad_1576[80];  // Offset: 1576 Size: 80



 // Functions 
 public:
	void ServerSpawnLaserChainEffect(struct FVector StartPoint, struct FVector TargetPoint, bool bIsMainChain); // Function ArkGunTech.ArkGunTech_LaserChain.ServerSpawnLaserChainEffect
	void ClientSpawnLaserChainEffect(struct FVector StartPoint, struct FVector TargetPoint, bool bIsMainChain); // Function ArkGunTech.ArkGunTech_LaserChain.ClientSpawnLaserChainEffect
}; 
 
 


//Class ArkGunTech.ArkGunTech_Partner Size 1576
// Inherited 1568 bytes 
class UArkGunTech_Partner : public UArkGunTechBase
{

 public: 
	float RecoverPercentage;  // Offset: 1568 Size: 4
	char pad_1572[4];  // Offset: 1572 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkGunTech.ArkGunTech_PlasmaBall Size 1568
// Inherited 1568 bytes 
class UArkGunTech_PlasmaBall : public UArkGunTechBase
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkGunTech.ArkGunTechAmmoFlyEffect Size 1040
// Inherited 1040 bytes 
class AArkGunTechAmmoFlyEffect : public AArkScoreFlyEffect
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkGunTech.ArkGunTech_Quintet Size 1576
// Inherited 1568 bytes 
class UArkGunTech_Quintet : public UArkGunTechBase
{

 public: 
	char pad_1568_1 : 7;  // Offset: 1568 Size: 1
	bool bContinueFiringWhenReleased : 1;  // Offset: 1568 Size: 1
	char pad_1569[7];  // Offset: 1569 Size: 7



 // Functions 
 public:
}; 
 
 


//Class ArkGunTech.ArkGunTech_ReboundSplit Size 1600
// Inherited 1568 bytes 
class UArkGunTech_ReboundSplit : public UArkGunTechBase
{

 public: 
	float SplitDamageDecreasePercent;  // Offset: 1568 Size: 4
	float PenetrateDamageDecreasePercent;  // Offset: 1572 Size: 4
	float SplitBulletHalfAngle_HitCharacter;  // Offset: 1576 Size: 4
	float SplitBulletHalfAngle_HitObstacle;  // Offset: 1580 Size: 4
	char SplitBulletNum;  // Offset: 1584 Size: 1
	char pad_1585[3];  // Offset: 1585 Size: 3
	float ReboundAnglePercent;  // Offset: 1588 Size: 4
	float BulletSpeedAfterSplit;  // Offset: 1592 Size: 4
	char pad_1596[4];  // Offset: 1596 Size: 4



 // Functions 
 public:
	void SimulatedDoBulletSplit(struct FVector Velocity, struct FVector HitPoint, struct FVector HitNormal, int32_t FireID, struct FVector InitialLoc, bool bIsHitCharacter, struct AActor* hitActor); // Function ArkGunTech.ArkGunTech_ReboundSplit.SimulatedDoBulletSplit
	void ServerDoBulletSplit(struct FVector Velocity, struct FVector HitPoint, struct FVector HitNormal, int32_t FireID, struct FVector InitialLoc, bool bIsHitCharacter, struct AActor* hitActor); // Function ArkGunTech.ArkGunTech_ReboundSplit.ServerDoBulletSplit
	void ApplyPenetrateDamage(struct AActor* DamagedActor, struct FHitResult Hit, int32_t HitFireID, struct FVector InitialLoc, struct FVector SpeedDir, bool bIsSplit, char HitTimes); // Function ArkGunTech.ArkGunTech_ReboundSplit.ApplyPenetrateDamage
}; 
 
 


//Class ArkGunTech.ArkGunTech_Slicer Size 1592
// Inherited 1568 bytes 
class UArkGunTech_Slicer : public UArkGunTechBase
{

 public: 
	float PenetrateDamageDecreasePercent;  // Offset: 1568 Size: 4
	char pad_1572_1 : 7;  // Offset: 1572 Size: 1
	bool bShootAdditionalWave : 1;  // Offset: 1572 Size: 1
	char pad_1573[3];  // Offset: 1573 Size: 3
	AArkProjectileBulletBase* AdditionalWaveBulletClass;  // Offset: 1576 Size: 8
	float AdditionalWaveDamageMultiplier;  // Offset: 1584 Size: 4
	char pad_1588[4];  // Offset: 1588 Size: 4



 // Functions 
 public:
	void SimulatedSpawnBullet(struct FVector ShootDir, struct FVector Origin, int32_t FireID); // Function ArkGunTech.ArkGunTech_Slicer.SimulatedSpawnBullet
	void CallServerNotifySpawnBullet(struct FVector ShootDir, struct FVector Origin, int32_t FireID); // Function ArkGunTech.ArkGunTech_Slicer.CallServerNotifySpawnBullet
	void ApplyPenetrateDamage(struct AActor* DamagedActor, struct FHitResult Hit, int32_t HitFireID, int32_t HitTimes, bool bIsAdditionalWave); // Function ArkGunTech.ArkGunTech_Slicer.ApplyPenetrateDamage
}; 
 
 


//Class ArkGunTech.ArkGunTech_TripleShoot Size 1584
// Inherited 1568 bytes 
class UArkGunTech_TripleShoot : public UArkGunTechBase
{

 public: 
	AArkProjectileBulletBase* AdditionalBulletClass;  // Offset: 1568 Size: 8
	float MinSpreadHalfAngleYaw;  // Offset: 1576 Size: 4
	char FireIntervalToShootAddtionalBullet;  // Offset: 1580 Size: 1
	char pad_1581[3];  // Offset: 1581 Size: 3



 // Functions 
 public:
	void SimulatedSpawnBullet(struct FVector ShootDir, float ConeHalfAngleYaw, struct FVector Origin, int32_t FireID); // Function ArkGunTech.ArkGunTech_TripleShoot.SimulatedSpawnBullet
	void CallServerNotifySpawnBullet(struct FVector ShootDir, float ConeHalfAngleYaw, struct FVector Origin, int32_t FireID); // Function ArkGunTech.ArkGunTech_TripleShoot.CallServerNotifySpawnBullet
}; 
 
 


//Class ArkGunTech.ArkProjectile_BlackHole Size 1872
// Inherited 1872 bytes 
class AArkProjectile_BlackHole : public AArkProjectileBulletSimulate
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkGunTech.ArkGunTechCrosshair_FirePluse Size 776
// Inherited 768 bytes 
class UArkGunTechCrosshair_FirePluse : public UArkUserWidgetBase
{

 public: 
	float MaxEnergy;  // Offset: 768 Size: 4
	char pad_772[4];  // Offset: 772 Size: 4



 // Functions 
 public:
	void SetEnergy(float inEnergy); // Function ArkGunTech.ArkGunTechCrosshair_FirePluse.SetEnergy
}; 
 
 


//Class ArkGunTech.ArkProjectile_Split Size 1896
// Inherited 1872 bytes 
class AArkProjectile_Split : public AArkProjectileBulletSimulate
{

 public: 
	char CurrentSplitTimes;  // Offset: 1872 Size: 1
	char pad_1873[7];  // Offset: 1873 Size: 7
	struct TArray<struct AActor*> DamagedActors;  // Offset: 1880 Size: 16



 // Functions 
 public:
	void SetSplitTimes(char Num); // Function ArkGunTech.ArkProjectile_Split.SetSplitTimes
	void AddIgnoreActor(struct AActor* Actor); // Function ArkGunTech.ArkProjectile_Split.AddIgnoreActor
}; 
 
 


//Class ArkGunTech.ArkGunTechCrosshair_SoundWave Size 808
// Inherited 768 bytes 
class UArkGunTechCrosshair_SoundWave : public UArkUserWidgetBase
{

 public: 
	UArkUserWidgetBase* BeatClass;  // Offset: 768 Size: 8
	struct TArray<struct UArkUserWidgetBase*> BeatPool;  // Offset: 776 Size: 16
	struct TArray<struct UArkUserWidgetBase*> CurrentBeatQueue;  // Offset: 792 Size: 16



 // Functions 
 public:
	void SpawnBeat(float Offset); // Function ArkGunTech.ArkGunTechCrosshair_SoundWave.SpawnBeat
	void SetCurrentScore(char Level, float Percent); // Function ArkGunTech.ArkGunTechCrosshair_SoundWave.SetCurrentScore
	void ReturnBeatToPool(struct UArkUserWidgetBase* beat); // Function ArkGunTech.ArkGunTechCrosshair_SoundWave.ReturnBeatToPool
	void HideBeat(bool bIsTriggered); // Function ArkGunTech.ArkGunTechCrosshair_SoundWave.HideBeat
	struct UArkUserWidgetBase* GetBeatFromPool(); // Function ArkGunTech.ArkGunTechCrosshair_SoundWave.GetBeatFromPool
}; 
 
 


//Class ArkGunTech.ArkProjectile_PosionLauncher Size 1872
// Inherited 1872 bytes 
class AArkProjectile_PosionLauncher : public AArkProjectileBulletSimulate
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkGunTech.ArkGunTechSpikes Size 1672
// Inherited 1584 bytes 
class UArkGunTechSpikes : public UArkGunTech_TripleShoot
{

 public: 
	float BackWardDamageMultiplier;  // Offset: 1584 Size: 4
	float PenetrateDamageDecreasePercent;  // Offset: 1588 Size: 4
	struct TSet<int32_t> BackingBulletIDList;  // Offset: 1592 Size: 80



 // Functions 
 public:
	void SetBackingBullet(int32_t BulletID, bool bIsBacking); // Function ArkGunTech.ArkGunTechSpikes.SetBackingBullet
	void ApplySpinDamage(struct FVector BoxExtent, struct FTransform BoxTransform, float DamageMultiplier, int32_t PackedFireAmmoInfo); // Function ArkGunTech.ArkGunTechSpikes.ApplySpinDamage
	void ApplyPenetrateDamage(struct AActor* DamagedActor, struct FHitResult Hit, int32_t HitFireID, int32_t HitTimes); // Function ArkGunTech.ArkGunTechSpikes.ApplyPenetrateDamage
	void ApplyBackWardDamage(struct AActor* DamagedActor, struct FHitResult Hit, int32_t HitFireID); // Function ArkGunTech.ArkGunTechSpikes.ApplyBackWardDamage
}; 
 
 


//Class ArkGunTech.ArkPosionLauncher Size 864
// Inherited 744 bytes 
class AArkPosionLauncher : public AActor
{

 public: 
	char pad_744[32];  // Offset: 744 Size: 32
	struct UBoxComponent* boxCollider;  // Offset: 776 Size: 8
	char pad_784[8];  // Offset: 784 Size: 8
	struct TArray<struct AArkCharacterBase*> CharactersInRange;  // Offset: 792 Size: 16
	float LifeTime;  // Offset: 808 Size: 4
	int32_t EffectBuffID;  // Offset: 812 Size: 4
	struct UArkSoftParticleSystemComponent* PosionParticle;  // Offset: 816 Size: 8
	struct TSoftObjectPtr<UAkAudioEvent> LauncherSound;  // Offset: 824 Size: 40



 // Functions 
 public:
}; 
 
 


//Class ArkGunTech.ArkProjectile_Bubble Size 1896
// Inherited 1872 bytes 
class AArkProjectile_Bubble : public AArkProjectileBulletSimulate
{

 public: 
	struct UCurveFloat* ForwardSpeedCurve;  // Offset: 1872 Size: 8
	struct UCurveFloat* VerticalSpeedCurve;  // Offset: 1880 Size: 8
	float MaxVerticalSpeed;  // Offset: 1888 Size: 4
	char pad_1892[4];  // Offset: 1892 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkGunTech.ArkProjectile_FirePluse Size 1880
// Inherited 1872 bytes 
class AArkProjectile_FirePluse : public AArkProjectileBulletSimulate
{

 public: 
	struct FName ColorParameterName;  // Offset: 1872 Size: 8



 // Functions 
 public:
}; 
 
 


//Class ArkGunTech.ArkProjectile_GrenadeLauncher Size 1928
// Inherited 1872 bytes 
class AArkProjectile_GrenadeLauncher : public AArkProjectileBulletSimulate
{

 public: 
	struct FVector ExplodeEmitterScale;  // Offset: 1872 Size: 12
	char pad_1884[4];  // Offset: 1884 Size: 4
	struct TSoftObjectPtr<UParticleSystem> ParticleTemplate;  // Offset: 1888 Size: 40



 // Functions 
 public:
}; 
 
 


//Class ArkGunTech.ArkProjectile_Kunai Size 2000
// Inherited 1872 bytes 
class AArkProjectile_Kunai : public AArkProjectileBulletSimulate
{

 public: 
	struct UArkSoftStaticMeshComponent* BulletMesh;  // Offset: 1872 Size: 8
	float LifeTime;  // Offset: 1880 Size: 4
	char pad_1884[4];  // Offset: 1884 Size: 4
	float BackingSpeed;  // Offset: 1888 Size: 4
	int32_t MaxSpikesInWorld;  // Offset: 1892 Size: 4
	float MaxFlyingSec;  // Offset: 1896 Size: 4
	char pad_1900[4];  // Offset: 1900 Size: 4
	struct TSoftObjectPtr<UAkAudioEvent> FlyBackSound;  // Offset: 1904 Size: 40
	enum class E_SpikesState CurrState;  // Offset: 1944 Size: 1
	char pad_1945[3];  // Offset: 1945 Size: 3
	uint32_t SpikesID;  // Offset: 1948 Size: 4
	char pad_1952[8];  // Offset: 1952 Size: 8
	struct UArkSoftParticleSystemComponent* SpinParticleComp;  // Offset: 1960 Size: 8
	struct TArray<struct AActor*> DamagedActors;  // Offset: 1968 Size: 16
	int32_t MaxPenetrateNum;  // Offset: 1984 Size: 4
	int32_t tempPenetrateNum;  // Offset: 1988 Size: 4
	struct AArkPlayer* OwnerPlayer;  // Offset: 1992 Size: 8



 // Functions 
 public:
	void PlayFlyBackSound(struct AArkRangeWeapon* Weapon); // Function ArkGunTech.ArkProjectile_Kunai.PlayFlyBackSound
}; 
 
 


//Class ArkGunTech.ArkProjectile_LaserChain Size 2344
// Inherited 1872 bytes 
class AArkProjectile_LaserChain : public AArkProjectileBulletSimulate
{

 public: 
	float ChainJumpRange;  // Offset: 1872 Size: 4
	int32_t MaxChainJumpNum;  // Offset: 1876 Size: 4
	struct FName ChainTargetSocket;  // Offset: 1880 Size: 8
	float LaserChainJumpIntervalSec;  // Offset: 1888 Size: 4
	char pad_1892_1 : 7;  // Offset: 1892 Size: 1
	bool bCastAdditionalLaserChain : 1;  // Offset: 1892 Size: 1
	char pad_1893[3];  // Offset: 1893 Size: 3
	struct FName LaserChainFxTargetParam;  // Offset: 1896 Size: 8
	struct TSoftObjectPtr<UParticleSystem> LaserChainFx;  // Offset: 1904 Size: 40
	struct TSoftObjectPtr<UParticleSystem> AdditionalLaserChainFx;  // Offset: 1944 Size: 40
	char pad_1984[24];  // Offset: 1984 Size: 24
	struct AArkCharacterBase* LastHitChar;  // Offset: 2008 Size: 8
	char pad_2016[16];  // Offset: 2016 Size: 16
	struct FArkLaserChainInfo MainLaserChainInfo;  // Offset: 2032 Size: 152
	struct FArkLaserChainInfo AdditionalLaserChainInfo;  // Offset: 2184 Size: 152
	char pad_2336_1 : 7;  // Offset: 2336 Size: 1
	bool bCastedChain : 1;  // Offset: 2336 Size: 1
	char pad_2337[7];  // Offset: 2337 Size: 7



 // Functions 
 public:
}; 
 
 


//Class ArkGunTech.ArkProjectile_PlasmaBall Size 1872
// Inherited 1872 bytes 
class AArkProjectile_PlasmaBall : public AArkProjectileBulletSimulate
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkGunTech.ArkProjectile_Rebound Size 1912
// Inherited 1872 bytes 
class AArkProjectile_Rebound : public AArkProjectileBulletSimulate
{

 public: 
	int32_t MaxReboundCount;  // Offset: 1872 Size: 4
	float LifeTime;  // Offset: 1876 Size: 4
	char pad_1880_1 : 7;  // Offset: 1880 Size: 1
	bool bOverrideBulletSpeedAfterFirstHit : 1;  // Offset: 1880 Size: 1
	char pad_1881[3];  // Offset: 1881 Size: 3
	float BulletSpeedAfterFirstHit;  // Offset: 1884 Size: 4
	char pad_1888[8];  // Offset: 1888 Size: 8
	struct TArray<struct AActor*> DamagedActors;  // Offset: 1896 Size: 16



 // Functions 
 public:
}; 
 
 


//Class ArkGunTech.ArkProjectile_ReboundSplit Size 1912
// Inherited 1872 bytes 
class AArkProjectile_ReboundSplit : public AArkProjectileBulletSimulate
{

 public: 
	char MaxPenetrateNum;  // Offset: 1872 Size: 1
	char pad_1873[3];  // Offset: 1873 Size: 3
	float LifeTime;  // Offset: 1876 Size: 4
	char pad_1880_1 : 7;  // Offset: 1880 Size: 1
	bool bCanReboundAfterSplit : 1;  // Offset: 1880 Size: 1
	char MaxReboundCount;  // Offset: 1881 Size: 1
	char pad_1882_1 : 7;  // Offset: 1882 Size: 1
	bool bIsSplit : 1;  // Offset: 1882 Size: 1
	char pad_1883[5];  // Offset: 1883 Size: 5
	struct TArray<struct AActor*> DamagedActors;  // Offset: 1888 Size: 16
	char tempPenetrateNum;  // Offset: 1904 Size: 1
	char CurrReboundCount;  // Offset: 1905 Size: 1
	char pad_1906[6];  // Offset: 1906 Size: 6



 // Functions 
 public:
}; 
 
 


//Class ArkGunTech.ArkProjectile_SpinningLeaf Size 2024
// Inherited 1872 bytes 
class AArkProjectile_SpinningLeaf : public AArkProjectileBulletSimulate
{

 public: 
	struct UArkSoftStaticMeshComponent* BulletMesh;  // Offset: 1872 Size: 8
	float LifeTime;  // Offset: 1880 Size: 4
	float BackingSpeed;  // Offset: 1884 Size: 4
	int32_t MaxSpikesInWorld;  // Offset: 1888 Size: 4
	float MaxFlyingSec;  // Offset: 1892 Size: 4
	struct TSoftObjectPtr<UAkAudioEvent> FlyBackSound;  // Offset: 1896 Size: 40
	enum class E_SpikesState CurrState;  // Offset: 1936 Size: 1
	char pad_1937[3];  // Offset: 1937 Size: 3
	uint32_t SpikesID;  // Offset: 1940 Size: 4
	char pad_1944_1 : 7;  // Offset: 1944 Size: 1
	bool bIsSpinning : 1;  // Offset: 1944 Size: 1
	char pad_1945[15];  // Offset: 1945 Size: 15
	struct UArkSoftParticleSystemComponent* SpinParticleComp;  // Offset: 1960 Size: 8
	struct TArray<struct AArkNpc*> SpinnedNpcs;  // Offset: 1968 Size: 16
	struct AArkPlayer* Player;  // Offset: 1984 Size: 8
	struct UBoxComponent* BoxComp;  // Offset: 1992 Size: 8
	float SpinDamageInterval;  // Offset: 2000 Size: 4
	float SpinDamageMultiplier;  // Offset: 2004 Size: 4
	char pad_2008_1 : 7;  // Offset: 2008 Size: 1
	bool bHasShootDamage : 1;  // Offset: 2008 Size: 1
	char pad_2009[3];  // Offset: 2009 Size: 3
	float tempTickSec;  // Offset: 2012 Size: 4
	int32_t CachePackedFireAmmoInfo;  // Offset: 2016 Size: 4
	char pad_2020[4];  // Offset: 2020 Size: 4



 // Functions 
 public:
	void PlayFlyBackSound(struct AArkRangeWeapon* Weapon); // Function ArkGunTech.ArkProjectile_SpinningLeaf.PlayFlyBackSound
	void OnRangeWeaponReloaded(struct AArkRangeWeapon* Weapon); // Function ArkGunTech.ArkProjectile_SpinningLeaf.OnRangeWeaponReloaded
}; 
 
 


