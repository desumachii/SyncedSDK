#pragma once 
#include <ArkImpactEffect_Footstep_Rager_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkImpactEffect_Footstep_Rager.ArkImpactEffect_Footstep_Rager_C Size 504
// Inherited 504 bytes 
class UArkImpactEffect_Footstep_Rager_C : public UArkImpactEffect
{

 public: 



 // Functions 
 public:
}; 
 
 


