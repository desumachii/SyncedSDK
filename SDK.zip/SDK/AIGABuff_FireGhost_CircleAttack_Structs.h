#pragma once 
#include <SDK_Engine_Objects.h> 
 
 
//Function AIGABuff_FireGhost_CircleAttack.AIGABuff_FireGhost_CircleAttack_C.ExecuteUbergraph_AIGABuff_FireGhost_CircleAttack Size 280
class FExecuteUbergraph_AIGABuff_FireGhost_CircleAttack
{

 public: 
	int32_t EntryPoint;  // Offset: 0 Size: 4
	char pad_4[4];  // Offset: 4 Size: 4
	struct AActor* CallFunc_GetOwner_ReturnValue;  // Offset: 8 Size: 8
	int32_t K2Node_Event_InstanceId;  // Offset: 16 Size: 4
	struct FVector K2Node_Event_Location;  // Offset: 20 Size: 12
	float K2Node_Event_Radius;  // Offset: 32 Size: 4
	float K2Node_Event_InitRadius;  // Offset: 36 Size: 4
	struct TArray<struct USceneComponent*> K2Node_Event_Attachments;  // Offset: 40 Size: 16
	char pad_56_1 : 7;  // Offset: 56 Size: 1
	bool K2Node_Event_bActive : 1;  // Offset: 56 Size: 1
	char pad_57[7];  // Offset: 57 Size: 7
	struct AArkNpc* K2Node_DynamicCast_AsArk_Npc;  // Offset: 64 Size: 8
	char pad_72_1 : 7;  // Offset: 72 Size: 1
	bool K2Node_DynamicCast_bSuccess : 1;  // Offset: 72 Size: 1
	char pad_73[3];  // Offset: 73 Size: 3
	float CallFunc_Divide_FloatFloat_ReturnValue;  // Offset: 76 Size: 4
	float CallFunc_GetScaledCapsuleHalfHeight_ReturnValue;  // Offset: 80 Size: 4
	struct FVector CallFunc_Conv_FloatToVector_ReturnValue;  // Offset: 84 Size: 12
	struct UArkSoftParticleSystemComponentWithPool* CallFunc_SpawnSoftEmitterAtLocation_ReturnValue;  // Offset: 96 Size: 8
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // Offset: 104 Size: 12
	float CallFunc_BreakVector_X;  // Offset: 116 Size: 4
	float CallFunc_BreakVector_Y;  // Offset: 120 Size: 4
	float CallFunc_BreakVector_Z;  // Offset: 124 Size: 4
	char pad_128_1 : 7;  // Offset: 128 Size: 1
	bool CallFunc_Map_Remove_ReturnValue : 1;  // Offset: 128 Size: 1
	char pad_129[3];  // Offset: 129 Size: 3
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // Offset: 132 Size: 4
	char pad_136_1 : 7;  // Offset: 136 Size: 1
	bool CallFunc_IsDedicatedServer_ReturnValue : 1;  // Offset: 136 Size: 1
	char pad_137[3];  // Offset: 137 Size: 3
	struct FVector CallFunc_MakeVector_ReturnValue;  // Offset: 140 Size: 12
	char pad_152[8];  // Offset: 152 Size: 8
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // Offset: 160 Size: 48
	char pad_208_1 : 7;  // Offset: 208 Size: 1
	bool CallFunc_Map_Contains_ReturnValue : 1;  // Offset: 208 Size: 1
	char pad_209[7];  // Offset: 209 Size: 7
	struct UParticleSystemComponent* CallFunc_Map_Find_Value;  // Offset: 216 Size: 8
	char pad_224_1 : 7;  // Offset: 224 Size: 1
	bool CallFunc_Map_Find_ReturnValue : 1;  // Offset: 224 Size: 1
	char pad_225[3];  // Offset: 225 Size: 3
	struct FName K2Node_Event_NotifyName;  // Offset: 228 Size: 8
	char pad_236[4];  // Offset: 236 Size: 4
	struct UAnimNotify* K2Node_Event_Notify;  // Offset: 240 Size: 8
	struct UParticleSystemComponent* CallFunc_Map_Find_Value_2;  // Offset: 248 Size: 8
	char pad_256_1 : 7;  // Offset: 256 Size: 1
	bool CallFunc_Map_Find_ReturnValue_2 : 1;  // Offset: 256 Size: 1
	char pad_257_1 : 7;  // Offset: 257 Size: 1
	bool K2Node_SwitchName_CmpSuccess : 1;  // Offset: 257 Size: 1
	char pad_258_1 : 7;  // Offset: 258 Size: 1
	bool CallFunc_HasAuthority_ReturnValue : 1;  // Offset: 258 Size: 1
	char pad_259[5];  // Offset: 259 Size: 5
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // Offset: 264 Size: 8
	struct AActor* CallFunc_FinishSpawningActor_ReturnValue;  // Offset: 272 Size: 8



 // Functions 
 public:
}; 
 
 //Function AIGABuff_FireGhost_CircleAttack.AIGABuff_FireGhost_CircleAttack_C.UpdateCircleEffect_BP Size 41
// Inherited 48 bytes 
class FUpdateCircleEffect_BP : public FUpdateCircleEffect_BP
{

 public: 
	int32_t InstanceId;  // Offset: 0 Size: 4
	struct FVector Location;  // Offset: 4 Size: 12
	float Radius;  // Offset: 16 Size: 4
	float InitRadius;  // Offset: 20 Size: 4
	struct TArray<struct USceneComponent*> Attachments;  // Offset: 24 Size: 16
	char pad_88_1 : 7;  // Offset: 88 Size: 1
	bool bActive : 1;  // Offset: 40 Size: 1



 // Functions 
 public:
}; 
 
 //Function AIGABuff_FireGhost_CircleAttack.AIGABuff_FireGhost_CircleAttack_C.OnAnimNotify_BP Size 16
// Inherited 16 bytes 
class FOnAnimNotify_BP : public FOnAnimNotify_BP
{

 public: 
	struct FName NotifyName;  // Offset: 0 Size: 8
	struct UAnimNotify* Notify;  // Offset: 8 Size: 8



 // Functions 
 public:
}; 
 
 