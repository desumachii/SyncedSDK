#pragma once 
#include <ArkFirePluseBullet_GT_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkFirePluseBullet_GT.ArkFirePluseBullet_GT_C Size 1880
// Inherited 1880 bytes 
class AArkFirePluseBullet_GT_C : public AArkProjectile_FirePluse
{

 public: 



 // Functions 
 public:
}; 
 
 


