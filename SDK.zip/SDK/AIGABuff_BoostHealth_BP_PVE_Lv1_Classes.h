#pragma once 
#include <AIGABuff_BoostHealth_BP_PVE_Lv1_Structs.h>
 
 
 
//BlueprintGeneratedClass AIGABuff_BoostHealth_BP_PVE_Lv1.AIGABuff_BoostHealth_BP_PVE_Lv1_C Size 1232
// Inherited 1232 bytes 
class UAIGABuff_BoostHealth_BP_PVE_Lv1_C : public UArkAIGABuff_ModifyHealth
{

 public: 



 // Functions 
 public:
}; 
 
 


