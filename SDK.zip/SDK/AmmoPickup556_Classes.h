#pragma once 
#include <AmmoPickup556_Structs.h>
 
 
 
//BlueprintGeneratedClass AmmoPickup556.AmmoPickup556_C Size 2416
// Inherited 2416 bytes 
class AAmmoPickup556_C : public AAmmoPickupBase_C
{

 public: 



 // Functions 
 public:
}; 
 
 


