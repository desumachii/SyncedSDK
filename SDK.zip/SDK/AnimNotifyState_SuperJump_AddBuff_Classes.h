#pragma once 
#include <AnimNotifyState_SuperJump_AddBuff_Structs.h>
 
 
 
//BlueprintGeneratedClass AnimNotifyState_SuperJump_AddBuff.AnimNotifyState_SuperJump_AddBuff_C Size 64
// Inherited 48 bytes 
class UAnimNotifyState_SuperJump_AddBuff_C : public UAnimNotifyState
{

 public: 
	struct TArray<int32_t> buffIDs_toBeAdded;  // Offset: 48 Size: 16



 // Functions 
 public:
	bool Received_NotifyBegin(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration); // Function AnimNotifyState_SuperJump_AddBuff.AnimNotifyState_SuperJump_AddBuff_C.Received_NotifyBegin
}; 
 
 


