#pragma once 
#include <ArkImpactEffect_Throwable_Rogue_FlameTrail_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkImpactEffect_Throwable_Rogue_FlameTrail.ArkImpactEffect_Throwable_Rogue_FlameTrail_C Size 504
// Inherited 504 bytes 
class UArkImpactEffect_Throwable_Rogue_FlameTrail_C : public UArkImpactEffect
{

 public: 



 // Functions 
 public:
}; 
 
 


