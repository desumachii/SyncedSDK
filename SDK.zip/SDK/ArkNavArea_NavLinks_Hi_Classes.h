#pragma once 
#include <ArkNavArea_NavLinks_Hi_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkNavArea_NavLinks_Hi.ArkNavArea_NavLinks_Hi_C Size 72
// Inherited 72 bytes 
class UArkNavArea_NavLinks_Hi_C : public UNavArea
{

 public: 



 // Functions 
 public:
}; 
 
 


