#pragma once 
#include <ArkDamageType_2doTs_CauseByRange_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkDamageType_2doTs_CauseByRange.ArkDamageType_2doTs_CauseByRange_C Size 264
// Inherited 264 bytes 
class UArkDamageType_2doTs_CauseByRange_C : public UArkDamageType_Range_C
{

 public: 



 // Functions 
 public:
}; 
 
 


