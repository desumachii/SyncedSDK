#pragma once 
#include <SDK_Engine_Objects.h> 
 
 
//Function ArkDeathCrate_BP.ArkDeathCrate_BP_C.ExecuteUbergraph_ArkDeathCrate_BP Size 14
class FExecuteUbergraph_ArkDeathCrate_BP
{

 public: 
	int32_t EntryPoint;  // Offset: 0 Size: 4
	int32_t K2Node_Event_QualityIndex_2;  // Offset: 4 Size: 4
	int32_t K2Node_Event_QualityIndex;  // Offset: 8 Size: 4
	char pad_12_1 : 7;  // Offset: 12 Size: 1
	bool K2Node_Event_bHide : 1;  // Offset: 12 Size: 1
	char pad_13_1 : 7;  // Offset: 13 Size: 1
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // Offset: 13 Size: 1



 // Functions 
 public:
}; 
 
 //Function ArkDeathCrate_BP.ArkDeathCrate_BP_C.BP_HideCrateMesh Size 1
// Inherited 1 bytes 
class FBP_HideCrateMesh : public FBP_HideCrateMesh
{

 public: 
	char pad_1_1 : 7;  // Offset: 1 Size: 1
	bool bHide : 1;  // Offset: 0 Size: 1



 // Functions 
 public:
}; 
 
 //Function ArkDeathCrate_BP.ArkDeathCrate_BP_C.BP_SetLootMeshTargetColorByQuality Size 4
// Inherited 4 bytes 
class FBP_SetLootMeshTargetColorByQuality : public FBP_SetLootMeshTargetColorByQuality
{

 public: 
	int32_t QualityIndex;  // Offset: 0 Size: 4



 // Functions 
 public:
}; 
 
 //Function ArkDeathCrate_BP.ArkDeathCrate_BP_C.GetPropSkeletalMeshComponent Size 9
// Inherited 8 bytes 
class FGetPropSkeletalMeshComponent : public FGetPropSkeletalMeshComponent
{

 public: 
	struct USkeletalMeshComponent* ReturnValue;  // Offset: 0 Size: 8
	char pad_16_1 : 7;  // Offset: 16 Size: 1
	bool CallFunc_IsVisible_ReturnValue : 1;  // Offset: 8 Size: 1



 // Functions 
 public:
}; 
 
 //Function ArkDeathCrate_BP.ArkDeathCrate_BP_C.BP_SetLootMeshEmmisiveColorByQuality Size 4
// Inherited 4 bytes 
class FBP_SetLootMeshEmmisiveColorByQuality : public FBP_SetLootMeshEmmisiveColorByQuality
{

 public: 
	int32_t QualityIndex;  // Offset: 0 Size: 4



 // Functions 
 public:
}; 
 
 //Function ArkDeathCrate_BP.ArkDeathCrate_BP_C.PlaceBagMesh Size 492
class FPlaceBagMesh
{

 public: 
	struct TArray<struct AActor*> Temp_object_Variable;  // Offset: 0 Size: 16
	char pad_16_1 : 7;  // Offset: 16 Size: 1
	bool CallFunc_IsDedicatedServer_ReturnValue : 1;  // Offset: 16 Size: 1
	char pad_17[3];  // Offset: 17 Size: 3
	struct FRotator CallFunc_K2_GetComponentRotation_ReturnValue;  // Offset: 20 Size: 12
	float CallFunc_GetScaledCapsuleRadius_ReturnValue;  // Offset: 32 Size: 4
	struct FVector CallFunc_GetForwardVector_ReturnValue;  // Offset: 36 Size: 12
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // Offset: 48 Size: 12
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // Offset: 60 Size: 12
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // Offset: 72 Size: 12
	struct FHitResult CallFunc_SphereTraceSingle_OutHit;  // Offset: 84 Size: 136
	char pad_220_1 : 7;  // Offset: 220 Size: 1
	bool CallFunc_SphereTraceSingle_ReturnValue : 1;  // Offset: 220 Size: 1
	char pad_221_1 : 7;  // Offset: 221 Size: 1
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // Offset: 221 Size: 1
	char pad_222_1 : 7;  // Offset: 222 Size: 1
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // Offset: 222 Size: 1
	char pad_223[1];  // Offset: 223 Size: 1
	float CallFunc_BreakHitResult_Time;  // Offset: 224 Size: 4
	float CallFunc_BreakHitResult_Distance;  // Offset: 228 Size: 4
	struct FVector CallFunc_BreakHitResult_Location;  // Offset: 232 Size: 12
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // Offset: 244 Size: 12
	struct FVector CallFunc_BreakHitResult_Normal;  // Offset: 256 Size: 12
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // Offset: 268 Size: 12
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // Offset: 280 Size: 8
	struct AActor* CallFunc_BreakHitResult_HitActor;  // Offset: 288 Size: 8
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // Offset: 296 Size: 8
	struct FName CallFunc_BreakHitResult_HitBoneName;  // Offset: 304 Size: 8
	int32_t CallFunc_BreakHitResult_HitItem;  // Offset: 312 Size: 4
	int32_t CallFunc_BreakHitResult_FaceIndex;  // Offset: 316 Size: 4
	struct FVector CallFunc_BreakHitResult_TraceStart;  // Offset: 320 Size: 12
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // Offset: 332 Size: 12
	struct FRotator CallFunc_MakeRotFromZX_ReturnValue;  // Offset: 344 Size: 12
	struct FHitResult CallFunc_K2_SetWorldRotation_SweepHitResult;  // Offset: 356 Size: 136



 // Functions 
 public:
}; 
 
 