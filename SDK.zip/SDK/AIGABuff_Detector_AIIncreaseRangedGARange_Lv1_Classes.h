#pragma once 
#include <AIGABuff_Detector_AIIncreaseRangedGARange_Lv1_Structs.h>
 
 
 
//BlueprintGeneratedClass AIGABuff_Detector_AIIncreaseRangedGARange_Lv1.AIGABuff_Detector_AIIncreaseRangedGARange_Lv1_C Size 1224
// Inherited 1224 bytes 
class UAIGABuff_Detector_AIIncreaseRangedGARange_Lv1_C : public UArkAIGameplayAbilityBuff
{

 public: 



 // Functions 
 public:
}; 
 
 


