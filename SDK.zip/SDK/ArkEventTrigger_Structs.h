#pragma once 
#include <SDK_Engine_Objects.h> 
 
 
//ScriptStruct ArkEventTrigger.ArkEventFilter_BoolParam Size 2
class FArkEventFilter_BoolParam
{

 public: 
	enum class EArkHitInfo_ParamType Type;  // Offset: 0 Size: 1
	enum class EArkGameBuff_BoolParam Value;  // Offset: 1 Size: 1



 // Functions 
 public:
}; 
 
 