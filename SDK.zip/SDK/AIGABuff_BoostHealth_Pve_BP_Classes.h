#pragma once 
#include <AIGABuff_BoostHealth_Pve_BP_Structs.h>
 
 
 
//BlueprintGeneratedClass AIGABuff_BoostHealth_Pve_BP.AIGABuff_BoostHealth_Pve_BP_C Size 1232
// Inherited 1232 bytes 
class UAIGABuff_BoostHealth_Pve_BP_C : public UArkAIGABuff_ModifyHealth
{

 public: 



 // Functions 
 public:
}; 
 
 


