#pragma once 
#include <ABP_Shield_SkateBoard_Structs.h>
 
 
 
//AnimBlueprintGeneratedClass ABP_Shield_SkateBoard.ABP_Shield_SkateBoard_C Size 1064
// Inherited 672 bytes 
class UABP_Shield_SkateBoard_C : public UAnimInstance
{

 public: 
	struct FPointerToUberGraphFrame UberGraphFrame;  // Offset: 672 Size: 8
	struct FAnimNode_Root AnimGraphNode_Root;  // Offset: 680 Size: 56
	struct FAnimNode_CopyPoseFromMesh AnimGraphNode_CopyPoseFromMesh;  // Offset: 736 Size: 328



 // Functions 
 public:
	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_Shield_SkateBoard.ABP_Shield_SkateBoard_C.AnimGraph
	void ExecuteUbergraph_ABP_Shield_SkateBoard(int32_t EntryPoint); // Function ABP_Shield_SkateBoard.ABP_Shield_SkateBoard_C.ExecuteUbergraph_ABP_Shield_SkateBoard
}; 
 
 


