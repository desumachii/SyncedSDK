#pragma once 
#include <SDK_Engine_Objects.h> 
 
 
//Function ArkBPFunctionLib.ArkBPFunctionLib_C.GFun_GetShuttleAlphabet Size 41
class FGFun_GetShuttleAlphabet
{

 public: 
	int32_t ShuttleID;  // Offset: 0 Size: 4
	char pad_4[4];  // Offset: 4 Size: 4
	struct UObject* __WorldContext;  // Offset: 8 Size: 8
	struct FText alphabet;  // Offset: 16 Size: 24
	char pad_40_1 : 7;  // Offset: 40 Size: 1
	bool K2Node_SwitchInteger_CmpSuccess : 1;  // Offset: 40 Size: 1



 // Functions 
 public:
}; 
 
 //Function ArkBPFunctionLib.ArkBPFunctionLib_C.GFun_GetPlayerStateByID Size 72
class FGFun_GetPlayerStateByID
{

 public: 
	struct FString PlayerId;  // Offset: 0 Size: 16
	struct AActor* WorldContextActor;  // Offset: 16 Size: 8
	struct UObject* __WorldContext;  // Offset: 24 Size: 8
	struct AArkPlayerStateBattle* PlayerState;  // Offset: 32 Size: 8
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue;  // Offset: 40 Size: 8
	struct AArkGameStateBattle* K2Node_DynamicCast_AsArk_Game_State_Battle;  // Offset: 48 Size: 8
	char pad_56_1 : 7;  // Offset: 56 Size: 1
	bool K2Node_DynamicCast_bSuccess : 1;  // Offset: 56 Size: 1
	char pad_57[7];  // Offset: 57 Size: 7
	struct AArkPlayerStateBattle* CallFunc_GetPlayerStateByPlayerIDStr_ReturnValue;  // Offset: 64 Size: 8



 // Functions 
 public:
}; 
 
 //Function ArkBPFunctionLib.ArkBPFunctionLib_C.GFun_GetShuttleIconColor Size 33
class FGFun_GetShuttleIconColor
{

 public: 
	int32_t ShuttleID;  // Offset: 0 Size: 4
	char pad_4[4];  // Offset: 4 Size: 4
	struct UObject* __WorldContext;  // Offset: 8 Size: 8
	struct FLinearColor Color;  // Offset: 16 Size: 16
	char pad_32_1 : 7;  // Offset: 32 Size: 1
	bool K2Node_SwitchInteger_CmpSuccess : 1;  // Offset: 32 Size: 1



 // Functions 
 public:
}; 
 
 //Function ArkBPFunctionLib.ArkBPFunctionLib_C.GFun_GetGameState Size 49
class FGFun_GetGameState
{

 public: 
	struct UObject* ContextObj;  // Offset: 0 Size: 8
	struct UObject* __WorldContext;  // Offset: 8 Size: 8
	struct AArkGameStateBattle* RetGameState;  // Offset: 16 Size: 8
	struct AGameModeBase* CallFunc_GetGameMode_ReturnValue;  // Offset: 24 Size: 8
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue;  // Offset: 32 Size: 8
	struct AArkGameStateBattle* K2Node_DynamicCast_AsArk_Game_State_Battle;  // Offset: 40 Size: 8
	char pad_48_1 : 7;  // Offset: 48 Size: 1
	bool K2Node_DynamicCast_bSuccess : 1;  // Offset: 48 Size: 1



 // Functions 
 public:
}; 
 
 //Function ArkBPFunctionLib.ArkBPFunctionLib_C.GFun_GetMyTeamID Size 40
class FGFun_GetMyTeamID
{

 public: 
	struct APlayerController* PlayerController;  // Offset: 0 Size: 8
	struct UObject* __WorldContext;  // Offset: 8 Size: 8
	int32_t OutTeamID;  // Offset: 16 Size: 4
	char pad_20[4];  // Offset: 20 Size: 4
	struct AArkPlayerStateBattle* K2Node_DynamicCast_AsArk_Player_State_Battle;  // Offset: 24 Size: 8
	char pad_32_1 : 7;  // Offset: 32 Size: 1
	bool K2Node_DynamicCast_bSuccess : 1;  // Offset: 32 Size: 1
	char pad_33[3];  // Offset: 33 Size: 3
	int32_t CallFunc_GetTeamID_ReturnValue;  // Offset: 36 Size: 4



 // Functions 
 public:
}; 
 
 //Function ArkBPFunctionLib.ArkBPFunctionLib_C.GFun_IsMeleeDamage Size 34
class FGFun_IsMeleeDamage
{

 public: 
	struct UDamageType* DamageType;  // Offset: 0 Size: 8
	struct UObject* __WorldContext;  // Offset: 8 Size: 8
	char pad_16_1 : 7;  // Offset: 16 Size: 1
	bool ReturnValue : 1;  // Offset: 16 Size: 1
	char pad_17[7];  // Offset: 17 Size: 7
	struct UArkDamageType* K2Node_DynamicCast_AsArk_Damage_Type;  // Offset: 24 Size: 8
	char pad_32_1 : 7;  // Offset: 32 Size: 1
	bool K2Node_DynamicCast_bSuccess : 1;  // Offset: 32 Size: 1
	char pad_33_1 : 7;  // Offset: 33 Size: 1
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // Offset: 33 Size: 1



 // Functions 
 public:
}; 
 
 //Function ArkBPFunctionLib.ArkBPFunctionLib_C.GFun_GetPlayerColor Size 33
class FGFun_GetPlayerColor
{

 public: 
	int32_t PlayerIndex;  // Offset: 0 Size: 4
	char pad_4[4];  // Offset: 4 Size: 4
	struct UObject* __WorldContext;  // Offset: 8 Size: 8
	struct FLinearColor Color;  // Offset: 16 Size: 16
	char pad_32_1 : 7;  // Offset: 32 Size: 1
	bool K2Node_SwitchInteger_CmpSuccess : 1;  // Offset: 32 Size: 1



 // Functions 
 public:
}; 
 
 //Function ArkBPFunctionLib.ArkBPFunctionLib_C.GFun_GetShuttleIcon Size 152
class FGFun_GetShuttleIcon
{

 public: 
	int32_t ShuttleID;  // Offset: 0 Size: 4
	char pad_4[4];  // Offset: 4 Size: 4
	struct UObject* __WorldContext;  // Offset: 8 Size: 8
	struct FText icon;  // Offset: 16 Size: 24
	int32_t LocalShuttleIndex;  // Offset: 40 Size: 4
	char pad_44_1 : 7;  // Offset: 44 Size: 1
	bool K2Node_SwitchInteger_CmpSuccess : 1;  // Offset: 44 Size: 1
	char pad_45[3];  // Offset: 45 Size: 3
	struct FFormatArgumentData K2Node_MakeStruct_FormatArgumentData;  // Offset: 48 Size: 64
	struct TArray<struct FFormatArgumentData> K2Node_MakeArray_Array;  // Offset: 112 Size: 16
	struct FText CallFunc_Format_ReturnValue;  // Offset: 128 Size: 24



 // Functions 
 public:
}; 
 
 //Function ArkBPFunctionLib.ArkBPFunctionLib_C.GFun_GetShuttleStateCountDown Size 80
class FGFun_GetShuttleStateCountDown
{

 public: 
	int32_t ShuttleID;  // Offset: 0 Size: 4
	enum class EArkShuttleStateType Type;  // Offset: 4 Size: 1
	char pad_5[3];  // Offset: 5 Size: 3
	struct UObject* __WorldContext;  // Offset: 8 Size: 8
	char pad_16_1 : 7;  // Offset: 16 Size: 1
	bool valid : 1;  // Offset: 16 Size: 1
	char pad_17[3];  // Offset: 17 Size: 3
	float Seconds;  // Offset: 20 Size: 4
	struct UArkECSManager* CallFunc_Get_ReturnValue;  // Offset: 24 Size: 8
	struct AGameStateBase* CallFunc_GetGameState_ReturnValue;  // Offset: 32 Size: 8
	float CallFunc_GetServerWorldTimeSeconds_ReturnValue;  // Offset: 40 Size: 4
	char pad_44[4];  // Offset: 44 Size: 4
	struct AArkShuttleBase* CallFunc_Map_Find_Value;  // Offset: 48 Size: 8
	char pad_56_1 : 7;  // Offset: 56 Size: 1
	bool CallFunc_Map_Find_ReturnValue : 1;  // Offset: 56 Size: 1
	char pad_57[3];  // Offset: 57 Size: 3
	struct FArkShuttleStateCurrentInfo CallFunc_GetStateInfoFromCatch_ReturnValue;  // Offset: 60 Size: 12
	char pad_72_1 : 7;  // Offset: 72 Size: 1
	bool CallFunc_NotEqual_ByteByte_ReturnValue : 1;  // Offset: 72 Size: 1
	char pad_73[3];  // Offset: 73 Size: 3
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // Offset: 76 Size: 4



 // Functions 
 public:
}; 
 
 //Function ArkBPFunctionLib.ArkBPFunctionLib_C.GFun_GetRegistColor Size 33
class FGFun_GetRegistColor
{

 public: 
	enum class EShuttleWidgetRegistEventType Type;  // Offset: 0 Size: 1
	char pad_1[7];  // Offset: 1 Size: 7
	struct UObject* __WorldContext;  // Offset: 8 Size: 8
	struct FLinearColor Color;  // Offset: 16 Size: 16
	char pad_32_1 : 7;  // Offset: 32 Size: 1
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // Offset: 32 Size: 1



 // Functions 
 public:
}; 
 
 //Function ArkBPFunctionLib.ArkBPFunctionLib_C.GFunGetThreatIconColorByLevel Size 38
class FGFunGetThreatIconColorByLevel
{

 public: 
	int32_t MyLevel;  // Offset: 0 Size: 4
	int32_t ThreatLevel;  // Offset: 4 Size: 4
	struct UObject* __WorldContext;  // Offset: 8 Size: 8
	struct FLinearColor ThreatColor;  // Offset: 16 Size: 16
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // Offset: 32 Size: 4
	char pad_36_1 : 7;  // Offset: 36 Size: 1
	bool CallFunc_GreaterEqual_IntInt_ReturnValue : 1;  // Offset: 36 Size: 1
	char pad_37_1 : 7;  // Offset: 37 Size: 1
	bool K2Node_SwitchInteger_CmpSuccess : 1;  // Offset: 37 Size: 1



 // Functions 
 public:
}; 
 
 //Function ArkBPFunctionLib.ArkBPFunctionLib_C.GFunGetThreatTextColorByLevel Size 184
class FGFunGetThreatTextColorByLevel
{

 public: 
	int32_t MyLevel;  // Offset: 0 Size: 4
	int32_t ThreatLevel;  // Offset: 4 Size: 4
	struct UObject* __WorldContext;  // Offset: 8 Size: 8
	struct FSlateColor ThreatColor;  // Offset: 16 Size: 40
	struct FSlateColor K2Node_MakeStruct_SlateColor;  // Offset: 56 Size: 40
	int32_t CallFunc_Subtract_IntInt_ReturnValue;  // Offset: 96 Size: 4
	char pad_100_1 : 7;  // Offset: 100 Size: 1
	bool K2Node_SwitchInteger_CmpSuccess : 1;  // Offset: 100 Size: 1
	char pad_101_1 : 7;  // Offset: 101 Size: 1
	bool CallFunc_GreaterEqual_IntInt_ReturnValue : 1;  // Offset: 101 Size: 1
	char pad_102[2];  // Offset: 102 Size: 2
	struct FSlateColor K2Node_MakeStruct_SlateColor_2;  // Offset: 104 Size: 40
	struct FSlateColor K2Node_MakeStruct_SlateColor_3;  // Offset: 144 Size: 40



 // Functions 
 public:
}; 
 
 //Function ArkBPFunctionLib.ArkBPFunctionLib_C.GFun_GetAttitudeColor Size 33
class FGFun_GetAttitudeColor
{

 public: 
	enum class ETeamAttitude TeamAttitude;  // Offset: 0 Size: 1
	char pad_1[7];  // Offset: 1 Size: 7
	struct UObject* __WorldContext;  // Offset: 8 Size: 8
	struct FLinearColor Color;  // Offset: 16 Size: 16
	char pad_32_1 : 7;  // Offset: 32 Size: 1
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // Offset: 32 Size: 1



 // Functions 
 public:
}; 
 
 //Function ArkBPFunctionLib.ArkBPFunctionLib_C.GFun_GetBasicColor Size 41
class FGFun_GetBasicColor
{

 public: 
	struct FString ColorName;  // Offset: 0 Size: 16
	struct UObject* __WorldContext;  // Offset: 16 Size: 8
	struct FLinearColor Color;  // Offset: 24 Size: 16
	char pad_40_1 : 7;  // Offset: 40 Size: 1
	bool K2Node_SwitchString_CmpSuccess : 1;  // Offset: 40 Size: 1



 // Functions 
 public:
}; 
 
 //Function ArkBPFunctionLib.ArkBPFunctionLib_C.GFun_GetQualityColor Size 41
class FGFun_GetQualityColor
{

 public: 
	struct FString ColorName;  // Offset: 0 Size: 16
	struct UObject* __WorldContext;  // Offset: 16 Size: 8
	struct FLinearColor Color;  // Offset: 24 Size: 16
	char pad_40_1 : 7;  // Offset: 40 Size: 1
	bool K2Node_SwitchString_CmpSuccess : 1;  // Offset: 40 Size: 1



 // Functions 
 public:
}; 
 
 //Function ArkBPFunctionLib.ArkBPFunctionLib_C.GFun_IsValidEnemyMonster Size 29
class FGFun_IsValidEnemyMonster
{

 public: 
	struct AArkNpc* InNpc;  // Offset: 0 Size: 8
	struct UObject* __WorldContext;  // Offset: 8 Size: 8
	char pad_16_1 : 7;  // Offset: 16 Size: 1
	bool IsValid : 1;  // Offset: 16 Size: 1
	char pad_17_1 : 7;  // Offset: 17 Size: 1
	bool CallFunc_IsAlive_ReturnValue : 1;  // Offset: 17 Size: 1
	char pad_18[2];  // Offset: 18 Size: 2
	int32_t CallFunc_GetTeamID_ReturnValue;  // Offset: 20 Size: 4
	char pad_24_1 : 7;  // Offset: 24 Size: 1
	bool CallFunc_IsSynced_ReturnValue : 1;  // Offset: 24 Size: 1
	char pad_25_1 : 7;  // Offset: 25 Size: 1
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // Offset: 25 Size: 1
	char pad_26_1 : 7;  // Offset: 26 Size: 1
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // Offset: 26 Size: 1
	char pad_27_1 : 7;  // Offset: 27 Size: 1
	bool CallFunc_BooleanAND_ReturnValue : 1;  // Offset: 27 Size: 1
	char pad_28_1 : 7;  // Offset: 28 Size: 1
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // Offset: 28 Size: 1



 // Functions 
 public:
}; 
 
 