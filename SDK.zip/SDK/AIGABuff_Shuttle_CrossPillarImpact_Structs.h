#pragma once 
#include <SDK_Engine_Objects.h> 
 
 
//Function AIGABuff_Shuttle_CrossPillarImpact.AIGABuff_Shuttle_CrossPillarImpact_C.ExecuteUbergraph_AIGABuff_Shuttle_CrossPillarImpact Size 625
class FExecuteUbergraph_AIGABuff_Shuttle_CrossPillarImpact
{

 public: 
	int32_t EntryPoint;  // Offset: 0 Size: 4
	char pad_4[4];  // Offset: 4 Size: 4
	struct UArkSceneQueryUtility* CallFunc_Get_ReturnValue;  // Offset: 8 Size: 8
	int32_t Temp_int_Array_Index_Variable;  // Offset: 16 Size: 4
	int32_t Temp_int_Loop_Counter_Variable;  // Offset: 20 Size: 4
	int32_t CallFunc_Add_IntInt_ReturnValue;  // Offset: 24 Size: 4
	int32_t Temp_int_Loop_Counter_Variable_2;  // Offset: 28 Size: 4
	int32_t Temp_int_Loop_Counter_Variable_3;  // Offset: 32 Size: 4
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // Offset: 36 Size: 4
	int32_t CallFunc_Add_IntInt_ReturnValue_3;  // Offset: 40 Size: 4
	int32_t Temp_int_Array_Index_Variable_2;  // Offset: 44 Size: 4
	struct AArkCharacterBase* CallFunc_GetOwnerAsCharacter_ReturnValue;  // Offset: 48 Size: 8
	int32_t CallFunc_Array_Length_ReturnValue;  // Offset: 56 Size: 4
	char pad_60_1 : 7;  // Offset: 60 Size: 1
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // Offset: 60 Size: 1
	char pad_61[3];  // Offset: 61 Size: 3
	float CallFunc_GetScaledCapsuleHalfHeight_ReturnValue;  // Offset: 64 Size: 4
	struct FVector CallFunc_MakeVector_ReturnValue;  // Offset: 68 Size: 12
	struct AArkNpc* K2Node_DynamicCast_AsArk_Npc;  // Offset: 80 Size: 8
	char pad_88_1 : 7;  // Offset: 88 Size: 1
	bool K2Node_DynamicCast_bSuccess : 1;  // Offset: 88 Size: 1
	char pad_89[3];  // Offset: 89 Size: 3
	int32_t CallFunc_Array_Length_ReturnValue_2;  // Offset: 92 Size: 4
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // Offset: 96 Size: 12
	char pad_108_1 : 7;  // Offset: 108 Size: 1
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // Offset: 108 Size: 1
	char pad_109[3];  // Offset: 109 Size: 3
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // Offset: 112 Size: 12
	char pad_124[4];  // Offset: 124 Size: 4
	struct TArray<struct AArkCharacterBase*> CallFunc_GetCharactersInRange_ReturnValue;  // Offset: 128 Size: 16
	int32_t Temp_int_Array_Index_Variable_3;  // Offset: 144 Size: 4
	struct FVector CallFunc_Array_Get_Item;  // Offset: 148 Size: 12
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue_2;  // Offset: 160 Size: 12
	struct FVector CallFunc_Vector_Normal2D_ReturnValue;  // Offset: 172 Size: 12
	struct FRotator CallFunc_MakeRotFromX_ReturnValue;  // Offset: 184 Size: 12
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // Offset: 196 Size: 12
	float CallFunc_BreakRotator_Roll;  // Offset: 208 Size: 4
	float CallFunc_BreakRotator_Pitch;  // Offset: 212 Size: 4
	float CallFunc_BreakRotator_Yaw;  // Offset: 216 Size: 4
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // Offset: 220 Size: 12
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // Offset: 232 Size: 12
	float CallFunc_BreakVector_X;  // Offset: 244 Size: 4
	float CallFunc_BreakVector_Y;  // Offset: 248 Size: 4
	float CallFunc_BreakVector_Z;  // Offset: 252 Size: 4
	struct FRotator CallFunc_MakeRotator_ReturnValue_2;  // Offset: 256 Size: 12
	struct FVector CallFunc_MakeVector_ReturnValue_2;  // Offset: 268 Size: 12
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // Offset: 280 Size: 4
	struct FVector CallFunc_MakeVector_ReturnValue_3;  // Offset: 284 Size: 12
	struct FHitResult CallFunc_LineTraceSingle_OutHit;  // Offset: 296 Size: 136
	char pad_432_1 : 7;  // Offset: 432 Size: 1
	bool CallFunc_LineTraceSingle_ReturnValue : 1;  // Offset: 432 Size: 1
	char pad_433_1 : 7;  // Offset: 433 Size: 1
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // Offset: 433 Size: 1
	char pad_434_1 : 7;  // Offset: 434 Size: 1
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // Offset: 434 Size: 1
	char pad_435[1];  // Offset: 435 Size: 1
	float CallFunc_BreakHitResult_Time;  // Offset: 436 Size: 4
	float CallFunc_BreakHitResult_Distance;  // Offset: 440 Size: 4
	struct FVector CallFunc_BreakHitResult_Location;  // Offset: 444 Size: 12
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // Offset: 456 Size: 12
	struct FVector CallFunc_BreakHitResult_Normal;  // Offset: 468 Size: 12
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // Offset: 480 Size: 12
	char pad_492[4];  // Offset: 492 Size: 4
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // Offset: 496 Size: 8
	struct AActor* CallFunc_BreakHitResult_HitActor;  // Offset: 504 Size: 8
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // Offset: 512 Size: 8
	struct FName CallFunc_BreakHitResult_HitBoneName;  // Offset: 520 Size: 8
	int32_t CallFunc_BreakHitResult_HitItem;  // Offset: 528 Size: 4
	int32_t CallFunc_BreakHitResult_FaceIndex;  // Offset: 532 Size: 4
	struct FVector CallFunc_BreakHitResult_TraceStart;  // Offset: 536 Size: 12
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // Offset: 548 Size: 12
	struct UArkSoftParticleSystemComponentWithPool* CallFunc_Array_Get_Item_2;  // Offset: 560 Size: 8
	struct UArkSoftParticleSystemComponentWithPool* CallFunc_SpawnSoftEmitterAtLocation_ReturnValue;  // Offset: 568 Size: 8
	char pad_576_1 : 7;  // Offset: 576 Size: 1
	bool CallFunc_IsValid_ReturnValue : 1;  // Offset: 576 Size: 1
	char pad_577[3];  // Offset: 577 Size: 3
	int32_t CallFunc_Array_Length_ReturnValue_3;  // Offset: 580 Size: 4
	char pad_584_1 : 7;  // Offset: 584 Size: 1
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // Offset: 584 Size: 1
	char pad_585[7];  // Offset: 585 Size: 7
	struct UArkSoftDecalComponentWithPool* CallFunc_SpawnSoftDecalAtLocation_ReturnValue;  // Offset: 592 Size: 8
	int32_t CallFunc_Array_Add_ReturnValue;  // Offset: 600 Size: 4
	char pad_604[4];  // Offset: 604 Size: 4
	struct UArkSoftParticleSystemComponentWithPool* CallFunc_Array_Get_Item_3;  // Offset: 608 Size: 8
	char pad_616_1 : 7;  // Offset: 616 Size: 1
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // Offset: 616 Size: 1
	char pad_617[3];  // Offset: 617 Size: 3
	int32_t CallFunc_Array_Length_ReturnValue_4;  // Offset: 620 Size: 4
	char pad_624_1 : 7;  // Offset: 624 Size: 1
	bool CallFunc_Less_IntInt_ReturnValue_3 : 1;  // Offset: 624 Size: 1



 // Functions 
 public:
}; 
 
 