#pragma once 
#include <AnimNotifyState_SuperJumpEnableExtraAction_Structs.h>
 
 
 
//BlueprintGeneratedClass AnimNotifyState_SuperJumpEnableExtraAction.AnimNotifyState_SuperJumpEnableExtraAction_C Size 52
// Inherited 48 bytes 
class UAnimNotifyState_SuperJumpEnableExtraAction_C : public UAnimNotifyState
{

 public: 
	int32_t SupportAction;  // Offset: 48 Size: 4



 // Functions 
 public:
	bool Received_NotifyEnd(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function AnimNotifyState_SuperJumpEnableExtraAction.AnimNotifyState_SuperJumpEnableExtraAction_C.Received_NotifyEnd
	bool Received_NotifyBegin(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration); // Function AnimNotifyState_SuperJumpEnableExtraAction.AnimNotifyState_SuperJumpEnableExtraAction_C.Received_NotifyBegin
}; 
 
 


