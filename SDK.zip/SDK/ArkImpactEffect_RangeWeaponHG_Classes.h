#pragma once 
#include <ArkImpactEffect_RangeWeaponHG_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkImpactEffect_RangeWeaponHG.ArkImpactEffect_RangeWeaponHG_C Size 504
// Inherited 504 bytes 
class UArkImpactEffect_RangeWeaponHG_C : public UArkImpactEffect_RangeWeapon_C
{

 public: 



 // Functions 
 public:
}; 
 
 


