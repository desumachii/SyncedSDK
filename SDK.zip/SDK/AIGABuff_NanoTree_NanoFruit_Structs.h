#pragma once 
#include <SDK_Engine_Objects.h> 
 
 
//Function AIGABuff_NanoTree_NanoFruit.AIGABuff_NanoTree_NanoFruit_C.ExecuteUbergraph_AIGABuff_NanoTree_NanoFruit Size 385
class FExecuteUbergraph_AIGABuff_NanoTree_NanoFruit
{

 public: 
	int32_t EntryPoint;  // Offset: 0 Size: 4
	int32_t Temp_int_Array_Index_Variable;  // Offset: 4 Size: 4
	int32_t Temp_int_Array_Index_Variable_2;  // Offset: 8 Size: 4
	int32_t Temp_int_Loop_Counter_Variable;  // Offset: 12 Size: 4
	int32_t CallFunc_Add_IntInt_ReturnValue;  // Offset: 16 Size: 4
	int32_t Temp_int_Array_Index_Variable_3;  // Offset: 20 Size: 4
	struct AActor* CallFunc_GetOwner_ReturnValue;  // Offset: 24 Size: 8
	struct AActor* CallFunc_GetOwner_ReturnValue_2;  // Offset: 32 Size: 8
	struct ABP_NanoTree_PVE_C* K2Node_DynamicCast_AsBP_Nano_Tree_PVE;  // Offset: 40 Size: 8
	char pad_48_1 : 7;  // Offset: 48 Size: 1
	bool K2Node_DynamicCast_bSuccess : 1;  // Offset: 48 Size: 1
	char pad_49[7];  // Offset: 49 Size: 7
	struct ABP_NanoTree_PVE_C* K2Node_DynamicCast_AsBP_Nano_Tree_PVE_2;  // Offset: 56 Size: 8
	char pad_64_1 : 7;  // Offset: 64 Size: 1
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // Offset: 64 Size: 1
	char pad_65[7];  // Offset: 65 Size: 7
	struct TArray<struct FVector> CallFunc_GetFruitSpawnLocations_Location;  // Offset: 72 Size: 16
	struct FVector CallFunc_Array_Get_Item;  // Offset: 88 Size: 12
	char pad_100_1 : 7;  // Offset: 100 Size: 1
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // Offset: 100 Size: 1
	char pad_101[3];  // Offset: 101 Size: 3
	int32_t CallFunc_Array_Length_ReturnValue;  // Offset: 104 Size: 4
	char pad_108_1 : 7;  // Offset: 108 Size: 1
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_2 : 1;  // Offset: 108 Size: 1
	char pad_109[3];  // Offset: 109 Size: 3
	struct AArkObj_NanoTree_NanoFruit* CallFunc_Array_Get_Item_2;  // Offset: 112 Size: 8
	char pad_120_1 : 7;  // Offset: 120 Size: 1
	bool CallFunc_IsObjectValid_ReturnValue : 1;  // Offset: 120 Size: 1
	char pad_121[3];  // Offset: 121 Size: 3
	int32_t CallFunc_Array_Length_ReturnValue_2;  // Offset: 124 Size: 4
	struct FAIRequestID Temp_struct_Variable;  // Offset: 128 Size: 4
	int32_t Temp_int_Loop_Counter_Variable_2;  // Offset: 132 Size: 4
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // Offset: 136 Size: 4
	struct FName K2Node_Event_NotifyName;  // Offset: 140 Size: 8
	char pad_148[4];  // Offset: 148 Size: 4
	struct UAnimNotify* K2Node_Event_Notify;  // Offset: 152 Size: 8
	char pad_160_1 : 7;  // Offset: 160 Size: 1
	bool K2Node_SwitchName_CmpSuccess : 1;  // Offset: 160 Size: 1
	char pad_161[3];  // Offset: 161 Size: 3
	int32_t Temp_int_Loop_Counter_Variable_3;  // Offset: 164 Size: 4
	int32_t Temp_int_Loop_Counter_Variable_4;  // Offset: 168 Size: 4
	char pad_172_1 : 7;  // Offset: 172 Size: 1
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // Offset: 172 Size: 1
	char pad_173[3];  // Offset: 173 Size: 3
	int32_t CallFunc_Add_IntInt_ReturnValue_3;  // Offset: 176 Size: 4
	char pad_180_1 : 7;  // Offset: 180 Size: 1
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // Offset: 180 Size: 1
	char pad_181[3];  // Offset: 181 Size: 3
	int32_t CallFunc_Add_IntInt_ReturnValue_4;  // Offset: 184 Size: 4
	char pad_188[4];  // Offset: 188 Size: 4
	struct TArray<struct AArkNpc*> Temp_object_Variable;  // Offset: 192 Size: 16
	int32_t Temp_int_Array_Index_Variable_4;  // Offset: 208 Size: 4
	int32_t CallFunc_Array_Length_ReturnValue_3;  // Offset: 212 Size: 4
	struct AArkNpc* CallFunc_Array_Get_Item_3;  // Offset: 216 Size: 8
	char pad_224_1 : 7;  // Offset: 224 Size: 1
	bool CallFunc_Less_IntInt_ReturnValue_3 : 1;  // Offset: 224 Size: 1
	char pad_225[7];  // Offset: 225 Size: 7
	struct AArkObj_NanoTree_NanoFruit* K2Node_DynamicCast_AsArk_Obj_Nano_Tree_Nano_Fruit;  // Offset: 232 Size: 8
	char pad_240_1 : 7;  // Offset: 240 Size: 1
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // Offset: 240 Size: 1
	char pad_241[3];  // Offset: 241 Size: 3
	int32_t CallFunc_Array_Add_ReturnValue;  // Offset: 244 Size: 4
	struct FAIRequestID K2Node_CustomEvent_RequestID;  // Offset: 248 Size: 4
	char pad_252[4];  // Offset: 252 Size: 4
	struct TArray<struct AArkNpc*> K2Node_CustomEvent_SpawnedNpcs;  // Offset: 256 Size: 16
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // Offset: 272 Size: 16
	char pad_288_1 : 7;  // Offset: 288 Size: 1
	bool CallFunc_HasAuthority_ReturnValue : 1;  // Offset: 288 Size: 1
	char pad_289_1 : 7;  // Offset: 289 Size: 1
	bool CallFunc_Check_if_Dead_Sector_bIfDeadSector : 1;  // Offset: 289 Size: 1
	char pad_290[6];  // Offset: 290 Size: 6
	struct UArkAISpawnPatternConfig* CallFunc_Array_Get_Item_4;  // Offset: 296 Size: 8
	struct UArkAIAsyncSpawnBlueprintProxy* CallFunc_CreateAsyncSpawnSpawnAIAtRadiusWithPatternProxyObject_ReturnValue;  // Offset: 304 Size: 8
	char pad_312_1 : 7;  // Offset: 312 Size: 1
	bool CallFunc_IsValid_ReturnValue : 1;  // Offset: 312 Size: 1
	char pad_313[7];  // Offset: 313 Size: 7
	struct UArkAISpawnPatternConfig* CallFunc_Array_Get_Item_5;  // Offset: 320 Size: 8
	char pad_328_1 : 7;  // Offset: 328 Size: 1
	bool CallFunc_HasAuthority_ReturnValue_2 : 1;  // Offset: 328 Size: 1
	char pad_329[3];  // Offset: 329 Size: 3
	struct FAIRequestID K2Node_CustomEvent_RequestID_2;  // Offset: 332 Size: 4
	struct TArray<struct AArkNpc*> K2Node_CustomEvent_SpawnedNpcs_2;  // Offset: 336 Size: 16
	struct AArkObj_NanoTree_NanoFruit* CallFunc_Array_Get_Item_6;  // Offset: 352 Size: 8
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // Offset: 360 Size: 16
	char pad_376_1 : 7;  // Offset: 376 Size: 1
	bool CallFunc_IsObjectValid_ReturnValue_2 : 1;  // Offset: 376 Size: 1
	char pad_377[3];  // Offset: 377 Size: 3
	int32_t CallFunc_Array_Length_ReturnValue_4;  // Offset: 380 Size: 4
	char pad_384_1 : 7;  // Offset: 384 Size: 1
	bool CallFunc_Less_IntInt_ReturnValue_4 : 1;  // Offset: 384 Size: 1



 // Functions 
 public:
}; 
 
 //Function AIGABuff_NanoTree_NanoFruit.AIGABuff_NanoTree_NanoFruit_C.OnAnimNotify_BP Size 16
// Inherited 16 bytes 
class FOnAnimNotify_BP : public FOnAnimNotify_BP
{

 public: 
	struct FName NotifyName;  // Offset: 0 Size: 8
	struct UAnimNotify* Notify;  // Offset: 8 Size: 8



 // Functions 
 public:
}; 
 
 //Function AIGABuff_NanoTree_NanoFruit.AIGABuff_NanoTree_NanoFruit_C.OnComplete_E6E81A3643B86339B40B5CB2FF8AD75A Size 24
class FOnComplete_E6E81A3643B86339B40B5CB2FF8AD75A
{

 public: 
	struct FAIRequestID RequestID;  // Offset: 0 Size: 4
	char pad_4[4];  // Offset: 4 Size: 4
	struct TArray<struct AArkNpc*> SpawnedNpcs;  // Offset: 8 Size: 16



 // Functions 
 public:
}; 
 
 //Function AIGABuff_NanoTree_NanoFruit.AIGABuff_NanoTree_NanoFruit_C.OnSingleNpcSpawnedEvent_E6E81A3643B86339B40B5CB2FF8AD75A Size 24
class FOnSingleNpcSpawnedEvent_E6E81A3643B86339B40B5CB2FF8AD75A
{

 public: 
	struct FAIRequestID RequestID;  // Offset: 0 Size: 4
	char pad_4[4];  // Offset: 4 Size: 4
	struct TArray<struct AArkNpc*> SpawnedNpcs;  // Offset: 8 Size: 16



 // Functions 
 public:
}; 
 
 