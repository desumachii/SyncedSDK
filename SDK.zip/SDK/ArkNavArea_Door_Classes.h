#pragma once 
#include <ArkNavArea_Door_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkNavArea_Door.ArkNavArea_Door_C Size 72
// Inherited 72 bytes 
class UArkNavArea_Door_C : public UNavArea
{

 public: 



 // Functions 
 public:
}; 
 
 


