#pragma once 
#include <Anne_Default_AddonA_00_Structs.h>
 
 
 
//BlueprintGeneratedClass Anne_Default_AddonA_00.Anne_Default_AddonA_00_C Size 400
// Inherited 400 bytes 
class UAnne_Default_AddonA_00_C : public UArkItemAvatarAttachment
{

 public: 



 // Functions 
 public:
}; 
 
 


