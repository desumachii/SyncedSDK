#pragma once 
#include <SDK_Engine_Objects.h> 
 
 
//Function ArkHavenRPCServer_BP.ArkHavenRPCServer_BP_C.GetModuleName Size 16
class FGetModuleName
{

 public: 
	struct FString ReturnValue;  // Offset: 0 Size: 16



 // Functions 
 public:
}; 
 
 