#pragma once 
#include <ArkNavFilter_Swarm_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkNavFilter_Swarm.ArkNavFilter_Swarm_C Size 248
// Inherited 248 bytes 
class UArkNavFilter_Swarm_C : public UArkNavFilterSwarm
{

 public: 



 // Functions 
 public:
}; 
 
 


