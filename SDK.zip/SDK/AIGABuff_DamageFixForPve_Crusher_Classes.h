#pragma once 
#include <AIGABuff_DamageFixForPve_Crusher_Structs.h>
 
 
 
//BlueprintGeneratedClass AIGABuff_DamageFixForPve_Crusher.AIGABuff_DamageFixForPve_Crusher_C Size 816
// Inherited 816 bytes 
class UAIGABuff_DamageFixForPve_Crusher_C : public UArkGameBuff_BaseDamageModifier
{

 public: 



 // Functions 
 public:
}; 
 
 


