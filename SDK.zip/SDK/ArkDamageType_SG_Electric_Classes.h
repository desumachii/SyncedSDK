#pragma once 
#include <ArkDamageType_SG_Electric_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkDamageType_SG_Electric.ArkDamageType_SG_Electric_C Size 264
// Inherited 264 bytes 
class UArkDamageType_SG_Electric_C : public UArkDamageType_Range_C
{

 public: 



 // Functions 
 public:
}; 
 
 


