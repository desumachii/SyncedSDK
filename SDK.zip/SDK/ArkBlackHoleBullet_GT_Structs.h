#pragma once 
#include <SDK_Engine_Objects.h> 
 
 
//Function ArkBlackHoleBullet_GT.ArkBlackHoleBullet_GT_C.ExecuteUbergraph_ArkBlackHoleBullet_GT Size 4
class FExecuteUbergraph_ArkBlackHoleBullet_GT
{

 public: 
	int32_t EntryPoint;  // Offset: 0 Size: 4



 // Functions 
 public:
}; 
 
 