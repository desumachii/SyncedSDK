#pragma once 
#include <ArkDamageType_Element_Radial_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkDamageType_Element_Radial.ArkDamageType_Element_Radial_C Size 264
// Inherited 264 bytes 
class UArkDamageType_Element_Radial_C : public UArkDamageType_Radial_C
{

 public: 



 // Functions 
 public:
}; 
 
 


