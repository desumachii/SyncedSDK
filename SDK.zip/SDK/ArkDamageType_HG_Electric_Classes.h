#pragma once 
#include <ArkDamageType_HG_Electric_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkDamageType_HG_Electric.ArkDamageType_HG_Electric_C Size 264
// Inherited 264 bytes 
class UArkDamageType_HG_Electric_C : public UArkDamageType_Range_C
{

 public: 



 // Functions 
 public:
}; 
 
 


