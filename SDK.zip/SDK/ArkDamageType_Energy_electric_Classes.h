#pragma once 
#include <ArkDamageType_Energy_electric_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkDamageType_Energy_electric.ArkDamageType_Energy_electric_C Size 264
// Inherited 264 bytes 
class UArkDamageType_Energy_electric_C : public UArkDamageType_Energy_C
{

 public: 



 // Functions 
 public:
}; 
 
 


