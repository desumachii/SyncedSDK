#pragma once 
#include <AIGABuff_FireGhost_CircleAttack_Structs.h>
 
 
 
//BlueprintGeneratedClass AIGABuff_FireGhost_CircleAttack.AIGABuff_FireGhost_CircleAttack_C Size 2336
// Inherited 2240 bytes 
class UAIGABuff_FireGhost_CircleAttack_C : public UArkAIGABuff_CircleAttack
{

 public: 
	struct FPointerToUberGraphFrame UberGraphFrame;  // Offset: 2240 Size: 8
	struct TMap<int32_t, struct UParticleSystemComponent*> EffectMap;  // Offset: 2248 Size: 80
	AActor* HeatingActor;  // Offset: 2328 Size: 8



 // Functions 
 public:
	void UpdateCircleEffect_BP(int32_t InstanceId, struct FVector& Location, float Radius, float InitRadius, struct TArray<struct USceneComponent*>& Attachments, bool bActive); // Function AIGABuff_FireGhost_CircleAttack.AIGABuff_FireGhost_CircleAttack_C.UpdateCircleEffect_BP
	void OnAnimNotify_BP(struct FName NotifyName, struct UAnimNotify* Notify); // Function AIGABuff_FireGhost_CircleAttack.AIGABuff_FireGhost_CircleAttack_C.OnAnimNotify_BP
	void ExecuteUbergraph_AIGABuff_FireGhost_CircleAttack(int32_t EntryPoint); // Function AIGABuff_FireGhost_CircleAttack.AIGABuff_FireGhost_CircleAttack_C.ExecuteUbergraph_AIGABuff_FireGhost_CircleAttack
}; 
 
 


