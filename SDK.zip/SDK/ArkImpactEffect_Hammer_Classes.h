#pragma once 
#include <ArkImpactEffect_Hammer_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkImpactEffect_Hammer.ArkImpactEffect_Hammer_C Size 504
// Inherited 504 bytes 
class UArkImpactEffect_Hammer_C : public UArkImpactEffect_Hammer_Large_C
{

 public: 



 // Functions 
 public:
}; 
 
 


