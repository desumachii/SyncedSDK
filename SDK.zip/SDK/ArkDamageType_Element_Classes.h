#pragma once 
#include <ArkDamageType_Element_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkDamageType_Element.ArkDamageType_Element_C Size 264
// Inherited 264 bytes 
class UArkDamageType_Element_C : public UArkDamageType
{

 public: 



 // Functions 
 public:
}; 
 
 


