#pragma once 
#include <ArkDamageType_Range_GadgetDirectHit_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkDamageType_Range_GadgetDirectHit.ArkDamageType_Range_GadgetDirectHit_C Size 264
// Inherited 264 bytes 
class UArkDamageType_Range_GadgetDirectHit_C : public UArkDamageType_Range_C
{

 public: 



 // Functions 
 public:
}; 
 
 


