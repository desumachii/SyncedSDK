#pragma once 
#include <AIGABuff_ReturnOfSpring_Structs.h>
 
 
 
//BlueprintGeneratedClass AIGABuff_ReturnOfSpring.AIGABuff_ReturnOfSpring_C Size 1368
// Inherited 1368 bytes 
class UAIGABuff_ReturnOfSpring_C : public UArkAIGABuff_ReturnOfSpring
{

 public: 



 // Functions 
 public:
}; 
 
 


