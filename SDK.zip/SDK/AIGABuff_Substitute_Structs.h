#pragma once 
#include <SDK_Engine_Objects.h> 
 
 
//Function AIGABuff_Substitute.AIGABuff_Substitute_C.ExecuteUbergraph_AIGABuff_Substitute Size 264
class FExecuteUbergraph_AIGABuff_Substitute
{

 public: 
	int32_t EntryPoint;  // Offset: 0 Size: 4
	char pad_4_1 : 7;  // Offset: 4 Size: 1
	bool Temp_bool_Variable : 1;  // Offset: 4 Size: 1
	char pad_5[3];  // Offset: 5 Size: 3
	struct FVector K2Node_Event_FromLoc;  // Offset: 8 Size: 12
	char pad_20_1 : 7;  // Offset: 20 Size: 1
	bool CallFunc_EqualExactly_VectorVector_ReturnValue : 1;  // Offset: 20 Size: 1
	char pad_21[3];  // Offset: 21 Size: 3
	struct AArkNpc* CallFunc_OwnerNpc_ReturnValue;  // Offset: 24 Size: 8
	struct AArkPlayer* CallFunc_GetSyncOwner_ReturnValue;  // Offset: 32 Size: 8
	char pad_40[8];  // Offset: 40 Size: 8
	struct FTransform CallFunc_K2_GetComponentToWorld_ReturnValue;  // Offset: 48 Size: 48
	struct FVector CallFunc_BreakTransform_Location;  // Offset: 96 Size: 12
	struct FRotator CallFunc_BreakTransform_Rotation;  // Offset: 108 Size: 12
	struct FVector CallFunc_BreakTransform_Scale;  // Offset: 120 Size: 12
	struct FRotator CallFunc_FindLookAtRotation_ReturnValue;  // Offset: 132 Size: 12
	float CallFunc_BreakRotator_Roll;  // Offset: 144 Size: 4
	float CallFunc_BreakRotator_Pitch;  // Offset: 148 Size: 4
	float CallFunc_BreakRotator_Yaw;  // Offset: 152 Size: 4
	float CallFunc_Add_FloatFloat_ReturnValue;  // Offset: 156 Size: 4
	struct FRotator CallFunc_MakeRotator_ReturnValue;  // Offset: 160 Size: 12
	struct FRotator K2Node_Select_Default;  // Offset: 172 Size: 12
	char pad_184[8];  // Offset: 184 Size: 8
	struct FTransform CallFunc_MakeTransform_ReturnValue;  // Offset: 192 Size: 48
	struct UArkSoftParticleSystemComponentWithPool* CallFunc_SpawnSoftEmitterAtLocation_ReturnValue;  // Offset: 240 Size: 8
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // Offset: 248 Size: 8
	struct ABP_Shield_Mod_death_VFX_C* CallFunc_FinishSpawningActor_ReturnValue;  // Offset: 256 Size: 8



 // Functions 
 public:
}; 
 
 //Function AIGABuff_Substitute.AIGABuff_Substitute_C.ClientPlayEffect_BP Size 12
// Inherited 12 bytes 
class FClientPlayEffect_BP : public FClientPlayEffect_BP
{

 public: 
	struct FVector FromLoc;  // Offset: 0 Size: 12



 // Functions 
 public:
}; 
 
 