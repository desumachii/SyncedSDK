#pragma once 
#include <AIGABuff_BoostHealth_Defencer_Stack_Structs.h>
 
 
 
//BlueprintGeneratedClass AIGABuff_BoostHealth_Defencer_Stack.AIGABuff_BoostHealth_Defencer_Stack_C Size 1232
// Inherited 1232 bytes 
class UAIGABuff_BoostHealth_Defencer_Stack_C : public UArkAIGABuff_ModifyHealth
{

 public: 



 // Functions 
 public:
}; 
 
 


