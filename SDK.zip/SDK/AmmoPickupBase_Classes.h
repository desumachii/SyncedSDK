#pragma once 
#include <AmmoPickupBase_Structs.h>
 
 
 
//BlueprintGeneratedClass AmmoPickupBase.AmmoPickupBase_C Size 2416
// Inherited 2416 bytes 
class AAmmoPickupBase_C : public ABP_ItemPickupBase_StaticMesh_C
{

 public: 



 // Functions 
 public:
}; 
 
 


