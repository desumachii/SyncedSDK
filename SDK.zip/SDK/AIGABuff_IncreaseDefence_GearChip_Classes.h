#pragma once 
#include <AIGABuff_IncreaseDefence_GearChip_Structs.h>
 
 
 
//BlueprintGeneratedClass AIGABuff_IncreaseDefence_GearChip.AIGABuff_IncreaseDefence_GearChip_C Size 1224
// Inherited 1224 bytes 
class UAIGABuff_IncreaseDefence_GearChip_C : public UArkAIGameplayAbilityBuff
{

 public: 



 // Functions 
 public:
}; 
 
 


