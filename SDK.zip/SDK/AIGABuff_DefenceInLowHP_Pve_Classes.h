#pragma once 
#include <AIGABuff_DefenceInLowHP_Pve_Structs.h>
 
 
 
//BlueprintGeneratedClass AIGABuff_DefenceInLowHP_Pve.AIGABuff_DefenceInLowHP_Pve_C Size 1224
// Inherited 1224 bytes 
class UAIGABuff_DefenceInLowHP_Pve_C : public UAIGABuff_DefenceInLowHP_Lv1_C
{

 public: 



 // Functions 
 public:
}; 
 
 


