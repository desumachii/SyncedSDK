#pragma once 
#include <SDK_Engine_Objects.h> 
 
 
//ScriptStruct ArkAnimation.TriggeredFacialAnim Size 160
class FTriggeredFacialAnim
{

 public: 
	struct TSoftObjectPtr<UAnimSequenceBase> SoftFacialAnim;  // Offset: 0 Size: 40
	struct TMap<struct USkeleton*, struct UAnimSequenceBase*> FacialAnimXFace;  // Offset: 40 Size: 80
	char pad_120_1 : 7;  // Offset: 120 Size: 1
	bool FA_IsAdditive : 1;  // Offset: 120 Size: 1
	char pad_121_1 : 7;  // Offset: 121 Size: 1
	bool FA_IsBreakOthers : 1;  // Offset: 121 Size: 1
	char pad_122[2];  // Offset: 122 Size: 2
	float FA_BlendInTime;  // Offset: 124 Size: 4
	float FA_BlendOutTime;  // Offset: 128 Size: 4
	float FA_PlayRate;  // Offset: 132 Size: 4
	int32_t FA_LoopCount;  // Offset: 136 Size: 4
	float FA_BlendOutTriggerTime;  // Offset: 140 Size: 4
	float FA_StartTime;  // Offset: 144 Size: 4
	char pad_148_1 : 7;  // Offset: 148 Size: 1
	bool FA_IsDependent : 1;  // Offset: 148 Size: 1
	char pad_149[11];  // Offset: 149 Size: 11



 // Functions 
 public:
}; 
 
 //ScriptStruct ArkAnimation.AnimNotifyInvisibleFadeParamterStruct Size 16
class FAnimNotifyInvisibleFadeParamterStruct
{

 public: 
	struct FName MaterialParamterName;  // Offset: 0 Size: 8
	struct UCurveFloat* ValueCurve;  // Offset: 8 Size: 8



 // Functions 
 public:
}; 
 
 