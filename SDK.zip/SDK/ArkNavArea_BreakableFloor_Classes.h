#pragma once 
#include <ArkNavArea_BreakableFloor_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkNavArea_BreakableFloor.ArkNavArea_BreakableFloor_C Size 72
// Inherited 72 bytes 
class UArkNavArea_BreakableFloor_C : public UNavArea
{

 public: 



 // Functions 
 public:
}; 
 
 


