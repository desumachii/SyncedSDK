#pragma once 
#include <AIGABuff_Stealth_Gold_Pve_BP_Structs.h>
 
 
 
//BlueprintGeneratedClass AIGABuff_Stealth_Gold_Pve_BP.AIGABuff_Stealth_Gold_Pve_BP_C Size 1264
// Inherited 1264 bytes 
class UAIGABuff_Stealth_Gold_Pve_BP_C : public UArkAIGABuff_Stealth
{

 public: 



 // Functions 
 public:
}; 
 
 


