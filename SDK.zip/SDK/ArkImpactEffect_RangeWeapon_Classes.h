#pragma once 
#include <ArkImpactEffect_RangeWeapon_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkImpactEffect_RangeWeapon.ArkImpactEffect_RangeWeapon_C Size 504
// Inherited 504 bytes 
class UArkImpactEffect_RangeWeapon_C : public UArkImpactEffect
{

 public: 



 // Functions 
 public:
}; 
 
 


