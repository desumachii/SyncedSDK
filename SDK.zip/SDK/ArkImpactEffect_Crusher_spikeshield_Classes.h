#pragma once 
#include <ArkImpactEffect_Crusher_spikeshield_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkImpactEffect_Crusher_spikeshield.ArkImpactEffect_Crusher_spikeshield_C Size 504
// Inherited 504 bytes 
class UArkImpactEffect_Crusher_spikeshield_C : public UArkImpactEffect_Crusher_C
{

 public: 



 // Functions 
 public:
}; 
 
 


