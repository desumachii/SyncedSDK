#pragma once 
#include <ArkDamageType_HG_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkDamageType_HG.ArkDamageType_HG_C Size 264
// Inherited 264 bytes 
class UArkDamageType_HG_C : public UArkDamageType_Range_C
{

 public: 



 // Functions 
 public:
}; 
 
 


