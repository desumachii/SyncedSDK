#pragma once 
#include <ArkGrenadeLauncherBullet_GT_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkGrenadeLauncherBullet_GT.ArkGrenadeLauncherBullet_GT_C Size 1936
// Inherited 1928 bytes 
class AArkGrenadeLauncherBullet_GT_C : public AArkProjectile_GrenadeLauncher
{

 public: 
	struct FPointerToUberGraphFrame UberGraphFrame;  // Offset: 1928 Size: 8



 // Functions 
 public:
	void BP_OnBulletInit(); // Function ArkGrenadeLauncherBullet_GT.ArkGrenadeLauncherBullet_GT_C.BP_OnBulletInit
	void C2BP_OnExploded(struct FHitResult& HitResult); // Function ArkGrenadeLauncherBullet_GT.ArkGrenadeLauncherBullet_GT_C.C2BP_OnExploded
	void ExecuteUbergraph_ArkGrenadeLauncherBullet_GT(int32_t EntryPoint); // Function ArkGrenadeLauncherBullet_GT.ArkGrenadeLauncherBullet_GT_C.ExecuteUbergraph_ArkGrenadeLauncherBullet_GT
}; 
 
 


