#pragma once 
#include <ArkDamageType_World_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkDamageType_World.ArkDamageType_World_C Size 264
// Inherited 264 bytes 
class UArkDamageType_World_C : public UArkDamageType
{

 public: 



 // Functions 
 public:
}; 
 
 


