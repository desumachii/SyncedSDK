#pragma once 
#include <ABP_Fpp_PostProcess_Structs.h>
 
 
 
//AnimBlueprintGeneratedClass ABP_Fpp_PostProcess.ABP_Fpp_PostProcess_C Size 6808
// Inherited 1120 bytes 
class UABP_Fpp_PostProcess_C : public UArkFppPostProcess
{

 public: 
	struct FPointerToUberGraphFrame UberGraphFrame;  // Offset: 1120 Size: 8
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone;  // Offset: 1128 Size: 272
	char pad_1400[8];  // Offset: 1400 Size: 8
	struct FAnimNode_TwoBoneIK AnimGraphNode_TwoBoneIK_4;  // Offset: 1408 Size: 512
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_4;  // Offset: 1920 Size: 40
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_9;  // Offset: 1960 Size: 48
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_4;  // Offset: 2008 Size: 40
	struct FAnimNode_TwoBoneIK AnimGraphNode_TwoBoneIK_3;  // Offset: 2048 Size: 512
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_3;  // Offset: 2560 Size: 40
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_5;  // Offset: 2600 Size: 192
	struct FAnimNode_LinkedInputPose AnimGraphNode_SubInput;  // Offset: 2792 Size: 128
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_3;  // Offset: 2920 Size: 40
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;  // Offset: 2960 Size: 272
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend;  // Offset: 3232 Size: 200
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_3;  // Offset: 3432 Size: 176
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_4;  // Offset: 3608 Size: 192
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_3;  // Offset: 3800 Size: 192
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_8;  // Offset: 3992 Size: 48
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_7;  // Offset: 4040 Size: 48
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_2;  // Offset: 4088 Size: 176
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_2;  // Offset: 4264 Size: 40
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_2;  // Offset: 4304 Size: 40
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_2;  // Offset: 4344 Size: 192
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_6;  // Offset: 4536 Size: 48
	struct FAnimNode_Root AnimGraphNode_Root;  // Offset: 4584 Size: 56
	struct FAnimNode_TwoBoneIK AnimGraphNode_TwoBoneIK_2;  // Offset: 4640 Size: 512
	struct FAnimNode_TwoBoneIK AnimGraphNode_TwoBoneIK;  // Offset: 5152 Size: 512
	struct FAnimNode_CopyBone AnimGraphNode_CopyBone;  // Offset: 5664 Size: 248
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;  // Offset: 5912 Size: 40
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;  // Offset: 5952 Size: 40
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose;  // Offset: 5992 Size: 192
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool;  // Offset: 6184 Size: 176
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_5;  // Offset: 6360 Size: 48
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_4;  // Offset: 6408 Size: 48
	struct FAnimNode_TwoWayBlend AnimGraphNode_TwoWayBlend;  // Offset: 6456 Size: 208
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_3;  // Offset: 6664 Size: 48
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_2;  // Offset: 6712 Size: 48
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose;  // Offset: 6760 Size: 48



 // Functions 
 public:
	void AnimGraph(struct FPoseLink InPose, struct FPoseLink& AnimGraph); // Function ABP_Fpp_PostProcess.ABP_Fpp_PostProcess_C.AnimGraph
	void ExecuteUbergraph_ABP_Fpp_PostProcess(int32_t EntryPoint); // Function ABP_Fpp_PostProcess.ABP_Fpp_PostProcess_C.ExecuteUbergraph_ABP_Fpp_PostProcess
}; 
 
 


