#pragma once 
#include <ABP_Detector_FlyCoat_Structs.h>
 
 
 
//AnimBlueprintGeneratedClass ABP_Detector_FlyCoat.ABP_Detector_FlyCoat_C Size 1064
// Inherited 672 bytes 
class UABP_Detector_FlyCoat_C : public UAnimInstance
{

 public: 
	struct FPointerToUberGraphFrame UberGraphFrame;  // Offset: 672 Size: 8
	struct FAnimNode_Root AnimGraphNode_Root;  // Offset: 680 Size: 56
	struct FAnimNode_CopyPoseFromMesh AnimGraphNode_CopyPoseFromMesh;  // Offset: 736 Size: 328



 // Functions 
 public:
	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_Detector_FlyCoat.ABP_Detector_FlyCoat_C.AnimGraph
	void ExecuteUbergraph_ABP_Detector_FlyCoat(int32_t EntryPoint); // Function ABP_Detector_FlyCoat.ABP_Detector_FlyCoat_C.ExecuteUbergraph_ABP_Detector_FlyCoat
}; 
 
 


