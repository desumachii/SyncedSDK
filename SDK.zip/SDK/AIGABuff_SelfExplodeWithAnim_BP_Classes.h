#pragma once 
#include <AIGABuff_SelfExplodeWithAnim_BP_Structs.h>
 
 
 
//BlueprintGeneratedClass AIGABuff_SelfExplodeWithAnim_BP.AIGABuff_SelfExplodeWithAnim_BP_C Size 2120
// Inherited 2016 bytes 
class UAIGABuff_SelfExplodeWithAnim_BP_C : public UArkAIGABuff_SelfExplode
{

 public: 
	struct FPointerToUberGraphFrame UberGraphFrame;  // Offset: 2016 Size: 8
	struct TMap<struct FName, int32_t> SummonAITypes;  // Offset: 2024 Size: 80
	float SummonRadius;  // Offset: 2104 Size: 4
	float SummonedLifeTime;  // Offset: 2108 Size: 4
	struct UArkAISpawnPatternConfig* Pattern;  // Offset: 2112 Size: 8



 // Functions 
 public:
	void OnAnimNotify_BP(struct FName NotifyName, struct UAnimNotify* Notify); // Function AIGABuff_SelfExplodeWithAnim_BP.AIGABuff_SelfExplodeWithAnim_BP_C.OnAnimNotify_BP
	void ExecuteUbergraph_AIGABuff_SelfExplodeWithAnim_BP(int32_t EntryPoint); // Function AIGABuff_SelfExplodeWithAnim_BP.AIGABuff_SelfExplodeWithAnim_BP_C.ExecuteUbergraph_AIGABuff_SelfExplodeWithAnim_BP
}; 
 
 


