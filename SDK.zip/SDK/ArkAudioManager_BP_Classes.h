#pragma once 
#include <ArkAudioManager_BP_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkAudioManager_BP.ArkAudioManager_BP_C Size 696
// Inherited 688 bytes 
class UArkAudioManager_BP_C : public UArkAudioManager
{

 public: 
	struct FPointerToUberGraphFrame UberGraphFrame;  // Offset: 688 Size: 8



 // Functions 
 public:
	void OnToggleLoadingScreen_BP(bool bLoadingScreenIsOn); // Function ArkAudioManager_BP.ArkAudioManager_BP_C.OnToggleLoadingScreen_BP
	void OnWorldCleanup_BP(); // Function ArkAudioManager_BP.ArkAudioManager_BP_C.OnWorldCleanup_BP
	void OnGameFlowChange_BP(enum class EArkGameFlowType OldType, enum class EArkGameFlowType NewType); // Function ArkAudioManager_BP.ArkAudioManager_BP_C.OnGameFlowChange_BP
	void OnCheat_BP(struct FString Command); // Function ArkAudioManager_BP.ArkAudioManager_BP_C.OnCheat_BP
	void ExecuteUbergraph_ArkAudioManager_BP(int32_t EntryPoint); // Function ArkAudioManager_BP.ArkAudioManager_BP_C.ExecuteUbergraph_ArkAudioManager_BP
}; 
 
 


