#pragma once 
#include <SDK_Engine_Objects.h> 
 
 
//Function AIGABuff_Teleport_Command_BP.AIGABuff_Teleport_Command_BP_C.ExecuteUbergraph_AIGABuff_Teleport_Command_BP Size 896
class FExecuteUbergraph_AIGABuff_Teleport_Command_BP
{

 public: 
	int32_t EntryPoint;  // Offset: 0 Size: 4
	struct FVector CallFunc_MakeVector_ReturnValue;  // Offset: 4 Size: 12
	struct AActor* CallFunc_GetOwner_ReturnValue;  // Offset: 16 Size: 8
	struct AActor* CallFunc_GetOwner_ReturnValue_2;  // Offset: 24 Size: 8
	struct ABP_Elite_C* K2Node_DynamicCast_AsBP_Elite;  // Offset: 32 Size: 8
	char pad_40_1 : 7;  // Offset: 40 Size: 1
	bool K2Node_DynamicCast_bSuccess : 1;  // Offset: 40 Size: 1
	char pad_41[7];  // Offset: 41 Size: 7
	struct AArkSwarmEntityCharacter* K2Node_DynamicCast_AsArk_Swarm_Entity_Character;  // Offset: 48 Size: 8
	char pad_56_1 : 7;  // Offset: 56 Size: 1
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // Offset: 56 Size: 1
	char pad_57_1 : 7;  // Offset: 57 Size: 1
	bool CallFunc_IsInStealthEffect_ReturnValue : 1;  // Offset: 57 Size: 1
	char pad_58[6];  // Offset: 58 Size: 6
	struct AArkSwarmEntityCharacter* K2Node_DynamicCast_AsArk_Swarm_Entity_Character_2;  // Offset: 64 Size: 8
	char pad_72_1 : 7;  // Offset: 72 Size: 1
	bool K2Node_DynamicCast_bSuccess_3 : 1;  // Offset: 72 Size: 1
	char pad_73[7];  // Offset: 73 Size: 7
	struct AActor* CallFunc_GetOwner_ReturnValue_3;  // Offset: 80 Size: 8
	struct ABP_Elite_C* K2Node_DynamicCast_AsBP_Elite_2;  // Offset: 88 Size: 8
	char pad_96_1 : 7;  // Offset: 96 Size: 1
	bool K2Node_DynamicCast_bSuccess_4 : 1;  // Offset: 96 Size: 1
	char pad_97[3];  // Offset: 97 Size: 3
	struct FVector_NetQuantize K2Node_Event_OldPotentialLoc;  // Offset: 100 Size: 12
	struct FVector_NetQuantize K2Node_Event_PotentialLoc;  // Offset: 112 Size: 12
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // Offset: 124 Size: 12
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // Offset: 136 Size: 12
	struct FRotator CallFunc_Conv_VectorToRotator_ReturnValue;  // Offset: 148 Size: 12
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // Offset: 160 Size: 12
	char pad_172[4];  // Offset: 172 Size: 4
	struct UArkSoftParticleSystemComponentWithPool* CallFunc_SpawnSoftEmitterAtLocation_ReturnValue;  // Offset: 176 Size: 8
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue_2;  // Offset: 184 Size: 12
	struct FTeleportResponseRepData K2Node_Event_InTeleportRepData;  // Offset: 196 Size: 40
	char pad_236[4];  // Offset: 236 Size: 4
	struct AActor* CallFunc_GetOwner_ReturnValue_4;  // Offset: 240 Size: 8
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // Offset: 248 Size: 12
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue_3;  // Offset: 260 Size: 12
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue_4;  // Offset: 272 Size: 12
	struct FRotator CallFunc_Conv_VectorToRotator_ReturnValue_2;  // Offset: 284 Size: 12
	struct FRotator CallFunc_Conv_VectorToRotator_ReturnValue_3;  // Offset: 296 Size: 12
	char pad_308[4];  // Offset: 308 Size: 4
	struct UArkSoftParticleSystemComponentWithPool* CallFunc_SpawnSoftEmitterAtLocation_ReturnValue_2;  // Offset: 312 Size: 8
	struct FVector CallFunc_Normal_ReturnValue;  // Offset: 320 Size: 12
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // Offset: 332 Size: 12
	struct UArkSoftParticleSystemComponentWithPool* CallFunc_SpawnSoftEmitterAtLocation_ReturnValue_3;  // Offset: 344 Size: 8
	struct UArkSoftParticleSystemComponentWithPool* CallFunc_SpawnSoftEmitterAtLocation_ReturnValue_4;  // Offset: 352 Size: 8
	char pad_360_1 : 7;  // Offset: 360 Size: 1
	bool CallFunc_IsValid_ReturnValue : 1;  // Offset: 360 Size: 1
	char pad_361[7];  // Offset: 361 Size: 7
	struct AActor* CallFunc_GetOwner_ReturnValue_5;  // Offset: 368 Size: 8
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_3;  // Offset: 376 Size: 12
	char pad_388[4];  // Offset: 388 Size: 4
	struct AActor* CallFunc_GetOwner_ReturnValue_6;  // Offset: 392 Size: 8
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue_5;  // Offset: 400 Size: 12
	char pad_412[4];  // Offset: 412 Size: 4
	struct AArkSwarmEntityCharacter* K2Node_DynamicCast_AsArk_Swarm_Entity_Character_3;  // Offset: 416 Size: 8
	char pad_424_1 : 7;  // Offset: 424 Size: 1
	bool K2Node_DynamicCast_bSuccess_5 : 1;  // Offset: 424 Size: 1
	char pad_425[7];  // Offset: 425 Size: 7
	struct UArkSoftParticleSystemComponentWithPool* CallFunc_SpawnSoftEmitterAtLocation_ReturnValue_5;  // Offset: 432 Size: 8
	char pad_440_1 : 7;  // Offset: 440 Size: 1
	bool CallFunc_IsInStealthEffect_ReturnValue_2 : 1;  // Offset: 440 Size: 1
	char pad_441[7];  // Offset: 441 Size: 7
	struct AActor* CallFunc_GetOwner_ReturnValue_7;  // Offset: 448 Size: 8
	struct ABP_Elite_C* K2Node_DynamicCast_AsBP_Elite_3;  // Offset: 456 Size: 8
	char pad_464_1 : 7;  // Offset: 464 Size: 1
	bool K2Node_DynamicCast_bSuccess_6 : 1;  // Offset: 464 Size: 1
	char pad_465[7];  // Offset: 465 Size: 7
	struct AActor* K2Node_Event_targetActor;  // Offset: 472 Size: 8
	enum class EArkAIGAActionStopReason K2Node_Event_StopReason;  // Offset: 480 Size: 1
	char pad_481[3];  // Offset: 481 Size: 3
	float CallFunc_PlayAnimMontageEx_ReturnValue;  // Offset: 484 Size: 4
	struct UArkSoftParticleSystemComponentWithPool* CallFunc_SpawnSoftEmitterAtLocation_ReturnValue_6;  // Offset: 488 Size: 8
	char pad_496_1 : 7;  // Offset: 496 Size: 1
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // Offset: 496 Size: 1
	char pad_497[7];  // Offset: 497 Size: 7
	struct FTakeHitInfo K2Node_Event_HitInfo;  // Offset: 504 Size: 328
	char pad_832_1 : 7;  // Offset: 832 Size: 1
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // Offset: 832 Size: 1
	char pad_833[7];  // Offset: 833 Size: 7
	struct AActor* CallFunc_GetOwner_ReturnValue_8;  // Offset: 840 Size: 8
	struct AArkNpc* K2Node_DynamicCast_AsArk_Npc;  // Offset: 848 Size: 8
	char pad_856_1 : 7;  // Offset: 856 Size: 1
	bool K2Node_DynamicCast_bSuccess_7 : 1;  // Offset: 856 Size: 1
	char pad_857_1 : 7;  // Offset: 857 Size: 1
	bool CallFunc_JustBornWithinTime_ReturnValue : 1;  // Offset: 857 Size: 1
	char pad_858[6];  // Offset: 858 Size: 6
	struct UArkSoftParticleSystemComponentWithPool* CallFunc_SpawnSoftEmitterAtLocation_ReturnValue_7;  // Offset: 864 Size: 8
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // Offset: 872 Size: 16
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // Offset: 888 Size: 8



 // Functions 
 public:
}; 
 
 //Function AIGABuff_Teleport_Command_BP.AIGABuff_Teleport_Command_BP_C.OnDeath_BP Size 328
// Inherited 328 bytes 
class FOnDeath_BP : public FOnDeath_BP
{

 public: 
	struct FTakeHitInfo HitInfo;  // Offset: 0 Size: 328



 // Functions 
 public:
}; 
 
 //Function AIGABuff_Teleport_Command_BP.AIGABuff_Teleport_Command_BP_C.PauseMovement Size 33
class FPauseMovement
{

 public: 
	char pad_0_1 : 7;  // Offset: 0 Size: 1
	bool bPause : 1;  // Offset: 0 Size: 1
	char pad_1[7];  // Offset: 1 Size: 7
	struct AActor* CallFunc_GetOwner_ReturnValue;  // Offset: 8 Size: 8
	char pad_16_1 : 7;  // Offset: 16 Size: 1
	bool CallFunc_NotEqual_BoolBool_ReturnValue : 1;  // Offset: 16 Size: 1
	char pad_17[7];  // Offset: 17 Size: 7
	struct AArkSwarmEntityCharacter* K2Node_DynamicCast_AsArk_Swarm_Entity_Character;  // Offset: 24 Size: 8
	char pad_32_1 : 7;  // Offset: 32 Size: 1
	bool K2Node_DynamicCast_bSuccess : 1;  // Offset: 32 Size: 1



 // Functions 
 public:
}; 
 
 //Function AIGABuff_Teleport_Command_BP.AIGABuff_Teleport_Command_BP_C.OnPotentialLocation_BP Size 24
// Inherited 24 bytes 
class FOnPotentialLocation_BP : public FOnPotentialLocation_BP
{

 public: 
	struct FVector_NetQuantize OldPotentialLoc;  // Offset: 0 Size: 12
	struct FVector_NetQuantize PotentialLoc;  // Offset: 12 Size: 12



 // Functions 
 public:
}; 
 
 //Function AIGABuff_Teleport_Command_BP.AIGABuff_Teleport_Command_BP_C.OnStopAction_BP Size 1
// Inherited 1 bytes 
class FOnStopAction_BP : public FOnStopAction_BP
{

 public: 
	enum class EArkAIGAActionStopReason StopReason;  // Offset: 0 Size: 1



 // Functions 
 public:
}; 
 
 //Function AIGABuff_Teleport_Command_BP.AIGABuff_Teleport_Command_BP_C.OnPerformAction_BP Size 8
// Inherited 8 bytes 
class FOnPerformAction_BP : public FOnPerformAction_BP
{

 public: 
	struct AActor* TargetActor;  // Offset: 0 Size: 8



 // Functions 
 public:
}; 
 
 //Function AIGABuff_Teleport_Command_BP.AIGABuff_Teleport_Command_BP_C.OnTeleport_BP Size 40
// Inherited 40 bytes 
class FOnTeleport_BP : public FOnTeleport_BP
{

 public: 
	struct FTeleportResponseRepData InTeleportRepData;  // Offset: 0 Size: 40



 // Functions 
 public:
}; 
 
 