#pragma once 
#include <ArkNavFilter_Floating_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkNavFilter_Floating.ArkNavFilter_Floating_C Size 152
// Inherited 152 bytes 
class UArkNavFilter_Floating_C : public UArkNavFilter_Base
{

 public: 



 // Functions 
 public:
}; 
 
 


