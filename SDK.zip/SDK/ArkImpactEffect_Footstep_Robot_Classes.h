#pragma once 
#include <ArkImpactEffect_Footstep_Robot_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkImpactEffect_Footstep_Robot.ArkImpactEffect_Footstep_Robot_C Size 504
// Inherited 504 bytes 
class UArkImpactEffect_Footstep_Robot_C : public UArkImpactEffect
{

 public: 



 // Functions 
 public:
}; 
 
 


