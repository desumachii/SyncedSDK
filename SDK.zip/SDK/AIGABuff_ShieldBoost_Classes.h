#pragma once 
#include <AIGABuff_ShieldBoost_Structs.h>
 
 
 
//BlueprintGeneratedClass AIGABuff_ShieldBoost.AIGABuff_ShieldBoost_C Size 1224
// Inherited 1224 bytes 
class UAIGABuff_ShieldBoost_C : public UArkAIGameplayAbilityBuff
{

 public: 



 // Functions 
 public:
}; 
 
 


