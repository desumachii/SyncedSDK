#pragma once 
#include <ArkDamageType_Radial_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkDamageType_Radial.ArkDamageType_Radial_C Size 264
// Inherited 264 bytes 
class UArkDamageType_Radial_C : public UArkDamageType
{

 public: 



 // Functions 
 public:
}; 
 
 


