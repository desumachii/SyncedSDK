#pragma once 
#include <AIGABuff_RecoveSelf_NotDying_Structs.h>
 
 
 
//BlueprintGeneratedClass AIGABuff_RecoveSelf_NotDying.AIGABuff_RecoveSelf_NotDying_C Size 1288
// Inherited 1288 bytes 
class UAIGABuff_RecoveSelf_NotDying_C : public UAIGABuff_RecoveSelf_Lv1_C
{

 public: 



 // Functions 
 public:
}; 
 
 


