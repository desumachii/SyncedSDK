#pragma once 
#include <ArkDamageType_ShockWave_electric_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkDamageType_ShockWave_electric.ArkDamageType_ShockWave_electric_C Size 264
// Inherited 264 bytes 
class UArkDamageType_ShockWave_electric_C : public UArkDamageType_ShockWave_C
{

 public: 



 // Functions 
 public:
}; 
 
 


