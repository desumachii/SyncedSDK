#pragma once 
#include <ArkImpactEffect_Crawl_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkImpactEffect_Crawl.ArkImpactEffect_Crawl_C Size 504
// Inherited 504 bytes 
class UArkImpactEffect_Crawl_C : public UArkImpactEffect
{

 public: 



 // Functions 
 public:
}; 
 
 


