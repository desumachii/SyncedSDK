#pragma once 
#include <ArkDamageType_CircleFixedDamage_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkDamageType_CircleFixedDamage.ArkDamageType_CircleFixedDamage_C Size 264
// Inherited 264 bytes 
class UArkDamageType_CircleFixedDamage_C : public UArkDamageType_ShockWave_C
{

 public: 



 // Functions 
 public:
}; 
 
 


