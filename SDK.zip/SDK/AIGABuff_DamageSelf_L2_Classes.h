#pragma once 
#include <AIGABuff_DamageSelf_L2_Structs.h>
 
 
 
//BlueprintGeneratedClass AIGABuff_DamageSelf_L2.AIGABuff_DamageSelf_L2_C Size 1240
// Inherited 1240 bytes 
class UAIGABuff_DamageSelf_L2_C : public UAIGABuff_DamageSelf_Base_C
{

 public: 



 // Functions 
 public:
}; 
 
 


