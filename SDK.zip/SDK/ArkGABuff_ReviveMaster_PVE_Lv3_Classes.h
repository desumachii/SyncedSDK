#pragma once 
#include <ArkGABuff_ReviveMaster_PVE_Lv3_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkGABuff_ReviveMaster_PVE_Lv3.ArkGABuff_ReviveMaster_PVE_Lv3_C Size 2080
// Inherited 2080 bytes 
class UArkGABuff_ReviveMaster_PVE_Lv3_C : public UArkGABuff_ReviveMaster_Lv1_C
{

 public: 



 // Functions 
 public:
}; 
 
 


