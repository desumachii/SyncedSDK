#pragma once 
#include <ArkAITacticalFollow_Attack_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkAITacticalFollow_Attack.ArkAITacticalFollow_Attack_C Size 392
// Inherited 392 bytes 
class UArkAITacticalFollow_Attack_C : public UArkAITacticalFollowCommand
{

 public: 



 // Functions 
 public:
}; 
 
 


