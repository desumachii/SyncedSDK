#pragma once 
#include <ArkDmgInfoComponent_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkDmgInfoComponent.ArkDmgInfoComponent_C Size 520
// Inherited 520 bytes 
class UArkDmgInfoComponent_C : public UArkDmgInfoComponent
{

 public: 



 // Functions 
 public:
}; 
 
 


