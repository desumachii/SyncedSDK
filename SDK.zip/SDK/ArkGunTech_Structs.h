#pragma once 
#include <SDK_Engine_Objects.h> 
 
 
//Function ArkGunTech.ArkGunTech_LaserChain.ClientSpawnLaserChainEffect Size 28
class FClientSpawnLaserChainEffect
{

 public: 
	struct FVector StartPoint;  // Offset: 0 Size: 12
	struct FVector TargetPoint;  // Offset: 12 Size: 12
	char pad_24_1 : 7;  // Offset: 24 Size: 1
	bool bIsMainChain : 1;  // Offset: 24 Size: 1
	char pad_25[3];  // Offset: 25 Size: 3



 // Functions 
 public:
}; 
 
 //Function ArkGunTech.ArkBlackHole.BlackHoleInit Size 152
class FBlackHoleInit
{

 public: 
	struct FHitResult Hit;  // Offset: 0 Size: 136
	int32_t HitFireID;  // Offset: 136 Size: 4
	char pad_140[4];  // Offset: 140 Size: 4
	struct AArkRangeWeapon* Weapon;  // Offset: 144 Size: 8



 // Functions 
 public:
}; 
 
 //Function ArkGunTech.ArkGunTech_BulletSplit.ApplySplitDamage Size 192
class FApplySplitDamage
{

 public: 
	struct AActor* DamagedActor;  // Offset: 0 Size: 8
	struct FHitResult Hit;  // Offset: 8 Size: 136
	int32_t HitFireID;  // Offset: 144 Size: 4
	struct FVector InitialLoc;  // Offset: 148 Size: 12
	struct FVector SpeedDir;  // Offset: 160 Size: 12
	char SplitTimes;  // Offset: 172 Size: 1
	char pad_173[3];  // Offset: 173 Size: 3
	struct TArray<struct AActor*> IgnoreActors;  // Offset: 176 Size: 16



 // Functions 
 public:
}; 
 
 //Function ArkGunTech.ArkGunTech_BulletSplit.DoBulletSplit Size 64
class FDoBulletSplit
{

 public: 
	struct FVector ShootDir;  // Offset: 0 Size: 12
	struct FVector Origin;  // Offset: 12 Size: 12
	int32_t FireID;  // Offset: 24 Size: 4
	struct FVector InitialLoc;  // Offset: 28 Size: 12
	char SplitTimes;  // Offset: 40 Size: 1
	char pad_41[7];  // Offset: 41 Size: 7
	struct TArray<struct AActor*> IgnoreActors;  // Offset: 48 Size: 16



 // Functions 
 public:
}; 
 
 //ScriptStruct ArkGunTech.ArkGunTechFirePlusHitInfo Size 16
class FArkGunTechFirePlusHitInfo
{

 public: 
	char HitTimes;  // Offset: 0 Size: 1
	char pad_1[7];  // Offset: 1 Size: 7
	struct FTimerHandle ClearTimerHandle;  // Offset: 8 Size: 8



 // Functions 
 public:
}; 
 
 //ScriptStruct ArkGunTech.ArkGunTechMusicBeatConfig Size 32
// Inherited 8 bytes 
class FArkGunTechMusicBeatConfig : public FTableRowBase
{

 public: 
	char BeatGroupID;  // Offset: 8 Size: 1
	char pad_9[3];  // Offset: 9 Size: 3
	uint32_t BeatNumber;  // Offset: 12 Size: 4
	float MusicSecond;  // Offset: 16 Size: 4
	char pad_20_1 : 7;  // Offset: 20 Size: 1
	bool bShowCrosshairCue : 1;  // Offset: 20 Size: 1
	char pad_21_1 : 7;  // Offset: 21 Size: 1
	bool bCanTriggerEffect : 1;  // Offset: 21 Size: 1
	char pad_22[2];  // Offset: 22 Size: 2
	float TriggerScore;  // Offset: 24 Size: 4
	char pad_28[4];  // Offset: 28 Size: 4



 // Functions 
 public:
}; 
 
 //ScriptStruct ArkGunTech.ArkLaserChainInfo Size 152
class FArkLaserChainInfo
{

 public: 
	struct AArkCharacterBase* LastHitChar;  // Offset: 0 Size: 8
	char pad_8_1 : 7;  // Offset: 8 Size: 1
	bool bSuccessJumped : 1;  // Offset: 8 Size: 1
	char pad_9[3];  // Offset: 9 Size: 3
	int32_t jumpCount;  // Offset: 12 Size: 4
	struct FHitResult CurHitResult;  // Offset: 16 Size: 136



 // Functions 
 public:
}; 
 
 //Function ArkGunTech.ArkPlasmaBall.PlayHitEffect Size 144
class FPlayHitEffect
{

 public: 
	struct FHitResult Hit;  // Offset: 0 Size: 136
	struct AArkRangeWeapon* InWeapon;  // Offset: 136 Size: 8



 // Functions 
 public:
}; 
 
 //Function ArkGunTech.ArkGunTech_FirePluse.ClientSpawnExplodeEffect Size 48
class FClientSpawnExplodeEffect
{

 public: 
	struct FTransform SpawnTrans;  // Offset: 0 Size: 48



 // Functions 
 public:
}; 
 
 //Function ArkGunTech.ArkGunTech_BlackHole.ClientOnBlackHoleSpawn Size 48
class FClientOnBlackHoleSpawn
{

 public: 
	struct FTransform SpawnTrans;  // Offset: 0 Size: 48



 // Functions 
 public:
}; 
 
 //Function ArkGunTech.ArkGunTech_DeepBreath.CallMagzineFullHUDTips Size 16
class FCallMagzineFullHUDTips
{

 public: 
	struct AArkRangeWeapon* Weapon;  // Offset: 0 Size: 8
	float Duration;  // Offset: 8 Size: 4
	char pad_12[4];  // Offset: 12 Size: 4



 // Functions 
 public:
}; 
 
 //Function ArkGunTech.ArkGunTech_FirePluse.ClientSpawnDrawAmmoEffect Size 12
class FClientSpawnDrawAmmoEffect
{

 public: 
	struct FVector spawnLoc;  // Offset: 0 Size: 12



 // Functions 
 public:
}; 
 
 //Function ArkGunTech.ArkGunTech_TripleShoot.CallServerNotifySpawnBullet Size 32
class FCallServerNotifySpawnBullet
{

 public: 
	struct FVector ShootDir;  // Offset: 0 Size: 12
	float ConeHalfAngleYaw;  // Offset: 12 Size: 4
	struct FVector Origin;  // Offset: 16 Size: 12
	int32_t FireID;  // Offset: 28 Size: 4



 // Functions 
 public:
}; 
 
 //Function ArkGunTech.ArkGunTech_TripleShoot.SimulatedSpawnBullet Size 32
class FSimulatedSpawnBullet
{

 public: 
	struct FVector ShootDir;  // Offset: 0 Size: 12
	float ConeHalfAngleYaw;  // Offset: 12 Size: 4
	struct FVector Origin;  // Offset: 16 Size: 12
	int32_t FireID;  // Offset: 28 Size: 4



 // Functions 
 public:
}; 
 
 //Function ArkGunTech.ArkGunTech_LaserChain.ServerSpawnLaserChainEffect Size 28
class FServerSpawnLaserChainEffect
{

 public: 
	struct FVector StartPoint;  // Offset: 0 Size: 12
	struct FVector TargetPoint;  // Offset: 12 Size: 12
	char pad_24_1 : 7;  // Offset: 24 Size: 1
	bool bIsMainChain : 1;  // Offset: 24 Size: 1
	char pad_25[3];  // Offset: 25 Size: 3



 // Functions 
 public:
}; 
 
 //Function ArkGunTech.ArkGunTech_Homeward.InternalHandleAfterFire Size 4
class FInternalHandleAfterFire
{

 public: 
	int32_t FireID;  // Offset: 0 Size: 4



 // Functions 
 public:
}; 
 
 //Function ArkGunTech.ArkGunTechSpikes.ApplyBackWardDamage Size 152
class FApplyBackWardDamage
{

 public: 
	struct AActor* DamagedActor;  // Offset: 0 Size: 8
	struct FHitResult Hit;  // Offset: 8 Size: 136
	int32_t HitFireID;  // Offset: 144 Size: 4
	char pad_148[4];  // Offset: 148 Size: 4



 // Functions 
 public:
}; 
 
 //Function ArkGunTech.ArkGunTech_PosionLauncher.PlayHitSound Size 12
class FPlayHitSound
{

 public: 
	struct FVector_NetQuantize ImpactPoint;  // Offset: 0 Size: 12



 // Functions 
 public:
}; 
 
 //Function ArkGunTech.ArkGunTechSpikes.ApplyPenetrateDamage Size 152
class FApplyPenetrateDamage
{

 public: 
	struct AActor* DamagedActor;  // Offset: 0 Size: 8
	struct FHitResult Hit;  // Offset: 8 Size: 136
	int32_t HitFireID;  // Offset: 144 Size: 4
	int32_t HitTimes;  // Offset: 148 Size: 4



 // Functions 
 public:
}; 
 
 //Function ArkGunTech.ArkGunTech_ReboundSplit.ServerDoBulletSplit Size 64
class FServerDoBulletSplit
{

 public: 
	struct FVector Velocity;  // Offset: 0 Size: 12
	struct FVector HitPoint;  // Offset: 12 Size: 12
	struct FVector HitNormal;  // Offset: 24 Size: 12
	int32_t FireID;  // Offset: 36 Size: 4
	struct FVector InitialLoc;  // Offset: 40 Size: 12
	char pad_52_1 : 7;  // Offset: 52 Size: 1
	bool bIsHitCharacter : 1;  // Offset: 52 Size: 1
	char pad_53[3];  // Offset: 53 Size: 3
	struct AActor* hitActor;  // Offset: 56 Size: 8



 // Functions 
 public:
}; 
 
 //Function ArkGunTech.ArkPlasmaBall.PlasmaBallInit Size 152
class FPlasmaBallInit
{

 public: 
	struct FHitResult Hit;  // Offset: 0 Size: 136
	int32_t HitFireID;  // Offset: 136 Size: 4
	char pad_140[4];  // Offset: 140 Size: 4
	struct AArkRangeWeapon* Weapon;  // Offset: 144 Size: 8



 // Functions 
 public:
}; 
 
 //Function ArkGunTech.ArkGunTech_ReboundSplit.SimulatedDoBulletSplit Size 64
class FSimulatedDoBulletSplit
{

 public: 
	struct FVector Velocity;  // Offset: 0 Size: 12
	struct FVector HitPoint;  // Offset: 12 Size: 12
	struct FVector HitNormal;  // Offset: 24 Size: 12
	int32_t FireID;  // Offset: 36 Size: 4
	struct FVector InitialLoc;  // Offset: 40 Size: 12
	char pad_52_1 : 7;  // Offset: 52 Size: 1
	bool bIsHitCharacter : 1;  // Offset: 52 Size: 1
	char pad_53[3];  // Offset: 53 Size: 3
	struct AActor* hitActor;  // Offset: 56 Size: 8



 // Functions 
 public:
}; 
 
 //Function ArkGunTech.ArkGunTech_SoundWave.ChangeLevel Size 1
class FChangeLevel
{

 public: 
	char inLevel;  // Offset: 0 Size: 1



 // Functions 
 public:
}; 
 
 //Function ArkGunTech.ArkGunTechCrosshair_SoundWave.SetCurrentScore Size 8
class FSetCurrentScore
{

 public: 
	char Level;  // Offset: 0 Size: 1
	char pad_1[3];  // Offset: 1 Size: 3
	float Percent;  // Offset: 4 Size: 4



 // Functions 
 public:
}; 
 
 //Function ArkGunTech.ArkGunTech_SoundWave.NetMulticast_SetTriggeredType Size 2
class FNetMulticast_SetTriggeredType
{

 public: 
	enum class EArkTriggerBeatType Type;  // Offset: 0 Size: 1
	char pad_1_1 : 7;  // Offset: 1 Size: 1
	bool bAdd : 1;  // Offset: 1 Size: 1



 // Functions 
 public:
}; 
 
 //Function ArkGunTech.ArkGunTech_SoundWave.Server_SetTriggeredType Size 2
class FServer_SetTriggeredType
{

 public: 
	enum class EArkTriggerBeatType Type;  // Offset: 0 Size: 1
	char pad_1_1 : 7;  // Offset: 1 Size: 1
	bool bAdd : 1;  // Offset: 1 Size: 1



 // Functions 
 public:
}; 
 
 //Function ArkGunTech.ArkGunTech_SoundWave.StartMusicTimer Size 16
class FStartMusicTimer
{

 public: 
	enum class EAkCallbackType CallbackType;  // Offset: 0 Size: 1
	char pad_1[7];  // Offset: 1 Size: 7
	struct UAkCallbackInfo* CallbackInfo;  // Offset: 8 Size: 8



 // Functions 
 public:
}; 
 
 //Function ArkGunTech.ArkGunTech_SoundWave.TryTriggerBeat Size 1
class FTryTriggerBeat
{

 public: 
	enum class EArkTriggerBeatType Type;  // Offset: 0 Size: 1



 // Functions 
 public:
}; 
 
 //Function ArkGunTech.ArkGunTechCrosshair_FirePluse.SetEnergy Size 4
class FSetEnergy
{

 public: 
	float inEnergy;  // Offset: 0 Size: 4



 // Functions 
 public:
}; 
 
 //Function ArkGunTech.ArkGunTechCrosshair_SoundWave.HideBeat Size 1
class FHideBeat
{

 public: 
	char pad_0_1 : 7;  // Offset: 0 Size: 1
	bool bIsTriggered : 1;  // Offset: 0 Size: 1



 // Functions 
 public:
}; 
 
 //Function ArkGunTech.ArkGunTechCrosshair_SoundWave.GetBeatFromPool Size 8
class FGetBeatFromPool
{

 public: 
	struct UArkUserWidgetBase* ReturnValue;  // Offset: 0 Size: 8



 // Functions 
 public:
}; 
 
 //Function ArkGunTech.ArkGunTechCrosshair_SoundWave.ReturnBeatToPool Size 8
class FReturnBeatToPool
{

 public: 
	struct UArkUserWidgetBase* beat;  // Offset: 0 Size: 8



 // Functions 
 public:
}; 
 
 //Function ArkGunTech.ArkGunTechCrosshair_SoundWave.SpawnBeat Size 4
class FSpawnBeat
{

 public: 
	float Offset;  // Offset: 0 Size: 4



 // Functions 
 public:
}; 
 
 //Function ArkGunTech.ArkGunTechSpikes.ApplySpinDamage Size 80
class FApplySpinDamage
{

 public: 
	struct FVector BoxExtent;  // Offset: 0 Size: 12
	char pad_12[4];  // Offset: 12 Size: 4
	struct FTransform BoxTransform;  // Offset: 16 Size: 48
	float DamageMultiplier;  // Offset: 64 Size: 4
	int32_t PackedFireAmmoInfo;  // Offset: 68 Size: 4
	char pad_72[8];  // Offset: 72 Size: 8



 // Functions 
 public:
}; 
 
 //Function ArkGunTech.ArkGunTechSpikes.SetBackingBullet Size 8
class FSetBackingBullet
{

 public: 
	int32_t BulletID;  // Offset: 0 Size: 4
	char pad_4_1 : 7;  // Offset: 4 Size: 1
	bool bIsBacking : 1;  // Offset: 4 Size: 1
	char pad_5[3];  // Offset: 5 Size: 3



 // Functions 
 public:
}; 
 
 //Function ArkGunTech.ArkProjectile_SpinningLeaf.PlayFlyBackSound Size 8
class FPlayFlyBackSound
{

 public: 
	struct AArkRangeWeapon* Weapon;  // Offset: 0 Size: 8



 // Functions 
 public:
}; 
 
 //Function ArkGunTech.ArkProjectile_SpinningLeaf.OnRangeWeaponReloaded Size 8
class FOnRangeWeaponReloaded
{

 public: 
	struct AArkRangeWeapon* Weapon;  // Offset: 0 Size: 8



 // Functions 
 public:
}; 
 
 //Function ArkGunTech.ArkProjectile_Split.AddIgnoreActor Size 8
class FAddIgnoreActor
{

 public: 
	struct AActor* Actor;  // Offset: 0 Size: 8



 // Functions 
 public:
}; 
 
 //Function ArkGunTech.ArkProjectile_Split.SetSplitTimes Size 1
class FSetSplitTimes
{

 public: 
	char Num;  // Offset: 0 Size: 1



 // Functions 
 public:
}; 
 
 