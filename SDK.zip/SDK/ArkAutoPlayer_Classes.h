#pragma once 
#include <ArkAutoPlayer_Structs.h>
 
 
 
//Class ArkAutoPlayer.ArkAutoPlayerTaskLookAround Size 96
// Inherited 88 bytes 
class UArkAutoPlayerTaskLookAround : public UArkAutoPlayerTaskBase
{

 public: 
	float Speed;  // Offset: 88 Size: 4
	char pad_92[4];  // Offset: 92 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkAutoPlayer.ArkAutoPlayerTaskUseHealthPack Size 96
// Inherited 88 bytes 
class UArkAutoPlayerTaskUseHealthPack : public UArkAutoPlayerTaskBase
{

 public: 
	char pad_88[8];  // Offset: 88 Size: 8



 // Functions 
 public:
}; 
 
 


//Class ArkAutoPlayer.ArkAutoPlayerServiceSpot Size 104
// Inherited 72 bytes 
class UArkAutoPlayerServiceSpot : public UArkAutoPlayerServiceBase
{

 public: 
	struct TArray<enum class EAutoPlayerSpotType> SpotTypes;  // Offset: 72 Size: 16
	float PlayerRadius;  // Offset: 88 Size: 4
	float NpcRadius;  // Offset: 92 Size: 4
	char pad_96[8];  // Offset: 96 Size: 8



 // Functions 
 public:
	void OnOptionChange(struct FArkAuotPlayerSpotOption& Option); // Function ArkAutoPlayer.ArkAutoPlayerServiceSpot.OnOptionChange
}; 
 
 


//Class ArkAutoPlayer.ArkAutoPlayerServiceMoveTo Size 280
// Inherited 72 bytes 
class UArkAutoPlayerServiceMoveTo : public UArkAutoPlayerServiceBase
{

 public: 
	char pad_72[72];  // Offset: 72 Size: 72
	struct TArray<uint32_t> NavLinkIDs;  // Offset: 144 Size: 16
	struct TArray<struct FVector> FollowPath;  // Offset: 160 Size: 16
	char pad_176[96];  // Offset: 176 Size: 96
	struct UArkAutoPlayerTaskBase* OwnerTask;  // Offset: 272 Size: 8



 // Functions 
 public:
	void OnStopMove(); // Function ArkAutoPlayer.ArkAutoPlayerServiceMoveTo.OnStopMove
	void OnNeedMove(struct FArkAutoPlayerNeedMove& MoveInfo); // Function ArkAutoPlayer.ArkAutoPlayerServiceMoveTo.OnNeedMove
	void NotifyGetPathFollow(struct TArray<struct FVector>& Path, struct TArray<uint32_t>& PathNavLinkIDs); // Function ArkAutoPlayer.ArkAutoPlayerServiceMoveTo.NotifyGetPathFollow
}; 
 
 


//Class ArkAutoPlayer.ArkAutoPlayerServiceBase Size 72
// Inherited 40 bytes 
class UArkAutoPlayerServiceBase : public UObject
{

 public: 
	struct AArkAutoPlayerTaskGroup* MyGroup;  // Offset: 40 Size: 8
	char pad_48[8];  // Offset: 48 Size: 8
	struct AArkPlayer* MyPlayer;  // Offset: 56 Size: 8
	struct AArkPlayerControllerBattle* MyPC;  // Offset: 64 Size: 8



 // Functions 
 public:
}; 
 
 


//Class ArkAutoPlayer.ArkAutoPlayerComponent Size 1248
// Inherited 480 bytes 
class UArkAutoPlayerComponent : public UActorComponent
{

 public: 
	char pad_480[40];  // Offset: 480 Size: 40
	AArkRobotController* RobotClass;  // Offset: 520 Size: 8
	struct FArkRobotStrategyOption StrategyOption;  // Offset: 528 Size: 32
	struct FArkRobotActionScore ActionScore;  // Offset: 560 Size: 296
	struct FArkRobotHostileInfo HostileInfo;  // Offset: 856 Size: 128
	struct TArray<struct FRobotHostileInfo> HostileList;  // Offset: 984 Size: 16
	struct AActor* CurTarget;  // Offset: 1000 Size: 8
	struct AArkPlayerControllerBattle* MyPC;  // Offset: 1008 Size: 8
	struct FMulticastInlineDelegate OnServiceFindPathEnd;  // Offset: 1016 Size: 16
	struct FMulticastInlineDelegate OnShuttleLand;  // Offset: 1032 Size: 16
	struct FMulticastInlineDelegate OnPickUped;  // Offset: 1048 Size: 16
	char pad_1064[8];  // Offset: 1064 Size: 8
	struct AArkAutoPlayerTaskGroup* CurrentTaskGroup;  // Offset: 1072 Size: 8
	char pad_1080[168];  // Offset: 1080 Size: 168



 // Functions 
 public:
	void Stop(); // Function ArkAutoPlayer.ArkAutoPlayerComponent.Stop
	void Start(struct FString& OpenCommand); // Function ArkAutoPlayer.ArkAutoPlayerComponent.Start
	void ServerUnBindFunctionOnGameEnd(); // Function ArkAutoPlayer.ArkAutoPlayerComponent.ServerUnBindFunctionOnGameEnd
	void ServerSetPlayerLoc(struct FVector NewLoc); // Function ArkAutoPlayer.ArkAutoPlayerComponent.ServerSetPlayerLoc
	void ServerNotifyShuttleStateChanged(enum class EArkShuttleStateType LastState, enum class EArkShuttleStateType NewState, float StartTime, int32_t OwnShuttleID); // Function ArkAutoPlayer.ArkAutoPlayerComponent.ServerNotifyShuttleStateChanged
	void ServerFindPath(struct FVector GoalLoc); // Function ArkAutoPlayer.ArkAutoPlayerComponent.ServerFindPath
	void ServerBindShuttleStateChanged(); // Function ArkAutoPlayer.ArkAutoPlayerComponent.ServerBindShuttleStateChanged
	void ServerBindFunctionOnGameEnd(); // Function ArkAutoPlayer.ArkAutoPlayerComponent.ServerBindFunctionOnGameEnd
	void OnGameFlowChange(enum class EArkGameFlowType LastMode, enum class EArkGameFlowType NewMode, float StartTime); // Function ArkAutoPlayer.ArkAutoPlayerComponent.OnGameFlowChange
	void NotifyShuttleStateChanged(struct AActor* Shuttle); // Function ArkAutoPlayer.ArkAutoPlayerComponent.NotifyShuttleStateChanged
	void NotifyGameEnd(); // Function ArkAutoPlayer.ArkAutoPlayerComponent.NotifyGameEnd
	void ClientOnFindPath(struct TArray<struct FVector> Path, struct TArray<uint32_t> PathNavLinkIDs); // Function ArkAutoPlayer.ArkAutoPlayerComponent.ClientOnFindPath
	void ClientCheckCommand(); // Function ArkAutoPlayer.ArkAutoPlayerComponent.ClientCheckCommand
}; 
 
 


//Class ArkAutoPlayer.ArkAutoPlayerTaskBase Size 88
// Inherited 40 bytes 
class UArkAutoPlayerTaskBase : public UObject
{

 public: 
	float ExecuteDuraion;  // Offset: 40 Size: 4
	float ExecuteColdTime;  // Offset: 44 Size: 4
	struct AArkAutoPlayerTaskGroup* MyGroup;  // Offset: 48 Size: 8
	char pad_56[32];  // Offset: 56 Size: 32



 // Functions 
 public:
}; 
 
 


//Class ArkAutoPlayer.ArkAutoPlayerTaskAttack Size 144
// Inherited 88 bytes 
class UArkAutoPlayerTaskAttack : public UArkAutoPlayerTaskBase
{

 public: 
	char pad_88_1 : 7;  // Offset: 88 Size: 1
	bool bAttackNPC : 1;  // Offset: 88 Size: 1
	char pad_89_1 : 7;  // Offset: 89 Size: 1
	bool bAttackPlayer : 1;  // Offset: 89 Size: 1
	char pad_90[38];  // Offset: 90 Size: 38
	struct AArkRangeWeapon* RecoredWeapon;  // Offset: 128 Size: 8
	char pad_136[8];  // Offset: 136 Size: 8



 // Functions 
 public:
	void Supervise(); // Function ArkAutoPlayer.ArkAutoPlayerTaskAttack.Supervise
}; 
 
 


//Class ArkAutoPlayer.ArkAutoPlayerTaskOperateDeathBag Size 136
// Inherited 88 bytes 
class UArkAutoPlayerTaskOperateDeathBag : public UArkAutoPlayerTaskBase
{

 public: 
	struct TArray<struct AActor*> VisitedBags;  // Offset: 88 Size: 16
	struct AArkDeathCrate* CurrentBag;  // Offset: 104 Size: 8
	char pad_112[24];  // Offset: 112 Size: 24



 // Functions 
 public:
}; 
 
 


//Class ArkAutoPlayer.ArkAutoPlayerTaskGroup Size 1080
// Inherited 744 bytes 
class AArkAutoPlayerTaskGroup : public AActor
{

 public: 
	struct TMap<UArkAutoPlayerTaskBase*, int32_t> ConfigTasks;  // Offset: 744 Size: 80
	struct TArray<struct UArkAutoPlayerTaskBase*> Tasks;  // Offset: 824 Size: 16
	struct UArkAutoPlayerTaskBase* CurTask;  // Offset: 840 Size: 8
	struct TArray<struct FPerformance> RecordPerformances;  // Offset: 848 Size: 16
	struct TArray<struct FTask> RecordTasks;  // Offset: 864 Size: 16
	struct FAutoPlayerBlackBoard Board;  // Offset: 880 Size: 120
	struct TArray<struct UArkAutoPlayerServiceBase*> Services;  // Offset: 1000 Size: 16
	struct UArkAutoPlayerServiceMoveTo* ServiceMoveTo;  // Offset: 1016 Size: 8
	char pad_1024[32];  // Offset: 1024 Size: 32
	struct TArray<UArkAutoPlayerServiceBase*> ServiceClass;  // Offset: 1056 Size: 16
	char pad_1072[8];  // Offset: 1072 Size: 8



 // Functions 
 public:
}; 
 
 


//Class ArkAutoPlayer.ArkAutoPlayerTaskMove Size 176
// Inherited 88 bytes 
class UArkAutoPlayerTaskMove : public UArkAutoPlayerTaskBase
{

 public: 
	char pad_88_1 : 7;  // Offset: 88 Size: 1
	bool bFixedMove : 1;  // Offset: 88 Size: 1
	char pad_89_1 : 7;  // Offset: 89 Size: 1
	bool bBasinMove : 1;  // Offset: 89 Size: 1
	char pad_90_1 : 7;  // Offset: 90 Size: 1
	bool bLootShuttle : 1;  // Offset: 90 Size: 1
	char pad_91[5];  // Offset: 91 Size: 5
	struct TArray<struct FVector> FixedPoi;  // Offset: 96 Size: 16
	struct TArray<struct FVector> BasinPoi;  // Offset: 112 Size: 16
	struct TArray<struct FVector> FinishedPois;  // Offset: 128 Size: 16
	char pad_144[32];  // Offset: 144 Size: 32



 // Functions 
 public:
	void NotifyShuttleLand(struct AActor* Shuttle_); // Function ArkAutoPlayer.ArkAutoPlayerTaskMove.NotifyShuttleLand
	void LoseShuttle(); // Function ArkAutoPlayer.ArkAutoPlayerTaskMove.LoseShuttle
}; 
 
 


//Class ArkAutoPlayer.ArkAutoPlayerTaskOpenSafeHouse Size 120
// Inherited 88 bytes 
class UArkAutoPlayerTaskOpenSafeHouse : public UArkAutoPlayerTaskBase
{

 public: 
	char pad_88[8];  // Offset: 88 Size: 8
	struct AArkSafeHouseDoor* HouseDoor;  // Offset: 96 Size: 8
	struct TArray<struct AArkSafeHouseDoor*> OpenedDoor;  // Offset: 104 Size: 16



 // Functions 
 public:
	void Supervise(); // Function ArkAutoPlayer.ArkAutoPlayerTaskOpenSafeHouse.Supervise
}; 
 
 


//Class ArkAutoPlayer.ArkAutoPlayerTaskPickUp Size 152
// Inherited 88 bytes 
class UArkAutoPlayerTaskPickUp : public UArkAutoPlayerTaskBase
{

 public: 
	char pad_88[16];  // Offset: 88 Size: 16
	struct AArkPickUp* FindedPickUp;  // Offset: 104 Size: 8
	struct TArray<struct AArkPickUp*> GiveUpPickUps;  // Offset: 112 Size: 16
	char pad_128[24];  // Offset: 128 Size: 24



 // Functions 
 public:
	void Supervise(); // Function ArkAutoPlayer.ArkAutoPlayerTaskPickUp.Supervise
	void OnMoveEnd(enum class EServiceNotify Notify_); // Function ArkAutoPlayer.ArkAutoPlayerTaskPickUp.OnMoveEnd
}; 
 
 


//Class ArkAutoPlayer.ArkAutoPlayerTaskSync Size 112
// Inherited 88 bytes 
class UArkAutoPlayerTaskSync : public UArkAutoPlayerTaskBase
{

 public: 
	float SyncSearchRange;  // Offset: 88 Size: 4
	char pad_92[4];  // Offset: 92 Size: 4
	struct AArkNpc* SyncNpcTarget;  // Offset: 96 Size: 8
	char pad_104[8];  // Offset: 104 Size: 8



 // Functions 
 public:
	void Supervise(); // Function ArkAutoPlayer.ArkAutoPlayerTaskSync.Supervise
	void OnSyncFinish(struct UObject* TargetObjRef, enum class EArkInteractionType InteractionType, bool bCancelled, float RemainingTime); // Function ArkAutoPlayer.ArkAutoPlayerTaskSync.OnSyncFinish
}; 
 
 


//Class ArkAutoPlayer.ArkAutoPlayerTaskTeleport Size 128
// Inherited 88 bytes 
class UArkAutoPlayerTaskTeleport : public UArkAutoPlayerTaskBase
{

 public: 
	AActor* NodeClass;  // Offset: 88 Size: 8
	float WaitTime;  // Offset: 96 Size: 4
	char pad_100[4];  // Offset: 100 Size: 4
	struct TArray<struct AActor*> Nodes;  // Offset: 104 Size: 16
	char pad_120[8];  // Offset: 120 Size: 8



 // Functions 
 public:
}; 
 
 


//Class ArkAutoPlayer.ArkAutoPlayerTaskUseSkill Size 104
// Inherited 88 bytes 
class UArkAutoPlayerTaskUseSkill : public UArkAutoPlayerTaskBase
{

 public: 
	char pad_88[16];  // Offset: 88 Size: 16



 // Functions 
 public:
}; 
 
 


