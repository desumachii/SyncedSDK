#pragma once 
#include <AIGABuff_RecoveSelf_Lv1_Structs.h>
 
 
 
//BlueprintGeneratedClass AIGABuff_RecoveSelf_Lv1.AIGABuff_RecoveSelf_Lv1_C Size 1288
// Inherited 1288 bytes 
class UAIGABuff_RecoveSelf_Lv1_C : public UArkAIGABuff_RecoverSelf
{

 public: 



 // Functions 
 public:
}; 
 
 


