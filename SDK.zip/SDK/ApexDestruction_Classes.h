#pragma once 
#include <ApexDestruction_Structs.h>
 
 
 
//Class ApexDestruction.DestructibleActor Size 768
// Inherited 744 bytes 
class ADestructibleActor : public AActor
{

 public: 
	struct UDestructibleComponent* DestructibleComponent;  // Offset: 744 Size: 8
	struct FMulticastInlineDelegate OnActorFracture;  // Offset: 752 Size: 16



 // Functions 
 public:
}; 
 
 


//Class ApexDestruction.DestructibleComponent Size 2704
// Inherited 2480 bytes 
class UDestructibleComponent : public USkinnedMeshComponent
{

 public: 
	char bFractureEffectOverride : 1;  // Offset: 2480 Size: 1
	char pad_2480_1 : 7;  // Offset: 2480 Size: 1
	char pad_2481[8];  // Offset: 2481 Size: 8
	struct TArray<struct FFractureEffect> FractureEffects;  // Offset: 2488 Size: 16
	char pad_2504_1 : 7;  // Offset: 2504 Size: 1
	bool bEnableHardSleeping : 1;  // Offset: 2504 Size: 1
	char pad_2505[3];  // Offset: 2505 Size: 3
	float LargeChunkThreshold;  // Offset: 2508 Size: 4
	char pad_2512[16];  // Offset: 2512 Size: 16
	struct FMulticastInlineDelegate OnComponentFracture;  // Offset: 2528 Size: 16
	char pad_2544[136];  // Offset: 2544 Size: 136
	char pad_2680_1 : 7;  // Offset: 2680 Size: 1
	bool bUseCustomTakeDamageProcess : 1;  // Offset: 2680 Size: 1
	char pad_2681[15];  // Offset: 2681 Size: 15
	int32_t UID;  // Offset: 2696 Size: 4
	char pad_2700[4];  // Offset: 2700 Size: 4



 // Functions 
 public:
	void SetDestructibleMesh(struct UDestructibleMesh* NewMesh); // Function ApexDestruction.DestructibleComponent.SetDestructibleMesh
	struct UDestructibleMesh* GetDestructibleMesh(); // Function ApexDestruction.DestructibleComponent.GetDestructibleMesh
	void ApplyRadiusDamage(float BaseDamage, struct FVector& HurtOrigin, float DamageRadius, float ImpulseStrength, bool bFullDamage); // Function ApexDestruction.DestructibleComponent.ApplyRadiusDamage
	void ApplyDamage(float DamageAmount, struct FVector& HitLocation, struct FVector& ImpulseDir, float ImpulseStrength); // Function ApexDestruction.DestructibleComponent.ApplyDamage
}; 
 
 


//Class ApexDestruction.DestructibleFractureSettings Size 184
// Inherited 40 bytes 
class UDestructibleFractureSettings : public UObject
{

 public: 
	int32_t CellSiteCount;  // Offset: 40 Size: 4
	struct FFractureMaterial FractureMaterialDesc;  // Offset: 44 Size: 36
	int32_t RandomSeed;  // Offset: 80 Size: 4
	char pad_84[4];  // Offset: 84 Size: 4
	struct TArray<struct FVector> VoronoiSites;  // Offset: 88 Size: 16
	int32_t OriginalSubmeshCount;  // Offset: 104 Size: 4
	char pad_108[4];  // Offset: 108 Size: 4
	struct TArray<struct UMaterialInterface*> Materials;  // Offset: 112 Size: 16
	struct TArray<struct FDestructibleChunkParameters> ChunkParameters;  // Offset: 128 Size: 16
	char pad_144[40];  // Offset: 144 Size: 40



 // Functions 
 public:
}; 
 
 


//Class ApexDestruction.DestructibleMesh Size 1088
// Inherited 928 bytes 
class UDestructibleMesh : public USkeletalMesh
{

 public: 
	struct FDestructibleParameters DefaultDestructibleParameters;  // Offset: 928 Size: 136
	struct TArray<struct FFractureEffect> FractureEffects;  // Offset: 1064 Size: 16
	char pad_1080[8];  // Offset: 1080 Size: 8



 // Functions 
 public:
}; 
 
 


