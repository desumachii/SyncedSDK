#pragma once 
#include <ArkDamageType_MeleeThrowable_Enhenced_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkDamageType_MeleeThrowable_Enhenced.ArkDamageType_MeleeThrowable_Enhenced_C Size 264
// Inherited 264 bytes 
class UArkDamageType_MeleeThrowable_Enhenced_C : public UArkDamageType_Melee_PlayerHitReaction_Enhenced_C
{

 public: 



 // Functions 
 public:
}; 
 
 


