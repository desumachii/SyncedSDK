#pragma once 
#include <SDK_Engine_Objects.h> 
 
 
//Function ArkGrenadeLauncherBullet_GT.ArkGrenadeLauncherBullet_GT_C.ExecuteUbergraph_ArkGrenadeLauncherBullet_GT Size 368
class FExecuteUbergraph_ArkGrenadeLauncherBullet_GT
{

 public: 
	int32_t EntryPoint;  // Offset: 0 Size: 4
	struct FDelegate Temp_delegate_Variable;  // Offset: 4 Size: 16
	char pad_20[4];  // Offset: 20 Size: 4
	struct TMap<struct FString, float> Temp_string_Variable;  // Offset: 24 Size: 80
	struct TArray<struct FString> Temp_string_Variable_2;  // Offset: 104 Size: 16
	struct FDelegate Temp_delegate_Variable_2;  // Offset: 120 Size: 16
	struct TMap<struct FString, float> Temp_string_Variable_3;  // Offset: 136 Size: 80
	struct TArray<struct FString> Temp_string_Variable_4;  // Offset: 216 Size: 16
	struct FHitResult K2Node_Event_HitResult;  // Offset: 232 Size: 136



 // Functions 
 public:
}; 
 
 //Function ArkGrenadeLauncherBullet_GT.ArkGrenadeLauncherBullet_GT_C.C2BP_OnExploded Size 136
// Inherited 136 bytes 
class FC2BP_OnExploded : public FC2BP_OnExploded
{

 public: 
	struct FHitResult HitResult;  // Offset: 0 Size: 136



 // Functions 
 public:
}; 
 
 