#pragma once 
#include <ArkNavArea_DoorOpen_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkNavArea_DoorOpen.ArkNavArea_DoorOpen_C Size 72
// Inherited 72 bytes 
class UArkNavArea_DoorOpen_C : public UNavArea
{

 public: 



 // Functions 
 public:
}; 
 
 


