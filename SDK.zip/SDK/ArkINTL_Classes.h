#pragma once 
#include <ArkINTL_Structs.h>
 
 
 
//Class ArkINTL.ArkINTLComplianceObserver Size 64
// Inherited 40 bytes 
class UArkINTLComplianceObserver : public UObject
{

 public: 
	char pad_40[8];  // Offset: 40 Size: 8
	struct UObject* curWorld;  // Offset: 48 Size: 8
	struct UArkUserDataModel* CurUserDataModel;  // Offset: 56 Size: 8



 // Functions 
 public:
	struct UObject* GetCurWorld(); // Function ArkINTL.ArkINTLComplianceObserver.GetCurWorld
}; 
 
 


//Class ArkINTL.ArkINTLNoticeObserver Size 64
// Inherited 40 bytes 
class UArkINTLNoticeObserver : public UObject
{

 public: 
	char pad_40[24];  // Offset: 40 Size: 24



 // Functions 
 public:
}; 
 
 


