#pragma once 
#include <SDK_Engine_Objects.h> 
 
 
//Function ArkINTL.ArkINTLComplianceObserver.GetCurWorld Size 8
class FGetCurWorld
{

 public: 
	struct UObject* ReturnValue;  // Offset: 0 Size: 8



 // Functions 
 public:
}; 
 
 