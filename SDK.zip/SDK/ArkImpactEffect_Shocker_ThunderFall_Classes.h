#pragma once 
#include <ArkImpactEffect_Shocker_ThunderFall_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkImpactEffect_Shocker_ThunderFall.ArkImpactEffect_Shocker_ThunderFall_C Size 504
// Inherited 504 bytes 
class UArkImpactEffect_Shocker_ThunderFall_C : public UArkImpactEffect_RangeWeapon_C
{

 public: 



 // Functions 
 public:
}; 
 
 


