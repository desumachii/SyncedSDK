#pragma once 
#include <SDK_Engine_Objects.h> 
 
 
//DelegateFunction ArkAutoPlayer.ServiceNotifySignature__DelegateSignature Size 1
class FServiceNotifySignature__DelegateSignature
{

 public: 
	enum class EServiceNotify Notify;  // Offset: 0 Size: 1



 // Functions 
 public:
}; 
 
 //Function ArkAutoPlayer.ArkAutoPlayerComponent.ServerFindPath Size 12
class FServerFindPath
{

 public: 
	struct FVector GoalLoc;  // Offset: 0 Size: 12



 // Functions 
 public:
}; 
 
 //DelegateFunction ArkAutoPlayer.ServiceFindPathEndSignature__DelegateSignature Size 32
class FServiceFindPathEndSignature__DelegateSignature
{

 public: 
	struct TArray<struct FVector> Path;  // Offset: 0 Size: 16
	struct TArray<uint32_t> PathNavLinkIDs;  // Offset: 16 Size: 16



 // Functions 
 public:
}; 
 
 //ScriptStruct ArkAutoPlayer.ArkAuotPlayerSpotOption Size 2
class FArkAuotPlayerSpotOption
{

 public: 
	char pad_0[2];  // Offset: 0 Size: 2



 // Functions 
 public:
}; 
 
 //DelegateFunction ArkAutoPlayer.OnAuotPlayerChangeSpotOption__DelegateSignature Size 2
class FOnAuotPlayerChangeSpotOption__DelegateSignature
{

 public: 
	struct FArkAuotPlayerSpotOption Option;  // Offset: 0 Size: 2



 // Functions 
 public:
}; 
 
 //ScriptStruct ArkAutoPlayer.Task Size 64
class FTask
{

 public: 
	char pad_0[64];  // Offset: 0 Size: 64



 // Functions 
 public:
}; 
 
 //ScriptStruct ArkAutoPlayer.ArkAutoPlayerNeedMove Size 40
class FArkAutoPlayerNeedMove
{

 public: 
	char pad_0[40];  // Offset: 0 Size: 40



 // Functions 
 public:
}; 
 
 //DelegateFunction ArkAutoPlayer.OnArkAutoPlayerNeedMove__DelegateSignature Size 40
class FOnArkAutoPlayerNeedMove__DelegateSignature
{

 public: 
	struct FArkAutoPlayerNeedMove MoveInfo;  // Offset: 0 Size: 40



 // Functions 
 public:
}; 
 
 //DelegateFunction ArkAutoPlayer.ShuttleLandSignature__DelegateSignature Size 8
class FShuttleLandSignature__DelegateSignature
{

 public: 
	struct AActor* Shuttle_;  // Offset: 0 Size: 8



 // Functions 
 public:
}; 
 
 //ScriptStruct ArkAutoPlayer.Performance Size 64
class FPerformance
{

 public: 
	char pad_0[64];  // Offset: 0 Size: 64



 // Functions 
 public:
}; 
 
 //ScriptStruct ArkAutoPlayer.AutoPlayerBlackBoard Size 120
class FAutoPlayerBlackBoard
{

 public: 
	struct UArkAutoPlayerComponent* MyAuto;  // Offset: 0 Size: 8
	struct AArkPlayerControllerBattle* MyPC;  // Offset: 8 Size: 8
	struct AArkPlayer* MyPlayer;  // Offset: 16 Size: 8
	char pad_24[40];  // Offset: 24 Size: 40
	struct AActor* TargetAct;  // Offset: 64 Size: 8
	char pad_72[48];  // Offset: 72 Size: 48



 // Functions 
 public:
}; 
 
 //Function ArkAutoPlayer.ArkAutoPlayerComponent.ClientOnFindPath Size 32
class FClientOnFindPath
{

 public: 
	struct TArray<struct FVector> Path;  // Offset: 0 Size: 16
	struct TArray<uint32_t> PathNavLinkIDs;  // Offset: 16 Size: 16



 // Functions 
 public:
}; 
 
 //Function ArkAutoPlayer.ArkAutoPlayerComponent.NotifyShuttleStateChanged Size 8
class FNotifyShuttleStateChanged
{

 public: 
	struct AActor* Shuttle;  // Offset: 0 Size: 8



 // Functions 
 public:
}; 
 
 //Function ArkAutoPlayer.ArkAutoPlayerServiceMoveTo.NotifyGetPathFollow Size 32
class FNotifyGetPathFollow
{

 public: 
	struct TArray<struct FVector> Path;  // Offset: 0 Size: 16
	struct TArray<uint32_t> PathNavLinkIDs;  // Offset: 16 Size: 16



 // Functions 
 public:
}; 
 
 //Function ArkAutoPlayer.ArkAutoPlayerComponent.OnGameFlowChange Size 8
class FOnGameFlowChange
{

 public: 
	enum class EArkGameFlowType LastMode;  // Offset: 0 Size: 1
	enum class EArkGameFlowType NewMode;  // Offset: 1 Size: 1
	char pad_2[2];  // Offset: 2 Size: 2
	float StartTime;  // Offset: 4 Size: 4



 // Functions 
 public:
}; 
 
 //Function ArkAutoPlayer.ArkAutoPlayerComponent.ServerNotifyShuttleStateChanged Size 12
class FServerNotifyShuttleStateChanged
{

 public: 
	enum class EArkShuttleStateType LastState;  // Offset: 0 Size: 1
	enum class EArkShuttleStateType NewState;  // Offset: 1 Size: 1
	char pad_2[2];  // Offset: 2 Size: 2
	float StartTime;  // Offset: 4 Size: 4
	int32_t OwnShuttleID;  // Offset: 8 Size: 4



 // Functions 
 public:
}; 
 
 //Function ArkAutoPlayer.ArkAutoPlayerComponent.ServerSetPlayerLoc Size 12
class FServerSetPlayerLoc
{

 public: 
	struct FVector NewLoc;  // Offset: 0 Size: 12



 // Functions 
 public:
}; 
 
 //Function ArkAutoPlayer.ArkAutoPlayerComponent.Start Size 16
class FStart
{

 public: 
	struct FString OpenCommand;  // Offset: 0 Size: 16



 // Functions 
 public:
}; 
 
 //Function ArkAutoPlayer.ArkAutoPlayerServiceSpot.OnOptionChange Size 2
class FOnOptionChange
{

 public: 
	struct FArkAuotPlayerSpotOption Option;  // Offset: 0 Size: 2



 // Functions 
 public:
}; 
 
 //Function ArkAutoPlayer.ArkAutoPlayerServiceMoveTo.OnNeedMove Size 40
class FOnNeedMove
{

 public: 
	struct FArkAutoPlayerNeedMove MoveInfo;  // Offset: 0 Size: 40



 // Functions 
 public:
}; 
 
 //Function ArkAutoPlayer.ArkAutoPlayerTaskMove.NotifyShuttleLand Size 8
class FNotifyShuttleLand
{

 public: 
	struct AActor* Shuttle_;  // Offset: 0 Size: 8



 // Functions 
 public:
}; 
 
 //Function ArkAutoPlayer.ArkAutoPlayerTaskPickUp.OnMoveEnd Size 1
class FOnMoveEnd
{

 public: 
	enum class EServiceNotify Notify_;  // Offset: 0 Size: 1



 // Functions 
 public:
}; 
 
 //Function ArkAutoPlayer.ArkAutoPlayerTaskSync.OnSyncFinish Size 16
class FOnSyncFinish
{

 public: 
	struct UObject* TargetObjRef;  // Offset: 0 Size: 8
	enum class EArkInteractionType InteractionType;  // Offset: 8 Size: 1
	char pad_9_1 : 7;  // Offset: 9 Size: 1
	bool bCancelled : 1;  // Offset: 9 Size: 1
	char pad_10[2];  // Offset: 10 Size: 2
	float RemainingTime;  // Offset: 12 Size: 4



 // Functions 
 public:
}; 
 
 