#pragma once 
#include <SDK_Engine_Objects.h> 
 
 
//Function ABP_CoreStone.ABP_CoreStone_C.ExecuteUbergraph_ABP_CoreStone Size 16
class FExecuteUbergraph_ABP_CoreStone
{

 public: 
	int32_t EntryPoint;  // Offset: 0 Size: 4
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // Offset: 4 Size: 4
	char pad_8_1 : 7;  // Offset: 8 Size: 1
	bool CallFunc_LessEqual_FloatFloat_ReturnValue : 1;  // Offset: 8 Size: 1
	char pad_9[3];  // Offset: 9 Size: 3
	float CallFunc_Subtract_FloatFloat_ReturnValue;  // Offset: 12 Size: 4



 // Functions 
 public:
}; 
 
 //Function ABP_CoreStone.ABP_CoreStone_C.ShowCoreMesh Size 1
class FShowCoreMesh
{

 public: 
	char pad_0_1 : 7;  // Offset: 0 Size: 1
	bool bShowCoreMesh : 1;  // Offset: 0 Size: 1



 // Functions 
 public:
}; 
 
 //Function ABP_CoreStone.ABP_CoreStone_C.AnimGraph Size 16
class FAnimGraph
{

 public: 
	struct FPoseLink AnimGraph;  // Offset: 0 Size: 16



 // Functions 
 public:
}; 
 
 