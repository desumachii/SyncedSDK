#pragma once 
#include <AN_SetSyncShuttleWidgetVisibility_Structs.h>
 
 
 
//BlueprintGeneratedClass AN_SetSyncShuttleWidgetVisibility.AN_SetSyncShuttleWidgetVisibility_C Size 57
// Inherited 56 bytes 
class UAN_SetSyncShuttleWidgetVisibility_C : public UAnimNotify
{

 public: 
	char pad_56_1 : 7;  // Offset: 56 Size: 1
	bool bVisibility : 1;  // Offset: 56 Size: 1



 // Functions 
 public:
	struct FString GetNotifyName(); // Function AN_SetSyncShuttleWidgetVisibility.AN_SetSyncShuttleWidgetVisibility_C.GetNotifyName
	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function AN_SetSyncShuttleWidgetVisibility.AN_SetSyncShuttleWidgetVisibility_C.Received_Notify
}; 
 
 


