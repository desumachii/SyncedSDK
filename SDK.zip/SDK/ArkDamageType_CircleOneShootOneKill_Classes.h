#pragma once 
#include <ArkDamageType_CircleOneShootOneKill_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkDamageType_CircleOneShootOneKill.ArkDamageType_CircleOneShootOneKill_C Size 264
// Inherited 264 bytes 
class UArkDamageType_CircleOneShootOneKill_C : public UArkDamageType_ShockWave_C
{

 public: 



 // Functions 
 public:
}; 
 
 


