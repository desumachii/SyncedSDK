#pragma once 
#include <AIGABuff_SelfExplode_BP_Structs.h>
 
 
 
//BlueprintGeneratedClass AIGABuff_SelfExplode_BP.AIGABuff_SelfExplode_BP_C Size 2024
// Inherited 2016 bytes 
class UAIGABuff_SelfExplode_BP_C : public UArkAIGABuff_SelfExplode
{

 public: 
	struct FPointerToUberGraphFrame UberGraphFrame;  // Offset: 2016 Size: 8



 // Functions 
 public:
	void OnAnimNotify_BP(struct FName NotifyName, struct UAnimNotify* Notify); // Function AIGABuff_SelfExplode_BP.AIGABuff_SelfExplode_BP_C.OnAnimNotify_BP
	void ExecuteUbergraph_AIGABuff_SelfExplode_BP(int32_t EntryPoint); // Function AIGABuff_SelfExplode_BP.AIGABuff_SelfExplode_BP_C.ExecuteUbergraph_AIGABuff_SelfExplode_BP
}; 
 
 


