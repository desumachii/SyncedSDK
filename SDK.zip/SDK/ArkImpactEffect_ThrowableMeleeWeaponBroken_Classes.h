#pragma once 
#include <ArkImpactEffect_ThrowableMeleeWeaponBroken_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkImpactEffect_ThrowableMeleeWeaponBroken.ArkImpactEffect_ThrowableMeleeWeaponBroken_C Size 1160
// Inherited 1160 bytes 
class AArkImpactEffect_ThrowableMeleeWeaponBroken_C : public AArkExplosionEffect
{

 public: 



 // Functions 
 public:
}; 
 
 


