#pragma once 
#include <ArkImpactEffect_Swarm_Melee_Small_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkImpactEffect_Swarm_Melee_Small.ArkImpactEffect_Swarm_Melee_Small_C Size 504
// Inherited 504 bytes 
class UArkImpactEffect_Swarm_Melee_Small_C : public UArkImpactEffect_RangeWeapon_C
{

 public: 



 // Functions 
 public:
}; 
 
 


