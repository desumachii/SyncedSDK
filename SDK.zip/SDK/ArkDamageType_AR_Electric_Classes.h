#pragma once 
#include <ArkDamageType_AR_Electric_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkDamageType_AR_Electric.ArkDamageType_AR_Electric_C Size 264
// Inherited 264 bytes 
class UArkDamageType_AR_Electric_C : public UArkDamageType_Range_C
{

 public: 



 // Functions 
 public:
}; 
 
 


