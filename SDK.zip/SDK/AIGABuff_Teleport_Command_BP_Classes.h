#pragma once 
#include <AIGABuff_Teleport_Command_BP_Structs.h>
 
 
 
//BlueprintGeneratedClass AIGABuff_Teleport_Command_BP.AIGABuff_Teleport_Command_BP_C Size 2256
// Inherited 2064 bytes 
class UAIGABuff_Teleport_Command_BP_C : public UArkAIGABuff_TeleportResponse
{

 public: 
	struct FPointerToUberGraphFrame UberGraphFrame;  // Offset: 2064 Size: 8
	struct TSoftObjectPtr<UParticleSystem> Teleport_Forming_FX;  // Offset: 2072 Size: 40
	struct TSoftObjectPtr<UParticleSystem> Teleport_Start_FX;  // Offset: 2112 Size: 40
	struct UParticleSystemComponent* Indicator_PSC;  // Offset: 2152 Size: 8
	struct FTimerHandle TargetPSCTimer;  // Offset: 2160 Size: 8
	struct UAnimMontage* TeleportEndAnim;  // Offset: 2168 Size: 8
	struct TSoftObjectPtr<UParticleSystem> Teleport Indicator;  // Offset: 2176 Size: 40
	struct TSoftObjectPtr<UParticleSystem> FadeIn FX;  // Offset: 2216 Size: 40



 // Functions 
 public:
	void PauseMovement(bool bPause); // Function AIGABuff_Teleport_Command_BP.AIGABuff_Teleport_Command_BP_C.PauseMovement
	void OnPerformAction_BP(struct AActor* TargetActor); // Function AIGABuff_Teleport_Command_BP.AIGABuff_Teleport_Command_BP_C.OnPerformAction_BP
	void OnPotentialLocation_BP(struct FVector_NetQuantize OldPotentialLoc, struct FVector_NetQuantize PotentialLoc); // Function AIGABuff_Teleport_Command_BP.AIGABuff_Teleport_Command_BP_C.OnPotentialLocation_BP
	void OnTeleport_BP(struct FTeleportResponseRepData InTeleportRepData); // Function AIGABuff_Teleport_Command_BP.AIGABuff_Teleport_Command_BP_C.OnTeleport_BP
	void ClearPSC(); // Function AIGABuff_Teleport_Command_BP.AIGABuff_Teleport_Command_BP_C.ClearPSC
	void OnStopAction_BP(enum class EArkAIGAActionStopReason StopReason); // Function AIGABuff_Teleport_Command_BP.AIGABuff_Teleport_Command_BP_C.OnStopAction_BP
	void OnDeath_BP(struct FTakeHitInfo& HitInfo); // Function AIGABuff_Teleport_Command_BP.AIGABuff_Teleport_Command_BP_C.OnDeath_BP
	void ExecuteUbergraph_AIGABuff_Teleport_Command_BP(int32_t EntryPoint); // Function AIGABuff_Teleport_Command_BP.AIGABuff_Teleport_Command_BP_C.ExecuteUbergraph_AIGABuff_Teleport_Command_BP
}; 
 
 


