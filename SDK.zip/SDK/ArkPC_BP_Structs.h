#pragma once 
#include <SDK_Engine_Objects.h> 
 
 
//Function ArkPC_BP.ArkPC_BP_C.ExecuteUbergraph_ArkPC_BP Size 52
class FExecuteUbergraph_ArkPC_BP
{

 public: 
	int32_t EntryPoint;  // Offset: 0 Size: 4
	struct FDelegate Temp_delegate_Variable;  // Offset: 4 Size: 16
	struct FDelegate Temp_delegate_Variable_2;  // Offset: 20 Size: 16
	struct FDelegate Temp_delegate_Variable_3;  // Offset: 36 Size: 16



 // Functions 
 public:
}; 
 
 //Function ArkPC_BP.ArkPC_BP_C.ForwardTrace Size 368
class FForwardTrace
{

 public: 
	float Length;  // Offset: 0 Size: 4
	char pad_4_1 : 7;  // Offset: 4 Size: 1
	bool ReturnFarestIfNotHit : 1;  // Offset: 4 Size: 1
	char pad_5_1 : 7;  // Offset: 5 Size: 1
	bool IsHit : 1;  // Offset: 5 Size: 1
	char pad_6[2];  // Offset: 6 Size: 2
	struct FVector HitLocation;  // Offset: 8 Size: 12
	char pad_20[4];  // Offset: 20 Size: 4
	struct APawn* CallFunc_K2_GetPawn_ReturnValue;  // Offset: 24 Size: 8
	struct TArray<struct AActor*> K2Node_MakeArray_Array;  // Offset: 32 Size: 16
	struct APlayerCameraManager* CallFunc_GetPlayerCameraManager_ReturnValue;  // Offset: 48 Size: 8
	struct FVector CallFunc_GetActorForwardVector_ReturnValue;  // Offset: 56 Size: 12
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // Offset: 68 Size: 12
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // Offset: 80 Size: 12
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // Offset: 92 Size: 12
	struct FHitResult CallFunc_LineTraceSingle_OutHit;  // Offset: 104 Size: 136
	char pad_240_1 : 7;  // Offset: 240 Size: 1
	bool CallFunc_LineTraceSingle_ReturnValue : 1;  // Offset: 240 Size: 1
	char pad_241_1 : 7;  // Offset: 241 Size: 1
	bool CallFunc_BreakHitResult_bBlockingHit : 1;  // Offset: 241 Size: 1
	char pad_242_1 : 7;  // Offset: 242 Size: 1
	bool CallFunc_BreakHitResult_bInitialOverlap : 1;  // Offset: 242 Size: 1
	char pad_243[1];  // Offset: 243 Size: 1
	float CallFunc_BreakHitResult_Time;  // Offset: 244 Size: 4
	float CallFunc_BreakHitResult_Distance;  // Offset: 248 Size: 4
	struct FVector CallFunc_BreakHitResult_Location;  // Offset: 252 Size: 12
	struct FVector CallFunc_BreakHitResult_ImpactPoint;  // Offset: 264 Size: 12
	struct FVector CallFunc_BreakHitResult_Normal;  // Offset: 276 Size: 12
	struct FVector CallFunc_BreakHitResult_ImpactNormal;  // Offset: 288 Size: 12
	char pad_300[4];  // Offset: 300 Size: 4
	struct UPhysicalMaterial* CallFunc_BreakHitResult_PhysMat;  // Offset: 304 Size: 8
	struct AActor* CallFunc_BreakHitResult_HitActor;  // Offset: 312 Size: 8
	struct UPrimitiveComponent* CallFunc_BreakHitResult_HitComponent;  // Offset: 320 Size: 8
	struct FName CallFunc_BreakHitResult_HitBoneName;  // Offset: 328 Size: 8
	int32_t CallFunc_BreakHitResult_HitItem;  // Offset: 336 Size: 4
	int32_t CallFunc_BreakHitResult_FaceIndex;  // Offset: 340 Size: 4
	struct FVector CallFunc_BreakHitResult_TraceStart;  // Offset: 344 Size: 12
	struct FVector CallFunc_BreakHitResult_TraceEnd;  // Offset: 356 Size: 12



 // Functions 
 public:
}; 
 
 //Function ArkPC_BP.ArkPC_BP_C.Update Low Health PP Size 63
class FUpdate Low Health PP
{

 public: 
	char pad_0_1 : 7;  // Offset: 0 Size: 1
	bool CallFunc_IsDedicatedServer_ReturnValue : 1;  // Offset: 0 Size: 1
	char pad_1[7];  // Offset: 1 Size: 7
	struct AArkPlayer* CallFunc_GetLocalPlayer_ReturnValue;  // Offset: 8 Size: 8
	char pad_16_1 : 7;  // Offset: 16 Size: 1
	bool CallFunc_IsDedicatedServer_ReturnValue_2 : 1;  // Offset: 16 Size: 1
	char pad_17[7];  // Offset: 17 Size: 7
	struct AArkPlayer* CallFunc_GetLocalPlayer_ReturnValue_2;  // Offset: 24 Size: 8
	struct APawn* CallFunc_GetLocalControlledPawnOrSpectator_ReturnValue;  // Offset: 32 Size: 8
	char pad_40_1 : 7;  // Offset: 40 Size: 1
	bool CallFunc_IsDedicatedServer_ReturnValue_3 : 1;  // Offset: 40 Size: 1
	char pad_41[7];  // Offset: 41 Size: 7
	struct AArkPlayer* K2Node_DynamicCast_AsArk_Player;  // Offset: 48 Size: 8
	char pad_56_1 : 7;  // Offset: 56 Size: 1
	bool K2Node_DynamicCast_bSuccess : 1;  // Offset: 56 Size: 1
	char pad_57_1 : 7;  // Offset: 57 Size: 1
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // Offset: 57 Size: 1
	char pad_58_1 : 7;  // Offset: 58 Size: 1
	bool CallFunc_IsAlive_ReturnValue : 1;  // Offset: 58 Size: 1
	char pad_59_1 : 7;  // Offset: 59 Size: 1
	bool CallFunc_IsValid_ReturnValue : 1;  // Offset: 59 Size: 1
	char pad_60_1 : 7;  // Offset: 60 Size: 1
	bool CallFunc_IsResistingDeath_ReturnValue : 1;  // Offset: 60 Size: 1
	char pad_61_1 : 7;  // Offset: 61 Size: 1
	bool CallFunc_IsLowHealth_ReturnValue : 1;  // Offset: 61 Size: 1
	char pad_62_1 : 7;  // Offset: 62 Size: 1
	bool CallFunc_BooleanOR_ReturnValue : 1;  // Offset: 62 Size: 1



 // Functions 
 public:
}; 
 
 