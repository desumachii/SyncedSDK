#pragma once 
#include <ArkImpactEffect_RangeWeaponSR_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkImpactEffect_RangeWeaponSR.ArkImpactEffect_RangeWeaponSR_C Size 504
// Inherited 504 bytes 
class UArkImpactEffect_RangeWeaponSR_C : public UArkImpactEffect_RangeWeapon_C
{

 public: 



 // Functions 
 public:
}; 
 
 


