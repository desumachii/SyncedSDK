#pragma once 
#include <ArkNavArea_Culled_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkNavArea_Culled.ArkNavArea_Culled_C Size 72
// Inherited 72 bytes 
class UArkNavArea_Culled_C : public UNavArea_Null
{

 public: 



 // Functions 
 public:
}; 
 
 


