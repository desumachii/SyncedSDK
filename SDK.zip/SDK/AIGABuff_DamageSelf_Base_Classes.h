#pragma once 
#include <AIGABuff_DamageSelf_Base_Structs.h>
 
 
 
//BlueprintGeneratedClass AIGABuff_DamageSelf_Base.AIGABuff_DamageSelf_Base_C Size 1240
// Inherited 1224 bytes 
class UAIGABuff_DamageSelf_Base_C : public UArkAIGameplayAbilityBuff
{

 public: 
	struct FPointerToUberGraphFrame UberGraphFrame;  // Offset: 1224 Size: 8
	float DamageInterval;  // Offset: 1232 Size: 4
	float DamagePercent;  // Offset: 1236 Size: 4



 // Functions 
 public:
	void DamageTimer(); // Function AIGABuff_DamageSelf_Base.AIGABuff_DamageSelf_Base_C.DamageTimer
	void C2BP_OnDeactive(); // Function AIGABuff_DamageSelf_Base.AIGABuff_DamageSelf_Base_C.C2BP_OnDeactive
	void C2BP_OnActive(); // Function AIGABuff_DamageSelf_Base.AIGABuff_DamageSelf_Base_C.C2BP_OnActive
	void ExecuteUbergraph_AIGABuff_DamageSelf_Base(int32_t EntryPoint); // Function AIGABuff_DamageSelf_Base.AIGABuff_DamageSelf_Base_C.ExecuteUbergraph_AIGABuff_DamageSelf_Base
}; 
 
 


