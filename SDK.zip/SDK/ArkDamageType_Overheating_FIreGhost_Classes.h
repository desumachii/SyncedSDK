#pragma once 
#include <ArkDamageType_Overheating_FIreGhost_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkDamageType_Overheating_FIreGhost.ArkDamageType_Overheating_FIreGhost_C Size 264
// Inherited 264 bytes 
class UArkDamageType_Overheating_FIreGhost_C : public UArkDamageType_Overheating_C
{

 public: 



 // Functions 
 public:
}; 
 
 


