#pragma once 
#include <ArkPlayerFlammableComponent_BP_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkPlayerFlammableComponent_BP.ArkPlayerFlammableComponent_BP_C Size 224
// Inherited 224 bytes 
class UArkPlayerFlammableComponent_BP_C : public UArkFlammableComponent
{

 public: 



 // Functions 
 public:
}; 
 
 


