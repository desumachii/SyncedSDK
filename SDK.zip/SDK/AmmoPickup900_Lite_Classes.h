#pragma once 
#include <AmmoPickup900_Lite_Structs.h>
 
 
 
//BlueprintGeneratedClass AmmoPickup900_Lite.AmmoPickup900_Lite_C Size 2416
// Inherited 2416 bytes 
class AAmmoPickup900_Lite_C : public AAmmoPickupBase_C
{

 public: 



 // Functions 
 public:
}; 
 
 


