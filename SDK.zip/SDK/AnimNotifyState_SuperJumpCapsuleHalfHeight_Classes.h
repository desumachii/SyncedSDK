#pragma once 
#include <AnimNotifyState_SuperJumpCapsuleHalfHeight_Structs.h>
 
 
 
//BlueprintGeneratedClass AnimNotifyState_SuperJumpCapsuleHalfHeight.AnimNotifyState_SuperJumpCapsuleHalfHeight_C Size 48
// Inherited 48 bytes 
class UAnimNotifyState_SuperJumpCapsuleHalfHeight_C : public UAnimNotifyState
{

 public: 



 // Functions 
 public:
	bool Received_NotifyEnd(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function AnimNotifyState_SuperJumpCapsuleHalfHeight.AnimNotifyState_SuperJumpCapsuleHalfHeight_C.Received_NotifyEnd
	bool Received_NotifyBegin(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration); // Function AnimNotifyState_SuperJumpCapsuleHalfHeight.AnimNotifyState_SuperJumpCapsuleHalfHeight_C.Received_NotifyBegin
}; 
 
 


