#pragma once 
#include <ArkImpactEffect_Kick_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkImpactEffect_Kick.ArkImpactEffect_Kick_C Size 504
// Inherited 504 bytes 
class UArkImpactEffect_Kick_C : public UArkImpactEffect
{

 public: 



 // Functions 
 public:
}; 
 
 


