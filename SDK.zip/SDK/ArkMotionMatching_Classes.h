#pragma once 
#include <ArkMotionMatching_Structs.h>
 
 
 
//Class ArkMotionMatching.ArkDefaultMotionMatchingAnimInstance Size 976
// Inherited 672 bytes 
class UArkDefaultMotionMatchingAnimInstance : public UAnimInstance
{

 public: 
	struct UArkMotionField* MotionField;  // Offset: 672 Size: 8
	struct TArray<struct FArkMotionAnimArchive> MotionAnims;  // Offset: 680 Size: 16
	struct TArray<struct FArkMotionCoordinate> PotentialCoordinates;  // Offset: 696 Size: 16
	struct FArkMotionCoordinate CurrentCoordinates;  // Offset: 712 Size: 16
	struct TArray<struct FArkMotionCoordinate> MatchedCoordinates;  // Offset: 728 Size: 16
	enum class EArkMotionMatchingResult MatchResult;  // Offset: 744 Size: 1
	char pad_745[7];  // Offset: 745 Size: 7
	struct FArkMotionTrajectory DesiredTrajectory;  // Offset: 752 Size: 136
	char pad_888[8];  // Offset: 888 Size: 8
	struct FTransform MeshTransform;  // Offset: 896 Size: 48
	struct TArray<struct FArkMotionTrajectoryPoint> PreviousTrajectory;  // Offset: 944 Size: 16
	struct TArray<struct FArkMotionTrajectoryPoint> FutureTrajectory;  // Offset: 960 Size: 16



 // Functions 
 public:
}; 
 
 


//Class ArkMotionMatching.ArkMotionBlueprintLibrary Size 40
// Inherited 40 bytes 
class UArkMotionBlueprintLibrary : public UBlueprintFunctionLibrary
{

 public: 



 // Functions 
 public:
	struct FArkMotionTrajectory ParseDataToMotionTrajectory(struct TArray<float>& Data); // Function ArkMotionMatching.ArkMotionBlueprintLibrary.ParseDataToMotionTrajectory
}; 
 
 


//Class ArkMotionMatching.ArkMotionField Size 304
// Inherited 40 bytes 
class UArkMotionField : public UObject
{

 public: 
	struct TArray<struct FArkTagHelper> TagHelpers;  // Offset: 40 Size: 16
	struct USkeleton* Skeleton;  // Offset: 56 Size: 8
	struct TArray<struct FArkMotionAnimProperty> AnimationProperties;  // Offset: 64 Size: 16
	struct TArray<struct FName> MotionBones;  // Offset: 80 Size: 16
	struct TArray<struct UAnimSequence*> SourceAnimations;  // Offset: 96 Size: 16
	struct FArkMotionFieldProperty MotionFieldProperty;  // Offset: 112 Size: 56
	struct TArray<struct FArkMotionKey> MotionKeys;  // Offset: 168 Size: 16
	char pad_184[120];  // Offset: 184 Size: 120



 // Functions 
 public:
	struct TArray<struct FArkMotionCoordinate> GetAllMotionCoordinates(); // Function ArkMotionMatching.ArkMotionField.GetAllMotionCoordinates
	struct FArkMotionCoordinate ConvertToKDTreeCoordinate(struct FVector& PreviousVelocity, struct FVector& CurrentVelocity, struct FVector& FutureVelocity, struct FVector& FarFutureVelocity); // Function ArkMotionMatching.ArkMotionField.ConvertToKDTreeCoordinate
}; 
 
 


//Class ArkMotionMatching.ArkMotionMatchingBPLibrary Size 40
// Inherited 40 bytes 
class UArkMotionMatchingBPLibrary : public UBlueprintFunctionLibrary
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkMotionMatching.ArkMotionMatchingAnimInstance Size 40
// Inherited 40 bytes 
class UArkMotionMatchingAnimInstance : public UInterface
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkMotionMatching.ArkMotionDebugPathFollower Size 1008
// Inherited 744 bytes 
class AArkMotionDebugPathFollower : public AActor
{

 public: 
	struct ACharacter* Character;  // Offset: 744 Size: 8
	struct TArray<struct AArkMotionDebugPathPoint*> PathPoints;  // Offset: 752 Size: 16
	float Tolerance;  // Offset: 768 Size: 4
	float BeginDelay;  // Offset: 772 Size: 4
	int32_t CurrentSegmentIndex;  // Offset: 776 Size: 4
	struct FVector CurrentPathSegmentStart;  // Offset: 780 Size: 12
	struct FVector CurrentPathSegmentFinish;  // Offset: 792 Size: 12
	struct FVector Velocity;  // Offset: 804 Size: 12
	struct FVector FutureVelocity;  // Offset: 816 Size: 12
	struct FVector FarFutureVelocity;  // Offset: 828 Size: 12
	struct FVector PreviousVelocity;  // Offset: 840 Size: 12
	float FutureTime;  // Offset: 852 Size: 4
	float PreviousTime;  // Offset: 856 Size: 4
	float PredictTimeStep;  // Offset: 860 Size: 4
	struct TArray<struct FArkMotionTrajectoryPoint> PredictedFutureTrajectory;  // Offset: 864 Size: 16
	float RotateSpeed;  // Offset: 880 Size: 4
	float MaxSpeed;  // Offset: 884 Size: 4
	float MaxAcceleration;  // Offset: 888 Size: 4
	float MaxBrakeDeceleration;  // Offset: 892 Size: 4
	float FutureVelocityTime;  // Offset: 896 Size: 4
	float FutureVelocitySmoothFactor;  // Offset: 900 Size: 4
	char pad_904[104];  // Offset: 904 Size: 104



 // Functions 
 public:
}; 
 
 


//Class ArkMotionMatching.ArkMotionDebugPathPoint Size 744
// Inherited 744 bytes 
class AArkMotionDebugPathPoint : public AActor
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkMotionMatching.MotionDatabase Size 288
// Inherited 40 bytes 
class UMotionDatabase : public UObject
{

 public: 
	struct TMap<int32_t, int32_t> SpeedCursorToMotionKeyMap;  // Offset: 40 Size: 80
	struct USkeleton* Skeleton;  // Offset: 120 Size: 8
	struct TArray<struct FMotionSequenceProperty> AnimationProperties;  // Offset: 128 Size: 16
	struct TArray<struct FName> MotionBones;  // Offset: 144 Size: 16
	struct TArray<struct UAnimSequence*> SourceAnimations;  // Offset: 160 Size: 16
	struct FMotionDatabaseProperty MotionDatabaseProperty;  // Offset: 176 Size: 16
	struct TArray<struct FMotionKey> MotionKeys;  // Offset: 192 Size: 16
	struct TArray<struct FMotionKey> LoopingMotionKeys;  // Offset: 208 Size: 16
	struct TArray<struct FStartMotionKey> StartMotionKeys;  // Offset: 224 Size: 16
	struct TArray<struct FPivotMotionKey> PivotMotionKeys;  // Offset: 240 Size: 16
	struct TArray<struct FEndMotionKey> EndMotionKeys;  // Offset: 256 Size: 16
	struct TArray<struct FTagMotionKey> TagMotionKeys;  // Offset: 272 Size: 16



 // Functions 
 public:
}; 
 
 


