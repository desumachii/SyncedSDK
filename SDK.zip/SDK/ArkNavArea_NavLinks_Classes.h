#pragma once 
#include <ArkNavArea_NavLinks_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkNavArea_NavLinks.ArkNavArea_NavLinks_C Size 72
// Inherited 72 bytes 
class UArkNavArea_NavLinks_C : public UNavArea
{

 public: 



 // Functions 
 public:
}; 
 
 


