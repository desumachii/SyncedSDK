#pragma once 
#include <SDK_Engine_Objects.h> 
 
 
//Function ArkGameState_PVE_TrapTreasureBox.ArkGameState_PVE_TrapTreasureBox_C.NotifyClientWaveFinished Size 4
class FNotifyClientWaveFinished
{

 public: 
	int32_t InWaveOrder;  // Offset: 0 Size: 4



 // Functions 
 public:
}; 
 
 //Function ArkGameState_PVE_TrapTreasureBox.ArkGameState_PVE_TrapTreasureBox_C.ExecuteUbergraph_ArkGameState_PVE_TrapTreasureBox Size 26
class FExecuteUbergraph_ArkGameState_PVE_TrapTreasureBox
{

 public: 
	int32_t EntryPoint;  // Offset: 0 Size: 4
	char pad_4_1 : 7;  // Offset: 4 Size: 1
	bool CallFunc_IsDedicatedServer_ReturnValue : 1;  // Offset: 4 Size: 1
	enum class EArkMaterialRunTTBStateType K2Node_Event_NewState;  // Offset: 5 Size: 1
	char pad_6_1 : 7;  // Offset: 6 Size: 1
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // Offset: 6 Size: 1
	char pad_7_1 : 7;  // Offset: 7 Size: 1
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_2 : 1;  // Offset: 7 Size: 1
	int32_t K2Node_CustomEvent_InWaveOrder;  // Offset: 8 Size: 4
	int32_t CallFunc_Add_IntInt_ReturnValue;  // Offset: 12 Size: 4
	char pad_16_1 : 7;  // Offset: 16 Size: 1
	bool CallFunc_HasAuthority_ReturnValue : 1;  // Offset: 16 Size: 1
	char pad_17[3];  // Offset: 17 Size: 3
	float CallFunc_Conv_IntToFloat_ReturnValue;  // Offset: 20 Size: 4
	char pad_24_1 : 7;  // Offset: 24 Size: 1
	bool CallFunc_IsDedicatedServer_ReturnValue_2 : 1;  // Offset: 24 Size: 1
	char pad_25_1 : 7;  // Offset: 25 Size: 1
	bool CallFunc_IsDedicatedServer_ReturnValue_3 : 1;  // Offset: 25 Size: 1



 // Functions 
 public:
}; 
 
 //Function ArkGameState_PVE_TrapTreasureBox.ArkGameState_PVE_TrapTreasureBox_C.OnCurrentRunStateChange_BP Size 1
// Inherited 1 bytes 
class FOnCurrentRunStateChange_BP : public FOnCurrentRunStateChange_BP
{

 public: 
	enum class EArkMaterialRunTTBStateType NewState;  // Offset: 0 Size: 1



 // Functions 
 public:
}; 
 
 //Function ArkGameState_PVE_TrapTreasureBox.ArkGameState_PVE_TrapTreasureBox_C.CheckIgnoreNanoSurgeDamage_BP Size 12
// Inherited 16 bytes 
class FCheckIgnoreNanoSurgeDamage_BP : public FCheckIgnoreNanoSurgeDamage_BP
{

 public: 
	struct AArkPlayer* Player;  // Offset: 0 Size: 8
	char pad_24_1 : 7;  // Offset: 24 Size: 1
	bool bIgnore : 1;  // Offset: 8 Size: 1
	char pad_25_1 : 7;  // Offset: 25 Size: 1
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // Offset: 9 Size: 1
	char pad_26_1 : 7;  // Offset: 26 Size: 1
	bool CallFunc_EqualEqual_ByteByte_ReturnValue_2 : 1;  // Offset: 10 Size: 1
	char pad_27_1 : 7;  // Offset: 27 Size: 1
	bool CallFunc_BooleanOR_ReturnValue : 1;  // Offset: 11 Size: 1



 // Functions 
 public:
}; 
 
 //Function ArkGameState_PVE_TrapTreasureBox.ArkGameState_PVE_TrapTreasureBox_C.GenerateTreasureBox Size 141
class FGenerateTreasureBox
{

 public: 
	struct APlayerStart* CallFunc_GetCurrentTeamStart_ReturnValue;  // Offset: 0 Size: 8
	struct TArray<struct FName> CallFunc_Find_Shareable_Loot_Name_List_ShareableLootList;  // Offset: 8 Size: 16
	int32_t CallFunc_Array_Length_ReturnValue;  // Offset: 24 Size: 4
	char pad_28_1 : 7;  // Offset: 28 Size: 1
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // Offset: 28 Size: 1
	char pad_29[3];  // Offset: 29 Size: 3
	struct TArray<struct ABP_TrapTeasureBoxLocator_C*> CallFunc_GetAllActorsOfClassWithTag_OutActors;  // Offset: 32 Size: 16
	struct ABP_TrapTeasureBoxLocator_C* CallFunc_Array_Get_Item;  // Offset: 48 Size: 8
	int32_t CallFunc_Array_Length_ReturnValue_2;  // Offset: 56 Size: 4
	char pad_60[4];  // Offset: 60 Size: 4
	struct FTransform CallFunc_GetTransform_ReturnValue;  // Offset: 64 Size: 48
	char pad_112_1 : 7;  // Offset: 112 Size: 1
	bool CallFunc_Greater_IntInt_ReturnValue_2 : 1;  // Offset: 112 Size: 1
	char pad_113[7];  // Offset: 113 Size: 7
	struct AActor* CallFunc_BeginDeferredActorSpawnFromClass_ReturnValue;  // Offset: 120 Size: 8
	struct ABP_TrapTreasureBoxBox_C* CallFunc_FinishSpawningActor_ReturnValue;  // Offset: 128 Size: 8
	int32_t CallFunc_Array_Length_ReturnValue_3;  // Offset: 136 Size: 4
	char pad_140_1 : 7;  // Offset: 140 Size: 1
	bool CallFunc_Greater_IntInt_ReturnValue_3 : 1;  // Offset: 140 Size: 1



 // Functions 
 public:
}; 
 
 //Function ArkGameState_PVE_TrapTreasureBox.ArkGameState_PVE_TrapTreasureBox_C.Find Shareable Loot Name List Size 175
class FFind Shareable Loot Name List
{

 public: 
	struct TArray<struct FName> ShareableLootList;  // Offset: 0 Size: 16
	int32_t FoundWaveOrder;  // Offset: 16 Size: 4
	char pad_20[4];  // Offset: 20 Size: 4
	struct TArray<struct FName> FoundShareableLootList;  // Offset: 24 Size: 16
	int32_t CurrentWave;  // Offset: 40 Size: 4
	int32_t Temp_int_Array_Index_Variable;  // Offset: 44 Size: 4
	int32_t Temp_int_Loop_Counter_Variable;  // Offset: 48 Size: 4
	int32_t CallFunc_Add_IntInt_ReturnValue;  // Offset: 52 Size: 4
	int32_t CallFunc_GetTrapTreasureBoxAbsoluteWave_ReturnValue;  // Offset: 56 Size: 4
	char pad_60[4];  // Offset: 60 Size: 4
	struct AArkGameStatePve* CallFunc_GetGameStateAsPVE_AsArk_Game_State_Pve;  // Offset: 64 Size: 8
	struct AArkGameStateMaterialRun_TrapTreasureBox* K2Node_DynamicCast_AsArk_Game_State_Material_Run_Trap_Treasure_Box;  // Offset: 72 Size: 8
	char pad_80_1 : 7;  // Offset: 80 Size: 1
	bool K2Node_DynamicCast_bSuccess : 1;  // Offset: 80 Size: 1
	char pad_81[7];  // Offset: 81 Size: 7
	struct TArray<struct FName> CallFunc_GetDataTableRowNames_OutRowNames;  // Offset: 88 Size: 16
	struct FName CallFunc_Array_Get_Item;  // Offset: 104 Size: 8
	int32_t CallFunc_Array_Length_ReturnValue;  // Offset: 112 Size: 4
	char pad_116[4];  // Offset: 116 Size: 4
	struct FStruct_TrapTreasureBoxShareableLoot CallFunc_GetDataTableRowFromName_OutRow;  // Offset: 120 Size: 48
	char pad_168_1 : 7;  // Offset: 168 Size: 1
	bool CallFunc_GetDataTableRowFromName_ReturnValue : 1;  // Offset: 168 Size: 1
	char pad_169_1 : 7;  // Offset: 169 Size: 1
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // Offset: 169 Size: 1
	char pad_170_1 : 7;  // Offset: 170 Size: 1
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // Offset: 170 Size: 1
	char pad_171_1 : 7;  // Offset: 171 Size: 1
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // Offset: 171 Size: 1
	char pad_172_1 : 7;  // Offset: 172 Size: 1
	bool CallFunc_GreaterEqual_IntInt_ReturnValue : 1;  // Offset: 172 Size: 1
	char pad_173_1 : 7;  // Offset: 173 Size: 1
	bool CallFunc_BooleanAND_ReturnValue : 1;  // Offset: 173 Size: 1
	char pad_174_1 : 7;  // Offset: 174 Size: 1
	bool CallFunc_BooleanAND_ReturnValue_2 : 1;  // Offset: 174 Size: 1



 // Functions 
 public:
}; 
 
 //Function ArkGameState_PVE_TrapTreasureBox.ArkGameState_PVE_TrapTreasureBox_C.Init Progress Bar Size 425
class FInit Progress Bar
{

 public: 
	float IntervalPercent;  // Offset: 0 Size: 4
	char pad_4[4];  // Offset: 4 Size: 4
	struct TArray<struct FProgressNodeInfo> NodeInfoArray;  // Offset: 8 Size: 16
	struct TArray<struct FStruct_TrapTreasureBoxShareableLoot> WaveCfgArray;  // Offset: 24 Size: 16
	int32_t Temp_int_Array_Index_Variable;  // Offset: 40 Size: 4
	int32_t CallFunc_Add_IntInt_ReturnValue;  // Offset: 44 Size: 4
	int32_t Temp_int_Loop_Counter_Variable;  // Offset: 48 Size: 4
	int32_t CallFunc_Add_IntInt_ReturnValue_2;  // Offset: 52 Size: 4
	int32_t Temp_int_Array_Index_Variable_2;  // Offset: 56 Size: 4
	char pad_60[4];  // Offset: 60 Size: 4
	struct UArkTextFormatManager* CallFunc_Get_ReturnValue;  // Offset: 64 Size: 8
	struct FColor K2Node_MakeStruct_Color;  // Offset: 72 Size: 4
	float CallFunc_Multiply_IntFloat_ReturnValue;  // Offset: 76 Size: 4
	int32_t Temp_int_Loop_Counter_Variable_2;  // Offset: 80 Size: 4
	char pad_84[4];  // Offset: 84 Size: 4
	struct FStruct_TrapTreasureBoxShareableLoot CallFunc_Array_Get_Item;  // Offset: 88 Size: 48
	int32_t CallFunc_Array_Length_ReturnValue;  // Offset: 136 Size: 4
	char pad_140_1 : 7;  // Offset: 140 Size: 1
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // Offset: 140 Size: 1
	char pad_141[3];  // Offset: 141 Size: 3
	int32_t CallFunc_Add_IntInt_ReturnValue_3;  // Offset: 144 Size: 4
	char pad_148[4];  // Offset: 148 Size: 4
	struct FArkTextFormatParam K2Node_MakeStruct_ArkTextFormatParam;  // Offset: 152 Size: 24
	float CallFunc_Conv_IntToFloat_ReturnValue;  // Offset: 176 Size: 4
	char pad_180[4];  // Offset: 180 Size: 4
	struct FText CallFunc_K2_Format_ReturnValue;  // Offset: 184 Size: 24
	int32_t CallFunc_Array_Length_ReturnValue_2;  // Offset: 208 Size: 4
	char pad_212[4];  // Offset: 212 Size: 4
	struct FString CallFunc_Conv_TextToString_ReturnValue;  // Offset: 216 Size: 16
	float CallFunc_Conv_IntToFloat_ReturnValue_2;  // Offset: 232 Size: 4
	char pad_236[4];  // Offset: 236 Size: 4
	struct FProgressNodeInfo K2Node_MakeStruct_ProgressNodeInfo;  // Offset: 240 Size: 56
	float CallFunc_Divide_FloatFloat_ReturnValue;  // Offset: 296 Size: 4
	int32_t CallFunc_Array_Add_ReturnValue;  // Offset: 300 Size: 4
	char pad_304_1 : 7;  // Offset: 304 Size: 1
	bool CallFunc_Greater_IntInt_ReturnValue : 1;  // Offset: 304 Size: 1
	char pad_305[3];  // Offset: 305 Size: 3
	int32_t CallFunc_Add_IntInt_ReturnValue_4;  // Offset: 308 Size: 4
	struct AArkGameStatePve* CallFunc_GetGameStateAsPVE_AsArk_Game_State_Pve;  // Offset: 312 Size: 8
	struct AArkGameStateMaterialRun_TrapTreasureBox* K2Node_DynamicCast_AsArk_Game_State_Material_Run_Trap_Treasure_Box;  // Offset: 320 Size: 8
	char pad_328_1 : 7;  // Offset: 328 Size: 1
	bool K2Node_DynamicCast_bSuccess : 1;  // Offset: 328 Size: 1
	char pad_329[7];  // Offset: 329 Size: 7
	struct TArray<struct FName> CallFunc_GetDataTableRowNames_OutRowNames;  // Offset: 336 Size: 16
	struct FName CallFunc_Array_Get_Item_2;  // Offset: 352 Size: 8
	int32_t CallFunc_Array_Length_ReturnValue_3;  // Offset: 360 Size: 4
	char pad_364[4];  // Offset: 364 Size: 4
	struct FStruct_TrapTreasureBoxShareableLoot CallFunc_GetDataTableRowFromName_OutRow;  // Offset: 368 Size: 48
	char pad_416_1 : 7;  // Offset: 416 Size: 1
	bool CallFunc_GetDataTableRowFromName_ReturnValue : 1;  // Offset: 416 Size: 1
	char pad_417_1 : 7;  // Offset: 417 Size: 1
	bool CallFunc_Less_IntInt_ReturnValue_2 : 1;  // Offset: 417 Size: 1
	char pad_418[2];  // Offset: 418 Size: 2
	int32_t CallFunc_Array_Add_ReturnValue_2;  // Offset: 420 Size: 4
	char pad_424_1 : 7;  // Offset: 424 Size: 1
	bool CallFunc_EqualEqual_IntInt_ReturnValue : 1;  // Offset: 424 Size: 1



 // Functions 
 public:
}; 
 
 //Function ArkGameState_PVE_TrapTreasureBox.ArkGameState_PVE_TrapTreasureBox_C.SetCurrentWaveOrder Size 4
class FSetCurrentWaveOrder
{

 public: 
	int32_t InWaveOrder;  // Offset: 0 Size: 4



 // Functions 
 public:
}; 
 
 //Function ArkGameState_PVE_TrapTreasureBox.ArkGameState_PVE_TrapTreasureBox_C.NotifyWaveFinished Size 4
class FNotifyWaveFinished
{

 public: 
	int32_t InWaveOrder;  // Offset: 0 Size: 4



 // Functions 
 public:
}; 
 
 