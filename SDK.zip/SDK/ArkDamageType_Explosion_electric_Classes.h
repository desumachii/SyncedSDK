#pragma once 
#include <ArkDamageType_Explosion_electric_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkDamageType_Explosion_electric.ArkDamageType_Explosion_electric_C Size 264
// Inherited 264 bytes 
class UArkDamageType_Explosion_electric_C : public UArkDamageType_Explosion_C
{

 public: 



 // Functions 
 public:
}; 
 
 


