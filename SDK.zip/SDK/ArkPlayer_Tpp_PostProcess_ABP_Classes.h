#pragma once 
#include <ArkPlayer_Tpp_PostProcess_ABP_Structs.h>
 
 
 
//AnimBlueprintGeneratedClass ArkPlayer_Tpp_PostProcess_ABP.ArkPlayer_Tpp_PostProcess_ABP_C Size 22920
// Inherited 2160 bytes 
class UArkPlayer_Tpp_PostProcess_ABP_C : public UArkTppPostProcess
{

 public: 
	struct FPointerToUberGraphFrame UberGraphFrame;  // Offset: 2160 Size: 8
	char pad_2168[8];  // Offset: 2168 Size: 8
	struct FAnimNode_TwoBoneIK AnimGraphNode_TwoBoneIK_12;  // Offset: 2176 Size: 512
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_11;  // Offset: 2688 Size: 40
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_11;  // Offset: 2728 Size: 192
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_11;  // Offset: 2920 Size: 40
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_10;  // Offset: 2960 Size: 40
	char pad_3000[8];  // Offset: 3000 Size: 8
	struct FAnimNode_TwoBoneIK AnimGraphNode_TwoBoneIK_11;  // Offset: 3008 Size: 512
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_15;  // Offset: 3520 Size: 272
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_9;  // Offset: 3792 Size: 40
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_14;  // Offset: 3832 Size: 272
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_10;  // Offset: 4104 Size: 40
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_13;  // Offset: 4144 Size: 272
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_8;  // Offset: 4416 Size: 40
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_10;  // Offset: 4456 Size: 176
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_9;  // Offset: 4632 Size: 40
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_7;  // Offset: 4672 Size: 40
	char pad_4712[8];  // Offset: 4712 Size: 8
	struct FAnimNode_TwoBoneIK AnimGraphNode_TwoBoneIK_10;  // Offset: 4720 Size: 512
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_9;  // Offset: 5232 Size: 176
	struct FAnimNode_TwoBoneIK AnimGraphNode_TwoBoneIK_9;  // Offset: 5408 Size: 512
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_8;  // Offset: 5920 Size: 40
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_10;  // Offset: 5960 Size: 192
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend_2;  // Offset: 6152 Size: 200
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_8;  // Offset: 6352 Size: 176
	struct FAnimNode_LayeredBoneBlend AnimGraphNode_LayeredBoneBlend;  // Offset: 6528 Size: 200
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_7;  // Offset: 6728 Size: 176
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_9;  // Offset: 6904 Size: 192
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_8;  // Offset: 7096 Size: 192
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_12;  // Offset: 7288 Size: 272
	char pad_7560[8];  // Offset: 7560 Size: 8
	struct FAnimNode_TwoBoneIK AnimGraphNode_TwoBoneIK_8;  // Offset: 7568 Size: 512
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_11;  // Offset: 8080 Size: 272
	struct FAnimNode_TwoWayBlend AnimGraphNode_TwoWayBlend_3;  // Offset: 8352 Size: 208
	struct FAnimNode_TwoWayBlend AnimGraphNode_TwoWayBlend_2;  // Offset: 8560 Size: 208
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_25;  // Offset: 8768 Size: 48
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_24;  // Offset: 8816 Size: 48
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_23;  // Offset: 8864 Size: 48
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_22;  // Offset: 8912 Size: 48
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_21;  // Offset: 8960 Size: 48
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_20;  // Offset: 9008 Size: 48
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_7;  // Offset: 9056 Size: 192
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_19;  // Offset: 9248 Size: 48
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_6;  // Offset: 9296 Size: 176
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_10;  // Offset: 9472 Size: 272
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_9;  // Offset: 9744 Size: 272
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_8;  // Offset: 10016 Size: 272
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_7;  // Offset: 10288 Size: 272
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_6;  // Offset: 10560 Size: 40
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_6;  // Offset: 10600 Size: 192
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_18;  // Offset: 10792 Size: 48
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_17;  // Offset: 10840 Size: 48
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_7;  // Offset: 10888 Size: 40
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_6;  // Offset: 10928 Size: 40
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_5;  // Offset: 10968 Size: 272
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_5;  // Offset: 11240 Size: 192
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_16;  // Offset: 11432 Size: 48
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_15;  // Offset: 11480 Size: 48
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_6;  // Offset: 11528 Size: 272
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_5;  // Offset: 11800 Size: 40
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_5;  // Offset: 11840 Size: 40
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_4;  // Offset: 11880 Size: 192
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_5;  // Offset: 12072 Size: 176
	struct FAnimNode_TwoWayBlend AnimGraphNode_TwoWayBlend;  // Offset: 12248 Size: 208
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_14;  // Offset: 12456 Size: 48
	struct FAnimNode_BlendListByEnum AnimGraphNode_BlendListByEnum;  // Offset: 12504 Size: 192
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_4;  // Offset: 12696 Size: 272
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3;  // Offset: 12968 Size: 272
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2;  // Offset: 13240 Size: 272
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;  // Offset: 13512 Size: 272
	struct FAnimNode_RotationOffsetBlendSpace AnimGraphNode_RotationOffsetBlendSpace;  // Offset: 13784 Size: 640
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_13;  // Offset: 14424 Size: 48
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_3;  // Offset: 14472 Size: 192
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_5;  // Offset: 14664 Size: 272
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_4;  // Offset: 14936 Size: 272
	char pad_15208[8];  // Offset: 15208 Size: 8
	struct FAnimNode_TwoBoneIK AnimGraphNode_TwoBoneIK_7;  // Offset: 15216 Size: 512
	struct FAnimNode_TwoBoneIK AnimGraphNode_TwoBoneIK_6;  // Offset: 15728 Size: 512
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_4;  // Offset: 16240 Size: 40
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_4;  // Offset: 16280 Size: 40
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_12;  // Offset: 16320 Size: 48
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_11;  // Offset: 16368 Size: 48
	struct FAnimNode_FootPlacement AnimGraphNode_FootPlacement;  // Offset: 16416 Size: 496
	struct FAnimNode_Mirror AnimGraphNode_Mirror;  // Offset: 16912 Size: 48
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose_2;  // Offset: 16960 Size: 192
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_10;  // Offset: 17152 Size: 48
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_9;  // Offset: 17200 Size: 48
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_8;  // Offset: 17248 Size: 48
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_7;  // Offset: 17296 Size: 48
	struct FAnimNode_TwoBoneIK AnimGraphNode_TwoBoneIK_5;  // Offset: 17344 Size: 512
	struct FAnimNode_TwoBoneIK AnimGraphNode_TwoBoneIK_4;  // Offset: 17856 Size: 512
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_3;  // Offset: 18368 Size: 40
	char pad_18408[8];  // Offset: 18408 Size: 8
	struct FAnimNode_TwoBoneIK AnimGraphNode_TwoBoneIK_3;  // Offset: 18416 Size: 512
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_3;  // Offset: 18928 Size: 272
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_4;  // Offset: 19200 Size: 176
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace_2;  // Offset: 19376 Size: 40
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_3;  // Offset: 19416 Size: 40
	struct FAnimNode_TwoBoneIK AnimGraphNode_TwoBoneIK_2;  // Offset: 19456 Size: 512
	struct FAnimNode_TwoBoneIK AnimGraphNode_TwoBoneIK;  // Offset: 19968 Size: 512
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace_2;  // Offset: 20480 Size: 40
	struct FAnimNode_CopyBone AnimGraphNode_CopyBone_2;  // Offset: 20520 Size: 248
	struct FAnimNode_CopyBone AnimGraphNode_CopyBone;  // Offset: 20768 Size: 248
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_6;  // Offset: 21016 Size: 48
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone_2;  // Offset: 21064 Size: 272
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose;  // Offset: 21336 Size: 192
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_3;  // Offset: 21528 Size: 176
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_5;  // Offset: 21704 Size: 48
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_4;  // Offset: 21752 Size: 48
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_2;  // Offset: 21800 Size: 176
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_3;  // Offset: 21976 Size: 48
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_2;  // Offset: 22024 Size: 48
	struct FAnimNode_ModifyBone AnimGraphNode_ModifyBone;  // Offset: 22072 Size: 272
	struct FAnimNode_LinkedInputPose AnimGraphNode_SubInput;  // Offset: 22344 Size: 128
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose;  // Offset: 22472 Size: 48
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool;  // Offset: 22520 Size: 176
	struct FAnimNode_Root AnimGraphNode_Root;  // Offset: 22696 Size: 56
	struct FAnimNode_ConvertComponentToLocalSpace AnimGraphNode_ComponentToLocalSpace;  // Offset: 22752 Size: 40
	struct FAnimNode_ConvertLocalToComponentSpace AnimGraphNode_LocalToComponentSpace;  // Offset: 22792 Size: 40
	float DeltaTimeX;  // Offset: 22832 Size: 4
	enum class EMovementMode MovementMode;  // Offset: 22836 Size: 1
	char pad_22837[3];  // Offset: 22837 Size: 3
	struct FName LeftFootBoneName_1;  // Offset: 22840 Size: 8
	struct FName RightFootBoneName_1;  // Offset: 22848 Size: 8
	struct FVector TraceStartOffset;  // Offset: 22856 Size: 12
	struct FVector TraceEndOffset;  // Offset: 22868 Size: 12
	struct AArkPlayer* PlayerRef;  // Offset: 22880 Size: 8
	struct FRotator CASpineRotation;  // Offset: 22888 Size: 12
	struct FVector CAHandPosOffset;  // Offset: 22900 Size: 12
	float NewVar_1;  // Offset: 22912 Size: 4
	float NewVar_2;  // Offset: 22916 Size: 4



 // Functions 
 public:
	void AnimGraph(struct FPoseLink InPose, struct FPoseLink& AnimGraph); // Function ArkPlayer_Tpp_PostProcess_ABP.ArkPlayer_Tpp_PostProcess_ABP_C.AnimGraph
	void ExecuteUbergraph_ArkPlayer_Tpp_PostProcess_ABP(int32_t EntryPoint); // Function ArkPlayer_Tpp_PostProcess_ABP.ArkPlayer_Tpp_PostProcess_ABP_C.ExecuteUbergraph_ArkPlayer_Tpp_PostProcess_ABP
}; 
 
 


