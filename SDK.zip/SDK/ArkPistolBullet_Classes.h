#pragma once 
#include <ArkPistolBullet_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkPistolBullet.ArkPistolBullet_C Size 1872
// Inherited 1872 bytes 
class AArkPistolBullet_C : public ABP_SimulateBulletBase_C
{

 public: 



 // Functions 
 public:
}; 
 
 


