#pragma once 
#include <SDK_Engine_Objects.h> 
 
 
//Function ArkGABuff_ReviveMaster_Lv1.ArkGABuff_ReviveMaster_Lv1_C.UpdateBeamEndPoint Size 29
class FUpdateBeamEndPoint
{

 public: 
	char pad_0_1 : 7;  // Offset: 0 Size: 1
	bool CallFunc_IsValid_ReturnValue : 1;  // Offset: 0 Size: 1
	char pad_1[3];  // Offset: 1 Size: 3
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // Offset: 4 Size: 12
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // Offset: 16 Size: 12
	char pad_28_1 : 7;  // Offset: 28 Size: 1
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // Offset: 28 Size: 1



 // Functions 
 public:
}; 
 
 //Function ArkGABuff_ReviveMaster_Lv1.ArkGABuff_ReviveMaster_Lv1_C.ExecuteUbergraph_ArkGABuff_ReviveMaster_Lv1 Size 82
class FExecuteUbergraph_ArkGABuff_ReviveMaster_Lv1
{

 public: 
	int32_t EntryPoint;  // Offset: 0 Size: 4
	char pad_4_1 : 7;  // Offset: 4 Size: 1
	bool CallFunc_IsDedicatedServer_ReturnValue : 1;  // Offset: 4 Size: 1
	char pad_5[3];  // Offset: 5 Size: 3
	struct AActor* K2Node_Event_targetActor;  // Offset: 8 Size: 8
	struct AActor* CallFunc_GetOwner_ReturnValue;  // Offset: 16 Size: 8
	struct AArkNpc* K2Node_DynamicCast_AsArk_Npc;  // Offset: 24 Size: 8
	char pad_32_1 : 7;  // Offset: 32 Size: 1
	bool K2Node_DynamicCast_bSuccess : 1;  // Offset: 32 Size: 1
	char pad_33[3];  // Offset: 33 Size: 3
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // Offset: 36 Size: 12
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // Offset: 48 Size: 12
	char pad_60[4];  // Offset: 60 Size: 4
	struct UArkSoftParticleSystemComponentWithPool* CallFunc_SpawnSoftEmitterAttached_ReturnValue;  // Offset: 64 Size: 8
	struct FTimerHandle CallFunc_K2_SetTimer_ReturnValue;  // Offset: 72 Size: 8
	enum class EArkAIGAActionStopReason K2Node_Event_StopReason;  // Offset: 80 Size: 1
	char pad_81_1 : 7;  // Offset: 81 Size: 1
	bool CallFunc_IsValid_ReturnValue : 1;  // Offset: 81 Size: 1



 // Functions 
 public:
}; 
 
 //Function ArkGABuff_ReviveMaster_Lv1.ArkGABuff_ReviveMaster_Lv1_C.OnStopAction_BP Size 1
// Inherited 1 bytes 
class FOnStopAction_BP : public FOnStopAction_BP
{

 public: 
	enum class EArkAIGAActionStopReason StopReason;  // Offset: 0 Size: 1



 // Functions 
 public:
}; 
 
 //Function ArkGABuff_ReviveMaster_Lv1.ArkGABuff_ReviveMaster_Lv1_C.OnPerformAction_BP Size 8
// Inherited 8 bytes 
class FOnPerformAction_BP : public FOnPerformAction_BP
{

 public: 
	struct AActor* TargetActor;  // Offset: 0 Size: 8



 // Functions 
 public:
}; 
 
 