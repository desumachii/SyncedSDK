#pragma once 
#include <AlwaysLoadedAssetsModule_Structs.h>
 
 
 
//Class AlwaysLoadedAssetsModule.AlwaysLoadedAssetsSettings Size 104
// Inherited 40 bytes 
class UAlwaysLoadedAssetsSettings : public UObject
{

 public: 
	struct TArray<struct FSoftClassPath> AlwaysLoadedAssetsByType;  // Offset: 40 Size: 16
	struct TArray<struct FSoftClassPath> AlwaysLoadedBlueprintsByClass;  // Offset: 56 Size: 16
	struct TArray<struct FSoftObjectPath> AlwaysLoadedAssets;  // Offset: 72 Size: 16
	struct TArray<struct FSoftObjectPath> AssetsWillBeLoaded;  // Offset: 88 Size: 16



 // Functions 
 public:
}; 
 
 


