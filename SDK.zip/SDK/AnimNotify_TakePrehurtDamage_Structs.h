#pragma once 
#include <SDK_Engine_Objects.h> 
 
 
//Function AnimNotify_TakePrehurtDamage.AnimNotify_TakePrehurtDamage_C.Received_Notify Size 269
// Inherited 24 bytes 
class FReceived_Notify : public FReceived_Notify
{

 public: 
	struct USkeletalMeshComponent* MeshComp;  // Offset: 0 Size: 8
	struct UAnimSequenceBase* Animation;  // Offset: 8 Size: 8
	char pad_40_1 : 7;  // Offset: 40 Size: 1
	bool ReturnValue : 1;  // Offset: 16 Size: 1
	struct AActor* CallFunc_GetOwner_ReturnValue;  // Offset: 24 Size: 8
	int32_t Temp_int_Array_Index_Variable;  // Offset: 32 Size: 4
	struct AArkCharacterBase* K2Node_DynamicCast_AsArk_Character_Base;  // Offset: 40 Size: 8
	char pad_61_1 : 7;  // Offset: 61 Size: 1
	bool K2Node_DynamicCast_bSuccess : 1;  // Offset: 48 Size: 1
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // Offset: 52 Size: 12
	int32_t Temp_int_Loop_Counter_Variable;  // Offset: 64 Size: 4
	int32_t CallFunc_Add_IntInt_ReturnValue;  // Offset: 68 Size: 4
	struct TArray<struct AArkNpc*> CallFunc_GetNPCsInRange_ReturnValue;  // Offset: 72 Size: 16
	int32_t CallFunc_Array_Length_ReturnValue;  // Offset: 88 Size: 4
	struct AArkNpc* CallFunc_Array_Get_Item;  // Offset: 96 Size: 8
	char pad_110_1 : 7;  // Offset: 110 Size: 1
	bool CallFunc_Less_IntInt_ReturnValue : 1;  // Offset: 104 Size: 1
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue_2;  // Offset: 108 Size: 12
	struct FVector CallFunc_Subtract_VectorVector_ReturnValue;  // Offset: 120 Size: 12
	struct FHitResult CallFunc_MakeHitResult_ReturnValue;  // Offset: 132 Size: 136
	char pad_271_1 : 7;  // Offset: 271 Size: 1
	bool CallFunc_ArkApplyPointDamage_ReturnValue : 1;  // Offset: 268 Size: 1



 // Functions 
 public:
}; 
 
 