#pragma once 
#include <AmmoPickup1200_Structs.h>
 
 
 
//BlueprintGeneratedClass AmmoPickup1200.AmmoPickup1200_C Size 2416
// Inherited 2416 bytes 
class AAmmoPickup1200_C : public AAmmoPickupBase_C
{

 public: 



 // Functions 
 public:
}; 
 
 


