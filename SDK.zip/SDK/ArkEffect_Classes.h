#pragma once 
#include <ArkEffect_Structs.h>
 
 
 
//Class ArkEffect.ArkEffect_PlayPostProcess Size 88
// Inherited 48 bytes 
class UArkEffect_PlayPostProcess : public UArkEffect
{

 public: 
	struct FString PostProcessTypeName;  // Offset: 48 Size: 16
	float DisplayDuration;  // Offset: 64 Size: 4
	char pad_68[4];  // Offset: 68 Size: 4
	struct AArkPlayer* CachePlayer;  // Offset: 72 Size: 8
	struct FTimerHandle PostProcess_TimerHandle;  // Offset: 80 Size: 8



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_AddAmmo Size 64
// Inherited 48 bytes 
class UArkEffect_AddAmmo : public UArkEffect
{

 public: 
	int32_t Count;  // Offset: 48 Size: 4
	float Percent;  // Offset: 52 Size: 4
	char pad_56_1 : 7;  // Offset: 56 Size: 1
	bool bag : 1;  // Offset: 56 Size: 1
	char pad_57_1 : 7;  // Offset: 57 Size: 1
	bool CLIP : 1;  // Offset: 57 Size: 1
	char pad_58_1 : 7;  // Offset: 58 Size: 1
	bool Free : 1;  // Offset: 58 Size: 1
	char pad_59[5];  // Offset: 59 Size: 5



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_AddBuffToRange Size 80
// Inherited 48 bytes 
class UArkEffect_AddBuffToRange : public UArkEffect
{

 public: 
	char pad_48[16];  // Offset: 48 Size: 16
	UArkGameBuff* BuffClass;  // Offset: 64 Size: 8
	int32_t BuffID;  // Offset: 72 Size: 4
	char pad_76[4];  // Offset: 76 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_RemoveBuffByTag Size 56
// Inherited 48 bytes 
class UArkEffect_RemoveBuffByTag : public UArkEffect
{

 public: 
	struct FName BuffTag;  // Offset: 48 Size: 8



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_AddBuffForSyncAI Size 72
// Inherited 48 bytes 
class UArkEffect_AddBuffForSyncAI : public UArkEffect
{

 public: 
	UArkGameBuff* BuffClass;  // Offset: 48 Size: 8
	int32_t BuffID;  // Offset: 56 Size: 4
	struct FName CheckAIType;  // Offset: 60 Size: 8
	char pad_68[4];  // Offset: 68 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_AddAmmoInClip Size 64
// Inherited 48 bytes 
class UArkEffect_AddAmmoInClip : public UArkEffect
{

 public: 
	int32_t Count;  // Offset: 48 Size: 4
	float Percent;  // Offset: 52 Size: 4
	char pad_56_1 : 7;  // Offset: 56 Size: 1
	bool Free : 1;  // Offset: 56 Size: 1
	char pad_57[7];  // Offset: 57 Size: 7



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_ChangeCDDuration Size 64
// Inherited 48 bytes 
class UArkEffect_ChangeCDDuration : public UArkEffect
{

 public: 
	struct FName Tag;  // Offset: 48 Size: 8
	float Value;  // Offset: 56 Size: 4
	char pad_60[4];  // Offset: 60 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_AddBuffTagTime Size 64
// Inherited 48 bytes 
class UArkEffect_AddBuffTagTime : public UArkEffect
{

 public: 
	struct FName Tag;  // Offset: 48 Size: 8
	float ModifyValue;  // Offset: 56 Size: 4
	float ModifyPercentage;  // Offset: 60 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_AddAmmoPerMag Size 72
// Inherited 48 bytes 
class UArkEffect_AddAmmoPerMag : public UArkEffect
{

 public: 
	float Percent;  // Offset: 48 Size: 4
	float MaxValue;  // Offset: 52 Size: 4
	float HasAdd;  // Offset: 56 Size: 4
	char pad_60[12];  // Offset: 60 Size: 12



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_ChangeCD Size 64
// Inherited 48 bytes 
class UArkEffect_ChangeCD : public UArkEffect
{

 public: 
	struct FName Tag;  // Offset: 48 Size: 8
	float Value;  // Offset: 56 Size: 4
	char pad_60[4];  // Offset: 60 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_AddBuff Size 64
// Inherited 48 bytes 
class UArkEffect_AddBuff : public UArkEffect
{

 public: 
	UArkGameBuff* BuffClass;  // Offset: 48 Size: 8
	int32_t BuffID;  // Offset: 56 Size: 4
	char pad_60[4];  // Offset: 60 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_RemoveParticle Size 56
// Inherited 48 bytes 
class UArkEffect_RemoveParticle : public UArkEffect
{

 public: 
	int32_t ParticleIdx;  // Offset: 48 Size: 4
	char pad_52[4];  // Offset: 52 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_BulletPenetrateSpreadBuff Size 48
// Inherited 48 bytes 
class UArkEffect_BulletPenetrateSpreadBuff : public UArkEffect
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_ChangeEnergyRate Size 64
// Inherited 48 bytes 
class UArkEffect_ChangeEnergyRate : public UArkEffect
{

 public: 
	struct FName Tag;  // Offset: 48 Size: 8
	float Value;  // Offset: 56 Size: 4
	char pad_60[4];  // Offset: 60 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_AddCurPerEnergy Size 56
// Inherited 48 bytes 
class UArkEffect_AddCurPerEnergy : public UArkEffect
{

 public: 
	float Percent;  // Offset: 48 Size: 4
	char pad_52[4];  // Offset: 52 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_AddDensity Size 56
// Inherited 48 bytes 
class UArkEffect_AddDensity : public UArkEffect
{

 public: 
	float Density;  // Offset: 48 Size: 4
	char pad_52[4];  // Offset: 52 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_DamageAndHeal Size 72
// Inherited 48 bytes 
class UArkEffect_DamageAndHeal : public UArkEffect
{

 public: 
	char pad_48_1 : 7;  // Offset: 48 Size: 1
	bool HasDamage : 1;  // Offset: 48 Size: 1
	char pad_49[3];  // Offset: 49 Size: 3
	struct FEffect_Value Damage;  // Offset: 52 Size: 8
	char pad_60_1 : 7;  // Offset: 60 Size: 1
	bool HasHeal : 1;  // Offset: 60 Size: 1
	char pad_61[3];  // Offset: 61 Size: 3
	struct FEffect_Value Heal;  // Offset: 64 Size: 8



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_BulletPenetrate Size 56
// Inherited 48 bytes 
class UArkEffect_BulletPenetrate : public UArkEffect
{

 public: 
	int32_t ModifyCount;  // Offset: 48 Size: 4
	char pad_52[4];  // Offset: 52 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_AddDeputyAmmo Size 64
// Inherited 64 bytes 
class UArkEffect_AddDeputyAmmo : public UArkEffect_AddAmmo
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_AddDeputyAmmoInClip Size 64
// Inherited 64 bytes 
class UArkEffect_AddDeputyAmmoInClip : public UArkEffect_AddAmmoInClip
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_AddBuffTime Size 64
// Inherited 48 bytes 
class UArkEffect_AddBuffTime : public UArkEffect
{

 public: 
	UArkGameBuff* BuffClass;  // Offset: 48 Size: 8
	int32_t BuffID;  // Offset: 56 Size: 4
	float Seconds;  // Offset: 60 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_CastElectricChain Size 48
// Inherited 48 bytes 
class UArkEffect_CastElectricChain : public UArkEffect
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_CauseStartle Size 48
// Inherited 48 bytes 
class UArkEffect_CauseStartle : public UArkEffect
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_ChangeCDRate Size 64
// Inherited 48 bytes 
class UArkEffect_ChangeCDRate : public UArkEffect
{

 public: 
	struct FName Tag;  // Offset: 48 Size: 8
	float Value;  // Offset: 56 Size: 4
	char pad_60[4];  // Offset: 60 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_HealMaster Size 56
// Inherited 48 bytes 
class UArkEffect_HealMaster : public UArkEffect
{

 public: 
	float Value;  // Offset: 48 Size: 4
	enum class EArkFormulaCalculationMethod Method;  // Offset: 52 Size: 1
	char pad_53[3];  // Offset: 53 Size: 3



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_ResetCD Size 56
// Inherited 48 bytes 
class UArkEffect_ResetCD : public UArkEffect
{

 public: 
	struct FName Tag;  // Offset: 48 Size: 8



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_StartCD Size 64
// Inherited 48 bytes 
class UArkEffect_StartCD : public UArkEffect
{

 public: 
	struct FName Tag;  // Offset: 48 Size: 8
	float Duration;  // Offset: 56 Size: 4
	int32_t ModID;  // Offset: 60 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_ModifyChipCDRemain Size 56
// Inherited 48 bytes 
class UArkEffect_ModifyChipCDRemain : public UArkEffect
{

 public: 
	int32_t Value;  // Offset: 48 Size: 4
	float Percent;  // Offset: 52 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_ModCDNtfUI Size 48
// Inherited 48 bytes 
class UArkEffect_ModCDNtfUI : public UArkEffect
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_StopCD Size 64
// Inherited 48 bytes 
class UArkEffect_StopCD : public UArkEffect
{

 public: 
	struct FName Tag;  // Offset: 48 Size: 8
	int32_t ModID;  // Offset: 56 Size: 4
	char pad_60[4];  // Offset: 60 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_ChangeTeam Size 48
// Inherited 48 bytes 
class UArkEffect_ChangeTeam : public UArkEffect
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_CloneSyncAIDotBuffs Size 64
// Inherited 48 bytes 
class UArkEffect_CloneSyncAIDotBuffs : public UArkEffect
{

 public: 
	enum class EArkElementType ElemType_Condition;  // Offset: 48 Size: 1
	char pad_49[3];  // Offset: 49 Size: 3
	int32_t BuffID;  // Offset: 52 Size: 4
	UArkGameBuff* BuffClass;  // Offset: 56 Size: 8



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_ReloadAllWeapon Size 56
// Inherited 48 bytes 
class UArkEffect_ReloadAllWeapon : public UArkEffect
{

 public: 
	char pad_48_1 : 7;  // Offset: 48 Size: 1
	bool ExceptCurrent : 1;  // Offset: 48 Size: 1
	char pad_49[7];  // Offset: 49 Size: 7



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_ModifySkillCD Size 56
// Inherited 48 bytes 
class UArkEffect_ModifySkillCD : public UArkEffect
{

 public: 
	int32_t Value;  // Offset: 48 Size: 4
	float Percent;  // Offset: 52 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_LootAmmo Size 128
// Inherited 48 bytes 
class UArkEffect_LootAmmo : public UArkEffect
{

 public: 
	struct TMap<int32_t, struct FString> LootByAmmo;  // Offset: 48 Size: 80



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_ConsumeAmmo Size 56
// Inherited 48 bytes 
class UArkEffect_ConsumeAmmo : public UArkEffect
{

 public: 
	int32_t Count;  // Offset: 48 Size: 4
	char pad_52_1 : 7;  // Offset: 52 Size: 1
	bool CLIP : 1;  // Offset: 52 Size: 1
	char pad_53[3];  // Offset: 53 Size: 3



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_Damage Size 64
// Inherited 48 bytes 
class UArkEffect_Damage : public UArkEffect
{

 public: 
	float Damage;  // Offset: 48 Size: 4
	float DamagePercent;  // Offset: 52 Size: 4
	enum class EArkDamageTypeTag DamageTypeTag;  // Offset: 56 Size: 1
	char pad_57[7];  // Offset: 57 Size: 7



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_DamageIgnoreShield Size 56
// Inherited 48 bytes 
class UArkEffect_DamageIgnoreShield : public UArkEffect
{

 public: 
	float Damage;  // Offset: 48 Size: 4
	float DamagePercent;  // Offset: 52 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_AddEnergy Size 64
// Inherited 48 bytes 
class UArkEffect_AddEnergy : public UArkEffect
{

 public: 
	struct FName Tag;  // Offset: 48 Size: 8
	float Value;  // Offset: 56 Size: 4
	char pad_60[4];  // Offset: 60 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_DisPlayIcon Size 120
// Inherited 48 bytes 
class UArkEffect_DisPlayIcon : public UArkEffect
{

 public: 
	int32_t IconIdx;  // Offset: 48 Size: 4
	float DisplayDuration;  // Offset: 52 Size: 4
	char pad_56_1 : 7;  // Offset: 56 Size: 1
	bool bSuperPerkIcon : 1;  // Offset: 56 Size: 1
	char pad_57[7];  // Offset: 57 Size: 7
	struct AArkPlayer* CachePlayer;  // Offset: 64 Size: 8
	struct FTimerHandle IconDisplay_TimerHandle;  // Offset: 72 Size: 8
	struct TSoftObjectPtr<UTexture2D> IconResource;  // Offset: 80 Size: 40



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_DoDetection Size 56
// Inherited 48 bytes 
class UArkEffect_DoDetection : public UArkEffect
{

 public: 
	char pad_48[8];  // Offset: 48 Size: 8



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_DropEnergy Size 56
// Inherited 48 bytes 
class UArkEffect_DropEnergy : public UArkEffect
{

 public: 
	char pad_48[8];  // Offset: 48 Size: 8



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_ChangeEnergyMax Size 64
// Inherited 48 bytes 
class UArkEffect_ChangeEnergyMax : public UArkEffect
{

 public: 
	struct FName Tag;  // Offset: 48 Size: 8
	float Value;  // Offset: 56 Size: 4
	char pad_60[4];  // Offset: 60 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_CostEnergy Size 64
// Inherited 48 bytes 
class UArkEffect_CostEnergy : public UArkEffect
{

 public: 
	struct FName Tag;  // Offset: 48 Size: 8
	float Value;  // Offset: 56 Size: 4
	char pad_60[4];  // Offset: 60 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_ExtraExchangePriceRate Size 56
// Inherited 48 bytes 
class UArkEffect_ExtraExchangePriceRate : public UArkEffect
{

 public: 
	float Percent;  // Offset: 48 Size: 4
	char pad_52[4];  // Offset: 52 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_FireSpeedUp Size 64
// Inherited 48 bytes 
class UArkEffect_FireSpeedUp : public UArkEffect
{

 public: 
	float SpeedUpValue;  // Offset: 48 Size: 4
	enum class EArkFormulaCalculationMethod SpeedUpMethod;  // Offset: 52 Size: 1
	char pad_53[3];  // Offset: 53 Size: 3
	float ClipPercent;  // Offset: 56 Size: 4
	char pad_60[4];  // Offset: 60 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_Funnel Size 104
// Inherited 48 bytes 
class UArkEffect_Funnel : public UArkEffect
{

 public: 
	struct AArkPlayer* OwnerCharacter;  // Offset: 48 Size: 8
	char pad_56[48];  // Offset: 56 Size: 48



 // Functions 
 public:
	void SpawnFunnel(); // Function ArkEffect.ArkEffect_Funnel.SpawnFunnel
}; 
 
 


//Class ArkEffect.ArkEffect_ModifyQuestTime Size 64
// Inherited 48 bytes 
class UArkEffect_ModifyQuestTime : public UArkEffect
{

 public: 
	enum class EArkGameBuff_ModifyQuestTime ModifyType;  // Offset: 48 Size: 1
	char pad_49[3];  // Offset: 49 Size: 3
	float Duration;  // Offset: 52 Size: 4
	float TimeFactor;  // Offset: 56 Size: 4
	int32_t questID;  // Offset: 60 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_GiveWeapon Size 64
// Inherited 48 bytes 
class UArkEffect_GiveWeapon : public UArkEffect
{

 public: 
	enum class EWeaponInventorySlot WeaponSlot;  // Offset: 48 Size: 1
	char pad_49[3];  // Offset: 49 Size: 3
	int32_t WeaponItemID;  // Offset: 52 Size: 4
	char pad_56_1 : 7;  // Offset: 56 Size: 1
	bool bAttach : 1;  // Offset: 56 Size: 1
	char pad_57[7];  // Offset: 57 Size: 7



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_HealDamagePer Size 56
// Inherited 48 bytes 
class UArkEffect_HealDamagePer : public UArkEffect
{

 public: 
	float Value;  // Offset: 48 Size: 4
	enum class EArkFormulaCalculationMethod Method;  // Offset: 52 Size: 1
	char pad_53[3];  // Offset: 53 Size: 3



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_GroupStartle Size 48
// Inherited 48 bytes 
class UArkEffect_GroupStartle : public UArkEffect
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_Heal Size 64
// Inherited 48 bytes 
class UArkEffect_Heal : public UArkEffect
{

 public: 
	float Value;  // Offset: 48 Size: 4
	enum class EArkFormulaCalculationMethod Method;  // Offset: 52 Size: 1
	char pad_53[3];  // Offset: 53 Size: 3
	int32_t PercentBaseSelect;  // Offset: 56 Size: 4
	char pad_60[4];  // Offset: 60 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_HealSync Size 56
// Inherited 48 bytes 
class UArkEffect_HealSync : public UArkEffect
{

 public: 
	float Value;  // Offset: 48 Size: 4
	enum class EArkFormulaCalculationMethod Method;  // Offset: 52 Size: 1
	char pad_53[3];  // Offset: 53 Size: 3



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_HighLightEnemyPlayer Size 56
// Inherited 48 bytes 
class UArkEffect_HighLightEnemyPlayer : public UArkEffect
{

 public: 
	char pad_48_1 : 7;  // Offset: 48 Size: 1
	bool bEnable : 1;  // Offset: 48 Size: 1
	char pad_49[7];  // Offset: 49 Size: 7



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_AddItemEnergy Size 56
// Inherited 48 bytes 
class UArkEffect_AddItemEnergy : public UArkEffect
{

 public: 
	float Value;  // Offset: 48 Size: 4
	char pad_52[4];  // Offset: 52 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_ModifyAvatarPartMIDParameter Size 64
// Inherited 48 bytes 
class UArkEffect_ModifyAvatarPartMIDParameter : public UArkEffect
{

 public: 
	enum class EArkAvatarPartType AvatarPartType;  // Offset: 48 Size: 1
	char pad_49[3];  // Offset: 49 Size: 3
	struct FName ParamName;  // Offset: 52 Size: 8
	float Value;  // Offset: 60 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_PlaySound Size 80
// Inherited 48 bytes 
class UArkEffect_PlaySound : public UArkEffect
{

 public: 
	int32_t SoundIdx;  // Offset: 48 Size: 4
	char pad_52_1 : 7;  // Offset: 52 Size: 1
	bool bSelfOrEnemy : 1;  // Offset: 52 Size: 1
	char pad_53[3];  // Offset: 53 Size: 3
	struct AArkCharacterBase* CacheCharacter;  // Offset: 56 Size: 8
	struct TArray<int32_t> CacheUIDs;  // Offset: 64 Size: 16



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_ModifyMPCValue Size 104
// Inherited 48 bytes 
class UArkEffect_ModifyMPCValue : public UArkEffect
{

 public: 
	struct TSoftObjectPtr<UMaterialParameterCollection> MPC;  // Offset: 48 Size: 40
	struct FName ParamName;  // Offset: 88 Size: 8
	float Value;  // Offset: 96 Size: 4
	char pad_100[4];  // Offset: 100 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_ReloadMasterWeapon Size 48
// Inherited 48 bytes 
class UArkEffect_ReloadMasterWeapon : public UArkEffect
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_SetDensityFactorInfo Size 80
// Inherited 48 bytes 
class UArkEffect_SetDensityFactorInfo : public UArkEffect
{

 public: 
	float InitialDensityPercent;  // Offset: 48 Size: 4
	float Factor;  // Offset: 52 Size: 4
	float CheckInterval;  // Offset: 56 Size: 4
	char pad_60[4];  // Offset: 60 Size: 4
	struct TArray<int32_t> BuffIDs;  // Offset: 64 Size: 16



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_ModifyWeaponMIDParameter Size 64
// Inherited 48 bytes 
class UArkEffect_ModifyWeaponMIDParameter : public UArkEffect
{

 public: 
	enum class EWeaponInventorySlot WeaponSlot;  // Offset: 48 Size: 1
	char pad_49[3];  // Offset: 49 Size: 3
	struct FName ParamName;  // Offset: 52 Size: 8
	float Value;  // Offset: 60 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_RemoveBuff Size 64
// Inherited 48 bytes 
class UArkEffect_RemoveBuff : public UArkEffect
{

 public: 
	int32_t BuffID;  // Offset: 48 Size: 4
	char pad_52[4];  // Offset: 52 Size: 4
	UArkGameBuff* BuffClass;  // Offset: 56 Size: 8



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_OneShootOneKill Size 72
// Inherited 48 bytes 
class UArkEffect_OneShootOneKill : public UArkEffect
{

 public: 
	float Probability;  // Offset: 48 Size: 4
	struct FEffect_Value Health;  // Offset: 52 Size: 8
	char pad_60[4];  // Offset: 60 Size: 4
	UArkDamageType* DamageType;  // Offset: 64 Size: 8



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_PlayParticle Size 96
// Inherited 48 bytes 
class UArkEffect_PlayParticle : public UArkEffect
{

 public: 
	int32_t ParticleIdx;  // Offset: 48 Size: 4
	struct FName AttachSocketName;  // Offset: 52 Size: 8
	char pad_60_1 : 7;  // Offset: 60 Size: 1
	bool bSelfOrEnemy : 1;  // Offset: 60 Size: 1
	char pad_61[3];  // Offset: 61 Size: 3
	int32_t bBodyOrWeaponOrHitLocation;  // Offset: 64 Size: 4
	char pad_68[4];  // Offset: 68 Size: 4
	struct AArkCharacterBase* CacheCharacter;  // Offset: 72 Size: 8
	struct TArray<int32_t> CacheUIDs;  // Offset: 80 Size: 16



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_ResistFinalAttack Size 56
// Inherited 48 bytes 
class UArkEffect_ResistFinalAttack : public UArkEffect
{

 public: 
	int32_t MinHealthValue;  // Offset: 48 Size: 4
	float MinHealthPercent;  // Offset: 52 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_Revive Size 48
// Inherited 48 bytes 
class UArkEffect_Revive : public UArkEffect
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_ReviveFacility Size 56
// Inherited 48 bytes 
class UArkEffect_ReviveFacility : public UArkEffect
{

 public: 
	char pad_48[8];  // Offset: 48 Size: 8



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_SetDensityZeroInfo Size 72
// Inherited 48 bytes 
class UArkEffect_SetDensityZeroInfo : public UArkEffect
{

 public: 
	float Duration;  // Offset: 48 Size: 4
	float CheckInterval;  // Offset: 52 Size: 4
	struct TArray<int32_t> BuffIDs;  // Offset: 56 Size: 16



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_SetEnemyPlayerMarker Size 48
// Inherited 48 bytes 
class UArkEffect_SetEnemyPlayerMarker : public UArkEffect
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_SetPlayerDensityInfo Size 64
// Inherited 48 bytes 
class UArkEffect_SetPlayerDensityInfo : public UArkEffect
{

 public: 
	struct TArray<int32_t> BuffIDs;  // Offset: 48 Size: 16



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_Shield Size 64
// Inherited 48 bytes 
class UArkEffect_Shield : public UArkEffect
{

 public: 
	float Value;  // Offset: 48 Size: 4
	enum class EArkFormulaCalculationMethod Method;  // Offset: 52 Size: 1
	char pad_53[3];  // Offset: 53 Size: 3
	int32_t PercentBaseSelect;  // Offset: 56 Size: 4
	char pad_60[4];  // Offset: 60 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_SpawnDamageArea Size 72
// Inherited 48 bytes 
class UArkEffect_SpawnDamageArea : public UArkEffect
{

 public: 
	AArkDamageArea* AreaClass;  // Offset: 48 Size: 8
	int32_t BuffID;  // Offset: 56 Size: 4
	int32_t DamageType;  // Offset: 60 Size: 4
	int32_t LocationType;  // Offset: 64 Size: 4
	float FixDamagePercentage;  // Offset: 68 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_ShieldRecover Size 48
// Inherited 48 bytes 
class UArkEffect_ShieldRecover : public UArkEffect
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_ShotTipsParameter Size 64
// Inherited 48 bytes 
class UArkEffect_ShotTipsParameter : public UArkEffect
{

 public: 
	char pad_48[16];  // Offset: 48 Size: 16



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_SpawnBuffArea Size 56
// Inherited 48 bytes 
class UArkEffect_SpawnBuffArea : public UArkEffect
{

 public: 
	AArkBuffArea* AreaClass;  // Offset: 48 Size: 8



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_SpawnBuffGadget Size 88
// Inherited 48 bytes 
class UArkEffect_SpawnBuffGadget : public UArkEffect
{

 public: 
	int32_t ItemId;  // Offset: 48 Size: 4
	struct FName SpawnSocoket;  // Offset: 52 Size: 8
	char pad_60[4];  // Offset: 60 Size: 4
	struct FString GadgetParam;  // Offset: 64 Size: 16
	char pad_80_1 : 7;  // Offset: 80 Size: 1
	bool bOnBodyOrWeapon : 1;  // Offset: 80 Size: 1
	char pad_81[7];  // Offset: 81 Size: 7



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_SpawnGadget Size 88
// Inherited 48 bytes 
class UArkEffect_SpawnGadget : public UArkEffect
{

 public: 
	int32_t ItemId;  // Offset: 48 Size: 4
	struct FName SpawnSocoket;  // Offset: 52 Size: 8
	char pad_60[4];  // Offset: 60 Size: 4
	struct FString GadgetParam;  // Offset: 64 Size: 16
	char pad_80_1 : 7;  // Offset: 80 Size: 1
	bool bOnBodyOrWeapon : 1;  // Offset: 80 Size: 1
	char pad_81[7];  // Offset: 81 Size: 7



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_SpawnPickUpItem Size 56
// Inherited 48 bytes 
class UArkEffect_SpawnPickUpItem : public UArkEffect
{

 public: 
	char pad_48[8];  // Offset: 48 Size: 8



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_SplitProjectile Size 56
// Inherited 48 bytes 
class UArkEffect_SplitProjectile : public UArkEffect
{

 public: 
	UArkGameBuff* BuffClass;  // Offset: 48 Size: 8



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkEffect_ToggleAbilityTag Size 64
// Inherited 48 bytes 
class UArkEffect_ToggleAbilityTag : public UArkEffect
{

 public: 
	struct FGameplayTag AbilityTag;  // Offset: 48 Size: 8
	char pad_56_1 : 7;  // Offset: 56 Size: 1
	bool bAddOrRemove : 1;  // Offset: 56 Size: 1
	char pad_57[7];  // Offset: 57 Size: 7



 // Functions 
 public:
}; 
 
 


//Class ArkEffect.ArkSubEffectManager Size 200
// Inherited 200 bytes 
class UArkSubEffectManager : public UArkEffectManager
{

 public: 



 // Functions 
 public:
}; 
 
 


