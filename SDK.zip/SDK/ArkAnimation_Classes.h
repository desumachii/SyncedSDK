#pragma once 
#include <ArkAnimation_Structs.h>
 
 
 
//Class ArkAnimation.AnimNotify_GunFire Size 88
// Inherited 56 bytes 
class UAnimNotify_GunFire : public UAnimNotify
{

 public: 
	AArkProjectileBase* ProjectileClass;  // Offset: 56 Size: 8
	float Count;  // Offset: 64 Size: 4
	float MaxRadius;  // Offset: 68 Size: 4
	float MinRadius;  // Offset: 72 Size: 4
	struct FName MuzzleName;  // Offset: 76 Size: 8
	float Height;  // Offset: 84 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotify_ArkNpcToggleWeakness Size 72
// Inherited 56 bytes 
class UAnimNotify_ArkNpcToggleWeakness : public UAnimNotify
{

 public: 
	struct FName DynamicDamageTakenInfoName;  // Offset: 56 Size: 8
	char pad_64_1 : 7;  // Offset: 64 Size: 1
	bool bEnable : 1;  // Offset: 64 Size: 1
	char pad_65[7];  // Offset: 65 Size: 7



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_CheckKnockDownBump Size 56
// Inherited 48 bytes 
class UAnimNotifyState_CheckKnockDownBump : public UAnimNotifyState
{

 public: 
	char pad_48_1 : 7;  // Offset: 48 Size: 1
	bool bDisableCheck : 1;  // Offset: 48 Size: 1
	char pad_49[7];  // Offset: 49 Size: 7



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotify_CauseDamage Size 64
// Inherited 56 bytes 
class UAnimNotify_CauseDamage : public UAnimNotify
{

 public: 
	char pad_56_1 : 7;  // Offset: 56 Size: 1
	bool bRangedAttack : 1;  // Offset: 56 Size: 1
	char pad_57[7];  // Offset: 57 Size: 7



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotify_DropBulletShell Size 56
// Inherited 56 bytes 
class UAnimNotify_DropBulletShell : public UAnimNotify
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_EnablePhysicsRotDuringRM Size 80
// Inherited 48 bytes 
class UAnimNotifyState_EnablePhysicsRotDuringRM : public UAnimNotifyState
{

 public: 
	struct FRotator CustomRotRate;  // Offset: 48 Size: 12
	float LimitRotAngle;  // Offset: 60 Size: 4
	char pad_64[16];  // Offset: 64 Size: 16



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotify_SpawnEffectActor Size 104
// Inherited 56 bytes 
class UAnimNotify_SpawnEffectActor : public UAnimNotify
{

 public: 
	AActor* ActorTemplate;  // Offset: 56 Size: 8
	char Attached : 1;  // Offset: 64 Size: 1
	char pad_64_1 : 7;  // Offset: 64 Size: 1
	char pad_65[4];  // Offset: 65 Size: 4
	struct FName PositioningComponentName;  // Offset: 68 Size: 8
	struct FName AttachSocketName;  // Offset: 76 Size: 8
	struct FVector LocationOffset;  // Offset: 84 Size: 12
	float CullDistanceOnCamera;  // Offset: 96 Size: 4
	float CullDistanceOffCamera;  // Offset: 100 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_ChangeWeaponHand Size 48
// Inherited 48 bytes 
class UAnimNotifyState_ChangeWeaponHand : public UAnimNotifyState
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_MeleeCommand Size 48
// Inherited 48 bytes 
class UAnimNotifyState_MeleeCommand : public UAnimNotifyState
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotify_DisableCrossBack Size 56
// Inherited 56 bytes 
class UAnimNotify_DisableCrossBack : public UAnimNotify
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotify_GunFireRandomCount Size 96
// Inherited 56 bytes 
class UAnimNotify_GunFireRandomCount : public UAnimNotify
{

 public: 
	AArkProjectileBase* ProjectileClass;  // Offset: 56 Size: 8
	float MinCount;  // Offset: 64 Size: 4
	float MaxCount;  // Offset: 68 Size: 4
	float MaxRadius;  // Offset: 72 Size: 4
	float MinRadius;  // Offset: 76 Size: 4
	struct FName MuzzleName;  // Offset: 80 Size: 8
	float Height;  // Offset: 88 Size: 4
	char pad_92[4];  // Offset: 92 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotify_EnableCrossBack Size 56
// Inherited 56 bytes 
class UAnimNotify_EnableCrossBack : public UAnimNotify
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotify_MeleeComboComplete Size 56
// Inherited 56 bytes 
class UAnimNotify_MeleeComboComplete : public UAnimNotify
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotify_SetGuideSpline Size 72
// Inherited 56 bytes 
class UAnimNotify_SetGuideSpline : public UAnimNotify
{

 public: 
	struct FName ThrowSocketName;  // Offset: 56 Size: 8
	float throwPitch;  // Offset: 64 Size: 4
	char pad_68[4];  // Offset: 68 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotify_InteractionEnd Size 56
// Inherited 56 bytes 
class UAnimNotify_InteractionEnd : public UAnimNotify
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotify_FireHeroSecondAnim Size 56
// Inherited 56 bytes 
class UAnimNotify_FireHeroSecondAnim : public UAnimNotify
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_DelayPlayWeaponParticle Size 168
// Inherited 48 bytes 
class UAnimNotifyState_DelayPlayWeaponParticle : public UAnimNotifyState
{

 public: 
	char bActivatedOnLocalViewTargetOnly : 1;  // Offset: 48 Size: 1
	char pad_48_1 : 7;  // Offset: 48 Size: 1
	char pad_49[8];  // Offset: 49 Size: 8
	struct TSoftObjectPtr<UParticleSystem> PSTemplate;  // Offset: 56 Size: 40
	struct TSoftObjectPtr<UParticleSystem> PSTemplateFpp;  // Offset: 96 Size: 40
	struct FName SocketName;  // Offset: 136 Size: 8
	struct FVector LocationOffset;  // Offset: 144 Size: 12
	struct FRotator RotationOffset;  // Offset: 156 Size: 12



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_AttachCustomMesh Size 224
// Inherited 48 bytes 
class UAnimNotifyState_AttachCustomMesh : public UAnimNotifyState
{

 public: 
	struct FName AttachSocketName;  // Offset: 48 Size: 8
	char pad_56_1 : 7;  // Offset: 56 Size: 1
	bool bAttachToWeapon : 1;  // Offset: 56 Size: 1
	char pad_57[7];  // Offset: 57 Size: 7
	struct TSoftObjectPtr<USkeletalMesh> SkelMesh;  // Offset: 64 Size: 40
	struct UAnimSequenceBase* SkelAnim;  // Offset: 104 Size: 8
	float AnimPlayRate;  // Offset: 112 Size: 4
	int32_t StaticMeshCompIndex;  // Offset: 116 Size: 4
	struct TSoftObjectPtr<UStaticMesh> StaticMesh;  // Offset: 120 Size: 40
	struct FTransform AttachRelativeTrans;  // Offset: 160 Size: 48
	char pad_208_1 : 7;  // Offset: 208 Size: 1
	bool bSyncUpdateWithParent : 1;  // Offset: 208 Size: 1
	char pad_209[7];  // Offset: 209 Size: 7
	UAnimInstance* SkelAnimClass;  // Offset: 216 Size: 8



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_ArkNpcActionEarlyFinish Size 56
// Inherited 48 bytes 
class UAnimNotifyState_ArkNpcActionEarlyFinish : public UAnimNotifyState
{

 public: 
	float BlendOutTime;  // Offset: 48 Size: 4
	char pad_52[4];  // Offset: 52 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotify_OnThrow Size 72
// Inherited 56 bytes 
class UAnimNotify_OnThrow : public UAnimNotify
{

 public: 
	struct FName ThrowSocketName;  // Offset: 56 Size: 8
	float ThrowAdditivePitch;  // Offset: 64 Size: 4
	char pad_68[4];  // Offset: 68 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotify_EndAbility Size 56
// Inherited 56 bytes 
class UAnimNotify_EndAbility : public UAnimNotify
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotify_HomingGunFire Size 88
// Inherited 56 bytes 
class UAnimNotify_HomingGunFire : public UAnimNotify
{

 public: 
	AArkAIProjectile* ProjectileClass;  // Offset: 56 Size: 8
	float Count;  // Offset: 64 Size: 4
	float Radius;  // Offset: 68 Size: 4
	struct FName MuzzleName;  // Offset: 72 Size: 8
	float Height;  // Offset: 80 Size: 4
	char pad_84[4];  // Offset: 84 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotify_InteractionBegin Size 56
// Inherited 56 bytes 
class UAnimNotify_InteractionBegin : public UAnimNotify
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_ArkAnimCameraModify Size 96
// Inherited 48 bytes 
class UAnimNotifyState_ArkAnimCameraModify : public UAnimNotifyState
{

 public: 
	struct UCurveFloat* BlendCurve;  // Offset: 48 Size: 8
	float BlendInTime;  // Offset: 56 Size: 4
	float BlendOutTime;  // Offset: 60 Size: 4
	float FOVOffset;  // Offset: 64 Size: 4
	struct FVector LocationOffset;  // Offset: 68 Size: 12
	struct FRotator RotationOffset;  // Offset: 80 Size: 12
	char pad_92[4];  // Offset: 92 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotify_StopCrossOver Size 64
// Inherited 56 bytes 
class UAnimNotify_StopCrossOver : public UAnimNotify
{

 public: 
	float BlendOutTime;  // Offset: 56 Size: 4
	char pad_60_1 : 7;  // Offset: 60 Size: 1
	bool bPauseCrossMontage : 1;  // Offset: 60 Size: 1
	char pad_61[3];  // Offset: 61 Size: 3



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotify_LastBulletFireStop Size 56
// Inherited 56 bytes 
class UAnimNotify_LastBulletFireStop : public UAnimNotify
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotify_MeleeComboBlendOut Size 64
// Inherited 56 bytes 
class UAnimNotify_MeleeComboBlendOut : public UAnimNotify
{

 public: 
	char pad_56_1 : 7;  // Offset: 56 Size: 1
	bool bPerfectBlendOut : 1;  // Offset: 56 Size: 1
	char pad_57[7];  // Offset: 57 Size: 7



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotify_MeleeEffect Size 80
// Inherited 56 bytes 
class UAnimNotify_MeleeEffect : public UAnimNotify
{

 public: 
	float DamageRange;  // Offset: 56 Size: 4
	float DamageAmount;  // Offset: 60 Size: 4
	UDamageType* DamageTypeClass;  // Offset: 64 Size: 8
	UArkGameBuff* BuffClass;  // Offset: 72 Size: 8



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotify_StartCrossTurn Size 64
// Inherited 56 bytes 
class UAnimNotify_StartCrossTurn : public UAnimNotify
{

 public: 
	float CrossTurnTime;  // Offset: 56 Size: 4
	char pad_60[4];  // Offset: 60 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotify_MeleeInterruptible Size 56
// Inherited 56 bytes 
class UAnimNotify_MeleeInterruptible : public UAnimNotify
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotify_OnUpdateWeaponAttach Size 56
// Inherited 56 bytes 
class UAnimNotify_OnUpdateWeaponAttach : public UAnimNotify
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotify_MeleeWind Size 144
// Inherited 48 bytes 
class UAnimNotify_MeleeWind : public UAnimNotifyState
{

 public: 
	struct FName SocketName;  // Offset: 48 Size: 8
	char pad_56[8];  // Offset: 56 Size: 8
	struct FTransform LocalOffsetTransform;  // Offset: 64 Size: 48
	struct FVector BoxExtent;  // Offset: 112 Size: 12
	char pad_124[4];  // Offset: 124 Size: 4
	struct UMaterialInterface* WindMat;  // Offset: 128 Size: 8
	char pad_136[8];  // Offset: 136 Size: 8



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotify_NPCStationDropItem Size 64
// Inherited 56 bytes 
class UAnimNotify_NPCStationDropItem : public UAnimNotify
{

 public: 
	int32_t StaticMeshCompIndex;  // Offset: 56 Size: 4
	char pad_60[4];  // Offset: 60 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_EnableAdditionalAiming Size 96
// Inherited 48 bytes 
class UAnimNotifyState_EnableAdditionalAiming : public UAnimNotifyState
{

 public: 
	struct FRotator AnimAimingOffset;  // Offset: 48 Size: 12
	struct FRotator AdditionalOffsetLimitMin;  // Offset: 60 Size: 12
	struct FRotator AdditionalOffsetLimitMax;  // Offset: 72 Size: 12
	float BlendInTime;  // Offset: 84 Size: 4
	float BlendOutTime;  // Offset: 88 Size: 4
	char pad_92[4];  // Offset: 92 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotify_NPCStationPickupItem Size 80
// Inherited 56 bytes 
class UAnimNotify_NPCStationPickupItem : public UAnimNotify
{

 public: 
	struct FName AttachSocketName;  // Offset: 56 Size: 8
	int32_t StaticMeshCompIndex;  // Offset: 64 Size: 4
	int32_t SkeletalMeshCompIndex;  // Offset: 68 Size: 4
	char pad_72_1 : 7;  // Offset: 72 Size: 1
	bool bIsStaticMesh : 1;  // Offset: 72 Size: 1
	char pad_73[7];  // Offset: 73 Size: 7



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.ArkAnimNotify_VTFeedbackOff Size 56
// Inherited 56 bytes 
class UArkAnimNotify_VTFeedbackOff : public UAnimNotify
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotify_OnCoverCross Size 64
// Inherited 56 bytes 
class UAnimNotify_OnCoverCross : public UAnimNotify
{

 public: 
	float ExitCoverBlendOutTime;  // Offset: 56 Size: 4
	char pad_60[4];  // Offset: 60 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_HideBones Size 64
// Inherited 48 bytes 
class UAnimNotifyState_HideBones : public UAnimNotifyState
{

 public: 
	struct TArray<struct FName> HideBoneNames;  // Offset: 48 Size: 16



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_ChiefInvisibleFade Size 88
// Inherited 88 bytes 
class UAnimNotifyState_ChiefInvisibleFade : public UAnimNotifyState_PlayerInvisibleFade
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotify_OnStartCrossingDown Size 56
// Inherited 56 bytes 
class UAnimNotify_OnStartCrossingDown : public UAnimNotify
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_HeroAnimAttachCustomMesh Size 224
// Inherited 48 bytes 
class UAnimNotifyState_HeroAnimAttachCustomMesh : public UAnimNotifyState
{

 public: 
	char pad_48_1 : 7;  // Offset: 48 Size: 1
	bool bIgnorePrimitiveManager : 1;  // Offset: 48 Size: 1
	char pad_49_1 : 7;  // Offset: 49 Size: 1
	bool bDetachParticleSystemOnEnd : 1;  // Offset: 49 Size: 1
	char pad_50[2];  // Offset: 50 Size: 2
	struct FName AttachSocketName;  // Offset: 52 Size: 8
	char pad_60_1 : 7;  // Offset: 60 Size: 1
	bool bSnapToTargetIncludingScale : 1;  // Offset: 60 Size: 1
	char pad_61[3];  // Offset: 61 Size: 3
	struct TSoftObjectPtr<USkeletalMesh> SkelMesh;  // Offset: 64 Size: 40
	struct UAnimSequenceBase* SkelAnim;  // Offset: 104 Size: 8
	float AnimPlayRate;  // Offset: 112 Size: 4
	char pad_116[4];  // Offset: 116 Size: 4
	struct TSoftObjectPtr<UStaticMesh> StaticMesh;  // Offset: 120 Size: 40
	struct FTransform AttachRelativeTrans;  // Offset: 160 Size: 48
	struct USkeletalMeshComponent* TempSkeletalMeshCom;  // Offset: 208 Size: 8
	struct UStaticMeshComponent* TempStaticMeshCom;  // Offset: 216 Size: 8



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotify_PlayerVO Size 64
// Inherited 56 bytes 
class UAnimNotify_PlayerVO : public UAnimNotify
{

 public: 
	struct FName VOEventName;  // Offset: 56 Size: 8



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotify_PlayWeaponParticle Size 208
// Inherited 56 bytes 
class UAnimNotify_PlayWeaponParticle : public UAnimNotify
{

 public: 
	struct TSoftObjectPtr<UParticleSystem> PSTemplate;  // Offset: 56 Size: 40
	struct TSoftObjectPtr<UParticleSystem> PSTemplateFpp;  // Offset: 96 Size: 40
	struct FVector LocationOffset;  // Offset: 136 Size: 12
	struct FRotator RotationOffset;  // Offset: 148 Size: 12
	char pad_160[16];  // Offset: 160 Size: 16
	struct FVector Scale;  // Offset: 176 Size: 12
	char Attached : 1;  // Offset: 188 Size: 1
	char pad_188_1 : 7;  // Offset: 188 Size: 1
	char pad_189[4];  // Offset: 189 Size: 4
	struct FName SocketName;  // Offset: 192 Size: 8
	char bActivatedOnLocalViewTargetOnly : 1;  // Offset: 200 Size: 1
	char bActivatedOnSimulatedOnly : 1;  // Offset: 200 Size: 1
	char pad_200_1 : 6;  // Offset: 200 Size: 1
	char pad_201[8];  // Offset: 201 Size: 8



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_ArkNpcToggleWeakness Size 56
// Inherited 48 bytes 
class UAnimNotifyState_ArkNpcToggleWeakness : public UAnimNotifyState
{

 public: 
	struct FName DynamicDamageTakenInfoName;  // Offset: 48 Size: 8



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotify_StartCrossCorrect Size 88
// Inherited 56 bytes 
class UAnimNotify_StartCrossCorrect : public UAnimNotify
{

 public: 
	char pad_56_1 : 7;  // Offset: 56 Size: 1
	bool bIsUpCorrect : 1;  // Offset: 56 Size: 1
	char pad_57[3];  // Offset: 57 Size: 3
	float UpCorrectionTime;  // Offset: 60 Size: 4
	char pad_64_1 : 7;  // Offset: 64 Size: 1
	bool bIsForwardCorrect : 1;  // Offset: 64 Size: 1
	char pad_65[3];  // Offset: 65 Size: 3
	float ForwardCorrectionTime;  // Offset: 68 Size: 4
	char pad_72_1 : 7;  // Offset: 72 Size: 1
	bool bIsDownCorrect : 1;  // Offset: 72 Size: 1
	char pad_73[3];  // Offset: 73 Size: 3
	float DownCorrectionTime;  // Offset: 76 Size: 4
	char pad_80_1 : 7;  // Offset: 80 Size: 1
	bool bIsRightCorrect : 1;  // Offset: 80 Size: 1
	char pad_81[3];  // Offset: 81 Size: 3
	float RightCorrectionTime;  // Offset: 84 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotify_StartCrossDownCorrect Size 64
// Inherited 56 bytes 
class UAnimNotify_StartCrossDownCorrect : public UAnimNotify
{

 public: 
	float CorrectionTime;  // Offset: 56 Size: 4
	char pad_60[4];  // Offset: 60 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotify_StartCrossOverCorrect Size 64
// Inherited 56 bytes 
class UAnimNotify_StartCrossOverCorrect : public UAnimNotify
{

 public: 
	float CorrectionTime;  // Offset: 56 Size: 4
	char pad_60[4];  // Offset: 60 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotify_StartShooting Size 56
// Inherited 56 bytes 
class UAnimNotify_StartShooting : public UAnimNotify
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotify_StopOpenDoor Size 56
// Inherited 56 bytes 
class UAnimNotify_StopOpenDoor : public UAnimNotify
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_PerkInterruptMontage Size 56
// Inherited 48 bytes 
class UAnimNotifyState_PerkInterruptMontage : public UAnimNotifyState
{

 public: 
	float StopMontageBlendOutTime;  // Offset: 48 Size: 4
	char pad_52[4];  // Offset: 52 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotify_Threaten Size 56
// Inherited 48 bytes 
class UAnimNotify_Threaten : public UAnimNotifyState
{

 public: 
	enum class EThreatenPurposeType ThreatenPurpose;  // Offset: 48 Size: 1
	char pad_49[7];  // Offset: 49 Size: 7



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotify_ThrowWeapon Size 64
// Inherited 56 bytes 
class UAnimNotify_ThrowWeapon : public UAnimNotify
{

 public: 
	float ThrowPitchOffset;  // Offset: 56 Size: 4
	char pad_60_1 : 7;  // Offset: 60 Size: 1
	bool bThrowMainOrSub : 1;  // Offset: 60 Size: 1
	char pad_61[3];  // Offset: 61 Size: 3



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_AimOffsetBlendAlpha Size 80
// Inherited 48 bytes 
class UAnimNotifyState_AimOffsetBlendAlpha : public UAnimNotifyState
{

 public: 
	struct FName AimOffsetBlendAlphaCurveName;  // Offset: 48 Size: 8
	char pad_56_1 : 7;  // Offset: 56 Size: 1
	bool bIsBlendBack : 1;  // Offset: 56 Size: 1
	char pad_57[23];  // Offset: 57 Size: 23



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_AnimEffect Size 64
// Inherited 48 bytes 
class UAnimNotifyState_AnimEffect : public UAnimNotifyState
{

 public: 
	UCameraShake* CustomHitCameraShake;  // Offset: 48 Size: 8
	struct UForceFeedbackEffect* CustomHitForceFeedback;  // Offset: 56 Size: 8



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_OnStopMontage Size 56
// Inherited 48 bytes 
class UAnimNotifyState_OnStopMontage : public UAnimNotifyState
{

 public: 
	float StopMontageBlendOutTime;  // Offset: 48 Size: 4
	char pad_52_1 : 7;  // Offset: 52 Size: 1
	bool bClearVelocityWithStopByCombat : 1;  // Offset: 52 Size: 1
	char pad_53[3];  // Offset: 53 Size: 3



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_CustomActionState Size 56
// Inherited 48 bytes 
class UAnimNotifyState_CustomActionState : public UAnimNotifyState
{

 public: 
	enum class EPlayerActionState CustomActionState;  // Offset: 48 Size: 1
	char pad_49[7];  // Offset: 49 Size: 7



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_PlayerInvisibleFade Size 88
// Inherited 48 bytes 
class UAnimNotifyState_PlayerInvisibleFade : public UAnimNotifyState
{

 public: 
	char pad_48_1 : 7;  // Offset: 48 Size: 1
	bool bFadeIn : 1;  // Offset: 48 Size: 1
	char pad_49[3];  // Offset: 49 Size: 3
	struct FName MaterialParamterName;  // Offset: 52 Size: 8
	char pad_60[4];  // Offset: 60 Size: 4
	struct UCurveFloat* FadeCurve;  // Offset: 64 Size: 8
	char pad_72[16];  // Offset: 72 Size: 16



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_ClearEnmity Size 48
// Inherited 48 bytes 
class UAnimNotifyState_ClearEnmity : public UAnimNotifyState
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_ClipVisibility Size 56
// Inherited 48 bytes 
class UAnimNotifyState_ClipVisibility : public UAnimNotifyState
{

 public: 
	struct FName BoneName;  // Offset: 48 Size: 8



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_CorrectWeaponAttach Size 72
// Inherited 48 bytes 
class UAnimNotifyState_CorrectWeaponAttach : public UAnimNotifyState
{

 public: 
	char pad_48[24];  // Offset: 48 Size: 24



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_CrossDownCorrect Size 72
// Inherited 48 bytes 
class UAnimNotifyState_CrossDownCorrect : public UAnimNotifyState
{

 public: 
	float MinCorrectDistanceD;  // Offset: 48 Size: 4
	char pad_52[20];  // Offset: 52 Size: 20



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_CrossUpCorrect Size 88
// Inherited 48 bytes 
class UAnimNotifyState_CrossUpCorrect : public UAnimNotifyState
{

 public: 
	float MinCorrectDistance;  // Offset: 48 Size: 4
	float MinCorrectDistanceF;  // Offset: 52 Size: 4
	char pad_56[32];  // Offset: 56 Size: 32



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_DamageWindow Size 72
// Inherited 48 bytes 
class UAnimNotifyState_DamageWindow : public UAnimNotifyState
{

 public: 
	struct TArray<struct FName> WeaponNames;  // Offset: 48 Size: 16
	struct FName damagetag;  // Offset: 64 Size: 8



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_DropClip Size 112
// Inherited 48 bytes 
class UAnimNotifyState_DropClip : public UAnimNotifyState
{

 public: 
	struct FName SocketName;  // Offset: 48 Size: 8
	struct FName PlayerSocketName;  // Offset: 56 Size: 8
	char pad_64_1 : 7;  // Offset: 64 Size: 1
	bool bFromWeaponOrPlayer : 1;  // Offset: 64 Size: 1
	char pad_65_1 : 7;  // Offset: 65 Size: 1
	bool bDropStart : 1;  // Offset: 65 Size: 1
	char pad_66_1 : 7;  // Offset: 66 Size: 1
	bool bDropEnd : 1;  // Offset: 66 Size: 1
	char pad_67[5];  // Offset: 67 Size: 5
	AArkProjectile_Clip* DropClipClass;  // Offset: 72 Size: 8
	struct FVector LastSocketLocation;  // Offset: 80 Size: 12
	struct FVector CurrentSocketLocation;  // Offset: 92 Size: 12
	float ClipSpeed;  // Offset: 104 Size: 4
	char pad_108_1 : 7;  // Offset: 108 Size: 1
	bool bNeedRecalcVelocity : 1;  // Offset: 108 Size: 1
	char pad_109[3];  // Offset: 109 Size: 3



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_EnableAdditionalMovement Size 64
// Inherited 48 bytes 
class UAnimNotifyState_EnableAdditionalMovement : public UAnimNotifyState
{

 public: 
	struct UCurveFloat* InterpCurve;  // Offset: 48 Size: 8
	char pad_56[8];  // Offset: 56 Size: 8



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.ArkAnimNotify_SyncStart Size 56
// Inherited 56 bytes 
class UArkAnimNotify_SyncStart : public UAnimNotify
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_HideAvatarParts Size 80
// Inherited 48 bytes 
class UAnimNotifyState_HideAvatarParts : public UAnimNotifyState
{

 public: 
	struct TArray<enum class EArkAvatarPartType> AvatarPartTypes;  // Offset: 48 Size: 16
	struct TArray<struct FName> AvatarBones;  // Offset: 64 Size: 16



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_EnableMeleeCharge Size 56
// Inherited 48 bytes 
class UAnimNotifyState_EnableMeleeCharge : public UAnimNotifyState
{

 public: 
	float MinTargetDistance;  // Offset: 48 Size: 4
	char pad_52[4];  // Offset: 52 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_EnableShuttleParticle Size 72
// Inherited 48 bytes 
class UAnimNotifyState_EnableShuttleParticle : public UAnimNotifyState
{

 public: 
	struct UParticleSystem* PSTemplate;  // Offset: 48 Size: 8
	struct FName SocketName;  // Offset: 56 Size: 8
	char bEnable : 1;  // Offset: 64 Size: 1
	char pad_64_1 : 7;  // Offset: 64 Size: 1
	char pad_65[8];  // Offset: 65 Size: 8



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_HiddenClip Size 56
// Inherited 48 bytes 
class UAnimNotifyState_HiddenClip : public UAnimNotifyState
{

 public: 
	struct FName ClipBoneName;  // Offset: 48 Size: 8



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_InvisibleFade Size 88
// Inherited 48 bytes 
class UAnimNotifyState_InvisibleFade : public UAnimNotifyState
{

 public: 
	char pad_48_1 : 7;  // Offset: 48 Size: 1
	bool bFadeIn : 1;  // Offset: 48 Size: 1
	char pad_49[7];  // Offset: 49 Size: 7
	struct TArray<struct FAnimNotifyInvisibleFadeParamterStruct> MaterialParamters;  // Offset: 56 Size: 16
	char pad_72[16];  // Offset: 72 Size: 16



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_ArkNpcToggleState Size 72
// Inherited 48 bytes 
class UAnimNotifyState_ArkNpcToggleState : public UAnimNotifyState
{

 public: 
	enum class EArkBuffState BuffState;  // Offset: 48 Size: 1
	char pad_49[3];  // Offset: 49 Size: 3
	struct FName CustomTag;  // Offset: 52 Size: 8
	float CustomValue;  // Offset: 60 Size: 4
	char pad_64_1 : 7;  // Offset: 64 Size: 1
	bool bInitialOn : 1;  // Offset: 64 Size: 1
	char pad_65[7];  // Offset: 65 Size: 7



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotify_ToggleNpcState Size 80
// Inherited 56 bytes 
class UAnimNotify_ToggleNpcState : public UAnimNotify
{

 public: 
	enum class EArkBuffState NpcState;  // Offset: 56 Size: 1
	char pad_57[3];  // Offset: 57 Size: 3
	struct FName CustomTag;  // Offset: 60 Size: 8
	float CustomValue;  // Offset: 68 Size: 4
	char pad_72_1 : 7;  // Offset: 72 Size: 1
	bool bOn : 1;  // Offset: 72 Size: 1
	char pad_73[7];  // Offset: 73 Size: 7



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_ArkToggleGameplayTags Size 80
// Inherited 48 bytes 
class UAnimNotifyState_ArkToggleGameplayTags : public UAnimNotifyState
{

 public: 
	struct FGameplayTagContainer GameplayTags;  // Offset: 48 Size: 32



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_PlayAdditionalAnim Size 56
// Inherited 48 bytes 
class UAnimNotifyState_PlayAdditionalAnim : public UAnimNotifyState
{

 public: 
	struct UAnimMontage* AdditionalAnim;  // Offset: 48 Size: 8



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_PlayFacial Size 96
// Inherited 48 bytes 
class UAnimNotifyState_PlayFacial : public UAnimNotifyState
{

 public: 
	struct TArray<struct FTriggeredFacialAnim> FacialAnimArray;  // Offset: 48 Size: 16
	struct TArray<struct TWeakObjectPtr<USkeletalMeshComponent>> WaitLoadComponents;  // Offset: 64 Size: 16
	char pad_80[16];  // Offset: 80 Size: 16



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_ReplayAnimBySection Size 64
// Inherited 48 bytes 
class UAnimNotifyState_ReplayAnimBySection : public UAnimNotifyState
{

 public: 
	struct FName SectiontName;  // Offset: 48 Size: 8
	float PlayRate;  // Offset: 56 Size: 4
	char pad_60[4];  // Offset: 60 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_ResistingDeath Size 48
// Inherited 48 bytes 
class UAnimNotifyState_ResistingDeath : public UAnimNotifyState
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_ShowArmorArm Size 72
// Inherited 48 bytes 
class UAnimNotifyState_ShowArmorArm : public UAnimNotifyState
{

 public: 
	char pad_48_1 : 7;  // Offset: 48 Size: 1
	bool bShowEffect : 1;  // Offset: 48 Size: 1
	char pad_49[7];  // Offset: 49 Size: 7
	struct FString ArmorArmType;  // Offset: 56 Size: 16



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_ShowClip Size 208
// Inherited 48 bytes 
class UAnimNotifyState_ShowClip : public UAnimNotifyState
{

 public: 
	struct FName AttachSocketName;  // Offset: 48 Size: 8
	char pad_56[8];  // Offset: 56 Size: 8
	struct TSoftObjectPtr<USkeletalMesh> SkelMesh;  // Offset: 64 Size: 40
	struct UAnimSequenceBase* SkelAnim;  // Offset: 104 Size: 8
	float AnimPlayRate;  // Offset: 112 Size: 4
	char pad_116[4];  // Offset: 116 Size: 4
	struct TSoftObjectPtr<UStaticMesh> StaticMesh;  // Offset: 120 Size: 40
	struct FTransform AttachRelativeTrans;  // Offset: 160 Size: 48



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_StartThrowing Size 48
// Inherited 48 bytes 
class UAnimNotifyState_StartThrowing : public UAnimNotifyState
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_StopCameraShake Size 72
// Inherited 48 bytes 
class UAnimNotifyState_StopCameraShake : public UAnimNotifyState
{

 public: 
	struct TArray<int32_t> CameraShakeTypes;  // Offset: 48 Size: 16
	char pad_64_1 : 7;  // Offset: 64 Size: 1
	bool bIsStopImmediately : 1;  // Offset: 64 Size: 1
	char pad_65[7];  // Offset: 65 Size: 7



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_SuperJumpFlying Size 48
// Inherited 48 bytes 
class UAnimNotifyState_SuperJumpFlying : public UAnimNotifyState
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_SuperJumpStop Size 48
// Inherited 48 bytes 
class UAnimNotifyState_SuperJumpStop : public UAnimNotifyState
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_SyncingInteraction Size 48
// Inherited 48 bytes 
class UAnimNotifyState_SyncingInteraction : public UAnimNotifyState
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_ToggleCrossBack Size 48
// Inherited 48 bytes 
class UAnimNotifyState_ToggleCrossBack : public UAnimNotifyState
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_ToggleHandAdditiveAnim Size 64
// Inherited 48 bytes 
class UAnimNotifyState_ToggleHandAdditiveAnim : public UAnimNotifyState
{

 public: 
	char pad_48_1 : 7;  // Offset: 48 Size: 1
	bool bEnableHandAdditiveAnim : 1;  // Offset: 48 Size: 1
	char pad_49[3];  // Offset: 49 Size: 3
	float BlendInTime;  // Offset: 52 Size: 4
	float BlendOutTime;  // Offset: 56 Size: 4
	char pad_60[4];  // Offset: 60 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_ToggleHandIKEffect Size 64
// Inherited 48 bytes 
class UAnimNotifyState_ToggleHandIKEffect : public UAnimNotifyState
{

 public: 
	char pad_48_1 : 7;  // Offset: 48 Size: 1
	bool bEnableHandIKEffect : 1;  // Offset: 48 Size: 1
	char pad_49[3];  // Offset: 49 Size: 3
	float BlendInTime;  // Offset: 52 Size: 4
	float BlendOutTime;  // Offset: 56 Size: 4
	char pad_60[4];  // Offset: 60 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_UpdateReloadScopeMesh Size 48
// Inherited 48 bytes 
class UAnimNotifyState_UpdateReloadScopeMesh : public UAnimNotifyState
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.ArkAnimNotify_DeadRagdoll Size 56
// Inherited 56 bytes 
class UArkAnimNotify_DeadRagdoll : public UAnimNotify
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.ArkAnimNotify_MeleeImpactSound Size 96
// Inherited 56 bytes 
class UArkAnimNotify_MeleeImpactSound : public UAnimNotify
{

 public: 
	struct TSoftObjectPtr<UAkAudioEvent> SoftSound;  // Offset: 56 Size: 40



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.ArkAnimNotify_ShowMesh Size 224
// Inherited 224 bytes 
class UArkAnimNotify_ShowMesh : public UAnimNotifyState_AttachCustomMesh
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.ArkAnimNotify_ShuttleAnim Size 56
// Inherited 56 bytes 
class UArkAnimNotify_ShuttleAnim : public UAnimNotify
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.AnimNotifyState_LoopSoundLottery Size 304
// Inherited 48 bytes 
class UAnimNotifyState_LoopSoundLottery : public UAnimNotifyState
{

 public: 
	struct TSoftObjectPtr<UAkAudioEvent> StartEventOrange;  // Offset: 48 Size: 40
	struct TSoftObjectPtr<UAkAudioEvent> EndEventOrange;  // Offset: 88 Size: 40
	struct TSoftObjectPtr<UAkAudioEvent> StartEventPurple;  // Offset: 128 Size: 40
	struct TSoftObjectPtr<UAkAudioEvent> EndEventPurple;  // Offset: 168 Size: 40
	struct TSoftObjectPtr<UAkAudioEvent> StartEventBlue;  // Offset: 208 Size: 40
	struct TSoftObjectPtr<UAkAudioEvent> EndEventBlue;  // Offset: 248 Size: 40
	struct FName AttachName;  // Offset: 288 Size: 8
	char pad_296_1 : 7;  // Offset: 296 Size: 1
	bool b1pOnly : 1;  // Offset: 296 Size: 1
	char pad_297_1 : 7;  // Offset: 297 Size: 1
	bool bDisableDistCull : 1;  // Offset: 297 Size: 1
	enum class EArkNoiseLevel NoiseLevel;  // Offset: 298 Size: 1
	char pad_299[5];  // Offset: 299 Size: 5



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.ArkAnimNotify_SyncEnd Size 56
// Inherited 56 bytes 
class UArkAnimNotify_SyncEnd : public UAnimNotify
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.ArkAnimNotify_VTFeedbackOn Size 56
// Inherited 56 bytes 
class UArkAnimNotify_VTFeedbackOn : public UAnimNotify
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.ArkAnimNotifyState_LotteryTimedParticleEffect Size 320
// Inherited 48 bytes 
class UArkAnimNotifyState_LotteryTimedParticleEffect : public UAnimNotifyState
{

 public: 
	struct TSoftObjectPtr<UParticleSystem> PSTemplateOrange;  // Offset: 48 Size: 40
	struct TSoftObjectPtr<UParticleSystem> PSTemplatePurple;  // Offset: 88 Size: 40
	struct TSoftObjectPtr<UParticleSystem> PSTemplateBlue;  // Offset: 128 Size: 40
	struct FArkParticleModifier TemplateModifier;  // Offset: 168 Size: 104
	struct FName SocketName;  // Offset: 272 Size: 8
	struct FVector LocationOffset;  // Offset: 280 Size: 12
	struct FRotator RotationOffset;  // Offset: 292 Size: 12
	char pad_304_1 : 7;  // Offset: 304 Size: 1
	bool bUsePool : 1;  // Offset: 304 Size: 1
	char pad_305_1 : 7;  // Offset: 305 Size: 1
	bool bForceSpawn : 1;  // Offset: 305 Size: 1
	char pad_306[2];  // Offset: 306 Size: 2
	float DestoryDelayTime;  // Offset: 308 Size: 4
	char pad_312[8];  // Offset: 312 Size: 8



 // Functions 
 public:
}; 
 
 


//Class ArkAnimation.ArkAnimNotifyState_TimedParticleEffect Size 232
// Inherited 48 bytes 
class UArkAnimNotifyState_TimedParticleEffect : public UAnimNotifyState
{

 public: 
	struct TSoftObjectPtr<UParticleSystem> PSTemplate;  // Offset: 48 Size: 40
	struct FArkParticleModifier TemplateModifier;  // Offset: 88 Size: 104
	struct FName SocketName;  // Offset: 192 Size: 8
	struct FVector LocationOffset;  // Offset: 200 Size: 12
	struct FRotator RotationOffset;  // Offset: 212 Size: 12
	char pad_224_1 : 7;  // Offset: 224 Size: 1
	bool bUsePool : 1;  // Offset: 224 Size: 1
	char pad_225_1 : 7;  // Offset: 225 Size: 1
	bool bForceSpawn : 1;  // Offset: 225 Size: 1
	char pad_226[2];  // Offset: 226 Size: 2
	float DestoryDelayTime;  // Offset: 228 Size: 4



 // Functions 
 public:
}; 
 
 


