#pragma once 
#include <SDK_Engine_Objects.h> 
 
 
//Function ArkAudioManager_BP.ArkAudioManager_BP_C.ExecuteUbergraph_ArkAudioManager_BP Size 281
class FExecuteUbergraph_ArkAudioManager_BP
{

 public: 
	int32_t EntryPoint;  // Offset: 0 Size: 4
	struct FDelegate Temp_delegate_Variable;  // Offset: 4 Size: 16
	char pad_20[4];  // Offset: 20 Size: 4
	struct TSoftObjectPtr<UAkStateValue> Temp_softobject_Variable;  // Offset: 24 Size: 40
	int32_t CallFunc_PostAkEvent_OutPlayingID;  // Offset: 64 Size: 4
	char pad_68[4];  // Offset: 68 Size: 4
	struct UArkAkComponent* CallFunc_PostAkEvent_ReturnValue;  // Offset: 72 Size: 8
	struct TSoftObjectPtr<UAkStateValue> Temp_softobject_Variable_2;  // Offset: 80 Size: 40
	int32_t CallFunc_SetAkStateByAsset_ReturnValue;  // Offset: 120 Size: 4
	struct FDelegate Temp_delegate_Variable_2;  // Offset: 124 Size: 16
	int32_t CallFunc_SetAkStateByAsset_ReturnValue_2;  // Offset: 140 Size: 4
	int32_t CallFunc_PostAkEvent_OutPlayingID_2;  // Offset: 144 Size: 4
	char pad_148[4];  // Offset: 148 Size: 4
	struct UArkAkComponent* CallFunc_PostAkEvent_ReturnValue_2;  // Offset: 152 Size: 8
	struct FDelegate Temp_delegate_Variable_3;  // Offset: 160 Size: 16
	struct FDelegate Temp_delegate_Variable_4;  // Offset: 176 Size: 16
	int32_t CallFunc_PostAkEvent_OutPlayingID_3;  // Offset: 192 Size: 4
	char pad_196[4];  // Offset: 196 Size: 4
	struct UArkAkComponent* CallFunc_PostAkEvent_ReturnValue_3;  // Offset: 200 Size: 8
	int32_t CallFunc_PostAkEvent_OutPlayingID_4;  // Offset: 208 Size: 4
	char pad_212[4];  // Offset: 212 Size: 4
	struct UArkAkComponent* CallFunc_PostAkEvent_ReturnValue_4;  // Offset: 216 Size: 8
	struct FDelegate Temp_delegate_Variable_5;  // Offset: 224 Size: 16
	char pad_240_1 : 7;  // Offset: 240 Size: 1
	bool K2Node_Event_bLoadingScreenIsOn : 1;  // Offset: 240 Size: 1
	char pad_241[3];  // Offset: 241 Size: 3
	int32_t CallFunc_PostAkEvent_OutPlayingID_5;  // Offset: 244 Size: 4
	struct UArkAkComponent* CallFunc_PostAkEvent_ReturnValue_5;  // Offset: 248 Size: 8
	char pad_256_1 : 7;  // Offset: 256 Size: 1
	bool CallFunc_IsPvpMode_ReturnValue : 1;  // Offset: 256 Size: 1
	enum class EArkGameFlowType K2Node_Event_OldType;  // Offset: 257 Size: 1
	enum class EArkGameFlowType K2Node_Event_NewType;  // Offset: 258 Size: 1
	char pad_259_1 : 7;  // Offset: 259 Size: 1
	bool K2Node_SwitchEnum_CmpSuccess : 1;  // Offset: 259 Size: 1
	char pad_260[4];  // Offset: 260 Size: 4
	struct FString K2Node_Event_Command;  // Offset: 264 Size: 16
	char pad_280_1 : 7;  // Offset: 280 Size: 1
	bool K2Node_SwitchString_CmpSuccess : 1;  // Offset: 280 Size: 1



 // Functions 
 public:
}; 
 
 //Function ArkAudioManager_BP.ArkAudioManager_BP_C.OnCheat_BP Size 16
// Inherited 16 bytes 
class FOnCheat_BP : public FOnCheat_BP
{

 public: 
	struct FString Command;  // Offset: 0 Size: 16



 // Functions 
 public:
}; 
 
 //Function ArkAudioManager_BP.ArkAudioManager_BP_C.OnGameFlowChange_BP Size 2
// Inherited 2 bytes 
class FOnGameFlowChange_BP : public FOnGameFlowChange_BP
{

 public: 
	enum class EArkGameFlowType OldType;  // Offset: 0 Size: 1
	enum class EArkGameFlowType NewType;  // Offset: 1 Size: 1



 // Functions 
 public:
}; 
 
 //Function ArkAudioManager_BP.ArkAudioManager_BP_C.OnToggleLoadingScreen_BP Size 1
// Inherited 1 bytes 
class FOnToggleLoadingScreen_BP : public FOnToggleLoadingScreen_BP
{

 public: 
	char pad_1_1 : 7;  // Offset: 1 Size: 1
	bool bLoadingScreenIsOn : 1;  // Offset: 0 Size: 1



 // Functions 
 public:
}; 
 
 