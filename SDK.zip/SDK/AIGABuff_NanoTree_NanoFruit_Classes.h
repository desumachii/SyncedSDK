#pragma once 
#include <AIGABuff_NanoTree_NanoFruit_Structs.h>
 
 
 
//BlueprintGeneratedClass AIGABuff_NanoTree_NanoFruit.AIGABuff_NanoTree_NanoFruit_C Size 2216
// Inherited 2144 bytes 
class UAIGABuff_NanoTree_NanoFruit_C : public UArkAIGABuff_MeleeAttack
{

 public: 
	struct FPointerToUberGraphFrame UberGraphFrame;  // Offset: 2144 Size: 8
	float FruitFallTime;  // Offset: 2152 Size: 4
	struct FName SpawnSource;  // Offset: 2156 Size: 8
	char pad_2164[4];  // Offset: 2164 Size: 4
	struct TArray<struct AArkObj_NanoTree_NanoFruit*> FruitGroup;  // Offset: 2168 Size: 16
	struct FTimerHandle TimerHandle;  // Offset: 2184 Size: 8
	struct TArray<struct UArkAISpawnPatternConfig*> FruitPatterns;  // Offset: 2192 Size: 16
	struct UArkAISpawnPatternConfig* CanSpawnFruit;  // Offset: 2208 Size: 8



 // Functions 
 public:
	void OnSingleNpcSpawnedEvent_E6E81A3643B86339B40B5CB2FF8AD75A(struct FAIRequestID RequestID, struct TArray<struct AArkNpc*>& SpawnedNpcs); // Function AIGABuff_NanoTree_NanoFruit.AIGABuff_NanoTree_NanoFruit_C.OnSingleNpcSpawnedEvent_E6E81A3643B86339B40B5CB2FF8AD75A
	void OnComplete_E6E81A3643B86339B40B5CB2FF8AD75A(struct FAIRequestID RequestID, struct TArray<struct AArkNpc*>& SpawnedNpcs); // Function AIGABuff_NanoTree_NanoFruit.AIGABuff_NanoTree_NanoFruit_C.OnComplete_E6E81A3643B86339B40B5CB2FF8AD75A
	void ReadyToReleaseNanoFruit(); // Function AIGABuff_NanoTree_NanoFruit.AIGABuff_NanoTree_NanoFruit_C.ReadyToReleaseNanoFruit
	void OnAnimNotify_BP(struct FName NotifyName, struct UAnimNotify* Notify); // Function AIGABuff_NanoTree_NanoFruit.AIGABuff_NanoTree_NanoFruit_C.OnAnimNotify_BP
	void C2BP_OnActive(); // Function AIGABuff_NanoTree_NanoFruit.AIGABuff_NanoTree_NanoFruit_C.C2BP_OnActive
	void DestroyAllNanoFruits(); // Function AIGABuff_NanoTree_NanoFruit.AIGABuff_NanoTree_NanoFruit_C.DestroyAllNanoFruits
	void ExecuteUbergraph_AIGABuff_NanoTree_NanoFruit(int32_t EntryPoint); // Function AIGABuff_NanoTree_NanoFruit.AIGABuff_NanoTree_NanoFruit_C.ExecuteUbergraph_AIGABuff_NanoTree_NanoFruit
}; 
 
 


