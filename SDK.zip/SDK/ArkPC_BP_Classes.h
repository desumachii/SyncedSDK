#pragma once 
#include <ArkPC_BP_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkPC_BP.ArkPC_BP_C Size 3889
// Inherited 3848 bytes 
class AArkPC_BP_C : public AArkPlayerControllerBattle
{

 public: 
	struct FPointerToUberGraphFrame UberGraphFrame;  // Offset: 3848 Size: 8
	struct UArkAutoPlayerComponent* ArkAutoPlayer;  // Offset: 3856 Size: 8
	struct FMulticastInlineDelegate OnEnterEpisode;  // Offset: 3864 Size: 16
	enum class EArkAIPlayerSyncState PreviousSyncState;  // Offset: 3880 Size: 1
	char pad_3881[3];  // Offset: 3881 Size: 3
	float RandomFloat;  // Offset: 3884 Size: 4
	char pad_3888_1 : 7;  // Offset: 3888 Size: 1
	bool HasSpawned : 1;  // Offset: 3888 Size: 1



 // Functions 
 public:
	void Update Low Health PP(); // Function ArkPC_BP.ArkPC_BP_C.Update Low Health PP
	void ForwardTrace(float Length, bool ReturnFarestIfNotHit, bool& IsHit, struct FVector& HitLocation); // Function ArkPC_BP.ArkPC_BP_C.ForwardTrace
	void PlayWayPointVO(); // Function ArkPC_BP.ArkPC_BP_C.PlayWayPointVO
	void PlayMarkerEventVO(); // Function ArkPC_BP.ArkPC_BP_C.PlayMarkerEventVO
	void PlayWheelMarkerVO(); // Function ArkPC_BP.ArkPC_BP_C.PlayWheelMarkerVO
	void ExecuteUbergraph_ArkPC_BP(int32_t EntryPoint); // Function ArkPC_BP.ArkPC_BP_C.ExecuteUbergraph_ArkPC_BP
	void OnEnterEpisode__DelegateSignature(); // Function ArkPC_BP.ArkPC_BP_C.OnEnterEpisode__DelegateSignature
}; 
 
 


