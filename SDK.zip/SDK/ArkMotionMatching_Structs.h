#pragma once 
#include <SDK_Engine_Objects.h> 
 
 
//ScriptStruct ArkMotionMatching.AnimNode_ArkMotionMatching Size 400
// Inherited 56 bytes 
class FAnimNode_ArkMotionMatching : public FAnimNode_AssetPlayerBase
{

 public: 
	struct UArkMotionField* MotionField;  // Offset: 56 Size: 8
	struct FArkMotionTrajectory DesiredTrajectory;  // Offset: 64 Size: 136
	int32_t NeighborNum;  // Offset: 200 Size: 4
	float NeighborDistanceFactor;  // Offset: 204 Size: 4
	float MinNeighborDistance;  // Offset: 208 Size: 4
	float MaxNeighborDistance;  // Offset: 212 Size: 4
	float SameAnimationThreshold;  // Offset: 216 Size: 4
	float VelocityWeight;  // Offset: 220 Size: 4
	float FootPositionWeight;  // Offset: 224 Size: 4
	float FootVelocityWeight;  // Offset: 228 Size: 4
	int32_t MaxPlayingMotionNumber;  // Offset: 232 Size: 4
	char pad_236[4];  // Offset: 236 Size: 4
	struct UAnimSequence* DefaultAnimSequence;  // Offset: 240 Size: 8
	int32_t IDVariation;  // Offset: 248 Size: 4
	float SwitchProtectTime;  // Offset: 252 Size: 4
	float TrajectoryLocationWeight;  // Offset: 256 Size: 4
	float TrajectoryRotationWeight;  // Offset: 260 Size: 4
	char pad_264[136];  // Offset: 264 Size: 136



 // Functions 
 public:
}; 
 
 //ScriptStruct ArkMotionMatching.TagTransitionProperty Size 44
// Inherited 32 bytes 
class FTagTransitionProperty : public FTransitionProperty
{

 public: 
	struct FGameplayTag MotionTag;  // Offset: 32 Size: 8
	float ForcePlayToPosition;  // Offset: 40 Size: 4



 // Functions 
 public:
}; 
 
 //Function ArkMotionMatching.ArkMotionField.ConvertToKDTreeCoordinate Size 64
class FConvertToKDTreeCoordinate
{

 public: 
	struct FVector PreviousVelocity;  // Offset: 0 Size: 12
	struct FVector CurrentVelocity;  // Offset: 12 Size: 12
	struct FVector FutureVelocity;  // Offset: 24 Size: 12
	struct FVector FarFutureVelocity;  // Offset: 36 Size: 12
	struct FArkMotionCoordinate ReturnValue;  // Offset: 48 Size: 16



 // Functions 
 public:
}; 
 
 //ScriptStruct ArkMotionMatching.ArkMotionTrajectory Size 136
class FArkMotionTrajectory
{

 public: 
	struct FVector FutureFacingDirection;  // Offset: 0 Size: 12
	struct FVector PreviousVelocity;  // Offset: 12 Size: 12
	struct FVector CurrentVelocity;  // Offset: 24 Size: 12
	struct FVector FutureVelocity;  // Offset: 36 Size: 12
	struct FVector FarFutureVelocity;  // Offset: 48 Size: 12
	char pad_60[4];  // Offset: 60 Size: 4
	struct TArray<struct FName> PreferredTags;  // Offset: 64 Size: 16
	struct TArray<struct FName> ForbiddenTags;  // Offset: 80 Size: 16
	char pad_96_1 : 7;  // Offset: 96 Size: 1
	bool bIsPreferMirroredAnimation : 1;  // Offset: 96 Size: 1
	char pad_97[7];  // Offset: 97 Size: 7
	struct TArray<struct FArkMotionTrajectoryPoint> PreviousTrajectoryPoints;  // Offset: 104 Size: 16
	struct TArray<struct FArkMotionTrajectoryPoint> FutureTrajectoryPoints;  // Offset: 120 Size: 16



 // Functions 
 public:
}; 
 
 //ScriptStruct ArkMotionMatching.ArkMotionTrajectoryPoint Size 32
class FArkMotionTrajectoryPoint
{

 public: 
	struct FVector Location;  // Offset: 0 Size: 12
	char pad_12[4];  // Offset: 12 Size: 4
	struct FQuat Rotation;  // Offset: 16 Size: 16



 // Functions 
 public:
}; 
 
 //ScriptStruct ArkMotionMatching.AnimNode_ArkMotionMatchingDebug Size 40
// Inherited 24 bytes 
class FAnimNode_ArkMotionMatchingDebug : public FAnimNode_Base
{

 public: 
	struct UAnimSequence* Sequence;  // Offset: 24 Size: 8
	char pad_32[8];  // Offset: 32 Size: 8



 // Functions 
 public:
}; 
 
 //ScriptStruct ArkMotionMatching.EndTransitionProperty Size 40
// Inherited 32 bytes 
class FEndTransitionProperty : public FTransitionProperty
{

 public: 
	int32_t EndSpeedCursor;  // Offset: 32 Size: 4
	float EndSpeed;  // Offset: 36 Size: 4



 // Functions 
 public:
}; 
 
 //ScriptStruct ArkMotionMatching.MotionSequenceProperty Size 88
class FMotionSequenceProperty
{

 public: 
	float SequenceSampleTimeStep;  // Offset: 0 Size: 4
	int32_t SpeedCursor;  // Offset: 4 Size: 4
	struct FGameplayTag MotionTag;  // Offset: 8 Size: 8
	struct TArray<struct FStartTransitionProperty> StartTransitionProperties;  // Offset: 16 Size: 16
	struct TArray<struct FPivotTransitionProperty> PivotTransitionProperties;  // Offset: 32 Size: 16
	struct TArray<struct FEndTransitionProperty> EndTransitionProperties;  // Offset: 48 Size: 16
	struct TArray<struct FTagTransitionProperty> TagTransitionProperties;  // Offset: 64 Size: 16
	char pad_80_1 : 7;  // Offset: 80 Size: 1
	bool bIsLoop : 1;  // Offset: 80 Size: 1
	char pad_81_1 : 7;  // Offset: 81 Size: 1
	bool bIsStart : 1;  // Offset: 81 Size: 1
	char pad_82_1 : 7;  // Offset: 82 Size: 1
	bool bIsPivot : 1;  // Offset: 82 Size: 1
	char pad_83_1 : 7;  // Offset: 83 Size: 1
	bool bIsEnd : 1;  // Offset: 83 Size: 1
	char pad_84_1 : 7;  // Offset: 84 Size: 1
	bool bIsTag : 1;  // Offset: 84 Size: 1
	char pad_85[3];  // Offset: 85 Size: 3



 // Functions 
 public:
}; 
 
 //ScriptStruct ArkMotionMatching.TransitionProperty Size 32
class FTransitionProperty
{

 public: 
	float FirstSequenceTime;  // Offset: 0 Size: 4
	float SecondSequenceTime;  // Offset: 4 Size: 4
	int32_t SpeedCursor;  // Offset: 8 Size: 4
	float StartCustomRotationTime;  // Offset: 12 Size: 4
	float EndTransitionTime;  // Offset: 16 Size: 4
	float RotationMakeUpDuration;  // Offset: 20 Size: 4
	float BlendInTime;  // Offset: 24 Size: 4
	float BlendOutTime;  // Offset: 28 Size: 4



 // Functions 
 public:
}; 
 
 //ScriptStruct ArkMotionMatching.PivotTransition Size 36
class FPivotTransition
{

 public: 
	float PivotDeltaRotationYaw;  // Offset: 0 Size: 4
	float PivotDistance;  // Offset: 4 Size: 4
	float PivotTransitionTime;  // Offset: 8 Size: 4
	float EndTransitionTime;  // Offset: 12 Size: 4
	float StartCustomRotationTime;  // Offset: 16 Size: 4
	float RotationMakeUpDuration;  // Offset: 20 Size: 4
	float BlendTime;  // Offset: 24 Size: 4
	float VelocityToFacingYaw;  // Offset: 28 Size: 4
	float VelocityScale;  // Offset: 32 Size: 4



 // Functions 
 public:
}; 
 
 //ScriptStruct ArkMotionMatching.PivotTransitionProperty Size 36
// Inherited 32 bytes 
class FPivotTransitionProperty : public FTransitionProperty
{

 public: 
	float PivotTransitionTime;  // Offset: 32 Size: 4



 // Functions 
 public:
}; 
 
 //ScriptStruct ArkMotionMatching.StartTransitionProperty Size 32
// Inherited 32 bytes 
class FStartTransitionProperty : public FTransitionProperty
{

 public: 



 // Functions 
 public:
}; 
 
 //Function ArkMotionMatching.ArkMotionField.GetAllMotionCoordinates Size 16
class FGetAllMotionCoordinates
{

 public: 
	struct TArray<struct FArkMotionCoordinate> ReturnValue;  // Offset: 0 Size: 16



 // Functions 
 public:
}; 
 
 //ScriptStruct ArkMotionMatching.MotionDatabaseProperty Size 16
class FMotionDatabaseProperty
{

 public: 
	float SampleTimeStep;  // Offset: 0 Size: 4
	float PredictTimeStep;  // Offset: 4 Size: 4
	float MeshRelativeRotationYaw;  // Offset: 8 Size: 4
	float MeshScale;  // Offset: 12 Size: 4



 // Functions 
 public:
}; 
 
 //ScriptStruct ArkMotionMatching.TagMotionKey Size 80
// Inherited 64 bytes 
class FTagMotionKey : public FMotionKey
{

 public: 
	struct FGameplayTag MotionTag;  // Offset: 64 Size: 8
	float ForcePlayToPosition;  // Offset: 72 Size: 4
	char pad_76_1 : 7;  // Offset: 76 Size: 1
	bool bIsLoop : 1;  // Offset: 76 Size: 1
	char pad_77[3];  // Offset: 77 Size: 3



 // Functions 
 public:
}; 
 
 //ScriptStruct ArkMotionMatching.SequenceArchive Size 32
class FSequenceArchive
{

 public: 
	struct UAnimSequence* RefAnimSequence;  // Offset: 0 Size: 8
	float PlayPosition;  // Offset: 8 Size: 4
	char pad_12_1 : 7;  // Offset: 12 Size: 1
	bool bIsLoop : 1;  // Offset: 12 Size: 1
	char pad_13[3];  // Offset: 13 Size: 3
	float BlendTime;  // Offset: 16 Size: 4
	float CurrentBlendTime;  // Offset: 20 Size: 4
	char pad_24_1 : 7;  // Offset: 24 Size: 1
	bool bIsBlendIn : 1;  // Offset: 24 Size: 1
	char pad_25_1 : 7;  // Offset: 25 Size: 1
	bool bIsBlendOut : 1;  // Offset: 25 Size: 1
	char pad_26[2];  // Offset: 26 Size: 2
	float Weight;  // Offset: 28 Size: 4



 // Functions 
 public:
}; 
 
 //ScriptStruct ArkMotionMatching.MotionKey Size 64
class FMotionKey
{

 public: 
	struct TArray<struct FMotionBoneData> MotionBoneData;  // Offset: 0 Size: 16
	enum class EAnimType AnimType;  // Offset: 16 Size: 1
	char pad_17[3];  // Offset: 17 Size: 3
	int32_t SourceSequenceIndex;  // Offset: 20 Size: 4
	float PlayPosition;  // Offset: 24 Size: 4
	int32_t SpeedCursor;  // Offset: 28 Size: 4
	float BlendInTime;  // Offset: 32 Size: 4
	float BlendOutTime;  // Offset: 36 Size: 4
	float EndTransitionTime;  // Offset: 40 Size: 4
	float MotionDirection;  // Offset: 44 Size: 4
	float StartCustomRotationTime;  // Offset: 48 Size: 4
	float RotationMakeUpDuration;  // Offset: 52 Size: 4
	float DeltaRotationYaw;  // Offset: 56 Size: 4
	char pad_60[4];  // Offset: 60 Size: 4



 // Functions 
 public:
}; 
 
 //ScriptStruct ArkMotionMatching.MotionBoneData Size 24
class FMotionBoneData
{

 public: 
	struct FVector BoneLocation;  // Offset: 0 Size: 12
	struct FVector BoneVelocity;  // Offset: 12 Size: 12



 // Functions 
 public:
}; 
 
 //ScriptStruct ArkMotionMatching.EndMotionKey Size 80
// Inherited 64 bytes 
class FEndMotionKey : public FMotionKey
{

 public: 
	int32_t EndSpeedCursor;  // Offset: 64 Size: 4
	float EndDistance;  // Offset: 68 Size: 4
	float EndSpeed;  // Offset: 72 Size: 4
	char pad_76[4];  // Offset: 76 Size: 4



 // Functions 
 public:
}; 
 
 //ScriptStruct ArkMotionMatching.ArkMotionFieldProperty Size 56
class FArkMotionFieldProperty
{

 public: 
	float SampleTimeStep;  // Offset: 0 Size: 4
	float PredictTimeStep;  // Offset: 4 Size: 4
	float FutureTime;  // Offset: 8 Size: 4
	float PreviousTime;  // Offset: 12 Size: 4
	float BlendTime;  // Offset: 16 Size: 4
	char pad_20[4];  // Offset: 20 Size: 4
	struct TArray<struct FString> Tags;  // Offset: 24 Size: 16
	float UpExtentRate;  // Offset: 40 Size: 4
	float DownExtentRate;  // Offset: 44 Size: 4
	int32_t ExntentNum;  // Offset: 48 Size: 4
	float MeshRotationOffset;  // Offset: 52 Size: 4



 // Functions 
 public:
}; 
 
 //ScriptStruct ArkMotionMatching.PivotMotionKey Size 72
// Inherited 64 bytes 
class FPivotMotionKey : public FMotionKey
{

 public: 
	float PivotTransitionTime;  // Offset: 64 Size: 4
	float PivotDistance;  // Offset: 68 Size: 4



 // Functions 
 public:
}; 
 
 //ScriptStruct ArkMotionMatching.StartMotionKey Size 64
// Inherited 64 bytes 
class FStartMotionKey : public FMotionKey
{

 public: 



 // Functions 
 public:
}; 
 
 //ScriptStruct ArkMotionMatching.SpeedCursorTransitionProperty Size 52
class FSpeedCursorTransitionProperty
{

 public: 
	float FirstSequenceTime;  // Offset: 0 Size: 4
	float SecondSequenceTime;  // Offset: 4 Size: 4
	struct FSpeedCursorTransition SpeedCursorTransition;  // Offset: 8 Size: 44



 // Functions 
 public:
}; 
 
 //ScriptStruct ArkMotionMatching.SpeedCursorTransition Size 44
class FSpeedCursorTransition
{

 public: 
	float SpeedCursorDeltaRotationYaw;  // Offset: 0 Size: 4
	int32_t FirstSpeedCursor;  // Offset: 4 Size: 4
	int32_t SecondSpeedCursor;  // Offset: 8 Size: 4
	float EndTransitionTime;  // Offset: 12 Size: 4
	float StartCustomRotationTime;  // Offset: 16 Size: 4
	float RotationMakeUpDuration;  // Offset: 20 Size: 4
	float BlendTime;  // Offset: 24 Size: 4
	float BlendInTime;  // Offset: 28 Size: 4
	float BlendOutTime;  // Offset: 32 Size: 4
	float VelocityToFacingYaw;  // Offset: 36 Size: 4
	float VelocityScale;  // Offset: 40 Size: 4



 // Functions 
 public:
}; 
 
 //ScriptStruct ArkMotionMatching.ArkMotionAnimProperty Size 120
class FArkMotionAnimProperty
{

 public: 
	char pad_0_1 : 7;  // Offset: 0 Size: 1
	bool bIsLoop : 1;  // Offset: 0 Size: 1
	char pad_1[3];  // Offset: 1 Size: 3
	int32_t MaxLoopCount;  // Offset: 4 Size: 4
	struct TArray<struct FName> Tags;  // Offset: 8 Size: 16
	struct TMap<struct UAnimSequence*, float> Successors;  // Offset: 24 Size: 80
	float StartTime;  // Offset: 104 Size: 4
	float EndTime;  // Offset: 108 Size: 4
	float SwitchProtectTime;  // Offset: 112 Size: 4
	float ProtectThresholdFactor;  // Offset: 116 Size: 4



 // Functions 
 public:
}; 
 
 //ScriptStruct ArkMotionMatching.ArkMotionCoordinate Size 16
class FArkMotionCoordinate
{

 public: 
	struct TArray<float> Coordinate;  // Offset: 0 Size: 16



 // Functions 
 public:
}; 
 
 //ScriptStruct ArkMotionMatching.ArkMotionAnimArchive Size 60
class FArkMotionAnimArchive
{

 public: 
	struct FName SourceAnimationName;  // Offset: 0 Size: 8
	int32_t ArchiveIndex;  // Offset: 8 Size: 4
	int32_t AnimationIndex;  // Offset: 12 Size: 4
	float PlayPosition;  // Offset: 16 Size: 4
	float MaxPlayPosition;  // Offset: 20 Size: 4
	char pad_24_1 : 7;  // Offset: 24 Size: 1
	bool bIsLoop : 1;  // Offset: 24 Size: 1
	char pad_25[3];  // Offset: 25 Size: 3
	float PlayRate;  // Offset: 28 Size: 4
	float CurrentBlendTime;  // Offset: 32 Size: 4
	float BlendTime;  // Offset: 36 Size: 4
	float Weight;  // Offset: 40 Size: 4
	char pad_44_1 : 7;  // Offset: 44 Size: 1
	bool bShouldBlendOut : 1;  // Offset: 44 Size: 1
	char pad_45[3];  // Offset: 45 Size: 3
	int32_t CurrentMotionKeyIndex;  // Offset: 48 Size: 4
	int32_t LoopCounter;  // Offset: 52 Size: 4
	float ProtectTimer;  // Offset: 56 Size: 4



 // Functions 
 public:
}; 
 
 //ScriptStruct ArkMotionMatching.ArkMotionKey Size 312
class FArkMotionKey
{

 public: 
	struct FName SourceAnimationName;  // Offset: 0 Size: 8
	int32_t SourceAnimationIndex;  // Offset: 8 Size: 4
	float StartTime;  // Offset: 12 Size: 4
	float MaxTime;  // Offset: 16 Size: 4
	char pad_20_1 : 7;  // Offset: 20 Size: 1
	bool bIsLoop : 1;  // Offset: 20 Size: 1
	char pad_21[3];  // Offset: 21 Size: 3
	int32_t MaxLoopCount;  // Offset: 24 Size: 4
	float PlayRate;  // Offset: 28 Size: 4
	struct TArray<char> TagsIndex;  // Offset: 32 Size: 16
	struct FVector PreviousVelocity;  // Offset: 48 Size: 12
	struct FVector CurrentVelocity;  // Offset: 60 Size: 12
	struct FVector FutureVelocity;  // Offset: 72 Size: 12
	struct FVector FarFutureVelocity;  // Offset: 84 Size: 12
	struct TArray<struct FArkMotionBoneData> MotionBoneData;  // Offset: 96 Size: 16
	int32_t PreviousMotionKeyIndex;  // Offset: 112 Size: 4
	int32_t CurrentMotionKeyIndex;  // Offset: 116 Size: 4
	int32_t NextMotionKeyIndex;  // Offset: 120 Size: 4
	char pad_124[4];  // Offset: 124 Size: 4
	struct TArray<int32_t> SuccessorKeyIndex;  // Offset: 128 Size: 16
	struct TArray<float> SuccessorRate;  // Offset: 144 Size: 16
	struct FArkMotionTrajectory MotionTrajectory;  // Offset: 160 Size: 136
	float MotionDuration;  // Offset: 296 Size: 4
	struct FName KeyBoneName;  // Offset: 300 Size: 8
	char pad_308[4];  // Offset: 308 Size: 4



 // Functions 
 public:
}; 
 
 //ScriptStruct ArkMotionMatching.ArkMotionBoneData Size 24
class FArkMotionBoneData
{

 public: 
	struct FVector BoneLocation;  // Offset: 0 Size: 12
	struct FVector BoneVelocity;  // Offset: 12 Size: 12



 // Functions 
 public:
}; 
 
 //ScriptStruct ArkMotionMatching.ArkTagHelper Size 24
class FArkTagHelper
{

 public: 
	struct FName AnimName;  // Offset: 0 Size: 8
	struct TArray<struct FArkTagRange> Ranges;  // Offset: 8 Size: 16



 // Functions 
 public:
}; 
 
 //ScriptStruct ArkMotionMatching.ArkTagRange Size 16
class FArkTagRange
{

 public: 
	struct TArray<float> RangeKeys;  // Offset: 0 Size: 16



 // Functions 
 public:
}; 
 
 //Function ArkMotionMatching.ArkMotionBlueprintLibrary.ParseDataToMotionTrajectory Size 152
class FParseDataToMotionTrajectory
{

 public: 
	struct TArray<float> Data;  // Offset: 0 Size: 16
	struct FArkMotionTrajectory ReturnValue;  // Offset: 16 Size: 136



 // Functions 
 public:
}; 
 
 