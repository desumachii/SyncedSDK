#pragma once 
#include <AmmoPickup556_Lite_Structs.h>
 
 
 
//BlueprintGeneratedClass AmmoPickup556_Lite.AmmoPickup556_Lite_C Size 2416
// Inherited 2416 bytes 
class AAmmoPickup556_Lite_C : public AAmmoPickupBase_C
{

 public: 



 // Functions 
 public:
}; 
 
 


