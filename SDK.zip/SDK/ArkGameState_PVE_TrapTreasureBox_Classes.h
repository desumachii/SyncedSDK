#pragma once 
#include <ArkGameState_PVE_TrapTreasureBox_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkGameState_PVE_TrapTreasureBox.ArkGameState_PVE_TrapTreasureBox_C Size 2708
// Inherited 2680 bytes 
class AArkGameState_PVE_TrapTreasureBox_C : public AArkGameStateMaterialRun_TrapTreasureBox
{

 public: 
	struct FPointerToUberGraphFrame UberGraphFrame;  // Offset: 2680 Size: 8
	struct USceneComponent* DefaultSceneRoot;  // Offset: 2688 Size: 8
	struct UDataTable* ShareableLootTable;  // Offset: 2696 Size: 8
	int32_t CurrentWaveOrder;  // Offset: 2704 Size: 4



 // Functions 
 public:
	void NotifyWaveFinished(int32_t InWaveOrder); // Function ArkGameState_PVE_TrapTreasureBox.ArkGameState_PVE_TrapTreasureBox_C.NotifyWaveFinished
	void Init Progress Bar(); // Function ArkGameState_PVE_TrapTreasureBox.ArkGameState_PVE_TrapTreasureBox_C.Init Progress Bar
	void GenerateTreasureBox(); // Function ArkGameState_PVE_TrapTreasureBox.ArkGameState_PVE_TrapTreasureBox_C.GenerateTreasureBox
	void SetCurrentWaveOrder(int32_t InWaveOrder); // Function ArkGameState_PVE_TrapTreasureBox.ArkGameState_PVE_TrapTreasureBox_C.SetCurrentWaveOrder
	void Find Shareable Loot Name List(struct TArray<struct FName>& ShareableLootList); // Function ArkGameState_PVE_TrapTreasureBox.ArkGameState_PVE_TrapTreasureBox_C.Find Shareable Loot Name List
	void CheckIgnoreNanoSurgeDamage_BP(struct AArkPlayer* Player, bool& bIgnore); // Function ArkGameState_PVE_TrapTreasureBox.ArkGameState_PVE_TrapTreasureBox_C.CheckIgnoreNanoSurgeDamage_BP
	void OnCurrentRunStateChange_BP(enum class EArkMaterialRunTTBStateType NewState); // Function ArkGameState_PVE_TrapTreasureBox.ArkGameState_PVE_TrapTreasureBox_C.OnCurrentRunStateChange_BP
	void NotifyClientWaveFinished(int32_t InWaveOrder); // Function ArkGameState_PVE_TrapTreasureBox.ArkGameState_PVE_TrapTreasureBox_C.NotifyClientWaveFinished
	void ExecuteUbergraph_ArkGameState_PVE_TrapTreasureBox(int32_t EntryPoint); // Function ArkGameState_PVE_TrapTreasureBox.ArkGameState_PVE_TrapTreasureBox_C.ExecuteUbergraph_ArkGameState_PVE_TrapTreasureBox
}; 
 
 


