#pragma once 
#include <SDK_Engine_Objects.h> 
 
 
//Function ArkPlayer_BP.ArkPlayer_BP_C.ClientAddQuest Size 4
class FClientAddQuest
{

 public: 
	int32_t questID;  // Offset: 0 Size: 4



 // Functions 
 public:
}; 
 
 //Function ArkPlayer_BP.ArkPlayer_BP_C.ExecuteUbergraph_ArkPlayer_BP Size 505
class FExecuteUbergraph_ArkPlayer_BP
{

 public: 
	int32_t EntryPoint;  // Offset: 0 Size: 4
	struct FName K2Node_CustomEvent_NotifyName_3;  // Offset: 4 Size: 8
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // Offset: 12 Size: 16
	struct FName K2Node_CustomEvent_NotifyName_2;  // Offset: 28 Size: 8
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // Offset: 36 Size: 16
	struct FName K2Node_CustomEvent_NotifyName;  // Offset: 52 Size: 8
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // Offset: 60 Size: 16
	struct FName Temp_name_Variable;  // Offset: 76 Size: 8
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_4;  // Offset: 84 Size: 16
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_5;  // Offset: 100 Size: 16
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_6;  // Offset: 116 Size: 16
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_7;  // Offset: 132 Size: 16
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_8;  // Offset: 148 Size: 16
	char pad_164_1 : 7;  // Offset: 164 Size: 1
	bool K2Node_Event_inAiming : 1;  // Offset: 164 Size: 1
	char pad_165[3];  // Offset: 165 Size: 3
	struct USkeletalMeshComponent* CallFunc_GetCurrentWeaponMesh_ReturnValue;  // Offset: 168 Size: 8
	struct USkeletalMeshComponent* CallFunc_GetCurrentWeaponMesh_ReturnValue_2;  // Offset: 176 Size: 8
	struct AArkWeaponBase* CallFunc_GetWeaponBySlot_ReturnValue;  // Offset: 184 Size: 8
	struct AArkWeaponBase* CallFunc_GetWeaponBySlot_ReturnValue_2;  // Offset: 192 Size: 8
	char pad_200_1 : 7;  // Offset: 200 Size: 1
	bool CallFunc_IsValid_ReturnValue : 1;  // Offset: 200 Size: 1
	char pad_201_1 : 7;  // Offset: 201 Size: 1
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // Offset: 201 Size: 1
	char pad_202[2];  // Offset: 202 Size: 2
	struct FName K2Node_CustomEvent_NotifyName_4;  // Offset: 204 Size: 8
	char pad_212[4];  // Offset: 212 Size: 4
	struct AArkWeaponBase* CallFunc_GetWeaponBySlot_ReturnValue_3;  // Offset: 216 Size: 8
	char pad_224_1 : 7;  // Offset: 224 Size: 1
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // Offset: 224 Size: 1
	char pad_225[7];  // Offset: 225 Size: 7
	struct AArkWeaponBase* CallFunc_GetWeaponBySlot_ReturnValue_4;  // Offset: 232 Size: 8
	char pad_240_1 : 7;  // Offset: 240 Size: 1
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // Offset: 240 Size: 1
	char pad_241[3];  // Offset: 241 Size: 3
	int32_t K2Node_Event_EnergyCount;  // Offset: 244 Size: 4
	char pad_248[8];  // Offset: 248 Size: 8
	struct FTransform K2Node_Event_EnergyTrans;  // Offset: 256 Size: 48
	struct FName K2Node_CustomEvent_NotifyName_5;  // Offset: 304 Size: 8
	struct UAnimMontage* K2Node_Event_inMontage;  // Offset: 312 Size: 8
	float K2Node_Event_inRate;  // Offset: 320 Size: 4
	char pad_324[4];  // Offset: 324 Size: 4
	struct AArkWeaponBase* CallFunc_GetCurrentWeapon_ReturnValue;  // Offset: 328 Size: 8
	struct UPlayMontageCallbackProxy* CallFunc_CreateProxyObjectForPlayMontage_ReturnValue;  // Offset: 336 Size: 8
	char pad_344_1 : 7;  // Offset: 344 Size: 1
	bool CallFunc_IsValid_ReturnValue_5 : 1;  // Offset: 344 Size: 1
	char pad_345[7];  // Offset: 345 Size: 7
	struct AArkThrowableWeapon* K2Node_DynamicCast_AsArk_Throwable_Weapon;  // Offset: 352 Size: 8
	char pad_360_1 : 7;  // Offset: 360 Size: 1
	bool K2Node_DynamicCast_bSuccess : 1;  // Offset: 360 Size: 1
	char pad_361_1 : 7;  // Offset: 361 Size: 1
	bool K2Node_Event_bSneakyOn : 1;  // Offset: 361 Size: 1
	char pad_362[6];  // Offset: 362 Size: 6
	struct AArkWeaponBase* CallFunc_GetCurrentWeapon_ReturnValue_2;  // Offset: 368 Size: 8
	enum class EEndPlayReason K2Node_Event_EndPlayReason;  // Offset: 376 Size: 1
	char pad_377_1 : 7;  // Offset: 377 Size: 1
	bool K2Node_Event_bIn : 1;  // Offset: 377 Size: 1
	char pad_378_1 : 7;  // Offset: 378 Size: 1
	bool K2Node_Event_inTargeting : 1;  // Offset: 378 Size: 1
	char pad_379_1 : 7;  // Offset: 379 Size: 1
	bool CallFunc_IsInHideArea_ReturnValue : 1;  // Offset: 379 Size: 1
	char pad_380_1 : 7;  // Offset: 380 Size: 1
	bool CallFunc_IsDedicatedServer_ReturnValue : 1;  // Offset: 380 Size: 1
	char pad_381_1 : 7;  // Offset: 381 Size: 1
	bool CallFunc_IsDedicatedServer_ReturnValue_2 : 1;  // Offset: 381 Size: 1
	char pad_382_1 : 7;  // Offset: 382 Size: 1
	bool CallFunc_IsTargeting_ReturnValue : 1;  // Offset: 382 Size: 1
	char pad_383[1];  // Offset: 383 Size: 1
	int32_t K2Node_CustomEvent_QuestID_2;  // Offset: 384 Size: 4
	int32_t K2Node_CustomEvent_QuestID;  // Offset: 388 Size: 4
	struct FString CallFunc_Conv_IntToString_ReturnValue;  // Offset: 392 Size: 16
	struct FString CallFunc_Concat_StrStr_ReturnValue;  // Offset: 408 Size: 16
	struct AArkPlayerStateBattle* K2Node_DynamicCast_AsArk_Player_State_Battle;  // Offset: 424 Size: 8
	char pad_432_1 : 7;  // Offset: 432 Size: 1
	bool K2Node_DynamicCast_bSuccess_2 : 1;  // Offset: 432 Size: 1
	char pad_433[7];  // Offset: 433 Size: 7
	struct UArkQuestComponent* CallFunc_GetQuestComponent_ReturnValue;  // Offset: 440 Size: 8
	struct UArkQuestInstance* CallFunc_AddInGameQuestByID_ReturnValue;  // Offset: 448 Size: 8
	char pad_456_1 : 7;  // Offset: 456 Size: 1
	bool CallFunc_IsValid_ReturnValue_6 : 1;  // Offset: 456 Size: 1
	char pad_457_1 : 7;  // Offset: 457 Size: 1
	bool CallFunc_IsDedicatedServer_ReturnValue_3 : 1;  // Offset: 457 Size: 1
	char pad_458_1 : 7;  // Offset: 458 Size: 1
	bool K2Node_CustomEvent_bClientSimulation_4 : 1;  // Offset: 458 Size: 1
	char pad_459_1 : 7;  // Offset: 459 Size: 1
	bool K2Node_CustomEvent_bClientSimulation_3 : 1;  // Offset: 459 Size: 1
	char pad_460_1 : 7;  // Offset: 460 Size: 1
	bool CallFunc_IsDedicatedServer_ReturnValue_4 : 1;  // Offset: 460 Size: 1
	char pad_461_1 : 7;  // Offset: 461 Size: 1
	bool K2Node_CustomEvent_bClientSimulation_2 : 1;  // Offset: 461 Size: 1
	char pad_462_1 : 7;  // Offset: 462 Size: 1
	bool K2Node_CustomEvent_bClientSimulation : 1;  // Offset: 462 Size: 1
	char pad_463[1];  // Offset: 463 Size: 1
	struct UArkItemInventoryComponent* CallFunc_GetItemInventoryComponent_ReturnValue;  // Offset: 464 Size: 8
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_9;  // Offset: 472 Size: 16
	char pad_488_1 : 7;  // Offset: 488 Size: 1
	bool CallFunc_IsValid_ReturnValue_7 : 1;  // Offset: 488 Size: 1
	char pad_489[3];  // Offset: 489 Size: 3
	int32_t CallFunc_AddItem_ReturnValue;  // Offset: 492 Size: 4
	int32_t CallFunc_AddItem_ReturnValue_2;  // Offset: 496 Size: 4
	int32_t CallFunc_AddItem_ReturnValue_3;  // Offset: 500 Size: 4
	char pad_504_1 : 7;  // Offset: 504 Size: 1
	bool CallFunc_HasAuthority_ReturnValue : 1;  // Offset: 504 Size: 1



 // Functions 
 public:
}; 
 
 //Function ArkPlayer_BP.ArkPlayer_BP_C.Leave Targeting Size 1
class FLeave Targeting
{

 public: 
	char pad_0_1 : 7;  // Offset: 0 Size: 1
	bool bClientSimulation : 1;  // Offset: 0 Size: 1



 // Functions 
 public:
}; 
 
 //Function ArkPlayer_BP.ArkPlayer_BP_C.Leave Aiming Size 1
class FLeave Aiming
{

 public: 
	char pad_0_1 : 7;  // Offset: 0 Size: 1
	bool bClientSimulation : 1;  // Offset: 0 Size: 1



 // Functions 
 public:
}; 
 
 //Function ArkPlayer_BP.ArkPlayer_BP_C.Enter Aiming Size 1
class FEnter Aiming
{

 public: 
	char pad_0_1 : 7;  // Offset: 0 Size: 1
	bool bClientSimulation : 1;  // Offset: 0 Size: 1



 // Functions 
 public:
}; 
 
 //Function ArkPlayer_BP.ArkPlayer_BP_C.NotifyInHideAreaEffect Size 1
// Inherited 1 bytes 
class FNotifyInHideAreaEffect : public FNotifyInHideAreaEffect
{

 public: 
	char pad_1_1 : 7;  // Offset: 1 Size: 1
	bool bin : 1;  // Offset: 0 Size: 1



 // Functions 
 public:
}; 
 
 //Function ArkPlayer_BP.ArkPlayer_BP_C.Enter Targeting Size 1
class FEnter Targeting
{

 public: 
	char pad_0_1 : 7;  // Offset: 0 Size: 1
	bool bClientSimulation : 1;  // Offset: 0 Size: 1



 // Functions 
 public:
}; 
 
 //Function ArkPlayer_BP.ArkPlayer_BP_C.ServerAddQuest Size 4
class FServerAddQuest
{

 public: 
	int32_t questID;  // Offset: 0 Size: 4



 // Functions 
 public:
}; 
 
 //Function ArkPlayer_BP.ArkPlayer_BP_C.UpdatePlayerTargeting Size 1
// Inherited 1 bytes 
class FUpdatePlayerTargeting : public FUpdatePlayerTargeting
{

 public: 
	char pad_1_1 : 7;  // Offset: 1 Size: 1
	bool inTargeting : 1;  // Offset: 0 Size: 1



 // Functions 
 public:
}; 
 
 //Function ArkPlayer_BP.ArkPlayer_BP_C.ReceiveEndPlay Size 1
// Inherited 1 bytes 
class FReceiveEndPlay : public FReceiveEndPlay
{

 public: 
	enum class EEndPlayReason EndPlayReason;  // Offset: 0 Size: 1



 // Functions 
 public:
}; 
 
 //Function ArkPlayer_BP.ArkPlayer_BP_C.OnStealthEffectChange_2 Size 1
class FOnStealthEffectChange_2
{

 public: 
	char pad_0_1 : 7;  // Offset: 0 Size: 1
	bool bSneakyOn : 1;  // Offset: 0 Size: 1



 // Functions 
 public:
}; 
 
 //Function ArkPlayer_BP.ArkPlayer_BP_C.NotifyPlayEquipAnim Size 12
// Inherited 16 bytes 
class FNotifyPlayEquipAnim : public FNotifyPlayEquipAnim
{

 public: 
	struct UAnimMontage* inMontage;  // Offset: 0 Size: 8
	float inRate;  // Offset: 8 Size: 4



 // Functions 
 public:
}; 
 
 //Function ArkPlayer_BP.ArkPlayer_BP_C.NotifyAddEnergyAt Size 64
// Inherited 64 bytes 
class FNotifyAddEnergyAt : public FNotifyAddEnergyAt
{

 public: 
	int32_t EnergyCount;  // Offset: 0 Size: 4
	struct FTransform EnergyTrans;  // Offset: 16 Size: 48



 // Functions 
 public:
}; 
 
 //Function ArkPlayer_BP.ArkPlayer_BP_C.OnInterrupted_2D3C37AA4907389D46CF53BABAD925F4 Size 8
class FOnInterrupted_2D3C37AA4907389D46CF53BABAD925F4
{

 public: 
	struct FName NotifyName;  // Offset: 0 Size: 8



 // Functions 
 public:
}; 
 
 //Function ArkPlayer_BP.ArkPlayer_BP_C.NotifyPlayerAiming Size 1
// Inherited 1 bytes 
class FNotifyPlayerAiming : public FNotifyPlayerAiming
{

 public: 
	char pad_1_1 : 7;  // Offset: 1 Size: 1
	bool inAiming : 1;  // Offset: 0 Size: 1



 // Functions 
 public:
}; 
 
 //Function ArkPlayer_BP.ArkPlayer_BP_C.OnCompleted_2D3C37AA4907389D46CF53BABAD925F4 Size 8
class FOnCompleted_2D3C37AA4907389D46CF53BABAD925F4
{

 public: 
	struct FName NotifyName;  // Offset: 0 Size: 8



 // Functions 
 public:
}; 
 
 //Function ArkPlayer_BP.ArkPlayer_BP_C.OnBlendOut_2D3C37AA4907389D46CF53BABAD925F4 Size 8
class FOnBlendOut_2D3C37AA4907389D46CF53BABAD925F4
{

 public: 
	struct FName NotifyName;  // Offset: 0 Size: 8



 // Functions 
 public:
}; 
 
 //Function ArkPlayer_BP.ArkPlayer_BP_C.OnNotifyBegin_2D3C37AA4907389D46CF53BABAD925F4 Size 8
class FOnNotifyBegin_2D3C37AA4907389D46CF53BABAD925F4
{

 public: 
	struct FName NotifyName;  // Offset: 0 Size: 8



 // Functions 
 public:
}; 
 
 //Function ArkPlayer_BP.ArkPlayer_BP_C.OnNotifyEnd_2D3C37AA4907389D46CF53BABAD925F4 Size 8
class FOnNotifyEnd_2D3C37AA4907389D46CF53BABAD925F4
{

 public: 
	struct FName NotifyName;  // Offset: 0 Size: 8



 // Functions 
 public:
}; 
 
 //Function ArkPlayer_BP.ArkPlayer_BP_C.TickCameraDOF Size 261
class FTickCameraDOF
{

 public: 
	float Focal Distance;  // Offset: 0 Size: 4
	char pad_4_1 : 7;  // Offset: 4 Size: 1
	bool CallFunc_IsAiming_ReturnValue : 1;  // Offset: 4 Size: 1
	char pad_5_1 : 7;  // Offset: 5 Size: 1
	bool CallFunc_IsSyncing_ReturnValue : 1;  // Offset: 5 Size: 1
	char pad_6_1 : 7;  // Offset: 6 Size: 1
	bool CallFunc_IsThrowing_ReturnValue : 1;  // Offset: 6 Size: 1
	char pad_7_1 : 7;  // Offset: 7 Size: 1
	bool CallFunc_IsValid_ReturnValue : 1;  // Offset: 7 Size: 1
	char pad_8_1 : 7;  // Offset: 8 Size: 1
	bool CallFunc_IsValid_ReturnValue_2 : 1;  // Offset: 8 Size: 1
	char pad_9_1 : 7;  // Offset: 9 Size: 1
	bool CallFunc_IsTargeting_ReturnValue : 1;  // Offset: 9 Size: 1
	char pad_10_1 : 7;  // Offset: 10 Size: 1
	bool CallFunc_IsSyncing_ReturnValue_2 : 1;  // Offset: 10 Size: 1
	char pad_11_1 : 7;  // Offset: 11 Size: 1
	bool CallFunc_IsAiming_ReturnValue_2 : 1;  // Offset: 11 Size: 1
	char pad_12_1 : 7;  // Offset: 12 Size: 1
	bool CallFunc_Not_PreBool_ReturnValue : 1;  // Offset: 12 Size: 1
	char pad_13[3];  // Offset: 13 Size: 3
	struct AArkWeaponBase* CallFunc_GetCurrentWeapon_ReturnValue;  // Offset: 16 Size: 8
	char pad_24_1 : 7;  // Offset: 24 Size: 1
	bool CallFunc_BooleanAND_ReturnValue : 1;  // Offset: 24 Size: 1
	char pad_25_1 : 7;  // Offset: 25 Size: 1
	bool CallFunc_HasMirror_ReturnValue : 1;  // Offset: 25 Size: 1
	char pad_26_1 : 7;  // Offset: 26 Size: 1
	bool CallFunc_IsDedicatedServer_ReturnValue : 1;  // Offset: 26 Size: 1
	char pad_27[5];  // Offset: 27 Size: 5
	struct APawn* CallFunc_GetLocalControlledPawnOrSpectator_ReturnValue;  // Offset: 32 Size: 8
	struct AArkPlayerCameraManager* CallFunc_GetLocalPlayerCameraManager_ReturnValue;  // Offset: 40 Size: 8
	char pad_48_1 : 7;  // Offset: 48 Size: 1
	bool CallFunc_EqualEqual_ObjectObject_ReturnValue : 1;  // Offset: 48 Size: 1
	char pad_49_1 : 7;  // Offset: 49 Size: 1
	bool CallFunc_IsValid_ReturnValue_3 : 1;  // Offset: 49 Size: 1
	char pad_50_1 : 7;  // Offset: 50 Size: 1
	bool CallFunc_IsAiming_ReturnValue_3 : 1;  // Offset: 50 Size: 1
	char pad_51_1 : 7;  // Offset: 51 Size: 1
	bool CallFunc_IsValid_ReturnValue_4 : 1;  // Offset: 51 Size: 1
	char pad_52_1 : 7;  // Offset: 52 Size: 1
	bool CallFunc_IsAiming_ReturnValue_4 : 1;  // Offset: 52 Size: 1
	char pad_53_1 : 7;  // Offset: 53 Size: 1
	bool CallFunc_IsAiming_ReturnValue_5 : 1;  // Offset: 53 Size: 1
	char pad_54_1 : 7;  // Offset: 54 Size: 1
	bool CallFunc_IsValid_ReturnValue_5 : 1;  // Offset: 54 Size: 1
	char pad_55[1];  // Offset: 55 Size: 1
	struct TArray<struct AActor*> Temp_object_Variable;  // Offset: 56 Size: 16
	char pad_72_1 : 7;  // Offset: 72 Size: 1
	bool CallFunc_IsValid_ReturnValue_6 : 1;  // Offset: 72 Size: 1
	char pad_73[3];  // Offset: 73 Size: 3
	struct FVector CallFunc_GetForwardVector_ReturnValue;  // Offset: 76 Size: 12
	struct FVector CallFunc_Multiply_VectorFloat_ReturnValue;  // Offset: 88 Size: 12
	struct FVector CallFunc_K2_GetComponentLocation_ReturnValue;  // Offset: 100 Size: 12
	struct FVector CallFunc_Add_VectorVector_ReturnValue;  // Offset: 112 Size: 12
	struct FHitResult CallFunc_LineTraceSingle_OutHit;  // Offset: 124 Size: 136
	char pad_260_1 : 7;  // Offset: 260 Size: 1
	bool CallFunc_LineTraceSingle_ReturnValue : 1;  // Offset: 260 Size: 1



 // Functions 
 public:
}; 
 
 //Function ArkPlayer_BP.ArkPlayer_BP_C.GetModuleName Size 16
class FGetModuleName
{

 public: 
	struct FString ReturnValue;  // Offset: 0 Size: 16



 // Functions 
 public:
}; 
 
 