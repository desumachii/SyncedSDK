#pragma once 
#include <Anne_Blue_01_AddonC_00_Structs.h>
 
 
 
//BlueprintGeneratedClass Anne_Blue_01_AddonC_00.Anne_Blue_01_AddonC_00_C Size 400
// Inherited 400 bytes 
class UAnne_Blue_01_AddonC_00_C : public UArkItemAvatarAttachment
{

 public: 



 // Functions 
 public:
}; 
 
 


