#pragma once 
#include <ArkDamageType_SMG_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkDamageType_SMG.ArkDamageType_SMG_C Size 264
// Inherited 264 bytes 
class UArkDamageType_SMG_C : public UArkDamageType_Range_C
{

 public: 



 // Functions 
 public:
}; 
 
 


