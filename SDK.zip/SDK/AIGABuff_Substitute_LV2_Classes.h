#pragma once 
#include <AIGABuff_Substitute_LV2_Structs.h>
 
 
 
//BlueprintGeneratedClass AIGABuff_Substitute_LV2.AIGABuff_Substitute_LV2_C Size 2088
// Inherited 2088 bytes 
class UAIGABuff_Substitute_LV2_C : public UAIGABuff_Substitute_C
{

 public: 



 // Functions 
 public:
}; 
 
 


