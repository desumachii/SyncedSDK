#pragma once 
#include <ArkDamageType_AR_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkDamageType_AR.ArkDamageType_AR_C Size 264
// Inherited 264 bytes 
class UArkDamageType_AR_C : public UArkDamageType_Range_C
{

 public: 



 // Functions 
 public:
}; 
 
 


