#pragma once 
#include <ArkDamageType_2doTs_Electric_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkDamageType_2doTs_Electric.ArkDamageType_2doTs_Electric_C Size 264
// Inherited 264 bytes 
class UArkDamageType_2doTs_Electric_C : public UArkDamageType_2doTs_C
{

 public: 



 // Functions 
 public:
}; 
 
 


