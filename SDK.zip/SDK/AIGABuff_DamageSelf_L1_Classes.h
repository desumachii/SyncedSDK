#pragma once 
#include <AIGABuff_DamageSelf_L1_Structs.h>
 
 
 
//BlueprintGeneratedClass AIGABuff_DamageSelf_L1.AIGABuff_DamageSelf_L1_C Size 1240
// Inherited 1240 bytes 
class UAIGABuff_DamageSelf_L1_C : public UAIGABuff_DamageSelf_Base_C
{

 public: 



 // Functions 
 public:
}; 
 
 


