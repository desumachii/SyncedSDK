#pragma once 
#include <SDK_Engine_Objects.h> 
 
 
//Function AIGABuff_SelfExplode_BP.AIGABuff_SelfExplode_BP_C.ExecuteUbergraph_AIGABuff_SelfExplode_BP Size 26
class FExecuteUbergraph_AIGABuff_SelfExplode_BP
{

 public: 
	int32_t EntryPoint;  // Offset: 0 Size: 4
	struct FName K2Node_Event_NotifyName;  // Offset: 4 Size: 8
	char pad_12[4];  // Offset: 12 Size: 4
	struct UAnimNotify* K2Node_Event_Notify;  // Offset: 16 Size: 8
	char pad_24_1 : 7;  // Offset: 24 Size: 1
	bool CallFunc_IsPerformingAction_ReturnValue : 1;  // Offset: 24 Size: 1
	char pad_25_1 : 7;  // Offset: 25 Size: 1
	bool K2Node_SwitchName_CmpSuccess : 1;  // Offset: 25 Size: 1



 // Functions 
 public:
}; 
 
 //Function AIGABuff_SelfExplode_BP.AIGABuff_SelfExplode_BP_C.OnAnimNotify_BP Size 16
// Inherited 16 bytes 
class FOnAnimNotify_BP : public FOnAnimNotify_BP
{

 public: 
	struct FName NotifyName;  // Offset: 0 Size: 8
	struct UAnimNotify* Notify;  // Offset: 8 Size: 8



 // Functions 
 public:
}; 
 
 