#pragma once 
#include <AIGABuff_IncreaseSpeed_Pve_Structs.h>
 
 
 
//BlueprintGeneratedClass AIGABuff_IncreaseSpeed_Pve.AIGABuff_IncreaseSpeed_Pve_C Size 1224
// Inherited 1224 bytes 
class UAIGABuff_IncreaseSpeed_Pve_C : public UArkAIGameplayAbilityBuff
{

 public: 



 // Functions 
 public:
}; 
 
 


