#pragma once 
#include <AnimNotify_SetGlobalDarkZoneValue_Structs.h>
 
 
 
//BlueprintGeneratedClass AnimNotify_SetGlobalDarkZoneValue.AnimNotify_SetGlobalDarkZoneValue_C Size 80
// Inherited 56 bytes 
class UAnimNotify_SetGlobalDarkZoneValue_C : public UAnimNotify
{

 public: 
	float GlobalDarkZoneValue;  // Offset: 56 Size: 4
	float Duration;  // Offset: 60 Size: 4
	float FadingDuration;  // Offset: 64 Size: 4
	char pad_68[4];  // Offset: 68 Size: 4
	struct UCurveFloat* DarkFadingCurve;  // Offset: 72 Size: 8



 // Functions 
 public:
	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function AnimNotify_SetGlobalDarkZoneValue.AnimNotify_SetGlobalDarkZoneValue_C.Received_Notify
}; 
 
 


