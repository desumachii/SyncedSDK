#pragma once 
#include <AIGABuff_Substitute_Structs.h>
 
 
 
//BlueprintGeneratedClass AIGABuff_Substitute.AIGABuff_Substitute_C Size 2088
// Inherited 2080 bytes 
class UAIGABuff_Substitute_C : public UArkAIGABuff_Substitute
{

 public: 
	struct FPointerToUberGraphFrame UberGraphFrame;  // Offset: 2080 Size: 8



 // Functions 
 public:
	void ClientPlayEffect_BP(struct FVector FromLoc); // Function AIGABuff_Substitute.AIGABuff_Substitute_C.ClientPlayEffect_BP
	void ExecuteUbergraph_AIGABuff_Substitute(int32_t EntryPoint); // Function AIGABuff_Substitute.AIGABuff_Substitute_C.ExecuteUbergraph_AIGABuff_Substitute
}; 
 
 


