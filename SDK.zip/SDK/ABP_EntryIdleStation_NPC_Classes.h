#pragma once 
#include <ABP_EntryIdleStation_NPC_Structs.h>
 
 
 
//AnimBlueprintGeneratedClass ABP_EntryIdleStation_NPC.ABP_EntryIdleStation_NPC_C Size 4280
// Inherited 880 bytes 
class UABP_EntryIdleStation_NPC_C : public UArkEntryIdleStationNPC_ABPBase
{

 public: 
	struct FPointerToUberGraphFrame UberGraphFrame;  // Offset: 880 Size: 8
	struct FAnimNode_Root AnimGraphNode_Root;  // Offset: 888 Size: 56
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_21;  // Offset: 944 Size: 48
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_20;  // Offset: 992 Size: 48
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_19;  // Offset: 1040 Size: 48
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_18;  // Offset: 1088 Size: 48
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_17;  // Offset: 1136 Size: 48
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_16;  // Offset: 1184 Size: 48
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_15;  // Offset: 1232 Size: 48
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_14;  // Offset: 1280 Size: 48
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_13;  // Offset: 1328 Size: 48
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_12;  // Offset: 1376 Size: 48
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_11;  // Offset: 1424 Size: 48
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_10;  // Offset: 1472 Size: 48
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_9;  // Offset: 1520 Size: 48
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_8;  // Offset: 1568 Size: 48
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_7;  // Offset: 1616 Size: 48
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_6;  // Offset: 1664 Size: 48
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_5;  // Offset: 1712 Size: 48
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_5;  // Offset: 1760 Size: 272
	struct FAnimNode_StateResult AnimGraphNode_StateResult_8;  // Offset: 2032 Size: 56
	struct FAnimNode_StateResult AnimGraphNode_StateResult_7;  // Offset: 2088 Size: 56
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_4;  // Offset: 2144 Size: 48
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_4;  // Offset: 2192 Size: 272
	struct FAnimNode_StateResult AnimGraphNode_StateResult_6;  // Offset: 2464 Size: 56
	struct FAnimNode_RandomPlayerNoRepeat AnimGraphNode_RandomPlayerNoRepeat_2;  // Offset: 2520 Size: 144
	struct FAnimNode_StateResult AnimGraphNode_StateResult_5;  // Offset: 2664 Size: 56
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_3;  // Offset: 2720 Size: 48
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3;  // Offset: 2768 Size: 272
	struct FAnimNode_StateResult AnimGraphNode_StateResult_4;  // Offset: 3040 Size: 56
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2;  // Offset: 3096 Size: 272
	struct FAnimNode_StateResult AnimGraphNode_StateResult_3;  // Offset: 3368 Size: 56
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;  // Offset: 3424 Size: 272
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2;  // Offset: 3696 Size: 56
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2;  // Offset: 3752 Size: 48
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult;  // Offset: 3800 Size: 48
	struct FAnimNode_RandomPlayerNoRepeat AnimGraphNode_RandomPlayerNoRepeat;  // Offset: 3848 Size: 144
	struct FAnimNode_StateResult AnimGraphNode_StateResult;  // Offset: 3992 Size: 56
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine;  // Offset: 4048 Size: 232



 // Functions 
 public:
	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_EntryIdleStation_NPC.ABP_EntryIdleStation_NPC_C.AnimGraph
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_EntryIdleStation_NPC_AnimGraphNode_TransitionResult_F15D57BD4A0628D46C9059A3D5AF81A4(); // Function ABP_EntryIdleStation_NPC.ABP_EntryIdleStation_NPC_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_EntryIdleStation_NPC_AnimGraphNode_TransitionResult_F15D57BD4A0628D46C9059A3D5AF81A4
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_EntryIdleStation_NPC_AnimGraphNode_TransitionResult_9D861F8B4E8E2C8479B47A88EE2617F9(); // Function ABP_EntryIdleStation_NPC.ABP_EntryIdleStation_NPC_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_EntryIdleStation_NPC_AnimGraphNode_TransitionResult_9D861F8B4E8E2C8479B47A88EE2617F9
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_EntryIdleStation_NPC_AnimGraphNode_TransitionResult_BC287B72416508AEFC9BF8A1F3A93E0A(); // Function ABP_EntryIdleStation_NPC.ABP_EntryIdleStation_NPC_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_EntryIdleStation_NPC_AnimGraphNode_TransitionResult_BC287B72416508AEFC9BF8A1F3A93E0A
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_EntryIdleStation_NPC_AnimGraphNode_SequencePlayer_0C17F6054A9195657449CF8D11881A1D(); // Function ABP_EntryIdleStation_NPC.ABP_EntryIdleStation_NPC_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_EntryIdleStation_NPC_AnimGraphNode_SequencePlayer_0C17F6054A9195657449CF8D11881A1D
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_EntryIdleStation_NPC_AnimGraphNode_TransitionResult_BF6A72FD4A91FEA8CE7381AC533C071E(); // Function ABP_EntryIdleStation_NPC.ABP_EntryIdleStation_NPC_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_EntryIdleStation_NPC_AnimGraphNode_TransitionResult_BF6A72FD4A91FEA8CE7381AC533C071E
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_EntryIdleStation_NPC_AnimGraphNode_TransitionResult_EEF45D5F4A69C2574EAB11AC2D425062(); // Function ABP_EntryIdleStation_NPC.ABP_EntryIdleStation_NPC_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_EntryIdleStation_NPC_AnimGraphNode_TransitionResult_EEF45D5F4A69C2574EAB11AC2D425062
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_EntryIdleStation_NPC_AnimGraphNode_TransitionResult_61BEBC184360670086AEE1BEC06F255C(); // Function ABP_EntryIdleStation_NPC.ABP_EntryIdleStation_NPC_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_EntryIdleStation_NPC_AnimGraphNode_TransitionResult_61BEBC184360670086AEE1BEC06F255C
	void AnimNotify_FinishedIdle(); // Function ABP_EntryIdleStation_NPC.ABP_EntryIdleStation_NPC_C.AnimNotify_FinishedIdle
	void AnimNotify_BlendToGround(); // Function ABP_EntryIdleStation_NPC.ABP_EntryIdleStation_NPC_C.AnimNotify_BlendToGround
	void AnimNotify_ExitStationComplete(); // Function ABP_EntryIdleStation_NPC.ABP_EntryIdleStation_NPC_C.AnimNotify_ExitStationComplete
	void ExecuteUbergraph_ABP_EntryIdleStation_NPC(int32_t EntryPoint); // Function ABP_EntryIdleStation_NPC.ABP_EntryIdleStation_NPC_C.ExecuteUbergraph_ABP_EntryIdleStation_NPC
}; 
 
 


