#pragma once 
#include <SDK_Engine_Objects.h> 
 
 
//Function ABP_EntryIdleStation_NPC.ABP_EntryIdleStation_NPC_C.ExecuteUbergraph_ABP_EntryIdleStation_NPC Size 53
class FExecuteUbergraph_ABP_EntryIdleStation_NPC
{

 public: 
	int32_t EntryPoint;  // Offset: 0 Size: 4
	float CallFunc_GetRelevantAnimTimeRemaining_ReturnValue;  // Offset: 4 Size: 4
	char pad_8_1 : 7;  // Offset: 8 Size: 1
	bool CallFunc_Less_FloatFloat_ReturnValue : 1;  // Offset: 8 Size: 1
	char pad_9[3];  // Offset: 9 Size: 3
	float CallFunc_GetRelevantAnimTimeRemaining_ReturnValue_2;  // Offset: 12 Size: 4
	char pad_16_1 : 7;  // Offset: 16 Size: 1
	bool CallFunc_Less_FloatFloat_ReturnValue_2 : 1;  // Offset: 16 Size: 1
	char pad_17[3];  // Offset: 17 Size: 3
	float CallFunc_GetRelevantAnimTimeRemaining_ReturnValue_3;  // Offset: 20 Size: 4
	char pad_24_1 : 7;  // Offset: 24 Size: 1
	bool CallFunc_Less_FloatFloat_ReturnValue_3 : 1;  // Offset: 24 Size: 1
	char pad_25[3];  // Offset: 25 Size: 3
	float CallFunc_GetMoveStateFootSync_SequencePos;  // Offset: 28 Size: 4
	float CallFunc_GetMoveStateFootSync_BlendspacePos;  // Offset: 32 Size: 4
	float CallFunc_GetRelevantAnimTimeRemaining_ReturnValue_4;  // Offset: 36 Size: 4
	float CallFunc_GetRelevantAnimTimeRemaining_ReturnValue_5;  // Offset: 40 Size: 4
	char pad_44_1 : 7;  // Offset: 44 Size: 1
	bool CallFunc_Less_FloatFloat_ReturnValue_4 : 1;  // Offset: 44 Size: 1
	char pad_45_1 : 7;  // Offset: 45 Size: 1
	bool CallFunc_Less_FloatFloat_ReturnValue_5 : 1;  // Offset: 45 Size: 1
	char pad_46[2];  // Offset: 46 Size: 2
	float CallFunc_GetRelevantAnimTimeRemaining_ReturnValue_6;  // Offset: 48 Size: 4
	char pad_52_1 : 7;  // Offset: 52 Size: 1
	bool CallFunc_Less_FloatFloat_ReturnValue_6 : 1;  // Offset: 52 Size: 1



 // Functions 
 public:
}; 
 
 //Function ABP_EntryIdleStation_NPC.ABP_EntryIdleStation_NPC_C.AnimGraph Size 16
class FAnimGraph
{

 public: 
	struct FPoseLink AnimGraph;  // Offset: 0 Size: 16



 // Functions 
 public:
}; 
 
 