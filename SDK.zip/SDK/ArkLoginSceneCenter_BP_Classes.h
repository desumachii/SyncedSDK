#pragma once 
#include <ArkLoginSceneCenter_BP_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkLoginSceneCenter_BP.ArkLoginSceneCenter_BP_C Size 496
// Inherited 496 bytes 
class UArkLoginSceneCenter_BP_C : public UArkInGameManagerCenter
{

 public: 



 // Functions 
 public:
}; 
 
 


