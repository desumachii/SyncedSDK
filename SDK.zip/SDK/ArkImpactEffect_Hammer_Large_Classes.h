#pragma once 
#include <ArkImpactEffect_Hammer_Large_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkImpactEffect_Hammer_Large.ArkImpactEffect_Hammer_Large_C Size 504
// Inherited 504 bytes 
class UArkImpactEffect_Hammer_Large_C : public UArkImpactEffect
{

 public: 



 // Functions 
 public:
}; 
 
 


