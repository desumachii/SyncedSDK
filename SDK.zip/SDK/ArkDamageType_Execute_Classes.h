#pragma once 
#include <ArkDamageType_Execute_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkDamageType_Execute.ArkDamageType_Execute_C Size 264
// Inherited 264 bytes 
class UArkDamageType_Execute_C : public UArkDamageType
{

 public: 



 // Functions 
 public:
}; 
 
 


