#pragma once 
#include <ArkDamageType_2doTs_CauseByRange_Electric_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkDamageType_2doTs_CauseByRange_Electric.ArkDamageType_2doTs_CauseByRange_Electric_C Size 264
// Inherited 264 bytes 
class UArkDamageType_2doTs_CauseByRange_Electric_C : public UArkDamageType_2doTs_CauseByRange_C
{

 public: 



 // Functions 
 public:
}; 
 
 


