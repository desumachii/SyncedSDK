#pragma once 
#include <AIGABuff_DeathTimer_PVE_Structs.h>
 
 
 
//BlueprintGeneratedClass AIGABuff_DeathTimer_PVE.AIGABuff_DeathTimer_PVE_C Size 1232
// Inherited 1224 bytes 
class UAIGABuff_DeathTimer_PVE_C : public UArkAIGameplayAbilityBuff
{

 public: 
	struct FPointerToUberGraphFrame UberGraphFrame;  // Offset: 1224 Size: 8



 // Functions 
 public:
	void C2BP_OnDeactive(); // Function AIGABuff_DeathTimer_PVE.AIGABuff_DeathTimer_PVE_C.C2BP_OnDeactive
	void ExecuteUbergraph_AIGABuff_DeathTimer_PVE(int32_t EntryPoint); // Function AIGABuff_DeathTimer_PVE.AIGABuff_DeathTimer_PVE_C.ExecuteUbergraph_AIGABuff_DeathTimer_PVE
}; 
 
 


