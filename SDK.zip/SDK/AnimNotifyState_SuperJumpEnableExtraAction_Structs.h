#pragma once 
#include <SDK_Engine_Objects.h> 
 
 
//Function AnimNotifyState_SuperJumpEnableExtraAction.AnimNotifyState_SuperJumpEnableExtraAction_C.Received_NotifyBegin Size 41
// Inherited 24 bytes 
class FReceived_NotifyBegin : public FReceived_NotifyBegin
{

 public: 
	struct USkeletalMeshComponent* MeshComp;  // Offset: 0 Size: 8
	struct UAnimSequenceBase* Animation;  // Offset: 8 Size: 8
	float TotalDuration;  // Offset: 16 Size: 4
	char pad_44_1 : 7;  // Offset: 44 Size: 1
	bool ReturnValue : 1;  // Offset: 20 Size: 1
	struct AActor* CallFunc_GetOwner_ReturnValue;  // Offset: 24 Size: 8
	struct AArkPlayer* K2Node_DynamicCast_AsArk_Player;  // Offset: 32 Size: 8
	char pad_61_1 : 7;  // Offset: 61 Size: 1
	bool K2Node_DynamicCast_bSuccess : 1;  // Offset: 40 Size: 1



 // Functions 
 public:
}; 
 
 //Function AnimNotifyState_SuperJumpEnableExtraAction.AnimNotifyState_SuperJumpEnableExtraAction_C.Received_NotifyEnd Size 41
// Inherited 24 bytes 
class FReceived_NotifyEnd : public FReceived_NotifyEnd
{

 public: 
	struct USkeletalMeshComponent* MeshComp;  // Offset: 0 Size: 8
	struct UAnimSequenceBase* Animation;  // Offset: 8 Size: 8
	char pad_40_1 : 7;  // Offset: 40 Size: 1
	bool ReturnValue : 1;  // Offset: 16 Size: 1
	struct AActor* CallFunc_GetOwner_ReturnValue;  // Offset: 24 Size: 8
	struct AArkPlayer* K2Node_DynamicCast_AsArk_Player;  // Offset: 32 Size: 8
	char pad_57_1 : 7;  // Offset: 57 Size: 1
	bool K2Node_DynamicCast_bSuccess : 1;  // Offset: 40 Size: 1



 // Functions 
 public:
}; 
 
 