#pragma once 
#include <SDK_Engine_Objects.h> 
 
 
//Function AIGABuff_DamageSelf_Base.AIGABuff_DamageSelf_Base_C.ExecuteUbergraph_AIGABuff_DamageSelf_Base Size 72
class FExecuteUbergraph_AIGABuff_DamageSelf_Base
{

 public: 
	int32_t EntryPoint;  // Offset: 0 Size: 4
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // Offset: 4 Size: 16
	char pad_20[4];  // Offset: 20 Size: 4
	struct AArkCharacterBase* CallFunc_GetOwnerAsCharacter_ReturnValue;  // Offset: 24 Size: 8
	struct AArkCharacterBase* CallFunc_GetOwnerAsCharacter_ReturnValue_2;  // Offset: 32 Size: 8
	enum class ECharacterState CallFunc_GetCharacterState_ReturnValue;  // Offset: 40 Size: 1
	char pad_41[3];  // Offset: 41 Size: 3
	float CallFunc_GetMaxHealth_ReturnValue;  // Offset: 44 Size: 4
	char pad_48_1 : 7;  // Offset: 48 Size: 1
	bool CallFunc_EqualEqual_ByteByte_ReturnValue : 1;  // Offset: 48 Size: 1
	char pad_49_1 : 7;  // Offset: 49 Size: 1
	bool CallFunc_BooleanAND_ReturnValue : 1;  // Offset: 49 Size: 1
	char pad_50[2];  // Offset: 50 Size: 2
	float CallFunc_Multiply_FloatFloat_ReturnValue;  // Offset: 52 Size: 4
	float CallFunc_ApplyDamage_ReturnValue;  // Offset: 56 Size: 4
	char pad_60_1 : 7;  // Offset: 60 Size: 1
	bool CallFunc_HasAuthority_ReturnValue : 1;  // Offset: 60 Size: 1
	char pad_61[3];  // Offset: 61 Size: 3
	struct FTimerHandle CallFunc_K2_SetTimerDelegate_ReturnValue;  // Offset: 64 Size: 8



 // Functions 
 public:
}; 
 
 