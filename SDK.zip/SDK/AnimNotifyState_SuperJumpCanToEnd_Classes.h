#pragma once 
#include <AnimNotifyState_SuperJumpCanToEnd_Structs.h>
 
 
 
//BlueprintGeneratedClass AnimNotifyState_SuperJumpCanToEnd.AnimNotifyState_SuperJumpCanToEnd_C Size 48
// Inherited 48 bytes 
class UAnimNotifyState_SuperJumpCanToEnd_C : public UAnimNotifyState
{

 public: 



 // Functions 
 public:
	bool Received_NotifyEnd(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function AnimNotifyState_SuperJumpCanToEnd.AnimNotifyState_SuperJumpCanToEnd_C.Received_NotifyEnd
	bool Received_NotifyBegin(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration); // Function AnimNotifyState_SuperJumpCanToEnd.AnimNotifyState_SuperJumpCanToEnd_C.Received_NotifyBegin
}; 
 
 


