#pragma once 
#include <AIGABuff_DamageFixForPve_Structs.h>
 
 
 
//BlueprintGeneratedClass AIGABuff_DamageFixForPve.AIGABuff_DamageFixForPve_C Size 816
// Inherited 816 bytes 
class UAIGABuff_DamageFixForPve_C : public UArkGameBuff_BaseDamageModifier
{

 public: 



 // Functions 
 public:
}; 
 
 


