#pragma once 
#include <AmmoPickup900_Structs.h>
 
 
 
//BlueprintGeneratedClass AmmoPickup900.AmmoPickup900_C Size 2416
// Inherited 2416 bytes 
class AAmmoPickup900_C : public AAmmoPickupBase_C
{

 public: 



 // Functions 
 public:
}; 
 
 


