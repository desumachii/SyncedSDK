#pragma once 
#include <ArkLaserChainBullet_GT_LV2_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkLaserChainBullet_GT_LV2.ArkLaserChainBullet_GT_LV2_C Size 2344
// Inherited 2344 bytes 
class AArkLaserChainBullet_GT_LV2_C : public AArkProjectile_LaserChain
{

 public: 



 // Functions 
 public:
}; 
 
 


