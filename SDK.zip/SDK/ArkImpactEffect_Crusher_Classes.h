#pragma once 
#include <ArkImpactEffect_Crusher_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkImpactEffect_Crusher.ArkImpactEffect_Crusher_C Size 504
// Inherited 504 bytes 
class UArkImpactEffect_Crusher_C : public UArkImpactEffect_RangeWeapon_C
{

 public: 



 // Functions 
 public:
}; 
 
 


