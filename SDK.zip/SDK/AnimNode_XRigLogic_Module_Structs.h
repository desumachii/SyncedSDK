#pragma once 
#include <SDK_Engine_Objects.h> 
 
 
//ScriptStruct AnimNode_XRigLogic_Module.AnimNode_XRigLogic Size 368
// Inherited 24 bytes 
class FAnimNode_XRigLogic : public FAnimNode_Base
{

 public: 
	struct FPoseLink AnimSequence;  // Offset: 24 Size: 16
	struct UXDNAContext* XDNAContext;  // Offset: 40 Size: 8
	char pad_48_1 : 7;  // Offset: 48 Size: 1
	bool IsUIControllerFromBlendshape : 1;  // Offset: 48 Size: 1
	char pad_49_1 : 7;  // Offset: 49 Size: 1
	bool DoRemapAsCalibration : 1;  // Offset: 49 Size: 1
	char pad_50_1 : 7;  // Offset: 50 Size: 1
	bool bBSRig : 1;  // Offset: 50 Size: 1
	char pad_51_1 : 7;  // Offset: 51 Size: 1
	bool bUseCache : 1;  // Offset: 51 Size: 1
	struct FName CharacterName;  // Offset: 52 Size: 8
	int32_t XRigCacheFramerate;  // Offset: 60 Size: 4
	char pad_64[304];  // Offset: 64 Size: 304



 // Functions 
 public:
}; 
 
 //Function AnimNode_XRigLogic_Module.XFaceBPLibrary.GetDemoIndex Size 4
class FGetDemoIndex
{

 public: 
	int32_t ReturnValue;  // Offset: 0 Size: 4



 // Functions 
 public:
}; 
 
 //Function AnimNode_XRigLogic_Module.XFaceBPLibrary.GetIPAddress Size 16
class FGetIPAddress
{

 public: 
	struct FString ReturnValue;  // Offset: 0 Size: 16



 // Functions 
 public:
}; 
 
 //Function AnimNode_XRigLogic_Module.XFaceBPLibrary.SetDemoIndex Size 8
class FSetDemoIndex
{

 public: 
	int32_t V;  // Offset: 0 Size: 4
	int32_t ReturnValue;  // Offset: 4 Size: 4



 // Functions 
 public:
}; 
 
 