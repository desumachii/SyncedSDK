#pragma once 
#include <AIGABuff_RecoveSelf_Pve_Structs.h>
 
 
 
//BlueprintGeneratedClass AIGABuff_RecoveSelf_Pve.AIGABuff_RecoveSelf_Pve_C Size 1288
// Inherited 1288 bytes 
class UAIGABuff_RecoveSelf_Pve_C : public UAIGABuff_RecoveSelf_Lv1_C
{

 public: 



 // Functions 
 public:
}; 
 
 


