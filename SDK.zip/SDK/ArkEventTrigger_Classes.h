#pragma once 
#include <ArkEventTrigger_Structs.h>
 
 
 
//Class ArkEventTrigger.ArkEventTrigger_ActivatedChipEnd Size 40
// Inherited 40 bytes 
class UArkEventTrigger_ActivatedChipEnd : public UArkEventTrigger
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_AddBuff Size 112
// Inherited 88 bytes 
class UArkEventTrigger_AddBuff : public UArkEventTrigger_BuffInfo
{

 public: 
	char pad_88[24];  // Offset: 88 Size: 24



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkSubEventTriggerManager Size 200
// Inherited 200 bytes 
class UArkSubEventTriggerManager : public UArkEventTriggerManager
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_SingleReload Size 64
// Inherited 40 bytes 
class UArkEventTrigger_SingleReload : public UArkEventTrigger
{

 public: 
	struct TArray<int32_t> WeaponId;  // Offset: 40 Size: 16
	char pad_56_1 : 7;  // Offset: 56 Size: 1
	bool Last : 1;  // Offset: 56 Size: 1
	char pad_57_1 : 7;  // Offset: 57 Size: 1
	bool First : 1;  // Offset: 57 Size: 1
	char pad_58[6];  // Offset: 58 Size: 6



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_BeginInteracting Size 56
// Inherited 40 bytes 
class UArkEventTrigger_BeginInteracting : public UArkEventTrigger
{

 public: 
	struct TArray<enum class EArkInteractionType> TypeArray;  // Offset: 40 Size: 16



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_BuffInfo Size 88
// Inherited 40 bytes 
class UArkEventTrigger_BuffInfo : public UArkEventTrigger
{

 public: 
	char pad_40[48];  // Offset: 40 Size: 48



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_ChipCDTimeUp Size 40
// Inherited 40 bytes 
class UArkEventTrigger_ChipCDTimeUp : public UArkEventTrigger
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_AddedBuff Size 112
// Inherited 88 bytes 
class UArkEventTrigger_AddedBuff : public UArkEventTrigger_BuffInfo
{

 public: 
	char pad_88[24];  // Offset: 88 Size: 24



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_RecoverShield Size 40
// Inherited 40 bytes 
class UArkEventTrigger_RecoverShield : public UArkEventTrigger
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_AddOrRemoveItem Size 56
// Inherited 40 bytes 
class UArkEventTrigger_AddOrRemoveItem : public UArkEventTrigger
{

 public: 
	enum class EArkItemInfo_ParamType SubType;  // Offset: 40 Size: 1
	char pad_41_1 : 7;  // Offset: 41 Size: 1
	bool bAddOrRemove : 1;  // Offset: 41 Size: 1
	char pad_42[2];  // Offset: 42 Size: 2
	int32_t ItemId;  // Offset: 44 Size: 4
	enum class EArkItemType ItemType;  // Offset: 48 Size: 1
	char pad_49[7];  // Offset: 49 Size: 7



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_AimingOrTargeting Size 48
// Inherited 40 bytes 
class UArkEventTrigger_AimingOrTargeting : public UArkEventTrigger
{

 public: 
	int32_t bIsAmingOrTargeting;  // Offset: 40 Size: 4
	char pad_44_1 : 7;  // Offset: 44 Size: 1
	bool bEnterOrLeave : 1;  // Offset: 44 Size: 1
	char pad_45[3];  // Offset: 45 Size: 3



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_AnimNotify Size 56
// Inherited 40 bytes 
class UArkEventTrigger_AnimNotify : public UArkEventTrigger
{

 public: 
	struct FString AnimName;  // Offset: 40 Size: 16



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_BuffStackCount Size 56
// Inherited 40 bytes 
class UArkEventTrigger_BuffStackCount : public UArkEventTrigger
{

 public: 
	char pad_40[16];  // Offset: 40 Size: 16



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_RevivePlayer Size 40
// Inherited 40 bytes 
class UArkEventTrigger_RevivePlayer : public UArkEventTrigger
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_BulletFire Size 56
// Inherited 40 bytes 
class UArkEventTrigger_BulletFire : public UArkEventTrigger
{

 public: 
	int32_t FirstBegin;  // Offset: 40 Size: 4
	int32_t FirstEnd;  // Offset: 44 Size: 4
	int32_t LastBegin;  // Offset: 48 Size: 4
	int32_t LastEnd;  // Offset: 52 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_GunChange Size 40
// Inherited 40 bytes 
class UArkEventTrigger_GunChange : public UArkEventTrigger
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_WeaponFire Size 40
// Inherited 40 bytes 
class UArkEventTrigger_WeaponFire : public UArkEventTrigger
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_NanoPossessing Size 48
// Inherited 40 bytes 
class UArkEventTrigger_NanoPossessing : public UArkEventTrigger
{

 public: 
	char pad_40_1 : 7;  // Offset: 40 Size: 1
	bool bSucceed : 1;  // Offset: 40 Size: 1
	char pad_41[7];  // Offset: 41 Size: 7



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_BulletSplit Size 40
// Inherited 40 bytes 
class UArkEventTrigger_BulletSplit : public UArkEventTrigger
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_LeaveActionState Size 48
// Inherited 40 bytes 
class UArkEventTrigger_LeaveActionState : public UArkEventTrigger
{

 public: 
	enum class EPlayerActionState State;  // Offset: 40 Size: 1
	char pad_41[7];  // Offset: 41 Size: 7



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_BulletWhoosh Size 48
// Inherited 40 bytes 
class UArkEventTrigger_BulletWhoosh : public UArkEventTrigger
{

 public: 
	float Dist;  // Offset: 40 Size: 4
	enum class EArkEventFilter_RelationType relation;  // Offset: 44 Size: 1
	char pad_45[3];  // Offset: 45 Size: 3



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_Custom Size 112
// Inherited 40 bytes 
class UArkEventTrigger_Custom : public UArkEventTrigger
{

 public: 
	struct FName EventName;  // Offset: 40 Size: 8
	struct FString Param1;  // Offset: 48 Size: 16
	struct FString Param2;  // Offset: 64 Size: 16
	struct FString Param3;  // Offset: 80 Size: 16
	struct FString Param4;  // Offset: 96 Size: 16



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_SyncAISuccessed Size 48
// Inherited 40 bytes 
class UArkEventTrigger_SyncAISuccessed : public UArkEventTrigger
{

 public: 
	char pad_40_1 : 7;  // Offset: 40 Size: 1
	bool bResync : 1;  // Offset: 40 Size: 1
	char pad_41[7];  // Offset: 41 Size: 7



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_HitInfo Size 368
// Inherited 40 bytes 
class UArkEventTrigger_HitInfo : public UArkEventTrigger
{

 public: 
	struct TArray<struct FArkEventFilter_BoolParam> BoolParams;  // Offset: 40 Size: 16
	enum class EArkGameBuff_BoolParam ShotHead;  // Offset: 56 Size: 1
	enum class EArkGameBuff_BoolParam WeakPoint;  // Offset: 57 Size: 1
	enum class EArkGameBuff_BoolParam FullLife;  // Offset: 58 Size: 1
	enum class EArkGameBuff_BoolParam Critical;  // Offset: 59 Size: 1
	enum class EArkGameBuff_BoolParam BrokeShield;  // Offset: 60 Size: 1
	enum class EArkGameBuff_BoolParam ShotBackward;  // Offset: 61 Size: 1
	enum class EArkGameBuff_BoolParam Penetrate;  // Offset: 62 Size: 1
	enum class EArkGameBuff_BoolParam Cover;  // Offset: 63 Size: 1
	enum class EArkGameBuff_BoolParam Startle;  // Offset: 64 Size: 1
	enum class EArkGameBuff_BoolParam HitStun;  // Offset: 65 Size: 1
	enum class EPlayerActionState VictimActionState;  // Offset: 66 Size: 1
	char pad_67[21];  // Offset: 67 Size: 21
	enum class EArkDamageTypeTag Tag;  // Offset: 88 Size: 1
	char pad_89[7];  // Offset: 89 Size: 7
	struct TArray<enum class EArkDamageTypeTag> Tags;  // Offset: 96 Size: 16
	struct TArray<enum class EArkElementType> Elements;  // Offset: 112 Size: 16
	struct TArray<UDamageType*> DamageType;  // Offset: 128 Size: 16
	struct TArray<struct FName> IncludeTags;  // Offset: 144 Size: 16
	struct TArray<struct FName> ExcludeTags;  // Offset: 160 Size: 16
	enum class EWeaponType WeaponType;  // Offset: 176 Size: 1
	char pad_177[7];  // Offset: 177 Size: 7
	struct TArray<enum class EWeaponDetailType> WeaponDetailType;  // Offset: 184 Size: 16
	enum class EWeaponSubType WeaponSubType;  // Offset: 200 Size: 1
	enum class EArkWeaponFireMode FireMode;  // Offset: 201 Size: 1
	enum class EScopeType Scope;  // Offset: 202 Size: 1
	char pad_203[1];  // Offset: 203 Size: 1
	int32_t FirstBegin;  // Offset: 204 Size: 4
	int32_t FirstEnd;  // Offset: 208 Size: 4
	int32_t LastBegin;  // Offset: 212 Size: 4
	int32_t LastEnd;  // Offset: 216 Size: 4
	int32_t ClipInterval;  // Offset: 220 Size: 4
	struct TArray<int32_t> ClipPos;  // Offset: 224 Size: 16
	enum class ELastAimingInfo Aiming;  // Offset: 240 Size: 1
	char pad_241[7];  // Offset: 241 Size: 7
	struct TArray<struct FName> CauserExcludeTag;  // Offset: 248 Size: 16
	struct TArray<struct FName> CauserIncludeTag;  // Offset: 264 Size: 16
	struct TArray<struct FName> VictimTag;  // Offset: 280 Size: 16
	struct TArray<struct FName> VictimExcludeTag;  // Offset: 296 Size: 16
	struct TArray<struct FName> VictimIncludeTag;  // Offset: 312 Size: 16
	struct TArray<struct FName> VictimTagArray;  // Offset: 328 Size: 16
	int32_t VictimTagCount;  // Offset: 344 Size: 4
	float HpLtPercent;  // Offset: 348 Size: 4
	float DistanceMin;  // Offset: 352 Size: 4
	float DistanceMax;  // Offset: 356 Size: 4
	enum class ECharacterState CharacterState;  // Offset: 360 Size: 1
	char pad_361[7];  // Offset: 361 Size: 7



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_Killed Size 376
// Inherited 368 bytes 
class UArkEventTrigger_Killed : public UArkEventTrigger_HitInfo
{

 public: 
	enum class EArkEliminateWay KilledReason;  // Offset: 368 Size: 1
	char pad_369[7];  // Offset: 369 Size: 7



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_Damage Size 416
// Inherited 368 bytes 
class UArkEventTrigger_Damage : public UArkEventTrigger_HitInfo
{

 public: 
	char pad_368[48];  // Offset: 368 Size: 48



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_DamageToHp Size 48
// Inherited 40 bytes 
class UArkEventTrigger_DamageToHp : public UArkEventTrigger
{

 public: 
	char pad_40[8];  // Offset: 40 Size: 8



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_SummonByGrave Size 40
// Inherited 40 bytes 
class UArkEventTrigger_SummonByGrave : public UArkEventTrigger
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_EnterActionState Size 48
// Inherited 40 bytes 
class UArkEventTrigger_EnterActionState : public UArkEventTrigger
{

 public: 
	enum class EPlayerActionState State;  // Offset: 40 Size: 1
	char pad_41[7];  // Offset: 41 Size: 7



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_EquipOrUnEquipChip Size 48
// Inherited 40 bytes 
class UArkEventTrigger_EquipOrUnEquipChip : public UArkEventTrigger
{

 public: 
	char pad_40_1 : 7;  // Offset: 40 Size: 1
	bool bEquipOrUnEquip : 1;  // Offset: 40 Size: 1
	char pad_41[3];  // Offset: 41 Size: 3
	int32_t ItemId;  // Offset: 44 Size: 4



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_Heal Size 56
// Inherited 40 bytes 
class UArkEventTrigger_Heal : public UArkEventTrigger
{

 public: 
	char pad_40[16];  // Offset: 40 Size: 16



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_WeaponThrowed Size 40
// Inherited 40 bytes 
class UArkEventTrigger_WeaponThrowed : public UArkEventTrigger
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_Healed Size 56
// Inherited 40 bytes 
class UArkEventTrigger_Healed : public UArkEventTrigger
{

 public: 
	char pad_40[16];  // Offset: 40 Size: 16



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_Hit Size 392
// Inherited 368 bytes 
class UArkEventTrigger_Hit : public UArkEventTrigger_HitInfo
{

 public: 
	enum class EArkEventFilter_RelationType TargetRelation;  // Offset: 368 Size: 1
	enum class EArkEventFilter_CharacterType TargetChar;  // Offset: 369 Size: 1
	char pad_370[6];  // Offset: 370 Size: 6
	struct TArray<enum class EArkEventFilter_CharacterType> TargetCharArray;  // Offset: 376 Size: 16



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_Hited Size 392
// Inherited 368 bytes 
class UArkEventTrigger_Hited : public UArkEventTrigger_HitInfo
{

 public: 
	enum class EArkEventFilter_RelationType CauserRelation;  // Offset: 368 Size: 1
	enum class EArkEventFilter_CharacterType CauserChar;  // Offset: 369 Size: 1
	char pad_370[6];  // Offset: 370 Size: 6
	struct TArray<enum class EArkEventFilter_CharacterType> CauserCharArray;  // Offset: 376 Size: 16



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_InstigateBuffTag Size 56
// Inherited 40 bytes 
class UArkEventTrigger_InstigateBuffTag : public UArkEventTrigger
{

 public: 
	struct FName Tag;  // Offset: 40 Size: 8
	char pad_48[8];  // Offset: 48 Size: 8



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_Kill Size 400
// Inherited 392 bytes 
class UArkEventTrigger_Kill : public UArkEventTrigger_Hit
{

 public: 
	enum class EArkEliminateWay Reason;  // Offset: 392 Size: 1
	enum class EArkGameBuff_BoolParam KnockDown;  // Offset: 393 Size: 1
	char pad_394[6];  // Offset: 394 Size: 6



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_NpcPerformAction Size 48
// Inherited 40 bytes 
class UArkEventTrigger_NpcPerformAction : public UArkEventTrigger
{

 public: 
	UArkAIGABuff_Performable* SkillClass;  // Offset: 40 Size: 8



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_KillByHomingProjectile Size 48
// Inherited 40 bytes 
class UArkEventTrigger_KillByHomingProjectile : public UArkEventTrigger
{

 public: 
	enum class EArkEliminateWay Reason;  // Offset: 40 Size: 1
	char pad_41[7];  // Offset: 41 Size: 7



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_Rechamber Size 56
// Inherited 40 bytes 
class UArkEventTrigger_Rechamber : public UArkEventTrigger
{

 public: 
	struct TArray<int32_t> WeaponId;  // Offset: 40 Size: 16



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_MeleeAttacked Size 48
// Inherited 40 bytes 
class UArkEventTrigger_MeleeAttacked : public UArkEventTrigger
{

 public: 
	char pad_40_1 : 7;  // Offset: 40 Size: 1
	bool bMainHand : 1;  // Offset: 40 Size: 1
	char pad_41_1 : 7;  // Offset: 41 Size: 1
	bool bSprintAttack : 1;  // Offset: 41 Size: 1
	char pad_42[6];  // Offset: 42 Size: 6



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_PickUpWeapon Size 56
// Inherited 40 bytes 
class UArkEventTrigger_PickUpWeapon : public UArkEventTrigger
{

 public: 
	struct TArray<int32_t> Weapons;  // Offset: 40 Size: 16



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_ReachLockHealth Size 48
// Inherited 40 bytes 
class UArkEventTrigger_ReachLockHealth : public UArkEventTrigger
{

 public: 
	char pad_40[8];  // Offset: 40 Size: 8



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_Reload Size 64
// Inherited 40 bytes 
class UArkEventTrigger_Reload : public UArkEventTrigger
{

 public: 
	struct TArray<int32_t> WeaponId;  // Offset: 40 Size: 16
	char pad_56_1 : 7;  // Offset: 56 Size: 1
	bool Single : 1;  // Offset: 56 Size: 1
	char pad_57_1 : 7;  // Offset: 57 Size: 1
	bool NotSingle : 1;  // Offset: 57 Size: 1
	char pad_58_1 : 7;  // Offset: 58 Size: 1
	bool Empty : 1;  // Offset: 58 Size: 1
	char pad_59_1 : 7;  // Offset: 59 Size: 1
	bool NotEmpty : 1;  // Offset: 59 Size: 1
	char pad_60_1 : 7;  // Offset: 60 Size: 1
	bool Last : 1;  // Offset: 60 Size: 1
	char pad_61_1 : 7;  // Offset: 61 Size: 1
	bool First : 1;  // Offset: 61 Size: 1
	char pad_62[2];  // Offset: 62 Size: 2



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_ReloadComplete Size 48
// Inherited 40 bytes 
class UArkEventTrigger_ReloadComplete : public UArkEventTrigger
{

 public: 
	enum class EArkGameBuff_BoolParam TacticalReload;  // Offset: 40 Size: 1
	enum class EArkGameBuff_BoolParam IsSingle;  // Offset: 41 Size: 1
	char pad_42[6];  // Offset: 42 Size: 6



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_SyncDetection Size 56
// Inherited 40 bytes 
class UArkEventTrigger_SyncDetection : public UArkEventTrigger
{

 public: 
	char pad_40[16];  // Offset: 40 Size: 16



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_SyncShieldAbsorb Size 56
// Inherited 40 bytes 
class UArkEventTrigger_SyncShieldAbsorb : public UArkEventTrigger
{

 public: 
	char pad_40[16];  // Offset: 40 Size: 16



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_SyncShieldFly Size 48
// Inherited 40 bytes 
class UArkEventTrigger_SyncShieldFly : public UArkEventTrigger
{

 public: 
	char pad_40[8];  // Offset: 40 Size: 8



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_TargetBuffTag Size 56
// Inherited 40 bytes 
class UArkEventTrigger_TargetBuffTag : public UArkEventTrigger
{

 public: 
	struct FName Tag;  // Offset: 40 Size: 8
	char pad_48[8];  // Offset: 48 Size: 8



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_TriggerCD Size 56
// Inherited 40 bytes 
class UArkEventTrigger_TriggerCD : public UArkEventTrigger
{

 public: 
	struct FName Tag;  // Offset: 40 Size: 8
	char pad_48_1 : 7;  // Offset: 48 Size: 1
	bool bStartOrStop : 1;  // Offset: 48 Size: 1
	char pad_49[7];  // Offset: 49 Size: 7



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_UseHealthPack Size 40
// Inherited 40 bytes 
class UArkEventTrigger_UseHealthPack : public UArkEventTrigger
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class ArkEventTrigger.ArkEventTrigger_WeaponRecycled Size 40
// Inherited 40 bytes 
class UArkEventTrigger_WeaponRecycled : public UArkEventTrigger
{

 public: 



 // Functions 
 public:
}; 
 
 


