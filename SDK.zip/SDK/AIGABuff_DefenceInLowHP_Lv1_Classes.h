#pragma once 
#include <AIGABuff_DefenceInLowHP_Lv1_Structs.h>
 
 
 
//BlueprintGeneratedClass AIGABuff_DefenceInLowHP_Lv1.AIGABuff_DefenceInLowHP_Lv1_C Size 1224
// Inherited 1224 bytes 
class UAIGABuff_DefenceInLowHP_Lv1_C : public UArkAIGameplayAbilityBuff
{

 public: 



 // Functions 
 public:
}; 
 
 


