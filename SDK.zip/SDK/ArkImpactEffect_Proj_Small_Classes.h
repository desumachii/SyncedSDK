#pragma once 
#include <ArkImpactEffect_Proj_Small_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkImpactEffect_Proj_Small.ArkImpactEffect_Proj_Small_C Size 504
// Inherited 504 bytes 
class UArkImpactEffect_Proj_Small_C : public UArkImpactEffect_Proj_Common_C
{

 public: 



 // Functions 
 public:
}; 
 
 


