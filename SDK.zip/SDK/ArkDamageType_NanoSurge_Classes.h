#pragma once 
#include <ArkDamageType_NanoSurge_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkDamageType_NanoSurge.ArkDamageType_NanoSurge_C Size 264
// Inherited 264 bytes 
class UArkDamageType_NanoSurge_C : public UArkDamageType
{

 public: 



 // Functions 
 public:
}; 
 
 


