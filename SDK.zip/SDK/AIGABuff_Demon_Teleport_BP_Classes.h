#pragma once 
#include <AIGABuff_Demon_Teleport_BP_Structs.h>
 
 
 
//BlueprintGeneratedClass AIGABuff_Demon_Teleport_BP.AIGABuff_Demon_Teleport_BP_C Size 2256
// Inherited 2256 bytes 
class UAIGABuff_Demon_Teleport_BP_C : public UAIGABuff_Teleport_Command_BP_C
{

 public: 



 // Functions 
 public:
}; 
 
 


