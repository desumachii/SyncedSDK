#pragma once 
#include <ArkImpactEffect_RangeWeaponSG_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkImpactEffect_RangeWeaponSG.ArkImpactEffect_RangeWeaponSG_C Size 504
// Inherited 504 bytes 
class UArkImpactEffect_RangeWeaponSG_C : public UArkImpactEffect_RangeWeapon_C
{

 public: 



 // Functions 
 public:
}; 
 
 


