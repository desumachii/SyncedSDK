#pragma once 
#include <ArkGABuff_ReviveMaster_Lv1_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkGABuff_ReviveMaster_Lv1.ArkGABuff_ReviveMaster_Lv1_C Size 2080
// Inherited 2064 bytes 
class UArkGABuff_ReviveMaster_Lv1_C : public UArkAIGABuff_Revive
{

 public: 
	struct FPointerToUberGraphFrame UberGraphFrame;  // Offset: 2064 Size: 8
	struct UParticleSystemComponent* ReviveBream;  // Offset: 2072 Size: 8



 // Functions 
 public:
	void UpdateBeamEndPoint(); // Function ArkGABuff_ReviveMaster_Lv1.ArkGABuff_ReviveMaster_Lv1_C.UpdateBeamEndPoint
	void OnPerformAction_BP(struct AActor* TargetActor); // Function ArkGABuff_ReviveMaster_Lv1.ArkGABuff_ReviveMaster_Lv1_C.OnPerformAction_BP
	void OnStopAction_BP(enum class EArkAIGAActionStopReason StopReason); // Function ArkGABuff_ReviveMaster_Lv1.ArkGABuff_ReviveMaster_Lv1_C.OnStopAction_BP
	void ExecuteUbergraph_ArkGABuff_ReviveMaster_Lv1(int32_t EntryPoint); // Function ArkGABuff_ReviveMaster_Lv1.ArkGABuff_ReviveMaster_Lv1_C.ExecuteUbergraph_ArkGABuff_ReviveMaster_Lv1
}; 
 
 


