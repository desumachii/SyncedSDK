#pragma once 
#include <AIGABuff_DefenceInHighHP_Lv1_Structs.h>
 
 
 
//BlueprintGeneratedClass AIGABuff_DefenceInHighHP_Lv1.AIGABuff_DefenceInHighHP_Lv1_C Size 1224
// Inherited 1224 bytes 
class UAIGABuff_DefenceInHighHP_Lv1_C : public UArkAIGameplayAbilityBuff
{

 public: 



 // Functions 
 public:
}; 
 
 


