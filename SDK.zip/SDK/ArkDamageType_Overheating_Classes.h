#pragma once 
#include <ArkDamageType_Overheating_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkDamageType_Overheating.ArkDamageType_Overheating_C Size 264
// Inherited 264 bytes 
class UArkDamageType_Overheating_C : public UArkDamageType
{

 public: 



 // Functions 
 public:
}; 
 
 


