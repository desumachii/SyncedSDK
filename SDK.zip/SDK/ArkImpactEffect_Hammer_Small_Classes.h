#pragma once 
#include <ArkImpactEffect_Hammer_Small_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkImpactEffect_Hammer_Small.ArkImpactEffect_Hammer_Small_C Size 504
// Inherited 504 bytes 
class UArkImpactEffect_Hammer_Small_C : public UArkImpactEffect_Hammer_Large_C
{

 public: 



 // Functions 
 public:
}; 
 
 


