#pragma once 
#include <ArkBubbleBullet_GT_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkBubbleBullet_GT.ArkBubbleBullet_GT_C Size 1896
// Inherited 1896 bytes 
class AArkBubbleBullet_GT_C : public AArkProjectile_Bubble
{

 public: 



 // Functions 
 public:
}; 
 
 


