#pragma once 
#include <SDK_Engine_Objects.h> 
 
 
//Function ArkLoginHUD_BP.ArkLoginHUD_BP_C.ArkLoginHUD_BP_AutoGenFunc Size 8
class FArkLoginHUD_BP_AutoGenFunc
{

 public: 
	struct UUserWidget* CreatedWidget;  // Offset: 0 Size: 8



 // Functions 
 public:
}; 
 
 //Function ArkLoginHUD_BP.ArkLoginHUD_BP_C.ExecuteUbergraph_ArkLoginHUD_BP Size 288
class FExecuteUbergraph_ArkLoginHUD_BP
{

 public: 
	int32_t EntryPoint;  // Offset: 0 Size: 4
	struct FDelegate K2Node_CreateDelegate_OutputDelegate;  // Offset: 4 Size: 16
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_2;  // Offset: 20 Size: 16
	char pad_36[4];  // Offset: 36 Size: 4
	struct FDataBoxOperateButton K2Node_MakeStruct_DataBoxOperateButton;  // Offset: 40 Size: 56
	struct FDataBoxOperateButton K2Node_MakeStruct_DataBoxOperateButton_2;  // Offset: 96 Size: 56
	struct FDelegate K2Node_CreateDelegate_OutputDelegate_3;  // Offset: 152 Size: 16
	struct TArray<struct FDataBoxOperateButton> K2Node_MakeArray_Array;  // Offset: 168 Size: 16
	struct FDataBoxPureTextTypeData K2Node_MakeStruct_DataBoxPureTextTypeData;  // Offset: 184 Size: 104



 // Functions 
 public:
}; 
 
 