#pragma once 
#include <AIGABuff_NightVision_BP_Structs.h>
 
 
 
//BlueprintGeneratedClass AIGABuff_NightVision_BP.AIGABuff_NightVision_BP_C Size 1244
// Inherited 1224 bytes 
class UAIGABuff_NightVision_BP_C : public UArkAIGABuff_NightVision
{

 public: 
	struct FPointerToUberGraphFrame UberGraphFrame;  // Offset: 1224 Size: 8
	struct FName NightVisionLevel_BBK;  // Offset: 1232 Size: 8
	int32_t NightVisionLevel;  // Offset: 1240 Size: 4



 // Functions 
 public:
	void C2BP_OnActive(); // Function AIGABuff_NightVision_BP.AIGABuff_NightVision_BP_C.C2BP_OnActive
	void C2BP_OnDeactive(); // Function AIGABuff_NightVision_BP.AIGABuff_NightVision_BP_C.C2BP_OnDeactive
	void ExecuteUbergraph_AIGABuff_NightVision_BP(int32_t EntryPoint); // Function AIGABuff_NightVision_BP.AIGABuff_NightVision_BP_C.ExecuteUbergraph_AIGABuff_NightVision_BP
}; 
 
 


