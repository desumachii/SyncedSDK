#pragma once 
#include <ArkDamageType_2doTs_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkDamageType_2doTs.ArkDamageType_2doTs_C Size 264
// Inherited 264 bytes 
class UArkDamageType_2doTs_C : public UArkDamageType_Element_C
{

 public: 



 // Functions 
 public:
}; 
 
 


