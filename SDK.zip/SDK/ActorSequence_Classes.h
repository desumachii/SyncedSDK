#pragma once 
#include <ActorSequence_Structs.h>
 
 
 
//Class ActorSequence.ActorSequenceComponent Size 520
// Inherited 480 bytes 
class UActorSequenceComponent : public UActorComponent
{

 public: 
	struct FMovieSceneSequencePlaybackSettings PlaybackSettings;  // Offset: 480 Size: 20
	char pad_500[4];  // Offset: 500 Size: 4
	struct UActorSequence* Sequence;  // Offset: 504 Size: 8
	struct UActorSequencePlayer* SequencePlayer;  // Offset: 512 Size: 8



 // Functions 
 public:
}; 
 
 


//Class ActorSequence.ActorSequence Size 880
// Inherited 840 bytes 
class UActorSequence : public UMovieSceneSequence
{

 public: 
	struct UMovieScene* MovieScene;  // Offset: 840 Size: 8
	struct FActorSequenceObjectReferenceMap ObjectReferences;  // Offset: 848 Size: 32



 // Functions 
 public:
}; 
 
 


//Class ActorSequence.ActorSequencePlayer Size 2344
// Inherited 2344 bytes 
class UActorSequencePlayer : public UMovieSceneSequencePlayer
{

 public: 



 // Functions 
 public:
}; 
 
 


