#pragma once 
#include <ArkDamageType_SR_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkDamageType_SR.ArkDamageType_SR_C Size 264
// Inherited 264 bytes 
class UArkDamageType_SR_C : public UArkDamageType_Range_C
{

 public: 



 // Functions 
 public:
}; 
 
 


