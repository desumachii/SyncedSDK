#pragma once 
#include <AnimNotifyState_SuperJumpWaitForVelocityZNearlyZero_Structs.h>
 
 
 
//BlueprintGeneratedClass AnimNotifyState_SuperJumpWaitForVelocityZNearlyZero.AnimNotifyState_SuperJumpWaitForVelocityZNearlyZero_C Size 48
// Inherited 48 bytes 
class UAnimNotifyState_SuperJumpWaitForVelocityZNearlyZero_C : public UAnimNotifyState
{

 public: 



 // Functions 
 public:
	bool Received_NotifyEnd(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function AnimNotifyState_SuperJumpWaitForVelocityZNearlyZero.AnimNotifyState_SuperJumpWaitForVelocityZNearlyZero_C.Received_NotifyEnd
}; 
 
 


