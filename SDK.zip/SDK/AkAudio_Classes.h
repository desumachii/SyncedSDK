#pragma once 
#include <AkAudio_Structs.h>
 
 
 
//Class AkAudio.AkPortalComponent Size 1136
// Inherited 944 bytes 
class UAkPortalComponent : public USceneComponent
{

 public: 
	char pad_944_1 : 7;  // Offset: 944 Size: 1
	bool bDynamic : 1;  // Offset: 936 Size: 1
	enum class AkAcousticPortalState InitialState;  // Offset: 937 Size: 1
	float ObstructionRefreshInterval;  // Offset: 940 Size: 4
	enum class ECollisionChannel ObstructionCollisionChannel;  // Offset: 944 Size: 1
	char pad_951[185];  // Offset: 951 Size: 185



 // Functions 
 public:
	bool PortalPlacementValid(); // Function AkAudio.AkPortalComponent.PortalPlacementValid
	void OpenPortal(); // Function AkAudio.AkPortalComponent.OpenPortal
	struct UPrimitiveComponent* GetPrimitiveParent(); // Function AkAudio.AkPortalComponent.GetPrimitiveParent
	enum class AkAcousticPortalState GetCurrentState(); // Function AkAudio.AkPortalComponent.GetCurrentState
	void ClosePortal(); // Function AkAudio.AkPortalComponent.ClosePortal
}; 
 
 


//Class AkAudio.AkAudioBank Size 280
// Inherited 80 bytes 
class UAkAudioBank : public UAkAssetBase
{

 public: 
	char pad_80_1 : 7;  // Offset: 80 Size: 1
	bool AutoLoad : 1;  // Offset: 80 Size: 1
	char pad_81[7];  // Offset: 81 Size: 7
	struct TMap<struct FString, struct UAkAssetPlatformData*> LocalizedPlatformAssetDataMap;  // Offset: 88 Size: 80
	struct TSet<struct TSoftObjectPtr<UAkAudioEvent>> LinkedAkEvents;  // Offset: 168 Size: 80
	struct UAkAssetPlatformData* CurrentLocalizedPlatformAssetData;  // Offset: 248 Size: 8
	char pad_256[24];  // Offset: 256 Size: 24



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkAudioType Size 64
// Inherited 40 bytes 
class UAkAudioType : public UObject
{

 public: 
	uint32_t ShortID;  // Offset: 40 Size: 4
	char pad_44[4];  // Offset: 44 Size: 4
	struct TArray<struct UObject*> UserData;  // Offset: 48 Size: 16



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkAcousticPortal Size 816
// Inherited 800 bytes 
class AAkAcousticPortal : public AVolume
{

 public: 
	struct UAkPortalComponent* Portal;  // Offset: 800 Size: 8
	enum class AkAcousticPortalState InitialState;  // Offset: 808 Size: 1
	char pad_809_1 : 7;  // Offset: 809 Size: 1
	bool bRequiresStateMigration : 1;  // Offset: 809 Size: 1
	char pad_810[6];  // Offset: 810 Size: 6



 // Functions 
 public:
	void OpenPortal(); // Function AkAudio.AkAcousticPortal.OpenPortal
	enum class AkAcousticPortalState GetCurrentState(); // Function AkAudio.AkAcousticPortal.GetCurrentState
	void ClosePortal(); // Function AkAudio.AkAcousticPortal.ClosePortal
}; 
 
 


//Class AkAudio.AkPS5InitializationSettings Size 240
// Inherited 40 bytes 
class UAkPS5InitializationSettings : public UObject
{

 public: 
	char pad_40[8];  // Offset: 40 Size: 8
	struct FAkCommonInitializationSettings CommonSettings;  // Offset: 48 Size: 96
	struct FAkCommunicationSettingsWithSystemInitialization CommunicationSettings;  // Offset: 144 Size: 40
	struct FAkPS5AdvancedInitializationSettings AdvancedSettings;  // Offset: 184 Size: 52
	char pad_236[4];  // Offset: 236 Size: 4



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkAcousticTextureSetComponent Size 960
// Inherited 944 bytes 
class UAkAcousticTextureSetComponent : public USceneComponent
{

 public: 
	char pad_944[16];  // Offset: 944 Size: 16



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkAcousticTexture Size 64
// Inherited 64 bytes 
class UAkAcousticTexture : public UAkAudioType
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkAmbientSound Size 808
// Inherited 744 bytes 
class AAkAmbientSound : public AActor
{

 public: 
	struct UAkAudioEvent* AkAudioEvent;  // Offset: 744 Size: 8
	struct UAkComponent* AkComponent;  // Offset: 752 Size: 8
	char pad_760_1 : 7;  // Offset: 760 Size: 1
	bool StopWhenOwnerIsDestroyed : 1;  // Offset: 760 Size: 1
	char pad_761_1 : 7;  // Offset: 761 Size: 1
	bool AutoPost : 1;  // Offset: 761 Size: 1
	char pad_762[46];  // Offset: 762 Size: 46



 // Functions 
 public:
	void StopAmbientSound(); // Function AkAudio.AkAmbientSound.StopAmbientSound
	void StartAmbientSound(); // Function AkAudio.AkAmbientSound.StartAmbientSound
}; 
 
 


//Class AkAudio.AkPlatformInfo Size 112
// Inherited 40 bytes 
class UAkPlatformInfo : public UObject
{

 public: 
	char pad_40[72];  // Offset: 40 Size: 72



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkAndroidInitializationSettings Size 248
// Inherited 40 bytes 
class UAkAndroidInitializationSettings : public UObject
{

 public: 
	char pad_40[8];  // Offset: 40 Size: 8
	struct FAkCommonInitializationSettingsWithSampleRate CommonSettings;  // Offset: 48 Size: 104
	struct FAkCommunicationSettingsWithSystemInitialization CommunicationSettings;  // Offset: 152 Size: 40
	struct FAkAndroidAdvancedInitializationSettings AdvancedSettings;  // Offset: 192 Size: 56



 // Functions 
 public:
	void MigrateMultiCoreRendering(bool NewValue); // Function AkAudio.AkAndroidInitializationSettings.MigrateMultiCoreRendering
}; 
 
 


//Class AkAudio.AkMediaAssetData Size 120
// Inherited 40 bytes 
class UAkMediaAssetData : public UObject
{

 public: 
	char pad_40_1 : 7;  // Offset: 40 Size: 1
	bool IsStreamed : 1;  // Offset: 40 Size: 1
	char pad_41_1 : 7;  // Offset: 41 Size: 1
	bool UseDeviceMemory : 1;  // Offset: 41 Size: 1
	char pad_42[6];  // Offset: 42 Size: 6
	struct FString Language;  // Offset: 48 Size: 16
	struct FString AssetPlatform;  // Offset: 64 Size: 16
	char pad_80[40];  // Offset: 80 Size: 40



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkAndroidPlatformInfo Size 112
// Inherited 112 bytes 
class UAkAndroidPlatformInfo : public UAkPlatformInfo
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkAssetBase Size 80
// Inherited 64 bytes 
class UAkAssetBase : public UAkAudioType
{

 public: 
	struct UAkAssetPlatformData* PlatformAssetData;  // Offset: 64 Size: 8
	char pad_72[8];  // Offset: 72 Size: 8



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkPS4PlatformInfo Size 112
// Inherited 112 bytes 
class UAkPS4PlatformInfo : public UAkPlatformInfo
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkRoomComponent Size 1024
// Inherited 976 bytes 
class UAkRoomComponent : public UAkGameObject
{

 public: 
	char pad_976_1 : 7;  // Offset: 976 Size: 1
	bool bEnable : 1;  // Offset: 968 Size: 1
	char pad_977_1 : 7;  // Offset: 977 Size: 1
	bool bDynamic : 1;  // Offset: 969 Size: 1
	float Priority;  // Offset: 972 Size: 4
	float WallOcclusion;  // Offset: 976 Size: 4
	float AuxSendLevel;  // Offset: 980 Size: 4
	char pad_990_1 : 7;  // Offset: 990 Size: 1
	bool AutoPost : 1;  // Offset: 984 Size: 1
	char pad_991[9];  // Offset: 991 Size: 9
	struct UAkAcousticTextureSetComponent* GeometryComponent;  // Offset: 1000 Size: 8
	char pad_1008[16];  // Offset: 1008 Size: 16



 // Functions 
 public:
	void SetGeometryComponent(struct UAkAcousticTextureSetComponent* textureSetComponent); // Function AkAudio.AkRoomComponent.SetGeometryComponent
	struct UPrimitiveComponent* GetPrimitiveParent(); // Function AkAudio.AkRoomComponent.GetPrimitiveParent
}; 
 
 


//Class AkAudio.AkAssetData Size 120
// Inherited 40 bytes 
class UAkAssetData : public UObject
{

 public: 
	uint32_t CachedHash;  // Offset: 40 Size: 4
	char pad_44[4];  // Offset: 44 Size: 4
	struct FString BankLanguage;  // Offset: 48 Size: 16
	char pad_64[56];  // Offset: 64 Size: 56



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkAssetDataWithMedia Size 136
// Inherited 120 bytes 
class UAkAssetDataWithMedia : public UAkAssetData
{

 public: 
	struct TArray<struct UAkMediaAsset*> MediaList;  // Offset: 120 Size: 16



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkFolder Size 184
// Inherited 64 bytes 
class UAkFolder : public UAkAudioType
{

 public: 
	struct FString UnrealFolderPath;  // Offset: 64 Size: 16
	struct FString WwiseFolderPath;  // Offset: 80 Size: 16
	char pad_96[88];  // Offset: 96 Size: 88



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkPS5PlatformInfo Size 112
// Inherited 112 bytes 
class UAkPS5PlatformInfo : public UAkPlatformInfo
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkAssetPlatformData Size 48
// Inherited 40 bytes 
class UAkAssetPlatformData : public UObject
{

 public: 
	struct UAkAssetData* CurrentAssetData;  // Offset: 40 Size: 8



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkItemBoolProperties Size 336
// Inherited 272 bytes 
class UAkItemBoolProperties : public UWidget
{

 public: 
	struct FMulticastInlineDelegate OnSelectionChanged;  // Offset: 272 Size: 16
	struct FMulticastInlineDelegate OnPropertyDragged;  // Offset: 288 Size: 16
	char pad_304[32];  // Offset: 304 Size: 32



 // Functions 
 public:
	void SetSearchText(struct FString newText); // Function AkAudio.AkItemBoolProperties.SetSearchText
	struct FString GetSelectedProperty(); // Function AkAudio.AkItemBoolProperties.GetSelectedProperty
	struct FString GetSearchText(); // Function AkAudio.AkItemBoolProperties.GetSearchText
}; 
 
 


//Class AkAudio.AkAssetDataSwitchContainerData Size 120
// Inherited 40 bytes 
class UAkAssetDataSwitchContainerData : public UObject
{

 public: 
	struct TSoftObjectPtr<UAkGroupValue> GroupValue;  // Offset: 40 Size: 40
	struct UAkGroupValue* DefaultGroupValue;  // Offset: 80 Size: 8
	struct TArray<struct UAkMediaAsset*> MediaList;  // Offset: 88 Size: 16
	struct TArray<struct UAkAssetDataSwitchContainerData*> Children;  // Offset: 104 Size: 16



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkAssetDataSwitchContainer Size 240
// Inherited 136 bytes 
class UAkAssetDataSwitchContainer : public UAkAssetDataWithMedia
{

 public: 
	struct TArray<struct UAkAssetDataSwitchContainerData*> SwitchContainers;  // Offset: 136 Size: 16
	struct UAkGroupValue* DefaultGroupValue;  // Offset: 152 Size: 8
	char pad_160[80];  // Offset: 160 Size: 80



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkRtpc Size 64
// Inherited 64 bytes 
class UAkRtpc : public UAkAudioType
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkPS4InitializationSettings Size 240
// Inherited 40 bytes 
class UAkPS4InitializationSettings : public UObject
{

 public: 
	char pad_40[8];  // Offset: 40 Size: 8
	struct FAkCommonInitializationSettings CommonSettings;  // Offset: 48 Size: 96
	struct FAkCommunicationSettingsWithSystemInitialization CommunicationSettings;  // Offset: 144 Size: 40
	struct FAkPS4AdvancedInitializationSettings AdvancedSettings;  // Offset: 184 Size: 56



 // Functions 
 public:
	void MigrateMultiCoreRendering(bool NewValue); // Function AkAudio.AkPS4InitializationSettings.MigrateMultiCoreRendering
}; 
 
 


//Class AkAudio.AkAudioEventData Size 656
// Inherited 240 bytes 
class UAkAudioEventData : public UAkAssetDataSwitchContainer
{

 public: 
	float MaxAttenuationRadius;  // Offset: 240 Size: 4
	char pad_244_1 : 7;  // Offset: 244 Size: 1
	bool IsInfinite : 1;  // Offset: 244 Size: 1
	char pad_245[3];  // Offset: 245 Size: 3
	float MinimumDuration;  // Offset: 248 Size: 4
	float MaximumDuration;  // Offset: 252 Size: 4
	struct TMap<struct FString, struct UAkAssetDataSwitchContainer*> LocalizedMedia;  // Offset: 256 Size: 80
	struct TSet<struct UAkAudioEvent*> PostedEvents;  // Offset: 336 Size: 80
	struct TSet<struct UAkAuxBus*> UserDefinedSends;  // Offset: 416 Size: 80
	struct TSet<struct UAkTrigger*> PostedTriggers;  // Offset: 496 Size: 80
	struct TSet<struct UAkGroupValue*> GroupValues;  // Offset: 576 Size: 80



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkIOSInitializationSettings Size 256
// Inherited 40 bytes 
class UAkIOSInitializationSettings : public UObject
{

 public: 
	char pad_40[8];  // Offset: 40 Size: 8
	struct FAkCommonInitializationSettingsWithSampleRate CommonSettings;  // Offset: 48 Size: 104
	struct FAkAudioSession AudioSession;  // Offset: 152 Size: 12
	char pad_164[4];  // Offset: 164 Size: 4
	struct FAkCommunicationSettingsWithSystemInitialization CommunicationSettings;  // Offset: 168 Size: 40
	struct FAkAdvancedInitializationSettings AdvancedSettings;  // Offset: 208 Size: 44
	char pad_252[4];  // Offset: 252 Size: 4



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkAudioEvent Size 208
// Inherited 80 bytes 
class UAkAudioEvent : public UAkAssetBase
{

 public: 
	struct TMap<struct FString, struct UAkAssetPlatformData*> LocalizedPlatformAssetDataMap;  // Offset: 80 Size: 80
	struct UAkAudioBank* RequiredBank;  // Offset: 160 Size: 8
	char pad_168[8];  // Offset: 168 Size: 8
	struct UAkAssetPlatformData* CurrentLocalizedPlatformData;  // Offset: 176 Size: 8
	float MaxAttenuationRadius;  // Offset: 184 Size: 4
	char pad_188_1 : 7;  // Offset: 188 Size: 1
	bool IsInfinite : 1;  // Offset: 188 Size: 1
	char pad_189[3];  // Offset: 189 Size: 3
	float MinimumDuration;  // Offset: 192 Size: 4
	float MaximumDuration;  // Offset: 196 Size: 4
	char pad_200[8];  // Offset: 200 Size: 8



 // Functions 
 public:
	float GetMinimumDuration(); // Function AkAudio.AkAudioEvent.GetMinimumDuration
	float GetMaximumDuration(); // Function AkAudio.AkAudioEvent.GetMaximumDuration
	float GetMaxAttenuationRadius(); // Function AkAudio.AkAudioEvent.GetMaxAttenuationRadius
	bool GetIsInfinite(); // Function AkAudio.AkAudioEvent.GetIsInfinite
}; 
 
 


//Class AkAudio.AkGameObject Size 976
// Inherited 944 bytes 
class UAkGameObject : public USceneComponent
{

 public: 
	struct UAkAudioEvent* AkAudioEvent;  // Offset: 936 Size: 8
	struct FString EventName;  // Offset: 944 Size: 16
	char pad_968[8];  // Offset: 968 Size: 8



 // Functions 
 public:
	void Stop(); // Function AkAudio.AkGameObject.Stop
	void SetRTPCValue(struct UAkRtpc* RTPCValue, float Value, int32_t InterpolationTimeMs, struct FString RTPC); // Function AkAudio.AkGameObject.SetRTPCValue
	void PostAssociatedAkEventAsync(struct UObject* WorldContextObject, int32_t CallbackMask, struct FDelegate& PostEventCallback, struct TArray<struct FAkExternalSourceInfo>& ExternalSources, struct FLatentActionInfo LatentInfo, int32_t& PlayingID); // Function AkAudio.AkGameObject.PostAssociatedAkEventAsync
	int32_t PostAssociatedAkEvent(int32_t CallbackMask, struct FDelegate& PostEventCallback, struct TArray<struct FAkExternalSourceInfo>& ExternalSources); // Function AkAudio.AkGameObject.PostAssociatedAkEvent
	void PostAkEventAsync(struct UObject* WorldContextObject, struct UAkAudioEvent* AkEvent, int32_t& PlayingID, int32_t CallbackMask, struct FDelegate& PostEventCallback, struct TArray<struct FAkExternalSourceInfo>& ExternalSources, struct FLatentActionInfo LatentInfo); // Function AkAudio.AkGameObject.PostAkEventAsync
	int32_t PostAkEvent(struct UAkAudioEvent* AkEvent, int32_t CallbackMask, struct FDelegate& PostEventCallback, struct TArray<struct FAkExternalSourceInfo>& ExternalSources, struct FString in_EventName); // Function AkAudio.AkGameObject.PostAkEvent
	void GetRTPCValue(struct UAkRtpc* RTPCValue, enum class ERTPCValueType InputValueType, float& Value, enum class ERTPCValueType& OutputValueType, struct FString RTPC, int32_t PlayingID); // Function AkAudio.AkGameObject.GetRTPCValue
}; 
 
 


//Class AkAudio.AkComponent Size 1424
// Inherited 976 bytes 
class UAkComponent : public UAkGameObject
{

 public: 
	char pad_976_1 : 7;  // Offset: 976 Size: 1
	bool bUseSpatialAudio : 1;  // Offset: 968 Size: 1
	enum class ECollisionChannel OcclusionCollisionChannel;  // Offset: 976 Size: 1
	char pad_978_1 : 7;  // Offset: 978 Size: 1
	bool EnableSpotReflectors : 1;  // Offset: 977 Size: 1
	char pad_979[1];  // Offset: 979 Size: 1
	float OuterRadius;  // Offset: 980 Size: 4
	float InnerRadius;  // Offset: 984 Size: 4
	char pad_988[4];  // Offset: 988 Size: 4
	struct UAkAuxBus* EarlyReflectionAuxBus;  // Offset: 992 Size: 8
	struct FString EarlyReflectionAuxBusName;  // Offset: 1000 Size: 16
	int32_t EarlyReflectionOrder;  // Offset: 1016 Size: 4
	float EarlyReflectionBusSendGain;  // Offset: 1020 Size: 4
	float EarlyReflectionMaxPathLength;  // Offset: 1024 Size: 4
	float roomReverbAuxBusGain;  // Offset: 1028 Size: 4
	int32_t diffractionMaxEdges;  // Offset: 1032 Size: 4
	int32_t diffractionMaxPaths;  // Offset: 1036 Size: 4
	float diffractionMaxPathLength;  // Offset: 1040 Size: 4
	char pad_1044_1 : 7;  // Offset: 1044 Size: 1
	bool DrawFirstOrderReflections : 1;  // Offset: 1044 Size: 1
	char pad_1045_1 : 7;  // Offset: 1045 Size: 1
	bool DrawSecondOrderReflections : 1;  // Offset: 1045 Size: 1
	char pad_1046_1 : 7;  // Offset: 1046 Size: 1
	bool DrawHigherOrderReflections : 1;  // Offset: 1046 Size: 1
	char pad_1047_1 : 7;  // Offset: 1047 Size: 1
	bool DrawDiffraction : 1;  // Offset: 1047 Size: 1
	char pad_1048_1 : 7;  // Offset: 1048 Size: 1
	bool StopWhenOwnerDestroyed : 1;  // Offset: 1048 Size: 1
	char pad_1049[3];  // Offset: 1049 Size: 3
	float AttenuationScalingFactor;  // Offset: 1052 Size: 4
	float OcclusionRefreshInterval;  // Offset: 1056 Size: 4
	char pad_1060_1 : 7;  // Offset: 1060 Size: 1
	bool bUseReverbVolumes : 1;  // Offset: 1060 Size: 1
	char pad_1061[363];  // Offset: 1061 Size: 363



 // Functions 
 public:
	void UseReverbVolumes(bool inUseReverbVolumes); // Function AkAudio.AkComponent.UseReverbVolumes
	void UseEarlyReflections(struct UAkAuxBus* AuxBus, int32_t Order, float BusSendGain, float MaxPathLength, bool SpotReflectors, struct FString AuxBusName); // Function AkAudio.AkComponent.UseEarlyReflections
	void SetSwitch(struct UAkSwitchValue* SwitchValue, struct FString SwitchGroup, struct FString SwitchState); // Function AkAudio.AkComponent.SetSwitch
	void SetStopWhenOwnerDestroyed(bool bStopWhenOwnerDestroyed); // Function AkAudio.AkComponent.SetStopWhenOwnerDestroyed
	void SetOutputBusVolume(float BusVolume); // Function AkAudio.AkComponent.SetOutputBusVolume
	void SetListeners(struct TArray<struct UAkComponent*>& Listeners); // Function AkAudio.AkComponent.SetListeners
	void SetGameObjectRadius(float in_outerRadius, float in_innerRadius); // Function AkAudio.AkComponent.SetGameObjectRadius
	void SetEarlyReflectionsVolume(float SendVolume); // Function AkAudio.AkComponent.SetEarlyReflectionsVolume
	void SetEarlyReflectionsAuxBus(struct FString AuxBusName); // Function AkAudio.AkComponent.SetEarlyReflectionsAuxBus
	void SetAttenuationScalingFactor(float Value); // Function AkAudio.AkComponent.SetAttenuationScalingFactor
	void PostTrigger(struct UAkTrigger* TriggerValue, struct FString Trigger); // Function AkAudio.AkComponent.PostTrigger
	void PostAssociatedAkEventAndWaitForEndAsync(int32_t& PlayingID, struct TArray<struct FAkExternalSourceInfo>& ExternalSources, struct FLatentActionInfo LatentInfo); // Function AkAudio.AkComponent.PostAssociatedAkEventAndWaitForEndAsync
	int32_t PostAssociatedAkEventAndWaitForEnd(struct TArray<struct FAkExternalSourceInfo>& ExternalSources, struct FLatentActionInfo LatentInfo); // Function AkAudio.AkComponent.PostAssociatedAkEventAndWaitForEnd
	int32_t PostAkEventByName(struct FString in_EventName); // Function AkAudio.AkComponent.PostAkEventByName
	void PostAkEventAndWaitForEndAsync(struct UAkAudioEvent* AkEvent, int32_t& PlayingID, struct TArray<struct FAkExternalSourceInfo>& ExternalSources, struct FLatentActionInfo LatentInfo); // Function AkAudio.AkComponent.PostAkEventAndWaitForEndAsync
	int32_t PostAkEventAndWaitForEnd(struct UAkAudioEvent* AkEvent, struct FString in_EventName, struct TArray<struct FAkExternalSourceInfo>& ExternalSources, struct FLatentActionInfo LatentInfo); // Function AkAudio.AkComponent.PostAkEventAndWaitForEnd
	float GetAttenuationRadius(); // Function AkAudio.AkComponent.GetAttenuationRadius
}; 
 
 


//Class AkAudio.AkXboxOneAnvilInitializationSettings Size 248
// Inherited 248 bytes 
class UAkXboxOneAnvilInitializationSettings : public UAkXboxOneGDKInitializationSettings
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkLinuxInitializationSettings Size 240
// Inherited 40 bytes 
class UAkLinuxInitializationSettings : public UObject
{

 public: 
	char pad_40[8];  // Offset: 40 Size: 8
	struct FAkCommonInitializationSettingsWithSampleRate CommonSettings;  // Offset: 48 Size: 104
	struct FAkCommunicationSettingsWithSystemInitialization CommunicationSettings;  // Offset: 152 Size: 40
	struct FAkAdvancedInitializationSettingsWithMultiCoreRendering AdvancedSettings;  // Offset: 192 Size: 48



 // Functions 
 public:
	void MigrateMultiCoreRendering(bool NewValue); // Function AkAudio.AkLinuxInitializationSettings.MigrateMultiCoreRendering
}; 
 
 


//Class AkAudio.AkAudioInputComponent Size 1472
// Inherited 1424 bytes 
class UAkAudioInputComponent : public UAkComponent
{

 public: 
	char pad_1424[48];  // Offset: 1424 Size: 48



 // Functions 
 public:
	int32_t PostAssociatedAudioInputEvent(); // Function AkAudio.AkAudioInputComponent.PostAssociatedAudioInputEvent
}; 
 
 


//Class AkAudio.AkAuxBus Size 88
// Inherited 80 bytes 
class UAkAuxBus : public UAkAssetBase
{

 public: 
	struct UAkAudioBank* RequiredBank;  // Offset: 80 Size: 8



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkLinuxPlatformInfo Size 112
// Inherited 112 bytes 
class UAkLinuxPlatformInfo : public UAkPlatformInfo
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkDurationCallbackInfo Size 80
// Inherited 56 bytes 
class UAkDurationCallbackInfo : public UAkEventCallbackInfo
{

 public: 
	float Duration;  // Offset: 56 Size: 4
	float EstimatedDuration;  // Offset: 60 Size: 4
	int32_t AudioNodeID;  // Offset: 64 Size: 4
	int32_t MediaID;  // Offset: 68 Size: 4
	char pad_72_1 : 7;  // Offset: 72 Size: 1
	bool bStreaming : 1;  // Offset: 72 Size: 1
	char pad_73[7];  // Offset: 73 Size: 7



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkCheckBox Size 2872
// Inherited 312 bytes 
class UAkCheckBox : public UContentWidget
{

 public: 
	char pad_312[912];  // Offset: 312 Size: 912
	enum class ECheckBoxState CheckedState;  // Offset: 1224 Size: 1
	char pad_1225[3];  // Offset: 1225 Size: 3
	struct FDelegate CheckedStateDelegate;  // Offset: 1228 Size: 16
	char pad_1244[4];  // Offset: 1244 Size: 4
	struct FCheckBoxStyle WidgetStyle;  // Offset: 1248 Size: 1408
	enum class EHorizontalAlignment HorizontalAlignment;  // Offset: 2656 Size: 1
	char pad_2657_1 : 7;  // Offset: 2657 Size: 1
	bool IsFocusable : 1;  // Offset: 2657 Size: 1
	char pad_2658[6];  // Offset: 2658 Size: 6
	struct FAkBoolPropertyToControl ThePropertyToControl;  // Offset: 2664 Size: 16
	struct FAkWwiseItemToControl ItemToControl;  // Offset: 2680 Size: 64
	struct FMulticastInlineDelegate AkOnCheckStateChanged;  // Offset: 2744 Size: 16
	struct FMulticastInlineDelegate OnItemDropped;  // Offset: 2760 Size: 16
	struct FMulticastInlineDelegate OnPropertyDropped;  // Offset: 2776 Size: 16
	char pad_2792[80];  // Offset: 2792 Size: 80



 // Functions 
 public:
	void SetIsChecked(bool InIsChecked); // Function AkAudio.AkCheckBox.SetIsChecked
	void SetCheckedState(enum class ECheckBoxState InCheckedState); // Function AkAudio.AkCheckBox.SetCheckedState
	void SetAkItemId(struct FGuid& ItemId); // Function AkAudio.AkCheckBox.SetAkItemId
	void SetAkBoolProperty(struct FString ItemProperty); // Function AkAudio.AkCheckBox.SetAkBoolProperty
	bool IsPressed(); // Function AkAudio.AkCheckBox.IsPressed
	bool IsChecked(); // Function AkAudio.AkCheckBox.IsChecked
	enum class ECheckBoxState GetCheckedState(); // Function AkAudio.AkCheckBox.GetCheckedState
	struct FString GetAkProperty(); // Function AkAudio.AkCheckBox.GetAkProperty
	struct FGuid GetAkItemId(); // Function AkAudio.AkCheckBox.GetAkItemId
}; 
 
 


//Class AkAudio.DrawPortalComponent Size 1648
// Inherited 1648 bytes 
class UDrawPortalComponent : public UPrimitiveComponent
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class AkAudio.DrawRoomComponent Size 1648
// Inherited 1648 bytes 
class UDrawRoomComponent : public UPrimitiveComponent
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkGameplayStatics Size 40
// Inherited 40 bytes 
class UAkGameplayStatics : public UBlueprintFunctionLibrary
{

 public: 



 // Functions 
 public:
	void UseReverbVolumes(bool inUseReverbVolumes, struct AActor* Actor); // Function AkAudio.AkGameplayStatics.UseReverbVolumes
	void UseEarlyReflections(struct AActor* Actor, struct UAkAuxBus* AuxBus, int32_t Order, float BusSendGain, float MaxPathLength, bool SpotReflectors, struct FString AuxBusName); // Function AkAudio.AkGameplayStatics.UseEarlyReflections
	void UnloadBankByName(struct FString BankName); // Function AkAudio.AkGameplayStatics.UnloadBankByName
	void UnloadBankAsync(struct UAkAudioBank* Bank, struct FDelegate& BankUnloadedCallback); // Function AkAudio.AkGameplayStatics.UnloadBankAsync
	void UnloadBank(struct UAkAudioBank* Bank, struct FString BankName, struct FLatentActionInfo LatentInfo, struct UObject* WorldContextObject); // Function AkAudio.AkGameplayStatics.UnloadBank
	void StopProfilerCapture(); // Function AkAudio.AkGameplayStatics.StopProfilerCapture
	void StopOutputCapture(); // Function AkAudio.AkGameplayStatics.StopOutputCapture
	void StopAllAmbientSounds(struct UObject* WorldContextObject); // Function AkAudio.AkGameplayStatics.StopAllAmbientSounds
	void StopAll(); // Function AkAudio.AkGameplayStatics.StopAll
	void StopActor(struct AActor* Actor); // Function AkAudio.AkGameplayStatics.StopActor
	void StartProfilerCapture(struct FString Filename); // Function AkAudio.AkGameplayStatics.StartProfilerCapture
	void StartOutputCapture(struct FString Filename); // Function AkAudio.AkGameplayStatics.StartOutputCapture
	void StartAllAmbientSounds(struct UObject* WorldContextObject); // Function AkAudio.AkGameplayStatics.StartAllAmbientSounds
	struct UAkComponent* SpawnAkComponentAtLocation(struct UObject* WorldContextObject, struct UAkAudioEvent* AkEvent, struct FVector Location, struct FRotator Orientation, bool AutoPost, struct FString EventName, bool AutoDestroy); // Function AkAudio.AkGameplayStatics.SpawnAkComponentAtLocation
	void SetSwitch(struct UAkSwitchValue* SwitchValue, struct AActor* Actor, struct FName SwitchGroup, struct FName SwitchState); // Function AkAudio.AkGameplayStatics.SetSwitch
	void SetState(struct UAkStateValue* StateValue, struct FName StateGroup, struct FName State); // Function AkAudio.AkGameplayStatics.SetState
	void SetSpeakerAngles(struct TArray<float>& SpeakerAngles, float HeightAngle, struct FString DeviceShareset); // Function AkAudio.AkGameplayStatics.SetSpeakerAngles
	void SetRTPCValue(struct UAkRtpc* RTPCValue, float Value, int32_t InterpolationTimeMs, struct AActor* Actor, struct FName RTPC); // Function AkAudio.AkGameplayStatics.SetRTPCValue
	void SetReflectionsOrder(int32_t Order, bool RefreshPaths); // Function AkAudio.AkGameplayStatics.SetReflectionsOrder
	void SetPortalToPortalObstruction(struct UAkPortalComponent* PortalComponent0, struct UAkPortalComponent* PortalComponent1, float ObstructionValue); // Function AkAudio.AkGameplayStatics.SetPortalToPortalObstruction
	void SetPortalObstructionAndOcclusion(struct UAkPortalComponent* PortalComponent, float ObstructionValue, float OcclusionValue); // Function AkAudio.AkGameplayStatics.SetPortalObstructionAndOcclusion
	void SetPanningRule(enum class PanningRule PanRule); // Function AkAudio.AkGameplayStatics.SetPanningRule
	void SetOutputBusVolume(float BusVolume, struct AActor* Actor); // Function AkAudio.AkGameplayStatics.SetOutputBusVolume
	void SetOcclusionScalingFactor(float ScalingFactor); // Function AkAudio.AkGameplayStatics.SetOcclusionScalingFactor
	void SetOcclusionRefreshInterval(float RefreshInterval, struct AActor* Actor); // Function AkAudio.AkGameplayStatics.SetOcclusionRefreshInterval
	void SetMultiplePositions(struct UAkComponent* GameObjectAkComponent, struct TArray<struct FTransform> Positions, enum class AkMultiPositionType MultiPositionType); // Function AkAudio.AkGameplayStatics.SetMultiplePositions
	void SetMultipleChannelMaskEmitterPositions(struct UAkComponent* GameObjectAkComponent, struct TArray<struct FAkChannelMask> ChannelMasks, struct TArray<struct FTransform> Positions, enum class AkMultiPositionType MultiPositionType); // Function AkAudio.AkGameplayStatics.SetMultipleChannelMaskEmitterPositions
	void SetMultipleChannelEmitterPositions(struct UAkComponent* GameObjectAkComponent, struct TArray<enum class AkChannelConfiguration> ChannelMasks, struct TArray<struct FTransform> Positions, enum class AkMultiPositionType MultiPositionType); // Function AkAudio.AkGameplayStatics.SetMultipleChannelEmitterPositions
	void SetGameObjectToPortalObstruction(struct UAkComponent* GameObjectAkComponent, struct UAkPortalComponent* PortalComponent, float ObstructionValue); // Function AkAudio.AkGameplayStatics.SetGameObjectToPortalObstruction
	void SetCurrentAudioCultureAsync(struct FString AudioCulture, struct FDelegate& Completed); // Function AkAudio.AkGameplayStatics.SetCurrentAudioCultureAsync
	void SetCurrentAudioCulture(struct FString AudioCulture, struct FLatentActionInfo LatentInfo, struct UObject* WorldContextObject); // Function AkAudio.AkGameplayStatics.SetCurrentAudioCulture
	void SetBusConfig(struct FString BusName, enum class AkChannelConfiguration ChannelConfiguration); // Function AkAudio.AkGameplayStatics.SetBusConfig
	void ResetRTPCValue(struct UAkRtpc* RTPCValue, int32_t InterpolationTimeMs, struct AActor* Actor, struct FName RTPC); // Function AkAudio.AkGameplayStatics.ResetRTPCValue
	void ReplaceMainOutput(struct FAkOutputSettings& MainOutputSettings); // Function AkAudio.AkGameplayStatics.ReplaceMainOutput
	void PostTrigger(struct UAkTrigger* TriggerValue, struct AActor* Actor, struct FName Trigger); // Function AkAudio.AkGameplayStatics.PostTrigger
	void PostEventByName(struct FString EventName, struct AActor* Actor, bool bStopWhenAttachedToDestroyed); // Function AkAudio.AkGameplayStatics.PostEventByName
	int32_t PostEventAttached(struct UAkAudioEvent* AkEvent, struct AActor* Actor, struct FName AttachPointName, bool bStopWhenAttachedToDestroyed, struct FString EventName); // Function AkAudio.AkGameplayStatics.PostEventAttached
	void PostEventAtLocationByName(struct FString EventName, struct FVector Location, struct FRotator Orientation, struct UObject* WorldContextObject); // Function AkAudio.AkGameplayStatics.PostEventAtLocationByName
	int32_t PostEventAtLocation(struct UAkAudioEvent* AkEvent, struct FVector Location, struct FRotator Orientation, struct FString EventName, struct UObject* WorldContextObject); // Function AkAudio.AkGameplayStatics.PostEventAtLocation
	int32_t PostEvent(struct UAkAudioEvent* AkEvent, struct AActor* Actor, int32_t CallbackMask, struct FDelegate& PostEventCallback, struct TArray<struct FAkExternalSourceInfo>& ExternalSources, bool bStopWhenAttachedToDestroyed, struct FString EventName); // Function AkAudio.AkGameplayStatics.PostEvent
	void PostAndWaitForEndOfEventAsync(struct UAkAudioEvent* AkEvent, struct AActor* Actor, int32_t& PlayingID, bool bStopWhenAttachedToDestroyed, struct TArray<struct FAkExternalSourceInfo>& ExternalSources, struct FLatentActionInfo LatentInfo); // Function AkAudio.AkGameplayStatics.PostAndWaitForEndOfEventAsync
	int32_t PostAndWaitForEndOfEvent(struct UAkAudioEvent* AkEvent, struct AActor* Actor, bool bStopWhenAttachedToDestroyed, struct TArray<struct FAkExternalSourceInfo>& ExternalSources, struct FString EventName, struct FLatentActionInfo LatentInfo); // Function AkAudio.AkGameplayStatics.PostAndWaitForEndOfEvent
	void LoadInitBank(); // Function AkAudio.AkGameplayStatics.LoadInitBank
	void LoadBanks(struct TArray<struct UAkAudioBank*>& SoundBanks, bool SynchronizeSoundBanks); // Function AkAudio.AkGameplayStatics.LoadBanks
	void LoadBankByName(struct FString BankName); // Function AkAudio.AkGameplayStatics.LoadBankByName
	void LoadBankAsync(struct UAkAudioBank* Bank, struct FDelegate& BankLoadedCallback); // Function AkAudio.AkGameplayStatics.LoadBankAsync
	void LoadBank(struct UAkAudioBank* Bank, struct FString BankName, struct FLatentActionInfo LatentInfo, struct UObject* WorldContextObject); // Function AkAudio.AkGameplayStatics.LoadBank
	bool IsGame(struct UObject* WorldContextObject); // Function AkAudio.AkGameplayStatics.IsGame
	bool IsEditor(); // Function AkAudio.AkGameplayStatics.IsEditor
	void GetSpeakerAngles(struct TArray<float>& SpeakerAngles, float& HeightAngle, struct FString DeviceShareset); // Function AkAudio.AkGameplayStatics.GetSpeakerAngles
	int32_t GetSourcePlayPosition(int32_t PlayingID); // Function AkAudio.AkGameplayStatics.GetSourcePlayPosition
	void GetRTPCValue(struct UAkRtpc* RTPCValue, int32_t PlayingID, enum class ERTPCValueType InputValueType, float& Value, enum class ERTPCValueType& OutputValueType, struct AActor* Actor, struct FName RTPC); // Function AkAudio.AkGameplayStatics.GetRTPCValue
	float GetOcclusionScalingFactor(); // Function AkAudio.AkGameplayStatics.GetOcclusionScalingFactor
	struct FString GetCurrentAudioCulture(); // Function AkAudio.AkGameplayStatics.GetCurrentAudioCulture
	struct TArray<struct FString> GetAvailableAudioCultures(); // Function AkAudio.AkGameplayStatics.GetAvailableAudioCultures
	struct UObject* GetAkMediaAssetUserData(struct UAkMediaAsset* Instance, UObject* Type); // Function AkAudio.AkGameplayStatics.GetAkMediaAssetUserData
	struct UAkComponent* GetAkComponent(struct USceneComponent* AttachToComponent, bool& ComponentCreated, struct FName AttachPointName, struct FVector Location, enum class EAttachLocation LocationType); // Function AkAudio.AkGameplayStatics.GetAkComponent
	struct UObject* GetAkAudioTypeUserData(struct UAkAudioType* Instance, UObject* Type); // Function AkAudio.AkGameplayStatics.GetAkAudioTypeUserData
	void ExecuteActionOnPlayingID(enum class AkActionOnEventType ActionType, int32_t PlayingID, int32_t TransitionDuration, enum class EAkCurveInterpolation FadeCurve); // Function AkAudio.AkGameplayStatics.ExecuteActionOnPlayingID
	void ExecuteActionOnEvent(struct UAkAudioEvent* AkEvent, enum class AkActionOnEventType ActionType, struct AActor* Actor, int32_t TransitionDuration, enum class EAkCurveInterpolation FadeCurve, int32_t PlayingID); // Function AkAudio.AkGameplayStatics.ExecuteActionOnEvent
	void ClearBanks(); // Function AkAudio.AkGameplayStatics.ClearBanks
	void CancelEventCallback(struct FDelegate& PostEventCallback); // Function AkAudio.AkGameplayStatics.CancelEventCallback
	void AddOutputCaptureMarker(struct FString MarkerText); // Function AkAudio.AkGameplayStatics.AddOutputCaptureMarker
}; 
 
 


//Class AkAudio.AkCallbackInfo Size 48
// Inherited 40 bytes 
class UAkCallbackInfo : public UObject
{

 public: 
	struct UAkComponent* AkComponent;  // Offset: 40 Size: 8



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkEventCallbackInfo Size 56
// Inherited 48 bytes 
class UAkEventCallbackInfo : public UAkCallbackInfo
{

 public: 
	int32_t PlayingID;  // Offset: 48 Size: 4
	int32_t EventID;  // Offset: 52 Size: 4



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkMIDIEventCallbackInfo Size 72
// Inherited 56 bytes 
class UAkMIDIEventCallbackInfo : public UAkEventCallbackInfo
{

 public: 
	char pad_56[16];  // Offset: 56 Size: 16



 // Functions 
 public:
	enum class EAkMidiEventType GetType(); // Function AkAudio.AkMIDIEventCallbackInfo.GetType
	bool GetProgramChange(struct FAkMidiProgramChange& AsProgramChange); // Function AkAudio.AkMIDIEventCallbackInfo.GetProgramChange
	bool GetPitchBend(struct FAkMidiPitchBend& AsPitchBend); // Function AkAudio.AkMIDIEventCallbackInfo.GetPitchBend
	bool GetNoteOn(struct FAkMidiNoteOnOff& AsNoteOn); // Function AkAudio.AkMIDIEventCallbackInfo.GetNoteOn
	bool GetNoteOff(struct FAkMidiNoteOnOff& AsNoteOff); // Function AkAudio.AkMIDIEventCallbackInfo.GetNoteOff
	bool GetNoteAftertouch(struct FAkMidiNoteAftertouch& AsNoteAftertouch); // Function AkAudio.AkMIDIEventCallbackInfo.GetNoteAftertouch
	bool GetGeneric(struct FAkMidiGeneric& AsGeneric); // Function AkAudio.AkMIDIEventCallbackInfo.GetGeneric
	bool GetChannelAftertouch(struct FAkMidiChannelAftertouch& AsChannelAftertouch); // Function AkAudio.AkMIDIEventCallbackInfo.GetChannelAftertouch
	char GetChannel(); // Function AkAudio.AkMIDIEventCallbackInfo.GetChannel
	bool GetCc(struct FAkMidiCc& AsCc); // Function AkAudio.AkMIDIEventCallbackInfo.GetCc
}; 
 
 


//Class AkAudio.AkItemBoolPropertiesConv Size 40
// Inherited 40 bytes 
class UAkItemBoolPropertiesConv : public UBlueprintFunctionLibrary
{

 public: 



 // Functions 
 public:
	struct FText Conv_FAkBoolPropertyToControlToText(struct FAkBoolPropertyToControl& INAkBoolPropertyToControl); // Function AkAudio.AkItemBoolPropertiesConv.Conv_FAkBoolPropertyToControlToText
	struct FString Conv_FAkBoolPropertyToControlToString(struct FAkBoolPropertyToControl& INAkBoolPropertyToControl); // Function AkAudio.AkItemBoolPropertiesConv.Conv_FAkBoolPropertyToControlToString
}; 
 
 


//Class AkAudio.AkMarkerCallbackInfo Size 80
// Inherited 56 bytes 
class UAkMarkerCallbackInfo : public UAkEventCallbackInfo
{

 public: 
	int32_t Identifier;  // Offset: 56 Size: 4
	int32_t Position;  // Offset: 60 Size: 4
	struct FString Label;  // Offset: 64 Size: 16



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkMusicSyncCallbackInfo Size 112
// Inherited 48 bytes 
class UAkMusicSyncCallbackInfo : public UAkCallbackInfo
{

 public: 
	int32_t PlayingID;  // Offset: 48 Size: 4
	struct FAkSegmentInfo SegmentInfo;  // Offset: 52 Size: 36
	enum class EAkCallbackType MusicSyncType;  // Offset: 88 Size: 1
	char pad_89[7];  // Offset: 89 Size: 7
	struct FString UserCueName;  // Offset: 96 Size: 16



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkGeometryComponent Size 1360
// Inherited 960 bytes 
class UAkGeometryComponent : public UAkAcousticTextureSetComponent
{

 public: 
	enum class AkMeshType MeshType;  // Offset: 960 Size: 1
	char pad_961[3];  // Offset: 961 Size: 3
	int32_t LOD;  // Offset: 964 Size: 4
	float WeldingThreshold;  // Offset: 968 Size: 4
	char pad_972[4];  // Offset: 972 Size: 4
	struct TMap<struct UMaterialInterface*, struct FAkGeometrySurfaceOverride> StaticMeshSurfaceOverride;  // Offset: 976 Size: 80
	struct FAkGeometrySurfaceOverride CollisionMeshSurfaceOverride;  // Offset: 1056 Size: 24
	char pad_1080_1 : 7;  // Offset: 1080 Size: 1
	bool bEnableDiffraction : 1;  // Offset: 1080 Size: 1
	char pad_1081_1 : 7;  // Offset: 1081 Size: 1
	bool bEnableDiffractionOnBoundaryEdges : 1;  // Offset: 1081 Size: 1
	char pad_1082[6];  // Offset: 1082 Size: 6
	struct AActor* AssociatedRoom;  // Offset: 1088 Size: 8
	char pad_1096[16];  // Offset: 1096 Size: 16
	struct FAkGeometryData GeometryData;  // Offset: 1112 Size: 80
	struct TMap<int32_t, double> SurfaceAreas;  // Offset: 1192 Size: 80
	char pad_1272[88];  // Offset: 1272 Size: 88



 // Functions 
 public:
	void UpdateGeometry(); // Function AkAudio.AkGeometryComponent.UpdateGeometry
	void SendGeometry(); // Function AkAudio.AkGeometryComponent.SendGeometry
	void RemoveGeometry(); // Function AkAudio.AkGeometryComponent.RemoveGeometry
	void ConvertMesh(); // Function AkAudio.AkGeometryComponent.ConvertMesh
}; 
 
 


//Class AkAudio.AkItemPropertiesConv Size 40
// Inherited 40 bytes 
class UAkItemPropertiesConv : public UBlueprintFunctionLibrary
{

 public: 



 // Functions 
 public:
	struct FText Conv_FAkPropertyToControlToText(struct FAkPropertyToControl& INAkPropertyToControl); // Function AkAudio.AkItemPropertiesConv.Conv_FAkPropertyToControlToText
	struct FString Conv_FAkPropertyToControlToString(struct FAkPropertyToControl& INAkPropertyToControl); // Function AkAudio.AkItemPropertiesConv.Conv_FAkPropertyToControlToString
}; 
 
 


//Class AkAudio.AkGroupValue Size 104
// Inherited 64 bytes 
class UAkGroupValue : public UAkAudioType
{

 public: 
	struct TArray<struct TSoftObjectPtr<UAkMediaAsset>> MediaDependencies;  // Offset: 64 Size: 16
	uint32_t GroupShortID;  // Offset: 80 Size: 4
	char pad_84[20];  // Offset: 84 Size: 20



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkDPXInitializationSettings Size 240
// Inherited 240 bytes 
class UAkDPXInitializationSettings : public UAkPS5InitializationSettings
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkHololensInitializationSettings Size 248
// Inherited 40 bytes 
class UAkHololensInitializationSettings : public UObject
{

 public: 
	char pad_40[8];  // Offset: 40 Size: 8
	struct FAkCommonInitializationSettingsWithSampleRate CommonSettings;  // Offset: 48 Size: 104
	struct FAkCommunicationSettingsWithSystemInitialization CommunicationSettings;  // Offset: 152 Size: 40
	struct FAkHololensAdvancedInitializationSettings AdvancedSettings;  // Offset: 192 Size: 52
	char pad_244[4];  // Offset: 244 Size: 4



 // Functions 
 public:
	void MigrateMultiCoreRendering(bool NewValue); // Function AkAudio.AkHololensInitializationSettings.MigrateMultiCoreRendering
}; 
 
 


//Class AkAudio.AkItemProperties Size 336
// Inherited 272 bytes 
class UAkItemProperties : public UWidget
{

 public: 
	struct FMulticastInlineDelegate OnSelectionChanged;  // Offset: 272 Size: 16
	struct FMulticastInlineDelegate OnPropertyDragged;  // Offset: 288 Size: 16
	char pad_304[32];  // Offset: 304 Size: 32



 // Functions 
 public:
	void SetSearchText(struct FString newText); // Function AkAudio.AkItemProperties.SetSearchText
	struct FString GetSelectedProperty(); // Function AkAudio.AkItemProperties.GetSelectedProperty
	struct FString GetSearchText(); // Function AkAudio.AkItemProperties.GetSearchText
}; 
 
 


//Class AkAudio.AkHololensPlatformInfo Size 112
// Inherited 112 bytes 
class UAkHololensPlatformInfo : public UAkPlatformInfo
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkInitBankAssetData Size 152
// Inherited 136 bytes 
class UAkInitBankAssetData : public UAkAssetDataWithMedia
{

 public: 
	struct TArray<struct FAkPluginInfo> PluginInfos;  // Offset: 136 Size: 16



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkInitBank Size 112
// Inherited 80 bytes 
class UAkInitBank : public UAkAssetBase
{

 public: 
	struct TArray<struct FString> AvailableAudioCultures;  // Offset: 80 Size: 16
	struct FString DefaultLanguage;  // Offset: 96 Size: 16



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkIOSPlatformInfo Size 112
// Inherited 112 bytes 
class UAkIOSPlatformInfo : public UAkPlatformInfo
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkLateReverbComponent Size 1072
// Inherited 944 bytes 
class UAkLateReverbComponent : public USceneComponent
{

 public: 
	char pad_944_1 : 7;  // Offset: 944 Size: 1
	bool bEnable : 1;  // Offset: 936 Size: 1
	float SendLevel;  // Offset: 940 Size: 4
	float FadeRate;  // Offset: 944 Size: 4
	float Priority;  // Offset: 948 Size: 4
	char pad_957_1 : 7;  // Offset: 957 Size: 1
	bool AutoAssignAuxBus : 1;  // Offset: 952 Size: 1
	char pad_958[2];  // Offset: 958 Size: 2
	struct UAkAuxBus* AuxBus;  // Offset: 960 Size: 8
	struct FString AuxBusName;  // Offset: 968 Size: 16
	char pad_984[8];  // Offset: 984 Size: 8
	struct UAkAuxBus* AuxBusManual;  // Offset: 992 Size: 8
	char pad_1000[72];  // Offset: 1000 Size: 72



 // Functions 
 public:
	void AssociateAkTextureSetComponent(struct UAkAcousticTextureSetComponent* textureSetComponent); // Function AkAudio.AkLateReverbComponent.AssociateAkTextureSetComponent
}; 
 
 


//Class AkAudio.AkMacInitializationSettings Size 240
// Inherited 40 bytes 
class UAkMacInitializationSettings : public UObject
{

 public: 
	char pad_40[8];  // Offset: 40 Size: 8
	struct FAkCommonInitializationSettingsWithSampleRate CommonSettings;  // Offset: 48 Size: 104
	struct FAkCommunicationSettingsWithSystemInitialization CommunicationSettings;  // Offset: 152 Size: 40
	struct FAkAdvancedInitializationSettingsWithMultiCoreRendering AdvancedSettings;  // Offset: 192 Size: 48



 // Functions 
 public:
	void MigrateMultiCoreRendering(bool NewValue); // Function AkAudio.AkMacInitializationSettings.MigrateMultiCoreRendering
}; 
 
 


//Class AkAudio.AkMacPlatformInfo Size 112
// Inherited 112 bytes 
class UAkMacPlatformInfo : public UAkPlatformInfo
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkMediaAsset Size 120
// Inherited 40 bytes 
class UAkMediaAsset : public UObject
{

 public: 
	uint32_t ID;  // Offset: 40 Size: 4
	char pad_44[4];  // Offset: 44 Size: 4
	struct FString MediaName;  // Offset: 48 Size: 16
	char pad_64_1 : 7;  // Offset: 64 Size: 1
	bool AutoLoad : 1;  // Offset: 64 Size: 1
	char pad_65[7];  // Offset: 65 Size: 7
	struct TArray<struct UObject*> UserData;  // Offset: 72 Size: 16
	struct FString Language;  // Offset: 88 Size: 16
	struct UAkMediaAssetData* CurrentMediaAssetData;  // Offset: 104 Size: 8
	char pad_112[8];  // Offset: 112 Size: 8



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkLocalizedMediaAsset Size 120
// Inherited 120 bytes 
class UAkLocalizedMediaAsset : public UAkMediaAsset
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkExternalMediaAsset Size 216
// Inherited 120 bytes 
class UAkExternalMediaAsset : public UAkMediaAsset
{

 public: 
	char pad_120[96];  // Offset: 120 Size: 96



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkPlatformInitialisationSettingsBase Size 40
// Inherited 40 bytes 
class UAkPlatformInitialisationSettingsBase : public UInterface
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkSettings Size 736
// Inherited 40 bytes 
class UAkSettings : public UObject
{

 public: 
	char MaxSimultaneousReverbVolumes;  // Offset: 40 Size: 1
	char pad_41[7];  // Offset: 41 Size: 7
	struct FFilePath WwiseProjectPath;  // Offset: 48 Size: 16
	struct FDirectoryPath WwiseSoundDataFolder;  // Offset: 64 Size: 16
	char pad_80_1 : 7;  // Offset: 80 Size: 1
	bool bAutoConnectToWAAPI : 1;  // Offset: 80 Size: 1
	enum class ECollisionChannel DefaultOcclusionCollisionChannel;  // Offset: 81 Size: 1
	enum class ECollisionChannel DefaultFitToGeometryCollisionChannel;  // Offset: 82 Size: 1
	char pad_83[5];  // Offset: 83 Size: 5
	struct TMap<struct TSoftObjectPtr<UPhysicalMaterial>, struct FAkGeometrySurfacePropertiesToMap> AkGeometryMap;  // Offset: 88 Size: 80
	float GlobalDecayAbsorption;  // Offset: 168 Size: 4
	char pad_172[4];  // Offset: 172 Size: 4
	struct TSoftObjectPtr<UAkAuxBus> DefaultReverbAuxBus;  // Offset: 176 Size: 40
	struct TMap<float, struct TSoftObjectPtr<UAkAuxBus>> EnvironmentDecayAuxBusMap;  // Offset: 216 Size: 80
	struct FString HFDampingName;  // Offset: 296 Size: 16
	struct FString DecayEstimateName;  // Offset: 312 Size: 16
	struct FString TimeToFirstReflectionName;  // Offset: 328 Size: 16
	struct TSoftObjectPtr<UAkRtpc> HFDampingRTPC;  // Offset: 344 Size: 40
	struct TSoftObjectPtr<UAkRtpc> DecayEstimateRTPC;  // Offset: 384 Size: 40
	struct TSoftObjectPtr<UAkRtpc> TimeToFirstReflectionRTPC;  // Offset: 424 Size: 40
	struct TSoftObjectPtr<UAkAudioEvent> AudioInputEvent;  // Offset: 464 Size: 40
	struct TMap<struct FGuid, struct FAkAcousticTextureParams> AcousticTextureParamsMap;  // Offset: 504 Size: 80
	char pad_584_1 : 7;  // Offset: 584 Size: 1
	bool SplitSwitchContainerMedia : 1;  // Offset: 584 Size: 1
	char pad_585_1 : 7;  // Offset: 585 Size: 1
	bool SplitMediaPerFolder : 1;  // Offset: 585 Size: 1
	char pad_586_1 : 7;  // Offset: 586 Size: 1
	bool UseEventBasedPackaging : 1;  // Offset: 586 Size: 1
	char pad_587_1 : 7;  // Offset: 587 Size: 1
	bool EnableAutomaticAssetSynchronization : 1;  // Offset: 587 Size: 1
	char pad_588[4];  // Offset: 588 Size: 4
	struct FString CommandletCommitMessage;  // Offset: 592 Size: 16
	struct TMap<struct FString, struct FString> UnrealCultureToWwiseCulture;  // Offset: 608 Size: 80
	char pad_688_1 : 7;  // Offset: 688 Size: 1
	bool AskedToUseNewAssetManagement : 1;  // Offset: 688 Size: 1
	char pad_689_1 : 7;  // Offset: 689 Size: 1
	bool bEnableMultiCoreRendering : 1;  // Offset: 689 Size: 1
	char pad_690_1 : 7;  // Offset: 690 Size: 1
	bool MigratedEnableMultiCoreRendering : 1;  // Offset: 690 Size: 1
	char pad_691_1 : 7;  // Offset: 691 Size: 1
	bool FixupRedirectorsDuringMigration : 1;  // Offset: 691 Size: 1
	char pad_692[4];  // Offset: 692 Size: 4
	struct FDirectoryPath WwiseWindowsInstallationPath;  // Offset: 696 Size: 16
	struct FFilePath WwiseMacInstallationPath;  // Offset: 712 Size: 16
	char pad_728[8];  // Offset: 728 Size: 8



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkWinAnvilPlatformInfo Size 112
// Inherited 112 bytes 
class UAkWinAnvilPlatformInfo : public UAkWinGDKPlatformInfo
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkReverbVolume Size 856
// Inherited 800 bytes 
class AAkReverbVolume : public AVolume
{

 public: 
	char pad_800_1 : 7;  // Offset: 800 Size: 1
	bool bEnabled : 1;  // Offset: 800 Size: 1
	char pad_801[7];  // Offset: 801 Size: 7
	struct UAkAuxBus* AuxBus;  // Offset: 808 Size: 8
	struct FString AuxBusName;  // Offset: 816 Size: 16
	float SendLevel;  // Offset: 832 Size: 4
	float FadeRate;  // Offset: 836 Size: 4
	float Priority;  // Offset: 840 Size: 4
	char pad_844[4];  // Offset: 844 Size: 4
	struct UAkLateReverbComponent* LateReverbComponent;  // Offset: 848 Size: 8



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkSettingsPerUser Size 128
// Inherited 40 bytes 
class UAkSettingsPerUser : public UObject
{

 public: 
	struct FDirectoryPath WwiseWindowsInstallationPath;  // Offset: 40 Size: 16
	struct FFilePath WwiseMacInstallationPath;  // Offset: 56 Size: 16
	char pad_72_1 : 7;  // Offset: 72 Size: 1
	bool EnableAutomaticAssetSynchronization : 1;  // Offset: 72 Size: 1
	char pad_73[7];  // Offset: 73 Size: 7
	struct FString WaapiIPAddress;  // Offset: 80 Size: 16
	uint32_t WaapiPort;  // Offset: 96 Size: 4
	char pad_100_1 : 7;  // Offset: 100 Size: 1
	bool bAutoConnectToWAAPI : 1;  // Offset: 100 Size: 1
	char pad_101_1 : 7;  // Offset: 101 Size: 1
	bool AutoSyncSelection : 1;  // Offset: 101 Size: 1
	char pad_102_1 : 7;  // Offset: 102 Size: 1
	bool SuppressWwiseProjectPathWarnings : 1;  // Offset: 102 Size: 1
	char pad_103_1 : 7;  // Offset: 103 Size: 1
	bool SoundDataGenerationSkipLanguage : 1;  // Offset: 103 Size: 1
	char pad_104[24];  // Offset: 104 Size: 24



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkSlider Size 1744
// Inherited 272 bytes 
class UAkSlider : public UWidget
{

 public: 
	float Value;  // Offset: 272 Size: 4
	struct FDelegate ValueDelegate;  // Offset: 276 Size: 16
	char pad_292[4];  // Offset: 292 Size: 4
	struct FSliderStyle WidgetStyle;  // Offset: 296 Size: 1240
	enum class EOrientation Orientation;  // Offset: 1536 Size: 1
	char pad_1537[3];  // Offset: 1537 Size: 3
	struct FLinearColor SliderBarColor;  // Offset: 1540 Size: 16
	struct FLinearColor SliderHandleColor;  // Offset: 1556 Size: 16
	char pad_1572_1 : 7;  // Offset: 1572 Size: 1
	bool IndentHandle : 1;  // Offset: 1572 Size: 1
	char pad_1573_1 : 7;  // Offset: 1573 Size: 1
	bool Locked : 1;  // Offset: 1573 Size: 1
	char pad_1574[2];  // Offset: 1574 Size: 2
	float StepSize;  // Offset: 1576 Size: 4
	char pad_1580_1 : 7;  // Offset: 1580 Size: 1
	bool IsFocusable : 1;  // Offset: 1580 Size: 1
	char pad_1581[3];  // Offset: 1581 Size: 3
	struct FAkPropertyToControl ThePropertyToControl;  // Offset: 1584 Size: 16
	struct FAkWwiseItemToControl ItemToControl;  // Offset: 1600 Size: 64
	struct FMulticastInlineDelegate OnValueChanged;  // Offset: 1664 Size: 16
	struct FMulticastInlineDelegate OnItemDropped;  // Offset: 1680 Size: 16
	struct FMulticastInlineDelegate OnPropertyDropped;  // Offset: 1696 Size: 16
	char pad_1712[32];  // Offset: 1712 Size: 32



 // Functions 
 public:
	void SetValue(float InValue); // Function AkAudio.AkSlider.SetValue
	void SetStepSize(float InValue); // Function AkAudio.AkSlider.SetStepSize
	void SetSliderHandleColor(struct FLinearColor InValue); // Function AkAudio.AkSlider.SetSliderHandleColor
	void SetSliderBarColor(struct FLinearColor InValue); // Function AkAudio.AkSlider.SetSliderBarColor
	void SetLocked(bool InValue); // Function AkAudio.AkSlider.SetLocked
	void SetIndentHandle(bool InValue); // Function AkAudio.AkSlider.SetIndentHandle
	void SetAkSliderItemProperty(struct FString ItemProperty); // Function AkAudio.AkSlider.SetAkSliderItemProperty
	void SetAkSliderItemId(struct FGuid& ItemId); // Function AkAudio.AkSlider.SetAkSliderItemId
	float GetValue(); // Function AkAudio.AkSlider.GetValue
	struct FString GetAkSliderItemProperty(); // Function AkAudio.AkSlider.GetAkSliderItemProperty
	struct FGuid GetAkSliderItemId(); // Function AkAudio.AkSlider.GetAkSliderItemId
}; 
 
 


//Class AkAudio.AkSpatialAudioVolume Size 824
// Inherited 800 bytes 
class AAkSpatialAudioVolume : public AVolume
{

 public: 
	struct UAkSurfaceReflectorSetComponent* SurfaceReflectorSet;  // Offset: 800 Size: 8
	struct UAkLateReverbComponent* LateReverb;  // Offset: 808 Size: 8
	struct UAkRoomComponent* Room;  // Offset: 816 Size: 8



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkSpotReflector Size 784
// Inherited 744 bytes 
class AAkSpotReflector : public AActor
{

 public: 
	struct UAkAuxBus* EarlyReflectionAuxBus;  // Offset: 744 Size: 8
	struct FString EarlyReflectionAuxBusName;  // Offset: 752 Size: 16
	struct UAkAcousticTexture* AcousticTexture;  // Offset: 768 Size: 8
	float DistanceScalingFactor;  // Offset: 776 Size: 4
	float Level;  // Offset: 780 Size: 4



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkStateValue Size 104
// Inherited 104 bytes 
class UAkStateValue : public UAkGroupValue
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkSubmixInputComponent Size 1568
// Inherited 1472 bytes 
class UAkSubmixInputComponent : public UAkAudioInputComponent
{

 public: 
	char pad_1472[8];  // Offset: 1472 Size: 8
	struct USoundSubmix* SubmixToRecord;  // Offset: 1480 Size: 8
	char pad_1488[80];  // Offset: 1488 Size: 80



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkSurfaceReflectorSetComponent Size 1008
// Inherited 960 bytes 
class UAkSurfaceReflectorSetComponent : public UAkAcousticTextureSetComponent
{

 public: 
	char pad_960_1 : 7;  // Offset: 960 Size: 1
	bool bEnableSurfaceReflectors : 1;  // Offset: 960 Size: 1
	char pad_961[7];  // Offset: 961 Size: 7
	struct TArray<struct FAkSurfacePoly> AcousticPolys;  // Offset: 968 Size: 16
	char pad_984_1 : 7;  // Offset: 984 Size: 1
	bool bEnableDiffraction : 1;  // Offset: 984 Size: 1
	char pad_985_1 : 7;  // Offset: 985 Size: 1
	bool bEnableDiffractionOnBoundaryEdges : 1;  // Offset: 985 Size: 1
	char pad_986[6];  // Offset: 986 Size: 6
	struct AActor* AssociatedRoom;  // Offset: 992 Size: 8
	char pad_1000[8];  // Offset: 1000 Size: 8



 // Functions 
 public:
	void UpdateSurfaceReflectorSet(); // Function AkAudio.AkSurfaceReflectorSetComponent.UpdateSurfaceReflectorSet
	void SendSurfaceReflectorSet(); // Function AkAudio.AkSurfaceReflectorSetComponent.SendSurfaceReflectorSet
	void RemoveSurfaceReflectorSet(); // Function AkAudio.AkSurfaceReflectorSetComponent.RemoveSurfaceReflectorSet
}; 
 
 


//Class AkAudio.AkSwitchInitializationSettings Size 240
// Inherited 40 bytes 
class UAkSwitchInitializationSettings : public UObject
{

 public: 
	char pad_40[8];  // Offset: 40 Size: 8
	struct FAkCommonInitializationSettingsWithSampleRate CommonSettings;  // Offset: 48 Size: 104
	struct FAkCommunicationSettingsWithCommSelection CommunicationSettings;  // Offset: 152 Size: 40
	struct FAkAdvancedInitializationSettingsWithMultiCoreRendering AdvancedSettings;  // Offset: 192 Size: 48



 // Functions 
 public:
	void MigrateMultiCoreRendering(bool NewValue); // Function AkAudio.AkSwitchInitializationSettings.MigrateMultiCoreRendering
}; 
 
 


//Class AkAudio.AkSwitchPlatformInfo Size 112
// Inherited 112 bytes 
class UAkSwitchPlatformInfo : public UAkPlatformInfo
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkSwitchValue Size 104
// Inherited 104 bytes 
class UAkSwitchValue : public UAkGroupValue
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkTrigger Size 64
// Inherited 64 bytes 
class UAkTrigger : public UAkAudioType
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkTVOSInitializationSettings Size 256
// Inherited 40 bytes 
class UAkTVOSInitializationSettings : public UObject
{

 public: 
	char pad_40[8];  // Offset: 40 Size: 8
	struct FAkCommonInitializationSettingsWithSampleRate CommonSettings;  // Offset: 48 Size: 104
	struct FAkAudioSession AudioSession;  // Offset: 152 Size: 12
	char pad_164[4];  // Offset: 164 Size: 4
	struct FAkCommunicationSettingsWithSystemInitialization CommunicationSettings;  // Offset: 168 Size: 40
	struct FAkAdvancedInitializationSettings AdvancedSettings;  // Offset: 208 Size: 44
	char pad_252[4];  // Offset: 252 Size: 4



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkXboxOneAnvilPlatformInfo Size 112
// Inherited 112 bytes 
class UAkXboxOneAnvilPlatformInfo : public UAkXboxOneGDKPlatformInfo
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkTVOSPlatformInfo Size 112
// Inherited 112 bytes 
class UAkTVOSPlatformInfo : public UAkPlatformInfo
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkWaapiCalls Size 40
// Inherited 40 bytes 
class UAkWaapiCalls : public UBlueprintFunctionLibrary
{

 public: 



 // Functions 
 public:
	struct FAKWaapiJsonObject Unsubscribe(struct FAkWaapiSubscriptionId& SubscriptionId, bool& UnsubscriptionDone); // Function AkAudio.AkWaapiCalls.Unsubscribe
	struct FAKWaapiJsonObject SubscribeToWaapi(struct FAkWaapiUri& WaapiUri, struct FAKWaapiJsonObject& WaapiOptions, struct FDelegate& Callback, struct FAkWaapiSubscriptionId& SubscriptionId, bool& SubscriptionDone); // Function AkAudio.AkWaapiCalls.SubscribeToWaapi
	void SetSubscriptionID(struct FAkWaapiSubscriptionId& Subscription, int32_t ID); // Function AkAudio.AkWaapiCalls.SetSubscriptionID
	bool RegisterWaapiProjectLoadedCallback(struct FDelegate& Callback); // Function AkAudio.AkWaapiCalls.RegisterWaapiProjectLoadedCallback
	bool RegisterWaapiConnectionLostCallback(struct FDelegate& Callback); // Function AkAudio.AkWaapiCalls.RegisterWaapiConnectionLostCallback
	int32_t GetSubscriptionID(struct FAkWaapiSubscriptionId& Subscription); // Function AkAudio.AkWaapiCalls.GetSubscriptionID
	struct FText Conv_FAkWaapiSubscriptionIdToText(struct FAkWaapiSubscriptionId& INAkWaapiSubscriptionId); // Function AkAudio.AkWaapiCalls.Conv_FAkWaapiSubscriptionIdToText
	struct FString Conv_FAkWaapiSubscriptionIdToString(struct FAkWaapiSubscriptionId& INAkWaapiSubscriptionId); // Function AkAudio.AkWaapiCalls.Conv_FAkWaapiSubscriptionIdToString
	struct FAKWaapiJsonObject CallWaapi(struct FAkWaapiUri& WaapiUri, struct FAKWaapiJsonObject& WaapiArgs, struct FAKWaapiJsonObject& WaapiOptions); // Function AkAudio.AkWaapiCalls.CallWaapi
}; 
 
 


//Class AkAudio.SAkWaapiFieldNamesConv Size 40
// Inherited 40 bytes 
class USAkWaapiFieldNamesConv : public UBlueprintFunctionLibrary
{

 public: 



 // Functions 
 public:
	struct FText Conv_FAkWaapiFieldNamesToText(struct FAkWaapiFieldNames& INAkWaapiFieldNames); // Function AkAudio.SAkWaapiFieldNamesConv.Conv_FAkWaapiFieldNamesToText
	struct FString Conv_FAkWaapiFieldNamesToString(struct FAkWaapiFieldNames& INAkWaapiFieldNames); // Function AkAudio.SAkWaapiFieldNamesConv.Conv_FAkWaapiFieldNamesToString
}; 
 
 


//Class AkAudio.AkWaapiJsonManager Size 40
// Inherited 40 bytes 
class UAkWaapiJsonManager : public UBlueprintFunctionLibrary
{

 public: 



 // Functions 
 public:
	struct FAKWaapiJsonObject SetStringField(struct FAkWaapiFieldNames& FieldName, struct FString FieldValue, struct FAKWaapiJsonObject Target); // Function AkAudio.AkWaapiJsonManager.SetStringField
	struct FAKWaapiJsonObject SetObjectField(struct FAkWaapiFieldNames& FieldName, struct FAKWaapiJsonObject FieldValue, struct FAKWaapiJsonObject Target); // Function AkAudio.AkWaapiJsonManager.SetObjectField
	struct FAKWaapiJsonObject SetNumberField(struct FAkWaapiFieldNames& FieldName, float FieldValue, struct FAKWaapiJsonObject Target); // Function AkAudio.AkWaapiJsonManager.SetNumberField
	struct FAKWaapiJsonObject SetBoolField(struct FAkWaapiFieldNames& FieldName, bool FieldValue, struct FAKWaapiJsonObject Target); // Function AkAudio.AkWaapiJsonManager.SetBoolField
	struct FAKWaapiJsonObject SetArrayStringFields(struct FAkWaapiFieldNames& FieldName, struct TArray<struct FString>& FieldStringValues, struct FAKWaapiJsonObject Target); // Function AkAudio.AkWaapiJsonManager.SetArrayStringFields
	struct FAKWaapiJsonObject SetArrayObjectFields(struct FAkWaapiFieldNames& FieldName, struct TArray<struct FAKWaapiJsonObject>& FieldObjectValues, struct FAKWaapiJsonObject Target); // Function AkAudio.AkWaapiJsonManager.SetArrayObjectFields
	struct FString GetStringField(struct FAkWaapiFieldNames& FieldName, struct FAKWaapiJsonObject Target); // Function AkAudio.AkWaapiJsonManager.GetStringField
	struct FAKWaapiJsonObject GetObjectField(struct FAkWaapiFieldNames& FieldName, struct FAKWaapiJsonObject Target); // Function AkAudio.AkWaapiJsonManager.GetObjectField
	float GetNumberField(struct FAkWaapiFieldNames& FieldName, struct FAKWaapiJsonObject Target); // Function AkAudio.AkWaapiJsonManager.GetNumberField
	int32_t GetIntegerField(struct FAkWaapiFieldNames& FieldName, struct FAKWaapiJsonObject Target); // Function AkAudio.AkWaapiJsonManager.GetIntegerField
	bool GetBoolField(struct FAkWaapiFieldNames& FieldName, struct FAKWaapiJsonObject Target); // Function AkAudio.AkWaapiJsonManager.GetBoolField
	struct TArray<struct FAKWaapiJsonObject> GetArrayField(struct FAkWaapiFieldNames& FieldName, struct FAKWaapiJsonObject Target); // Function AkAudio.AkWaapiJsonManager.GetArrayField
	struct FText Conv_FAKWaapiJsonObjectToText(struct FAKWaapiJsonObject INAKWaapiJsonObject); // Function AkAudio.AkWaapiJsonManager.Conv_FAKWaapiJsonObjectToText
	struct FString Conv_FAKWaapiJsonObjectToString(struct FAKWaapiJsonObject INAKWaapiJsonObject); // Function AkAudio.AkWaapiJsonManager.Conv_FAKWaapiJsonObjectToString
}; 
 
 


//Class AkAudio.AkWaapiUriConv Size 40
// Inherited 40 bytes 
class UAkWaapiUriConv : public UBlueprintFunctionLibrary
{

 public: 



 // Functions 
 public:
	struct FText Conv_FAkWaapiUriToText(struct FAkWaapiUri& INAkWaapiUri); // Function AkAudio.AkWaapiUriConv.Conv_FAkWaapiUriToText
	struct FString Conv_FAkWaapiUriToString(struct FAkWaapiUri& INAkWaapiUri); // Function AkAudio.AkWaapiUriConv.Conv_FAkWaapiUriToString
}; 
 
 


//Class AkAudio.AkWwiseTree Size 336
// Inherited 272 bytes 
class UAkWwiseTree : public UWidget
{

 public: 
	struct FMulticastInlineDelegate OnSelectionChanged;  // Offset: 272 Size: 16
	struct FMulticastInlineDelegate OnItemDragged;  // Offset: 288 Size: 16
	char pad_304[32];  // Offset: 304 Size: 32



 // Functions 
 public:
	void SetSearchText(struct FString newText); // Function AkAudio.AkWwiseTree.SetSearchText
	struct FAkWwiseObjectDetails GetSelectedItem(); // Function AkAudio.AkWwiseTree.GetSelectedItem
	struct FString GetSearchText(); // Function AkAudio.AkWwiseTree.GetSearchText
}; 
 
 


//Class AkAudio.AkWindowsInitializationSettings Size 248
// Inherited 40 bytes 
class UAkWindowsInitializationSettings : public UObject
{

 public: 
	char pad_40[8];  // Offset: 40 Size: 8
	struct FAkCommonInitializationSettingsWithSampleRate CommonSettings;  // Offset: 48 Size: 104
	struct FAkCommunicationSettingsWithSystemInitialization CommunicationSettings;  // Offset: 152 Size: 40
	struct FAkWindowsAdvancedInitializationSettings AdvancedSettings;  // Offset: 192 Size: 56



 // Functions 
 public:
	void MigrateMultiCoreRendering(bool NewValue); // Function AkAudio.AkWindowsInitializationSettings.MigrateMultiCoreRendering
}; 
 
 


//Class AkAudio.AkWin32PlatformInfo Size 112
// Inherited 112 bytes 
class UAkWin32PlatformInfo : public UAkPlatformInfo
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkWin64PlatformInfo Size 112
// Inherited 112 bytes 
class UAkWin64PlatformInfo : public UAkPlatformInfo
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkWindowsPlatformInfo Size 112
// Inherited 112 bytes 
class UAkWindowsPlatformInfo : public UAkWin64PlatformInfo
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkWinGDKInitializationSettings Size 248
// Inherited 40 bytes 
class UAkWinGDKInitializationSettings : public UObject
{

 public: 
	char pad_40[8];  // Offset: 40 Size: 8
	struct FAkCommonInitializationSettingsWithSampleRate CommonSettings;  // Offset: 48 Size: 104
	struct FAkCommunicationSettingsWithSystemInitialization CommunicationSettings;  // Offset: 152 Size: 40
	struct FAkWinGDKAdvancedInitializationSettings AdvancedSettings;  // Offset: 192 Size: 52
	char pad_244[4];  // Offset: 244 Size: 4



 // Functions 
 public:
	void MigrateMultiCoreRendering(bool NewValue); // Function AkAudio.AkWinGDKInitializationSettings.MigrateMultiCoreRendering
}; 
 
 


//Class AkAudio.AkWinAnvilInitializationSettings Size 248
// Inherited 248 bytes 
class UAkWinAnvilInitializationSettings : public UAkWinGDKInitializationSettings
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkWinGDKPlatformInfo Size 112
// Inherited 112 bytes 
class UAkWinGDKPlatformInfo : public UAkPlatformInfo
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkWwiseTreeSelector Size 368
// Inherited 272 bytes 
class UAkWwiseTreeSelector : public UWidget
{

 public: 
	struct FMulticastInlineDelegate OnSelectionChanged;  // Offset: 272 Size: 16
	struct FMulticastInlineDelegate OnItemDragged;  // Offset: 288 Size: 16
	char pad_304[64];  // Offset: 304 Size: 64



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkXboxOneGDKInitializationSettings Size 248
// Inherited 40 bytes 
class UAkXboxOneGDKInitializationSettings : public UObject
{

 public: 
	char pad_40[8];  // Offset: 40 Size: 8
	struct FAkCommonInitializationSettings CommonSettings;  // Offset: 48 Size: 96
	struct FAkXboxOneGDKApuHeapInitializationSettings ApuHeapSettings;  // Offset: 144 Size: 8
	struct FAkCommunicationSettingsWithSystemInitialization CommunicationSettings;  // Offset: 152 Size: 40
	struct FAkXboxOneGDKAdvancedInitializationSettings AdvancedSettings;  // Offset: 192 Size: 52
	char pad_244[4];  // Offset: 244 Size: 4



 // Functions 
 public:
	void MigrateMultiCoreRendering(bool NewValue); // Function AkAudio.AkXboxOneGDKInitializationSettings.MigrateMultiCoreRendering
}; 
 
 


//Class AkAudio.AkXB1InitializationSettings Size 248
// Inherited 248 bytes 
class UAkXB1InitializationSettings : public UAkXboxOneGDKInitializationSettings
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkXboxOneGDKPlatformInfo Size 112
// Inherited 112 bytes 
class UAkXboxOneGDKPlatformInfo : public UAkPlatformInfo
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkXB1PlatformInfo Size 112
// Inherited 112 bytes 
class UAkXB1PlatformInfo : public UAkXboxOneGDKPlatformInfo
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkXboxOneInitializationSettings Size 248
// Inherited 40 bytes 
class UAkXboxOneInitializationSettings : public UObject
{

 public: 
	char pad_40[8];  // Offset: 40 Size: 8
	struct FAkCommonInitializationSettings CommonSettings;  // Offset: 48 Size: 96
	struct FAkXboxOneApuHeapInitializationSettings ApuHeapSettings;  // Offset: 144 Size: 8
	struct FAkCommunicationSettingsWithSystemInitialization CommunicationSettings;  // Offset: 152 Size: 40
	struct FAkXboxOneAdvancedInitializationSettings AdvancedSettings;  // Offset: 192 Size: 52
	char pad_244[4];  // Offset: 244 Size: 4



 // Functions 
 public:
	void MigrateMultiCoreRendering(bool NewValue); // Function AkAudio.AkXboxOneInitializationSettings.MigrateMultiCoreRendering
}; 
 
 


//Class AkAudio.AkXboxOnePlatformInfo Size 112
// Inherited 112 bytes 
class UAkXboxOnePlatformInfo : public UAkPlatformInfo
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkXSXInitializationSettings Size 256
// Inherited 40 bytes 
class UAkXSXInitializationSettings : public UObject
{

 public: 
	char pad_40[8];  // Offset: 40 Size: 8
	struct FAkCommonInitializationSettings CommonSettings;  // Offset: 48 Size: 96
	struct FAkXSXApuHeapInitializationSettings ApuHeapSettings;  // Offset: 144 Size: 8
	struct FAkCommunicationSettingsWithSystemInitialization CommunicationSettings;  // Offset: 152 Size: 40
	struct FAkXSXAdvancedInitializationSettings AdvancedSettings;  // Offset: 192 Size: 60
	char pad_252[4];  // Offset: 252 Size: 4



 // Functions 
 public:
	void MigrateMultiCoreRendering(bool NewValue); // Function AkAudio.AkXSXInitializationSettings.MigrateMultiCoreRendering
}; 
 
 


//Class AkAudio.AkMPXInitializationSettings Size 256
// Inherited 256 bytes 
class UAkMPXInitializationSettings : public UAkXSXInitializationSettings
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkXSXPlatformInfo Size 112
// Inherited 112 bytes 
class UAkXSXPlatformInfo : public UAkPlatformInfo
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class AkAudio.AkXboxSeriesXPlatformInfo Size 112
// Inherited 112 bytes 
class UAkXboxSeriesXPlatformInfo : public UAkXSXPlatformInfo
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class AkAudio.MovieSceneAkAudioEventSection Size 456
// Inherited 224 bytes 
class UMovieSceneAkAudioEventSection : public UMovieSceneSection
{

 public: 
	char pad_224[64];  // Offset: 224 Size: 64
	struct UAkAudioEvent* Event;  // Offset: 288 Size: 8
	char pad_296_1 : 7;  // Offset: 296 Size: 1
	bool RetriggerEvent : 1;  // Offset: 296 Size: 1
	char pad_297[3];  // Offset: 297 Size: 3
	int32_t ScrubTailLengthMs;  // Offset: 300 Size: 4
	char pad_304_1 : 7;  // Offset: 304 Size: 1
	bool StopAtSectionEnd : 1;  // Offset: 304 Size: 1
	char pad_305[7];  // Offset: 305 Size: 7
	struct FString EventName;  // Offset: 312 Size: 16
	char pad_328[32];  // Offset: 328 Size: 32
	float MaxSourceDuration;  // Offset: 360 Size: 4
	char pad_364[4];  // Offset: 364 Size: 4
	struct FString MaxDurationSourceID;  // Offset: 368 Size: 16
	char pad_384[72];  // Offset: 384 Size: 72



 // Functions 
 public:
}; 
 
 


//Class AkAudio.MovieSceneAkTrack Size 112
// Inherited 88 bytes 
class UMovieSceneAkTrack : public UMovieSceneTrack
{

 public: 
	struct TArray<struct UMovieSceneSection*> Sections;  // Offset: 88 Size: 16
	char pad_104_1 : 7;  // Offset: 104 Size: 1
	bool bIsAMasterTrack : 1;  // Offset: 104 Size: 1
	char pad_105[7];  // Offset: 105 Size: 7



 // Functions 
 public:
}; 
 
 


//Class AkAudio.MovieSceneAkAudioEventTrack Size 112
// Inherited 112 bytes 
class UMovieSceneAkAudioEventTrack : public UMovieSceneAkTrack
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class AkAudio.MovieSceneAkAudioRTPCSection Size 584
// Inherited 224 bytes 
class UMovieSceneAkAudioRTPCSection : public UMovieSceneSection
{

 public: 
	struct UAkRtpc* RTPC;  // Offset: 224 Size: 8
	struct FString Name;  // Offset: 232 Size: 16
	struct FRichCurve FloatCurve;  // Offset: 248 Size: 128
	struct FMovieSceneFloatChannelSerializationHelper FloatChannelSerializationHelper;  // Offset: 376 Size: 48
	struct FMovieSceneFloatChannel RTPCChannel;  // Offset: 424 Size: 160



 // Functions 
 public:
}; 
 
 


//Class AkAudio.MovieSceneAkAudioRTPCTrack Size 112
// Inherited 112 bytes 
class UMovieSceneAkAudioRTPCTrack : public UMovieSceneAkTrack
{

 public: 



 // Functions 
 public:
}; 
 
 


//Class AkAudio.PostEventAsync Size 160
// Inherited 48 bytes 
class UPostEventAsync : public UBlueprintAsyncActionBase
{

 public: 
	struct FMulticastInlineDelegate Completed;  // Offset: 48 Size: 16
	char pad_64[96];  // Offset: 64 Size: 96



 // Functions 
 public:
	struct UPostEventAsync* PostEventAsync(struct UObject* WorldContextObject, struct UAkAudioEvent* AkEvent, struct AActor* Actor, int32_t CallbackMask, struct FDelegate& PostEventCallback, struct TArray<struct FAkExternalSourceInfo>& ExternalSources, bool bStopWhenAttachedToDestroyed); // Function AkAudio.PostEventAsync.PostEventAsync
	void PollPostEventFuture(); // Function AkAudio.PostEventAsync.PollPostEventFuture
}; 
 
 


//Class AkAudio.PostEventAtLocationAsync Size 128
// Inherited 48 bytes 
class UPostEventAtLocationAsync : public UBlueprintAsyncActionBase
{

 public: 
	struct FMulticastInlineDelegate Completed;  // Offset: 48 Size: 16
	char pad_64[64];  // Offset: 64 Size: 64



 // Functions 
 public:
	struct UPostEventAtLocationAsync* PostEventAtLocationAsync(struct UObject* WorldContextObject, struct UAkAudioEvent* AkEvent, struct FVector Location, struct FRotator Orientation); // Function AkAudio.PostEventAtLocationAsync.PostEventAtLocationAsync
	void PollPostEventFuture(); // Function AkAudio.PostEventAtLocationAsync.PollPostEventFuture
}; 
 
 


