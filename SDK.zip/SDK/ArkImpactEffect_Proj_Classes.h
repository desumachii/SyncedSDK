#pragma once 
#include <ArkImpactEffect_Proj_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkImpactEffect_Proj.ArkImpactEffect_Proj_C Size 504
// Inherited 504 bytes 
class UArkImpactEffect_Proj_C : public UArkImpactEffect_Proj_Common_C
{

 public: 



 // Functions 
 public:
}; 
 
 


