#pragma once 
#include <SDK_Engine_Objects.h> 
 
 
//ScriptStruct AnimationBudgetAllocator.AnimationBudgetAllocatorParameters Size 80
class FAnimationBudgetAllocatorParameters
{

 public: 
	float BudgetInMs;  // Offset: 0 Size: 4
	float MinQuality;  // Offset: 4 Size: 4
	int32_t MaxTickRate;  // Offset: 8 Size: 4
	float WorkUnitSmoothingSpeed;  // Offset: 12 Size: 4
	float AlwaysTickFalloffAggression;  // Offset: 16 Size: 4
	float InterpolationFalloffAggression;  // Offset: 20 Size: 4
	int32_t InterpolationMaxRate;  // Offset: 24 Size: 4
	int32_t MaxInterpolatedComponents;  // Offset: 28 Size: 4
	float InterpolationTickMultiplier;  // Offset: 32 Size: 4
	float InitialEstimatedWorkUnitTimeMs;  // Offset: 36 Size: 4
	int32_t MaxTickedOffsreenComponents;  // Offset: 40 Size: 4
	int32_t StateChangeThrottleInFrames;  // Offset: 44 Size: 4
	float BudgetFactorBeforeReducedWork;  // Offset: 48 Size: 4
	float BudgetFactorBeforeReducedWorkEpsilon;  // Offset: 52 Size: 4
	float BudgetPressureSmoothingSpeed;  // Offset: 56 Size: 4
	int32_t ReducedWorkThrottleMinInFrames;  // Offset: 60 Size: 4
	int32_t ReducedWorkThrottleMaxInFrames;  // Offset: 64 Size: 4
	float BudgetFactorBeforeAggressiveReducedWork;  // Offset: 68 Size: 4
	int32_t ReducedWorkThrottleMaxPerFrame;  // Offset: 72 Size: 4
	float BudgetPressureBeforeEmergencyReducedWork;  // Offset: 76 Size: 4



 // Functions 
 public:
}; 
 
 //Function AnimationBudgetAllocator.SkeletalMeshComponentBudgeted.SetAutoRegisterWithBudgetAllocator Size 1
class FSetAutoRegisterWithBudgetAllocator
{

 public: 
	char pad_0_1 : 7;  // Offset: 0 Size: 1
	bool bInAutoRegisterWithBudgetAllocator : 1;  // Offset: 0 Size: 1



 // Functions 
 public:
}; 
 
 //Function AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary.EnableAnimationBudget Size 16
class FEnableAnimationBudget
{

 public: 
	struct UObject* WorldContextObject;  // Offset: 0 Size: 8
	char pad_8_1 : 7;  // Offset: 8 Size: 1
	bool bEnabled : 1;  // Offset: 8 Size: 1
	char pad_9[7];  // Offset: 9 Size: 7



 // Functions 
 public:
}; 
 
 //Function AnimationBudgetAllocator.AnimationBudgetBlueprintLibrary.SetAnimationBudgetParameters Size 88
class FSetAnimationBudgetParameters
{

 public: 
	struct UObject* WorldContextObject;  // Offset: 0 Size: 8
	struct FAnimationBudgetAllocatorParameters InParameters;  // Offset: 8 Size: 80



 // Functions 
 public:
}; 
 
 