#pragma once 
#include <ArkImpactEffect_HandAxe_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkImpactEffect_HandAxe.ArkImpactEffect_HandAxe_C Size 504
// Inherited 504 bytes 
class UArkImpactEffect_HandAxe_C : public UArkImpactEffect_RangeWeapon_C
{

 public: 



 // Functions 
 public:
}; 
 
 


