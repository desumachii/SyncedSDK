#pragma once 
#include <ArkGABuff_Rebate_Pve_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkGABuff_Rebate_Pve.ArkGABuff_Rebate_Pve_C Size 1240
// Inherited 1240 bytes 
class UArkGABuff_Rebate_Pve_C : public UArkAIGABuff_Feedback
{

 public: 



 // Functions 
 public:
}; 
 
 


