#pragma once 
#include <ArkLaserChainBullet_GT_LV1_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkLaserChainBullet_GT_LV1.ArkLaserChainBullet_GT_LV1_C Size 2344
// Inherited 2344 bytes 
class AArkLaserChainBullet_GT_LV1_C : public AArkProjectile_LaserChain
{

 public: 



 // Functions 
 public:
}; 
 
 


