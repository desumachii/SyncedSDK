#pragma once 
#include <AIGABuff_ReturnOfSpring_lv2_Structs.h>
 
 
 
//BlueprintGeneratedClass AIGABuff_ReturnOfSpring_lv2.AIGABuff_ReturnOfSpring_lv2_C Size 1368
// Inherited 1368 bytes 
class UAIGABuff_ReturnOfSpring_lv2_C : public UAIGABuff_ReturnOfSpring_C
{

 public: 



 // Functions 
 public:
}; 
 
 


