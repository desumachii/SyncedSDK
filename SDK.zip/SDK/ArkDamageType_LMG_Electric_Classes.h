#pragma once 
#include <ArkDamageType_LMG_Electric_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkDamageType_LMG_Electric.ArkDamageType_LMG_Electric_C Size 264
// Inherited 264 bytes 
class UArkDamageType_LMG_Electric_C : public UArkDamageType_Range_C
{

 public: 



 // Functions 
 public:
}; 
 
 


