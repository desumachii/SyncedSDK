#pragma once 
#include <AIGABuff_DamageFixForPve_Suppressor_Structs.h>
 
 
 
//BlueprintGeneratedClass AIGABuff_DamageFixForPve_Suppressor.AIGABuff_DamageFixForPve_Suppressor_C Size 816
// Inherited 816 bytes 
class UAIGABuff_DamageFixForPve_Suppressor_C : public UArkGameBuff_BaseDamageModifier
{

 public: 



 // Functions 
 public:
}; 
 
 


