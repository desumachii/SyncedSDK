#pragma once 
#include <AIGABuff_SelfExplode_BP_Summon_Structs.h>
 
 
 
//BlueprintGeneratedClass AIGABuff_SelfExplode_BP_Summon.AIGABuff_SelfExplode_BP_Summon_C Size 2024
// Inherited 2024 bytes 
class UAIGABuff_SelfExplode_BP_Summon_C : public UAIGABuff_SelfExplode_BP_C
{

 public: 



 // Functions 
 public:
}; 
 
 


