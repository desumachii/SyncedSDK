#pragma once 
#include <ArkNavFilter_EliteBase_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkNavFilter_EliteBase.ArkNavFilter_EliteBase_C Size 152
// Inherited 152 bytes 
class UArkNavFilter_EliteBase_C : public UArkNavFilter_Base
{

 public: 



 // Functions 
 public:
}; 
 
 


