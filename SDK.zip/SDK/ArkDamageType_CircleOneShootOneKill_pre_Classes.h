#pragma once 
#include <ArkDamageType_CircleOneShootOneKill_pre_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkDamageType_CircleOneShootOneKill_pre.ArkDamageType_CircleOneShootOneKill_pre_C Size 264
// Inherited 264 bytes 
class UArkDamageType_CircleOneShootOneKill_pre_C : public UArkDamageType_ShockWave_C
{

 public: 



 // Functions 
 public:
}; 
 
 


