#pragma once 
#include <SDK_Engine_Objects.h> 
 
 
//Function AnimNotify_SetGlobalDarkZoneValue.AnimNotify_SetGlobalDarkZoneValue_C.Received_Notify Size 44
// Inherited 24 bytes 
class FReceived_Notify : public FReceived_Notify
{

 public: 
	struct USkeletalMeshComponent* MeshComp;  // Offset: 0 Size: 8
	struct UAnimSequenceBase* Animation;  // Offset: 8 Size: 8
	char pad_40_1 : 7;  // Offset: 40 Size: 1
	bool ReturnValue : 1;  // Offset: 16 Size: 1
	struct AActor* CallFunc_GetOwner_ReturnValue;  // Offset: 24 Size: 8
	struct FVector CallFunc_K2_GetActorLocation_ReturnValue;  // Offset: 32 Size: 12



 // Functions 
 public:
}; 
 
 