#pragma once 
#include <AIGABuff_Shuttle_CrossPillarImpact_Structs.h>
 
 
 
//BlueprintGeneratedClass AIGABuff_Shuttle_CrossPillarImpact.AIGABuff_Shuttle_CrossPillarImpact_C Size 3120
// Inherited 3056 bytes 
class UAIGABuff_Shuttle_CrossPillarImpact_C : public UArkAIGABuff_CrossPillarImpact
{

 public: 
	struct FPointerToUberGraphFrame UberGraphFrame;  // Offset: 3056 Size: 8
	struct TSoftObjectPtr<UMaterialInterface> Decal;  // Offset: 3064 Size: 40
	struct TArray<struct UArkSoftParticleSystemComponentWithPool*> ParticleSystem;  // Offset: 3104 Size: 16



 // Functions 
 public:
	void C2BP_OnDeactive(); // Function AIGABuff_Shuttle_CrossPillarImpact.AIGABuff_Shuttle_CrossPillarImpact_C.C2BP_OnDeactive
	void SpawnWarningEffect(); // Function AIGABuff_Shuttle_CrossPillarImpact.AIGABuff_Shuttle_CrossPillarImpact_C.SpawnWarningEffect
	void ExecuteUbergraph_AIGABuff_Shuttle_CrossPillarImpact(int32_t EntryPoint); // Function AIGABuff_Shuttle_CrossPillarImpact.AIGABuff_Shuttle_CrossPillarImpact_C.ExecuteUbergraph_AIGABuff_Shuttle_CrossPillarImpact
}; 
 
 


