#pragma once 
#include <ArkNavArea_DynamicObstacle_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkNavArea_DynamicObstacle.ArkNavArea_DynamicObstacle_C Size 72
// Inherited 72 bytes 
class UArkNavArea_DynamicObstacle_C : public UNavArea
{

 public: 



 // Functions 
 public:
}; 
 
 


