#pragma once 
#include <AnimNotifyState_SuperJumpCanControlRot_Structs.h>
 
 
 
//BlueprintGeneratedClass AnimNotifyState_SuperJumpCanControlRot.AnimNotifyState_SuperJumpCanControlRot_C Size 48
// Inherited 48 bytes 
class UAnimNotifyState_SuperJumpCanControlRot_C : public UAnimNotifyState
{

 public: 



 // Functions 
 public:
	bool Received_NotifyEnd(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function AnimNotifyState_SuperJumpCanControlRot.AnimNotifyState_SuperJumpCanControlRot_C.Received_NotifyEnd
	bool Received_NotifyBegin(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration); // Function AnimNotifyState_SuperJumpCanControlRot.AnimNotifyState_SuperJumpCanControlRot_C.Received_NotifyBegin
}; 
 
 


