#pragma once 
#include <ArkImpactEffect_Sword_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkImpactEffect_Sword.ArkImpactEffect_Sword_C Size 504
// Inherited 504 bytes 
class UArkImpactEffect_Sword_C : public UArkImpactEffect_Sword_Large_C
{

 public: 



 // Functions 
 public:
}; 
 
 


