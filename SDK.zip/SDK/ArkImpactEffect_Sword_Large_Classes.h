#pragma once 
#include <ArkImpactEffect_Sword_Large_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkImpactEffect_Sword_Large.ArkImpactEffect_Sword_Large_C Size 504
// Inherited 504 bytes 
class UArkImpactEffect_Sword_Large_C : public UArkImpactEffect
{

 public: 



 // Functions 
 public:
}; 
 
 


