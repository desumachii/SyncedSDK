#pragma once 
#include <ArkDamageType_ShockWave_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkDamageType_ShockWave.ArkDamageType_ShockWave_C Size 264
// Inherited 264 bytes 
class UArkDamageType_ShockWave_C : public UArkDamageType
{

 public: 



 // Functions 
 public:
}; 
 
 


