#pragma once 
#include <ArkDamageType_Detector_shockwave_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkDamageType_Detector_shockwave.ArkDamageType_Detector_shockwave_C Size 264
// Inherited 264 bytes 
class UArkDamageType_Detector_shockwave_C : public UArkDamageType_Range_C
{

 public: 



 // Functions 
 public:
}; 
 
 


