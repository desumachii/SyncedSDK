#pragma once 
#include <AnimationCore_Structs.h>
 
 
 
//Class AnimationCore.AnimationDataSourceRegistry Size 120
// Inherited 40 bytes 
class UAnimationDataSourceRegistry : public UObject
{

 public: 
	struct TMap<struct FName, struct TWeakObjectPtr<UObject>> DataSources;  // Offset: 40 Size: 80



 // Functions 
 public:
}; 
 
 


