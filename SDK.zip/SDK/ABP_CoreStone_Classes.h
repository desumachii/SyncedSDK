#pragma once 
#include <ABP_CoreStone_Structs.h>
 
 
 
//AnimBlueprintGeneratedClass ABP_CoreStone.ABP_CoreStone_C Size 2680
// Inherited 672 bytes 
class UABP_CoreStone_C : public UAnimInstance
{

 public: 
	struct FPointerToUberGraphFrame UberGraphFrame;  // Offset: 672 Size: 8
	struct FAnimNode_Slot AnimGraphNode_Slot_3;  // Offset: 680 Size: 80
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool_2;  // Offset: 760 Size: 176
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2;  // Offset: 936 Size: 272
	struct FAnimNode_SaveCachedPose AnimGraphNode_SaveCachedPose;  // Offset: 1208 Size: 192
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_4;  // Offset: 1400 Size: 48
	struct FAnimNode_Slot AnimGraphNode_Slot_2;  // Offset: 1448 Size: 80
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_3;  // Offset: 1528 Size: 48
	struct FAnimNode_Slot AnimGraphNode_Slot;  // Offset: 1576 Size: 80
	struct FAnimNode_TwoWayBlend AnimGraphNode_TwoWayBlend_2;  // Offset: 1656 Size: 208
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool;  // Offset: 1864 Size: 176
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose_2;  // Offset: 2040 Size: 48
	struct FAnimNode_TwoWayBlend AnimGraphNode_TwoWayBlend;  // Offset: 2088 Size: 208
	struct FAnimNode_UseCachedPose AnimGraphNode_UseCachedPose;  // Offset: 2296 Size: 48
	struct FAnimNode_Root AnimGraphNode_Root;  // Offset: 2344 Size: 56
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer;  // Offset: 2400 Size: 272
	char pad_2672_1 : 7;  // Offset: 2672 Size: 1
	bool bShowCoreMesh : 1;  // Offset: 2672 Size: 1
	char pad_2673[3];  // Offset: 2673 Size: 3
	float PitchingAlpha;  // Offset: 2676 Size: 4



 // Functions 
 public:
	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_CoreStone.ABP_CoreStone_C.AnimGraph
	void ShowCoreMesh(bool bShowCoreMesh); // Function ABP_CoreStone.ABP_CoreStone_C.ShowCoreMesh
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CoreStone_AnimGraphNode_TwoWayBlend_FA14CFFC448245CA47AE93872DD131DE(); // Function ABP_CoreStone.ABP_CoreStone_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CoreStone_AnimGraphNode_TwoWayBlend_FA14CFFC448245CA47AE93872DD131DE
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CoreStone_AnimGraphNode_BlendListByBool_15A60B4A4E90D49FB0DF1E92C707CE4F(); // Function ABP_CoreStone.ABP_CoreStone_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CoreStone_AnimGraphNode_BlendListByBool_15A60B4A4E90D49FB0DF1E92C707CE4F
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CoreStone_AnimGraphNode_TwoWayBlend_597C8D2C438047DBB48517A0DE68034B(); // Function ABP_CoreStone.ABP_CoreStone_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_CoreStone_AnimGraphNode_TwoWayBlend_597C8D2C438047DBB48517A0DE68034B
	void ExecuteUbergraph_ABP_CoreStone(int32_t EntryPoint); // Function ABP_CoreStone.ABP_CoreStone_C.ExecuteUbergraph_ABP_CoreStone
}; 
 
 


