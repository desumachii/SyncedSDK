#pragma once 
#include <ArkNavArea_Breakable_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkNavArea_Breakable.ArkNavArea_Breakable_C Size 72
// Inherited 72 bytes 
class UArkNavArea_Breakable_C : public UNavArea
{

 public: 



 // Functions 
 public:
}; 
 
 


