#pragma once 
#include <ArkDamageType_Melee_PlayerHitReaction_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkDamageType_Melee_PlayerHitReaction.ArkDamageType_Melee_PlayerHitReaction_C Size 264
// Inherited 264 bytes 
class UArkDamageType_Melee_PlayerHitReaction_C : public UArkDamageType_Melee_C
{

 public: 



 // Functions 
 public:
}; 
 
 


