#pragma once 
#include <AIGABuff_SyncAttackDamage_BP_3_Structs.h>
 
 
 
//BlueprintGeneratedClass AIGABuff_SyncAttackDamage_BP_3.AIGABuff_SyncAttackDamage_BP_2_C Size 1224
// Inherited 1224 bytes 
class UAIGABuff_SyncAttackDamage_BP_2_C : public UArkAIGameplayAbilityBuff
{

 public: 



 // Functions 
 public:
}; 
 
 


