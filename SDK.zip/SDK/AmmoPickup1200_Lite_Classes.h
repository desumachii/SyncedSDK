#pragma once 
#include <AmmoPickup1200_Lite_Structs.h>
 
 
 
//BlueprintGeneratedClass AmmoPickup1200_Lite.AmmoPickup1200_Lite_C Size 2416
// Inherited 2416 bytes 
class AAmmoPickup1200_Lite_C : public AAmmoPickupBase_C
{

 public: 



 // Functions 
 public:
}; 
 
 


