#pragma once 
#include <SDK_Engine_Objects.h> 
 
 
//Function ABP_Fpp_PostProcess.ABP_Fpp_PostProcess_C.ExecuteUbergraph_ABP_Fpp_PostProcess Size 4
class FExecuteUbergraph_ABP_Fpp_PostProcess
{

 public: 
	int32_t EntryPoint;  // Offset: 0 Size: 4



 // Functions 
 public:
}; 
 
 //Function ABP_Fpp_PostProcess.ABP_Fpp_PostProcess_C.AnimGraph Size 32
class FAnimGraph
{

 public: 
	struct FPoseLink InPose;  // Offset: 0 Size: 16
	struct FPoseLink AnimGraph;  // Offset: 16 Size: 16



 // Functions 
 public:
}; 
 
 