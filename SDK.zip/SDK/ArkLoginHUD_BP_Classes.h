#pragma once 
#include <ArkLoginHUD_BP_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkLoginHUD_BP.ArkLoginHUD_BP_C Size 1416
// Inherited 1400 bytes 
class AArkLoginHUD_BP_C : public AArkBattleHUD
{

 public: 
	struct FPointerToUberGraphFrame UberGraphFrame;  // Offset: 1400 Size: 8
	struct USceneComponent* DefaultSceneRoot;  // Offset: 1408 Size: 8



 // Functions 
 public:
	void OnQuitGame(); // Function ArkLoginHUD_BP.ArkLoginHUD_BP_C.OnQuitGame
	void ArkLoginHUD_BP_AutoGenFunc(struct UUserWidget* CreatedWidget); // Function ArkLoginHUD_BP.ArkLoginHUD_BP_C.ArkLoginHUD_BP_AutoGenFunc
	void CustomEvent_QuitGame(); // Function ArkLoginHUD_BP.ArkLoginHUD_BP_C.CustomEvent_QuitGame
	void OnAgreeAction(); // Function ArkLoginHUD_BP.ArkLoginHUD_BP_C.OnAgreeAction
	void OnDisagreeAction(); // Function ArkLoginHUD_BP.ArkLoginHUD_BP_C.OnDisagreeAction
	void ExecuteUbergraph_ArkLoginHUD_BP(int32_t EntryPoint); // Function ArkLoginHUD_BP.ArkLoginHUD_BP_C.ExecuteUbergraph_ArkLoginHUD_BP
}; 
 
 


