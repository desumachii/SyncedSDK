#pragma once 
#include <Anne_Default_AddonC_00_Structs.h>
 
 
 
//BlueprintGeneratedClass Anne_Default_AddonC_00.Anne_Default_AddonC_00_C Size 400
// Inherited 400 bytes 
class UAnne_Default_AddonC_00_C : public UArkItemAvatarAttachment
{

 public: 



 // Functions 
 public:
}; 
 
 


