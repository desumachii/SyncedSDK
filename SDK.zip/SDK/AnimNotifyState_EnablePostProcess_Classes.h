#pragma once 
#include <AnimNotifyState_EnablePostProcess_Structs.h>
 
 
 
//BlueprintGeneratedClass AnimNotifyState_EnablePostProcess.AnimNotifyState_EnablePostProcess_C Size 72
// Inherited 48 bytes 
class UAnimNotifyState_EnablePostProcess_C : public UAnimNotifyState
{

 public: 
	float BlendIn;  // Offset: 48 Size: 4
	char pad_52[4];  // Offset: 52 Size: 4
	struct FString TypeName;  // Offset: 56 Size: 16



 // Functions 
 public:
	bool Received_NotifyEnd(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation); // Function AnimNotifyState_EnablePostProcess.AnimNotifyState_EnablePostProcess_C.Received_NotifyEnd
	bool Received_NotifyBegin(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, float TotalDuration); // Function AnimNotifyState_EnablePostProcess.AnimNotifyState_EnablePostProcess_C.Received_NotifyBegin
}; 
 
 


