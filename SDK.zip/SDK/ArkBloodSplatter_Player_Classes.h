#pragma once 
#include <ArkBloodSplatter_Player_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkBloodSplatter_Player.ArkBloodSplatter_Player_C Size 56
// Inherited 56 bytes 
class UArkBloodSplatter_Player_C : public UArkBloodSplatter
{

 public: 



 // Functions 
 public:
}; 
 
 


