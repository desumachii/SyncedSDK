#pragma once 
#include <SDK_Engine_Objects.h> 
 
 
//ScriptStruct AkAudio.AKWaapiJsonObject Size 16
class FAKWaapiJsonObject
{

 public: 
	char pad_0[16];  // Offset: 0 Size: 16



 // Functions 
 public:
}; 
 
 //DelegateFunction AkAudio.OnAkBankCallback__DelegateSignature Size 1
class FOnAkBankCallback__DelegateSignature
{

 public: 
	enum class EAkResult Result;  // Offset: 0 Size: 1



 // Functions 
 public:
}; 
 
 //DelegateFunction AkAudio.OnAkPostEventCallback__DelegateSignature Size 16
class FOnAkPostEventCallback__DelegateSignature
{

 public: 
	enum class EAkCallbackType CallbackType;  // Offset: 0 Size: 1
	char pad_1[7];  // Offset: 1 Size: 7
	struct UAkCallbackInfo* CallbackInfo;  // Offset: 8 Size: 8



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkWaapiUri Size 16
class FAkWaapiUri
{

 public: 
	struct FString URI;  // Offset: 0 Size: 16



 // Functions 
 public:
}; 
 
 //DelegateFunction AkAudio.OnItemPropertyDragDetected__DelegateSignature Size 16
class FOnItemPropertyDragDetected__DelegateSignature
{

 public: 
	struct FString PropertyDragged;  // Offset: 0 Size: 16



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkWaapiSubscriptionId Size 8
class FAkWaapiSubscriptionId
{

 public: 
	char pad_0[8];  // Offset: 0 Size: 8



 // Functions 
 public:
}; 
 
 //DelegateFunction AkAudio.OnSetCurrentAudioCultureCallback__DelegateSignature Size 1
class FOnSetCurrentAudioCultureCallback__DelegateSignature
{

 public: 
	char pad_0_1 : 7;  // Offset: 0 Size: 1
	bool Succeeded : 1;  // Offset: 0 Size: 1



 // Functions 
 public:
}; 
 
 //DelegateFunction AkAudio.OnEventCallback__DelegateSignature Size 24
class FOnEventCallback__DelegateSignature
{

 public: 
	struct FAkWaapiSubscriptionId SubscriptionId;  // Offset: 0 Size: 8
	struct FAKWaapiJsonObject WaapiJsonObject;  // Offset: 8 Size: 16



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.PostEvent Size 88
class FPostEvent
{

 public: 
	struct UAkAudioEvent* AkEvent;  // Offset: 0 Size: 8
	struct AActor* Actor;  // Offset: 8 Size: 8
	int32_t CallbackMask;  // Offset: 16 Size: 4
	struct FDelegate PostEventCallback;  // Offset: 20 Size: 16
	char pad_36[4];  // Offset: 36 Size: 4
	struct TArray<struct FAkExternalSourceInfo> ExternalSources;  // Offset: 40 Size: 16
	char pad_56_1 : 7;  // Offset: 56 Size: 1
	bool bStopWhenAttachedToDestroyed : 1;  // Offset: 56 Size: 1
	char pad_57[7];  // Offset: 57 Size: 7
	struct FString EventName;  // Offset: 64 Size: 16
	int32_t ReturnValue;  // Offset: 80 Size: 4
	char pad_84[4];  // Offset: 84 Size: 4



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkCheckBox.GetCheckedState Size 1
class FGetCheckedState
{

 public: 
	enum class ECheckBoxState ReturnValue;  // Offset: 0 Size: 1



 // Functions 
 public:
}; 
 
 //DelegateFunction AkAudio.OnItemPropertySelectionChanged__DelegateSignature Size 16
class FOnItemPropertySelectionChanged__DelegateSignature
{

 public: 
	struct FString PropertySelected;  // Offset: 0 Size: 16



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkWwiseObjectDetails Size 48
class FAkWwiseObjectDetails
{

 public: 
	struct FString ItemName;  // Offset: 0 Size: 16
	struct FString ItemPath;  // Offset: 16 Size: 16
	struct FString ItemId;  // Offset: 32 Size: 16



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkSlider.GetValue Size 4
class FGetValue
{

 public: 
	float ReturnValue;  // Offset: 0 Size: 4



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.GetSpeakerAngles Size 40
class FGetSpeakerAngles
{

 public: 
	struct TArray<float> SpeakerAngles;  // Offset: 0 Size: 16
	float HeightAngle;  // Offset: 16 Size: 4
	char pad_20[4];  // Offset: 20 Size: 4
	struct FString DeviceShareset;  // Offset: 24 Size: 16



 // Functions 
 public:
}; 
 
 //DelegateFunction AkAudio.AkOnFloatValueChangedEvent__DelegateSignature Size 4
class FAkOnFloatValueChangedEvent__DelegateSignature
{

 public: 
	float Value;  // Offset: 0 Size: 4



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkOutputSettings Size 24
class FAkOutputSettings
{

 public: 
	struct FString AudioDeviceSharesetName;  // Offset: 0 Size: 16
	int32_t IdDevice;  // Offset: 16 Size: 4
	enum class PanningRule PanRule;  // Offset: 20 Size: 1
	enum class AkChannelConfiguration ChannelConfig;  // Offset: 21 Size: 1
	char pad_22[2];  // Offset: 22 Size: 2



 // Functions 
 public:
}; 
 
 //DelegateFunction AkAudio.OnItemDropDetected__DelegateSignature Size 16
class FOnItemDropDetected__DelegateSignature
{

 public: 
	struct FGuid ItemDroppedID;  // Offset: 0 Size: 16



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkWaapiCalls.GetSubscriptionID Size 16
class FGetSubscriptionID
{

 public: 
	struct FAkWaapiSubscriptionId Subscription;  // Offset: 0 Size: 8
	int32_t ReturnValue;  // Offset: 8 Size: 4
	char pad_12[4];  // Offset: 12 Size: 4



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkMidiCc Size 4
// Inherited 2 bytes 
class FAkMidiCc : public FAkMidiEventBase
{

 public: 
	enum class EAkMidiCcValues Cc;  // Offset: 2 Size: 1
	char Value;  // Offset: 3 Size: 1



 // Functions 
 public:
}; 
 
 //DelegateFunction AkAudio.OnPropertyDropDetected__DelegateSignature Size 16
class FOnPropertyDropDetected__DelegateSignature
{

 public: 
	struct FString PropertyDropped;  // Offset: 0 Size: 16



 // Functions 
 public:
}; 
 
 //DelegateFunction AkAudio.OnItemBoolPropertySelectionChanged__DelegateSignature Size 16
class FOnItemBoolPropertySelectionChanged__DelegateSignature
{

 public: 
	struct FString PropertySelected;  // Offset: 0 Size: 16



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkExternalSourceInfo Size 56
class FAkExternalSourceInfo
{

 public: 
	struct FString ExternalSrcName;  // Offset: 0 Size: 16
	enum class AkCodecId CodecID;  // Offset: 16 Size: 1
	char pad_17[7];  // Offset: 17 Size: 7
	struct FString Filename;  // Offset: 24 Size: 16
	struct UAkExternalMediaAsset* ExternalSourceAsset;  // Offset: 40 Size: 8
	char pad_48_1 : 7;  // Offset: 48 Size: 1
	bool IsStreamed : 1;  // Offset: 48 Size: 1
	char pad_49[7];  // Offset: 49 Size: 7



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkWaapiFieldNames Size 16
class FAkWaapiFieldNames
{

 public: 
	struct FString FieldName;  // Offset: 0 Size: 16



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkAudioSession Size 12
class FAkAudioSession
{

 public: 
	enum class EAkAudioSessionCategory AudioSessionCategory;  // Offset: 0 Size: 4
	uint32_t AudioSessionCategoryOptions;  // Offset: 4 Size: 4
	enum class EAkAudioSessionMode AudioSessionMode;  // Offset: 8 Size: 4



 // Functions 
 public:
}; 
 
 //DelegateFunction AkAudio.OnItemBoolPropertyDragDetected__DelegateSignature Size 16
class FOnItemBoolPropertyDragDetected__DelegateSignature
{

 public: 
	struct FString PropertyDragged;  // Offset: 0 Size: 16



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkMainOutputSettings Size 40
class FAkMainOutputSettings
{

 public: 
	struct FString AudioDeviceShareset;  // Offset: 0 Size: 16
	uint32_t DeviceID;  // Offset: 16 Size: 4
	enum class EAkPanningRule PanningRule;  // Offset: 20 Size: 4
	enum class EAkChannelConfigType ChannelConfigType;  // Offset: 24 Size: 4
	uint32_t ChannelMask;  // Offset: 28 Size: 4
	uint32_t NumberOfChannels;  // Offset: 32 Size: 4
	char pad_36[4];  // Offset: 36 Size: 4



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkMIDIEventCallbackInfo.GetPitchBend Size 12
class FGetPitchBend
{

 public: 
	struct FAkMidiPitchBend AsPitchBend;  // Offset: 0 Size: 8
	char pad_8_1 : 7;  // Offset: 8 Size: 1
	bool ReturnValue : 1;  // Offset: 8 Size: 1
	char pad_9[3];  // Offset: 9 Size: 3



 // Functions 
 public:
}; 
 
 //DelegateFunction AkAudio.AkOnCheckBoxComponentStateChanged__DelegateSignature Size 1
class FAkOnCheckBoxComponentStateChanged__DelegateSignature
{

 public: 
	char pad_0_1 : 7;  // Offset: 0 Size: 1
	bool bIsChecked : 1;  // Offset: 0 Size: 1



 // Functions 
 public:
}; 
 
 //DelegateFunction AkAudio.OnWwiseItemDropDetected__DelegateSignature Size 16
class FOnWwiseItemDropDetected__DelegateSignature
{

 public: 
	struct FGuid ItemDroppedID;  // Offset: 0 Size: 16



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkSegmentInfo Size 36
class FAkSegmentInfo
{

 public: 
	int32_t CurrentPosition;  // Offset: 0 Size: 4
	int32_t PreEntryDuration;  // Offset: 4 Size: 4
	int32_t ActiveDuration;  // Offset: 8 Size: 4
	int32_t PostExitDuration;  // Offset: 12 Size: 4
	int32_t RemainingLookAheadTime;  // Offset: 16 Size: 4
	float BeatDuration;  // Offset: 20 Size: 4
	float BarDuration;  // Offset: 24 Size: 4
	float GridDuration;  // Offset: 28 Size: 4
	float GridOffset;  // Offset: 32 Size: 4



 // Functions 
 public:
}; 
 
 //DelegateFunction AkAudio.OnBoolPropertyDropDetected__DelegateSignature Size 16
class FOnBoolPropertyDropDetected__DelegateSignature
{

 public: 
	struct FString PropertyDropped;  // Offset: 0 Size: 16



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.StopActor Size 8
class FStopActor
{

 public: 
	struct AActor* Actor;  // Offset: 0 Size: 8



 // Functions 
 public:
}; 
 
 //DelegateFunction AkAudio.OnItemSelectionChanged__DelegateSignature Size 16
class FOnItemSelectionChanged__DelegateSignature
{

 public: 
	struct FGuid ItemSelectedID;  // Offset: 0 Size: 16



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkBoolPropertyToControl Size 16
class FAkBoolPropertyToControl
{

 public: 
	struct FString ItemProperty;  // Offset: 0 Size: 16



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkAdvancedInitializationSettings Size 44
class FAkAdvancedInitializationSettings
{

 public: 
	uint32_t IO_MemorySize;  // Offset: 0 Size: 4
	uint32_t IO_Granularity;  // Offset: 4 Size: 4
	float TargetAutoStreamBufferLength;  // Offset: 8 Size: 4
	char pad_12_1 : 7;  // Offset: 12 Size: 1
	bool UseStreamCache : 1;  // Offset: 12 Size: 1
	char pad_13[3];  // Offset: 13 Size: 3
	uint32_t MaximumPinnedBytesInCache;  // Offset: 16 Size: 4
	char pad_20_1 : 7;  // Offset: 20 Size: 1
	bool EnableGameSyncPreparation : 1;  // Offset: 20 Size: 1
	char pad_21[3];  // Offset: 21 Size: 3
	uint32_t ContinuousPlaybackLookAhead;  // Offset: 24 Size: 4
	uint32_t MonitorQueuePoolSize;  // Offset: 28 Size: 4
	uint32_t MaximumHardwareTimeoutMs;  // Offset: 32 Size: 4
	char pad_36_1 : 7;  // Offset: 36 Size: 1
	bool DebugOutOfRangeCheckEnabled : 1;  // Offset: 36 Size: 1
	char pad_37[3];  // Offset: 37 Size: 3
	float DebugOutOfRangeLimit;  // Offset: 40 Size: 4



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkSpatialAudioSettings Size 32
class FAkSpatialAudioSettings
{

 public: 
	uint32_t MaxSoundPropagationDepth;  // Offset: 0 Size: 4
	float MovementThreshold;  // Offset: 4 Size: 4
	uint32_t NumberOfPrimaryRays;  // Offset: 8 Size: 4
	uint32_t ReflectionOrder;  // Offset: 12 Size: 4
	float MaximumPathLength;  // Offset: 16 Size: 4
	float CPULimitPercentage;  // Offset: 20 Size: 4
	char pad_24_1 : 7;  // Offset: 24 Size: 1
	bool EnableDiffractionOnReflections : 1;  // Offset: 24 Size: 1
	char pad_25_1 : 7;  // Offset: 25 Size: 1
	bool EnableGeometricDiffractionAndTransmission : 1;  // Offset: 25 Size: 1
	char pad_26_1 : 7;  // Offset: 26 Size: 1
	bool CalcEmitterVirtualPosition : 1;  // Offset: 26 Size: 1
	char pad_27_1 : 7;  // Offset: 27 Size: 1
	bool UseObstruction : 1;  // Offset: 27 Size: 1
	char pad_28_1 : 7;  // Offset: 28 Size: 1
	bool UseOcclusion : 1;  // Offset: 28 Size: 1
	char pad_29[3];  // Offset: 29 Size: 3



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.UnloadBank Size 56
class FUnloadBank
{

 public: 
	struct UAkAudioBank* Bank;  // Offset: 0 Size: 8
	struct FString BankName;  // Offset: 8 Size: 16
	struct FLatentActionInfo LatentInfo;  // Offset: 24 Size: 24
	struct UObject* WorldContextObject;  // Offset: 48 Size: 8



 // Functions 
 public:
}; 
 
 //DelegateFunction AkAudio.OnItemDragDetected__DelegateSignature Size 32
class FOnItemDragDetected__DelegateSignature
{

 public: 
	struct FGuid ItemDraggedID;  // Offset: 0 Size: 16
	struct FString ItemDraggedName;  // Offset: 16 Size: 16



 // Functions 
 public:
}; 
 
 //DelegateFunction AkAudio.PostEventAsyncOutputPin__DelegateSignature Size 4
class FPostEventAsyncOutputPin__DelegateSignature
{

 public: 
	int32_t PlayingID;  // Offset: 0 Size: 4



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkPS5AdvancedInitializationSettings Size 52
// Inherited 48 bytes 
class FAkPS5AdvancedInitializationSettings : public FAkAdvancedInitializationSettingsWithMultiCoreRendering
{

 public: 
	char pad_48_1 : 7;  // Offset: 48 Size: 1
	bool UseHardwareCodecLowLatencyMode : 1;  // Offset: 48 Size: 1
	char pad_49_1 : 7;  // Offset: 49 Size: 1
	bool bVorbisHwAcceleration : 1;  // Offset: 49 Size: 1
	char pad_50[2];  // Offset: 50 Size: 2



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.SetSpeakerAngles Size 40
class FSetSpeakerAngles
{

 public: 
	struct TArray<float> SpeakerAngles;  // Offset: 0 Size: 16
	float HeightAngle;  // Offset: 16 Size: 4
	char pad_20[4];  // Offset: 20 Size: 4
	struct FString DeviceShareset;  // Offset: 24 Size: 16



 // Functions 
 public:
}; 
 
 //DelegateFunction AkAudio.PostEventAtLocationAsyncOutputPin__DelegateSignature Size 4
class FPostEventAtLocationAsyncOutputPin__DelegateSignature
{

 public: 
	int32_t PlayingID;  // Offset: 0 Size: 4



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkGeometrySurfaceOverride Size 24
class FAkGeometrySurfaceOverride
{

 public: 
	struct UAkAcousticTexture* AcousticTexture;  // Offset: 0 Size: 8
	char pad_8_1 : 7;  // Offset: 8 Size: 1
	bool bEnableOcclusionOverride : 1;  // Offset: 8 Size: 1
	char pad_9[3];  // Offset: 9 Size: 3
	float OcclusionValue;  // Offset: 12 Size: 4
	float SurfaceArea;  // Offset: 16 Size: 4
	char pad_20[4];  // Offset: 20 Size: 4



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkAdvancedInitializationSettingsWithMultiCoreRendering Size 48
// Inherited 44 bytes 
class FAkAdvancedInitializationSettingsWithMultiCoreRendering : public FAkAdvancedInitializationSettings
{

 public: 
	char pad_44_1 : 7;  // Offset: 44 Size: 1
	bool EnableMultiCoreRendering : 1;  // Offset: 44 Size: 1
	char pad_45[3];  // Offset: 45 Size: 3



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkSurfaceEdgeInfo Size 40
class FAkSurfaceEdgeInfo
{

 public: 
	char pad_0[40];  // Offset: 0 Size: 40



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkAndroidAdvancedInitializationSettings Size 56
// Inherited 48 bytes 
class FAkAndroidAdvancedInitializationSettings : public FAkAdvancedInitializationSettingsWithMultiCoreRendering
{

 public: 
	uint32_t AudioAPI;  // Offset: 48 Size: 4
	char pad_52_1 : 7;  // Offset: 52 Size: 1
	bool RoundFrameSizeToHardwareSize : 1;  // Offset: 52 Size: 1
	char pad_53[3];  // Offset: 53 Size: 3



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkWwiseItemToControl Size 64
class FAkWwiseItemToControl
{

 public: 
	struct FAkWwiseObjectDetails ItemPicked;  // Offset: 0 Size: 48
	struct FString ItemPath;  // Offset: 48 Size: 16



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkMidiEventBase Size 2
class FAkMidiEventBase
{

 public: 
	enum class EAkMidiEventType Type;  // Offset: 0 Size: 1
	char Chan;  // Offset: 1 Size: 1



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkMidiProgramChange Size 3
// Inherited 2 bytes 
class FAkMidiProgramChange : public FAkMidiEventBase
{

 public: 
	char ProgramNum;  // Offset: 2 Size: 1



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkMidiChannelAftertouch Size 3
// Inherited 2 bytes 
class FAkMidiChannelAftertouch : public FAkMidiEventBase
{

 public: 
	char Value;  // Offset: 2 Size: 1



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkMidiNoteAftertouch Size 4
// Inherited 2 bytes 
class FAkMidiNoteAftertouch : public FAkMidiEventBase
{

 public: 
	char Note;  // Offset: 2 Size: 1
	char Value;  // Offset: 3 Size: 1



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkMidiPitchBend Size 8
// Inherited 2 bytes 
class FAkMidiPitchBend : public FAkMidiEventBase
{

 public: 
	char ValueLsb;  // Offset: 2 Size: 1
	char ValueMsb;  // Offset: 3 Size: 1
	int32_t FullValue;  // Offset: 4 Size: 4



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkMidiNoteOnOff Size 4
// Inherited 2 bytes 
class FAkMidiNoteOnOff : public FAkMidiEventBase
{

 public: 
	char Note;  // Offset: 2 Size: 1
	char Velocity;  // Offset: 3 Size: 1



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkWaapiJsonManager.SetObjectField Size 64
class FSetObjectField
{

 public: 
	struct FAkWaapiFieldNames FieldName;  // Offset: 0 Size: 16
	struct FAKWaapiJsonObject FieldValue;  // Offset: 16 Size: 16
	struct FAKWaapiJsonObject Target;  // Offset: 32 Size: 16
	struct FAKWaapiJsonObject ReturnValue;  // Offset: 48 Size: 16



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkMidiGeneric Size 4
// Inherited 2 bytes 
class FAkMidiGeneric : public FAkMidiEventBase
{

 public: 
	char Param1;  // Offset: 2 Size: 1
	char Param2;  // Offset: 3 Size: 1



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkChannelMask Size 4
class FAkChannelMask
{

 public: 
	int32_t ChannelMask;  // Offset: 0 Size: 4



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkCheckBox.GetAkItemId Size 16
class FGetAkItemId
{

 public: 
	struct FGuid ReturnValue;  // Offset: 0 Size: 16



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkCommunicationSettingsWithSystemInitialization Size 40
// Inherited 32 bytes 
class FAkCommunicationSettingsWithSystemInitialization : public FAkCommunicationSettings
{

 public: 
	char pad_32_1 : 7;  // Offset: 32 Size: 1
	bool InitializeSystemComms : 1;  // Offset: 32 Size: 1
	char pad_33[7];  // Offset: 33 Size: 7



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkGeometryData Size 80
class FAkGeometryData
{

 public: 
	struct TArray<struct FVector> Vertices;  // Offset: 0 Size: 16
	struct TArray<struct FAkAcousticSurface> Surfaces;  // Offset: 16 Size: 16
	struct TArray<struct FAkTriangle> Triangles;  // Offset: 32 Size: 16
	struct TArray<struct UPhysicalMaterial*> ToOverrideAcousticTexture;  // Offset: 48 Size: 16
	struct TArray<struct UPhysicalMaterial*> ToOverrideOcclusion;  // Offset: 64 Size: 16



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkCommonInitializationSettings Size 96
class FAkCommonInitializationSettings
{

 public: 
	uint32_t MaximumNumberOfMemoryPools;  // Offset: 0 Size: 4
	uint32_t MaximumNumberOfPositioningPaths;  // Offset: 4 Size: 4
	uint32_t CommandQueueSize;  // Offset: 8 Size: 4
	uint32_t SamplesPerFrame;  // Offset: 12 Size: 4
	struct FAkMainOutputSettings MainOutputSettings;  // Offset: 16 Size: 40
	float StreamingLookAheadRatio;  // Offset: 56 Size: 4
	uint16_t NumberOfRefillsInVoice;  // Offset: 60 Size: 2
	char pad_62[2];  // Offset: 62 Size: 2
	struct FAkSpatialAudioSettings SpatialAudioSettings;  // Offset: 64 Size: 32



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkTriangle Size 8
class FAkTriangle
{

 public: 
	uint16_t Point0;  // Offset: 0 Size: 2
	uint16_t Point1;  // Offset: 2 Size: 2
	uint16_t Point2;  // Offset: 4 Size: 2
	uint16_t Surface;  // Offset: 6 Size: 2



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkAcousticSurface Size 24
class FAkAcousticSurface
{

 public: 
	uint32_t Texture;  // Offset: 0 Size: 4
	float Occlusion;  // Offset: 4 Size: 4
	struct FString Name;  // Offset: 8 Size: 16



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkPluginInfo Size 40
class FAkPluginInfo
{

 public: 
	struct FString Name;  // Offset: 0 Size: 16
	uint32_t PluginID;  // Offset: 16 Size: 4
	char pad_20[4];  // Offset: 20 Size: 4
	struct FString dll;  // Offset: 24 Size: 16



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkHololensAdvancedInitializationSettings Size 52
// Inherited 48 bytes 
class FAkHololensAdvancedInitializationSettings : public FAkAdvancedInitializationSettingsWithMultiCoreRendering
{

 public: 
	char pad_48_1 : 7;  // Offset: 48 Size: 1
	bool UseHeadMountedDisplayAudioDevice : 1;  // Offset: 48 Size: 1
	char pad_49[3];  // Offset: 49 Size: 3



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkCommonInitializationSettingsWithSampleRate Size 104
// Inherited 96 bytes 
class FAkCommonInitializationSettingsWithSampleRate : public FAkCommonInitializationSettings
{

 public: 
	uint32_t SampleRate;  // Offset: 96 Size: 4
	char pad_100[4];  // Offset: 100 Size: 4



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkGeometrySurfacePropertiesToMap Size 48
class FAkGeometrySurfacePropertiesToMap
{

 public: 
	struct TSoftObjectPtr<UAkAcousticTexture> AcousticTexture;  // Offset: 0 Size: 40
	float OcclusionValue;  // Offset: 40 Size: 4
	char pad_44[4];  // Offset: 44 Size: 4



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkCommunicationSettingsWithCommSelection Size 40
// Inherited 32 bytes 
class FAkCommunicationSettingsWithCommSelection : public FAkCommunicationSettings
{

 public: 
	enum class EAkCommSystem CommunicationSystem;  // Offset: 32 Size: 4
	char pad_36[4];  // Offset: 36 Size: 4



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkCommunicationSettings Size 32
class FAkCommunicationSettings
{

 public: 
	uint32_t PoolSize;  // Offset: 0 Size: 4
	uint16_t DiscoveryBroadcastPort;  // Offset: 4 Size: 2
	uint16_t CommandPort;  // Offset: 6 Size: 2
	uint16_t NotificationPort;  // Offset: 8 Size: 2
	char pad_10[6];  // Offset: 10 Size: 6
	struct FString NetworkName;  // Offset: 16 Size: 16



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkPropertyToControl Size 16
class FAkPropertyToControl
{

 public: 
	struct FString ItemProperty;  // Offset: 0 Size: 16



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkMIDIEventCallbackInfo.GetCc Size 5
class FGetCc
{

 public: 
	struct FAkMidiCc AsCc;  // Offset: 0 Size: 4
	char pad_4_1 : 7;  // Offset: 4 Size: 1
	bool ReturnValue : 1;  // Offset: 4 Size: 1



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkPS4AdvancedInitializationSettings Size 56
// Inherited 48 bytes 
class FAkPS4AdvancedInitializationSettings : public FAkAdvancedInitializationSettingsWithMultiCoreRendering
{

 public: 
	uint32_t ACPBatchBufferSize;  // Offset: 48 Size: 4
	char pad_52_1 : 7;  // Offset: 52 Size: 1
	bool UseHardwareCodecLowLatencyMode : 1;  // Offset: 52 Size: 1
	char pad_53[3];  // Offset: 53 Size: 3



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkReverbDescriptor Size 40
class FAkReverbDescriptor
{

 public: 
	char pad_0[40];  // Offset: 0 Size: 40



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkAcousticTextureParams Size 32
class FAkAcousticTextureParams
{

 public: 
	struct FVector4 AbsorptionValues;  // Offset: 0 Size: 16
	char pad_16[16];  // Offset: 16 Size: 16



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkSurfacePoly Size 24
class FAkSurfacePoly
{

 public: 
	struct UAkAcousticTexture* Texture;  // Offset: 0 Size: 8
	float Occlusion;  // Offset: 8 Size: 4
	char pad_12_1 : 7;  // Offset: 12 Size: 1
	bool EnableSurface : 1;  // Offset: 12 Size: 1
	char pad_13[3];  // Offset: 13 Size: 3
	float SurfaceArea;  // Offset: 16 Size: 4
	char pad_20[4];  // Offset: 20 Size: 4



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.PostEventAtLocation Size 64
class FPostEventAtLocation
{

 public: 
	struct UAkAudioEvent* AkEvent;  // Offset: 0 Size: 8
	struct FVector Location;  // Offset: 8 Size: 12
	struct FRotator Orientation;  // Offset: 20 Size: 12
	struct FString EventName;  // Offset: 32 Size: 16
	struct UObject* WorldContextObject;  // Offset: 48 Size: 8
	int32_t ReturnValue;  // Offset: 56 Size: 4
	char pad_60[4];  // Offset: 60 Size: 4



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.IsGame Size 16
class FIsGame
{

 public: 
	struct UObject* WorldContextObject;  // Offset: 0 Size: 8
	char pad_8_1 : 7;  // Offset: 8 Size: 1
	bool ReturnValue : 1;  // Offset: 8 Size: 1
	char pad_9[7];  // Offset: 9 Size: 7



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameObject.PostAssociatedAkEvent Size 48
class FPostAssociatedAkEvent
{

 public: 
	int32_t CallbackMask;  // Offset: 0 Size: 4
	struct FDelegate PostEventCallback;  // Offset: 4 Size: 16
	char pad_20[4];  // Offset: 20 Size: 4
	struct TArray<struct FAkExternalSourceInfo> ExternalSources;  // Offset: 24 Size: 16
	int32_t ReturnValue;  // Offset: 40 Size: 4
	char pad_44[4];  // Offset: 44 Size: 4



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkSurfaceEdgeVerts Size 24
class FAkSurfaceEdgeVerts
{

 public: 
	char pad_0[24];  // Offset: 0 Size: 24



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkWindowsAdvancedInitializationSettings Size 56
// Inherited 48 bytes 
class FAkWindowsAdvancedInitializationSettings : public FAkAdvancedInitializationSettingsWithMultiCoreRendering
{

 public: 
	char pad_48_1 : 7;  // Offset: 48 Size: 1
	bool UseHeadMountedDisplayAudioDevice : 1;  // Offset: 48 Size: 1
	char pad_49[3];  // Offset: 49 Size: 3
	uint32_t MaxSystemAudioObjects;  // Offset: 52 Size: 4



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkWinGDKAdvancedInitializationSettings Size 52
// Inherited 48 bytes 
class FAkWinGDKAdvancedInitializationSettings : public FAkAdvancedInitializationSettingsWithMultiCoreRendering
{

 public: 
	char pad_48_1 : 7;  // Offset: 48 Size: 1
	bool UseHeadMountedDisplayAudioDevice : 1;  // Offset: 48 Size: 1
	char pad_49[3];  // Offset: 49 Size: 3



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkXboxOneGDKApuHeapInitializationSettings Size 8
class FAkXboxOneGDKApuHeapInitializationSettings
{

 public: 
	uint32_t CachedSize;  // Offset: 0 Size: 4
	uint32_t NonCachedSize;  // Offset: 4 Size: 4



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkXboxOneGDKAdvancedInitializationSettings Size 52
// Inherited 48 bytes 
class FAkXboxOneGDKAdvancedInitializationSettings : public FAkAdvancedInitializationSettingsWithMultiCoreRendering
{

 public: 
	uint16_t MaximumNumberOfXMAVoices;  // Offset: 48 Size: 2
	char pad_50_1 : 7;  // Offset: 50 Size: 1
	bool UseHardwareCodecLowLatencyMode : 1;  // Offset: 50 Size: 1
	char pad_51[1];  // Offset: 51 Size: 1



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkXboxOneApuHeapInitializationSettings Size 8
class FAkXboxOneApuHeapInitializationSettings
{

 public: 
	uint32_t CachedSize;  // Offset: 0 Size: 4
	uint32_t NonCachedSize;  // Offset: 4 Size: 4



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkXboxOneAdvancedInitializationSettings Size 52
// Inherited 48 bytes 
class FAkXboxOneAdvancedInitializationSettings : public FAkAdvancedInitializationSettingsWithMultiCoreRendering
{

 public: 
	uint16_t MaximumNumberOfXMAVoices;  // Offset: 48 Size: 2
	char pad_50_1 : 7;  // Offset: 50 Size: 1
	bool UseHardwareCodecLowLatencyMode : 1;  // Offset: 50 Size: 1
	char pad_51[1];  // Offset: 51 Size: 1



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkXSXApuHeapInitializationSettings Size 8
class FAkXSXApuHeapInitializationSettings
{

 public: 
	uint32_t CachedSize;  // Offset: 0 Size: 4
	uint32_t NonCachedSize;  // Offset: 4 Size: 4



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkComponent.PostAssociatedAkEventAndWaitForEnd Size 48
class FPostAssociatedAkEventAndWaitForEnd
{

 public: 
	struct TArray<struct FAkExternalSourceInfo> ExternalSources;  // Offset: 0 Size: 16
	struct FLatentActionInfo LatentInfo;  // Offset: 16 Size: 24
	int32_t ReturnValue;  // Offset: 40 Size: 4
	char pad_44[4];  // Offset: 44 Size: 4



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.AkXSXAdvancedInitializationSettings Size 60
// Inherited 48 bytes 
class FAkXSXAdvancedInitializationSettings : public FAkAdvancedInitializationSettingsWithMultiCoreRendering
{

 public: 
	uint16_t MaximumNumberOfXMAVoices;  // Offset: 48 Size: 2
	char pad_50_1 : 7;  // Offset: 50 Size: 1
	bool UseHardwareCodecLowLatencyMode : 1;  // Offset: 50 Size: 1
	char pad_51[1];  // Offset: 51 Size: 1
	uint16_t MaximumNumberOfOpusVoices;  // Offset: 52 Size: 2
	char pad_54[2];  // Offset: 54 Size: 2
	uint32_t uMaxSystemAudioObjects;  // Offset: 56 Size: 4



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.MovieSceneAkAudioEventTemplate Size 40
// Inherited 32 bytes 
class FMovieSceneAkAudioEventTemplate : public FMovieSceneEvalTemplate
{

 public: 
	struct UMovieSceneAkAudioEventSection* Section;  // Offset: 32 Size: 8



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkWaapiJsonManager.GetIntegerField Size 40
class FGetIntegerField
{

 public: 
	struct FAkWaapiFieldNames FieldName;  // Offset: 0 Size: 16
	struct FAKWaapiJsonObject Target;  // Offset: 16 Size: 16
	int32_t ReturnValue;  // Offset: 32 Size: 4
	char pad_36[4];  // Offset: 36 Size: 4



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.ExecuteActionOnEvent Size 40
class FExecuteActionOnEvent
{

 public: 
	struct UAkAudioEvent* AkEvent;  // Offset: 0 Size: 8
	enum class AkActionOnEventType ActionType;  // Offset: 8 Size: 1
	char pad_9[7];  // Offset: 9 Size: 7
	struct AActor* Actor;  // Offset: 16 Size: 8
	int32_t TransitionDuration;  // Offset: 24 Size: 4
	enum class EAkCurveInterpolation FadeCurve;  // Offset: 28 Size: 1
	char pad_29[3];  // Offset: 29 Size: 3
	int32_t PlayingID;  // Offset: 32 Size: 4
	char pad_36[4];  // Offset: 36 Size: 4



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.MovieSceneAkAudioRTPCTemplate Size 40
// Inherited 32 bytes 
class FMovieSceneAkAudioRTPCTemplate : public FMovieSceneEvalTemplate
{

 public: 
	struct UMovieSceneAkAudioRTPCSection* Section;  // Offset: 32 Size: 8



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.MovieSceneFloatChannelSerializationHelper Size 48
class FMovieSceneFloatChannelSerializationHelper
{

 public: 
	enum class ERichCurveExtrapolation PreInfinityExtrap;  // Offset: 0 Size: 1
	enum class ERichCurveExtrapolation PostInfinityExtrap;  // Offset: 1 Size: 1
	char pad_2[6];  // Offset: 2 Size: 6
	struct TArray<int32_t> Times;  // Offset: 8 Size: 16
	struct TArray<struct FMovieSceneFloatValueSerializationHelper> Values;  // Offset: 24 Size: 16
	float DefaultValue;  // Offset: 40 Size: 4
	char pad_44_1 : 7;  // Offset: 44 Size: 1
	bool bHasDefaultValue : 1;  // Offset: 44 Size: 1
	char pad_45[3];  // Offset: 45 Size: 3



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.MovieSceneFloatValueSerializationHelper Size 28
class FMovieSceneFloatValueSerializationHelper
{

 public: 
	float Value;  // Offset: 0 Size: 4
	enum class ERichCurveInterpMode InterpMode;  // Offset: 4 Size: 1
	enum class ERichCurveTangentMode TangentMode;  // Offset: 5 Size: 1
	char pad_6[2];  // Offset: 6 Size: 2
	struct FMovieSceneTangentDataSerializationHelper Tangent;  // Offset: 8 Size: 20



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkWaapiJsonManager.GetNumberField Size 40
class FGetNumberField
{

 public: 
	struct FAkWaapiFieldNames FieldName;  // Offset: 0 Size: 16
	struct FAKWaapiJsonObject Target;  // Offset: 16 Size: 16
	float ReturnValue;  // Offset: 32 Size: 4
	char pad_36[4];  // Offset: 36 Size: 4



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkWaapiCalls.Conv_FAkWaapiSubscriptionIdToString Size 24
class FConv_FAkWaapiSubscriptionIdToString
{

 public: 
	struct FAkWaapiSubscriptionId INAkWaapiSubscriptionId;  // Offset: 0 Size: 8
	struct FString ReturnValue;  // Offset: 8 Size: 16



 // Functions 
 public:
}; 
 
 //ScriptStruct AkAudio.MovieSceneTangentDataSerializationHelper Size 20
class FMovieSceneTangentDataSerializationHelper
{

 public: 
	float ArriveTangent;  // Offset: 0 Size: 4
	float LeaveTangent;  // Offset: 4 Size: 4
	enum class ERichCurveTangentWeightMode TangentWeightMode;  // Offset: 8 Size: 1
	char pad_9[3];  // Offset: 9 Size: 3
	float ArriveTangentWeight;  // Offset: 12 Size: 4
	float LeaveTangentWeight;  // Offset: 16 Size: 4



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkAcousticPortal.GetCurrentState Size 1
class FGetCurrentState
{

 public: 
	enum class AkAcousticPortalState ReturnValue;  // Offset: 0 Size: 1



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkRoomComponent.GetPrimitiveParent Size 8
class FGetPrimitiveParent
{

 public: 
	struct UPrimitiveComponent* ReturnValue;  // Offset: 0 Size: 8



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkPortalComponent.PortalPlacementValid Size 1
class FPortalPlacementValid
{

 public: 
	char pad_0_1 : 7;  // Offset: 0 Size: 1
	bool ReturnValue : 1;  // Offset: 0 Size: 1



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkXSXInitializationSettings.MigrateMultiCoreRendering Size 1
class FMigrateMultiCoreRendering
{

 public: 
	char pad_0_1 : 7;  // Offset: 0 Size: 1
	bool NewValue : 1;  // Offset: 0 Size: 1



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkWaapiJsonManager.Conv_FAKWaapiJsonObjectToString Size 32
class FConv_FAKWaapiJsonObjectToString
{

 public: 
	struct FAKWaapiJsonObject INAKWaapiJsonObject;  // Offset: 0 Size: 16
	struct FString ReturnValue;  // Offset: 16 Size: 16



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkAudioEvent.GetIsInfinite Size 1
class FGetIsInfinite
{

 public: 
	char pad_0_1 : 7;  // Offset: 0 Size: 1
	bool ReturnValue : 1;  // Offset: 0 Size: 1



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkAudioEvent.GetMaxAttenuationRadius Size 4
class FGetMaxAttenuationRadius
{

 public: 
	float ReturnValue;  // Offset: 0 Size: 4



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkAudioEvent.GetMaximumDuration Size 4
class FGetMaximumDuration
{

 public: 
	float ReturnValue;  // Offset: 0 Size: 4



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkAudioEvent.GetMinimumDuration Size 4
class FGetMinimumDuration
{

 public: 
	float ReturnValue;  // Offset: 0 Size: 4



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.GetRTPCValue Size 40
class FGetRTPCValue
{

 public: 
	struct UAkRtpc* RTPCValue;  // Offset: 0 Size: 8
	int32_t PlayingID;  // Offset: 8 Size: 4
	enum class ERTPCValueType InputValueType;  // Offset: 12 Size: 1
	char pad_13[3];  // Offset: 13 Size: 3
	float Value;  // Offset: 16 Size: 4
	enum class ERTPCValueType OutputValueType;  // Offset: 20 Size: 1
	char pad_21[3];  // Offset: 21 Size: 3
	struct AActor* Actor;  // Offset: 24 Size: 8
	struct FName RTPC;  // Offset: 32 Size: 8



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.SetBusConfig Size 24
class FSetBusConfig
{

 public: 
	struct FString BusName;  // Offset: 0 Size: 16
	enum class AkChannelConfiguration ChannelConfiguration;  // Offset: 16 Size: 1
	char pad_17[7];  // Offset: 17 Size: 7



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameObject.PostAkEvent Size 72
class FPostAkEvent
{

 public: 
	struct UAkAudioEvent* AkEvent;  // Offset: 0 Size: 8
	int32_t CallbackMask;  // Offset: 8 Size: 4
	struct FDelegate PostEventCallback;  // Offset: 12 Size: 16
	char pad_28[4];  // Offset: 28 Size: 4
	struct TArray<struct FAkExternalSourceInfo> ExternalSources;  // Offset: 32 Size: 16
	struct FString in_EventName;  // Offset: 48 Size: 16
	int32_t ReturnValue;  // Offset: 64 Size: 4
	char pad_68[4];  // Offset: 68 Size: 4



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkSlider.SetSliderHandleColor Size 16
class FSetSliderHandleColor
{

 public: 
	struct FLinearColor InValue;  // Offset: 0 Size: 16



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkLateReverbComponent.AssociateAkTextureSetComponent Size 8
class FAssociateAkTextureSetComponent
{

 public: 
	struct UAkAcousticTextureSetComponent* textureSetComponent;  // Offset: 0 Size: 8



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.GetAvailableAudioCultures Size 16
class FGetAvailableAudioCultures
{

 public: 
	struct TArray<struct FString> ReturnValue;  // Offset: 0 Size: 16



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameObject.PostAkEventAsync Size 80
class FPostAkEventAsync
{

 public: 
	struct UObject* WorldContextObject;  // Offset: 0 Size: 8
	struct UAkAudioEvent* AkEvent;  // Offset: 8 Size: 8
	int32_t PlayingID;  // Offset: 16 Size: 4
	int32_t CallbackMask;  // Offset: 20 Size: 4
	struct FDelegate PostEventCallback;  // Offset: 24 Size: 16
	struct TArray<struct FAkExternalSourceInfo> ExternalSources;  // Offset: 40 Size: 16
	struct FLatentActionInfo LatentInfo;  // Offset: 56 Size: 24



 // Functions 
 public:
}; 
 
 //Function AkAudio.PostEventAtLocationAsync.PostEventAtLocationAsync Size 48
class FPostEventAtLocationAsync
{

 public: 
	struct UObject* WorldContextObject;  // Offset: 0 Size: 8
	struct UAkAudioEvent* AkEvent;  // Offset: 8 Size: 8
	struct FVector Location;  // Offset: 16 Size: 12
	struct FRotator Orientation;  // Offset: 28 Size: 12
	struct UPostEventAtLocationAsync* ReturnValue;  // Offset: 40 Size: 8



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameObject.PostAssociatedAkEventAsync Size 80
class FPostAssociatedAkEventAsync
{

 public: 
	struct UObject* WorldContextObject;  // Offset: 0 Size: 8
	int32_t CallbackMask;  // Offset: 8 Size: 4
	struct FDelegate PostEventCallback;  // Offset: 12 Size: 16
	char pad_28[4];  // Offset: 28 Size: 4
	struct TArray<struct FAkExternalSourceInfo> ExternalSources;  // Offset: 32 Size: 16
	struct FLatentActionInfo LatentInfo;  // Offset: 48 Size: 24
	int32_t PlayingID;  // Offset: 72 Size: 4
	char pad_76[4];  // Offset: 76 Size: 4



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.SetRTPCValue Size 32
class FSetRTPCValue
{

 public: 
	struct UAkRtpc* RTPCValue;  // Offset: 0 Size: 8
	float Value;  // Offset: 8 Size: 4
	int32_t InterpolationTimeMs;  // Offset: 12 Size: 4
	struct AActor* Actor;  // Offset: 16 Size: 8
	struct FName RTPC;  // Offset: 24 Size: 8



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkComponent.GetAttenuationRadius Size 4
class FGetAttenuationRadius
{

 public: 
	float ReturnValue;  // Offset: 0 Size: 4



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkComponent.PostAkEventAndWaitForEnd Size 72
class FPostAkEventAndWaitForEnd
{

 public: 
	struct UAkAudioEvent* AkEvent;  // Offset: 0 Size: 8
	struct FString in_EventName;  // Offset: 8 Size: 16
	struct TArray<struct FAkExternalSourceInfo> ExternalSources;  // Offset: 24 Size: 16
	struct FLatentActionInfo LatentInfo;  // Offset: 40 Size: 24
	int32_t ReturnValue;  // Offset: 64 Size: 4
	char pad_68[4];  // Offset: 68 Size: 4



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkComponent.PostAkEventAndWaitForEndAsync Size 56
class FPostAkEventAndWaitForEndAsync
{

 public: 
	struct UAkAudioEvent* AkEvent;  // Offset: 0 Size: 8
	int32_t PlayingID;  // Offset: 8 Size: 4
	char pad_12[4];  // Offset: 12 Size: 4
	struct TArray<struct FAkExternalSourceInfo> ExternalSources;  // Offset: 16 Size: 16
	struct FLatentActionInfo LatentInfo;  // Offset: 32 Size: 24



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkComponent.PostAkEventByName Size 24
class FPostAkEventByName
{

 public: 
	struct FString in_EventName;  // Offset: 0 Size: 16
	int32_t ReturnValue;  // Offset: 16 Size: 4
	char pad_20[4];  // Offset: 20 Size: 4



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkComponent.PostAssociatedAkEventAndWaitForEndAsync Size 48
class FPostAssociatedAkEventAndWaitForEndAsync
{

 public: 
	int32_t PlayingID;  // Offset: 0 Size: 4
	char pad_4[4];  // Offset: 4 Size: 4
	struct TArray<struct FAkExternalSourceInfo> ExternalSources;  // Offset: 8 Size: 16
	struct FLatentActionInfo LatentInfo;  // Offset: 24 Size: 24



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.PostTrigger Size 24
class FPostTrigger
{

 public: 
	struct UAkTrigger* TriggerValue;  // Offset: 0 Size: 8
	struct AActor* Actor;  // Offset: 8 Size: 8
	struct FName Trigger;  // Offset: 16 Size: 8



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkComponent.SetAttenuationScalingFactor Size 4
class FSetAttenuationScalingFactor
{

 public: 
	float Value;  // Offset: 0 Size: 4



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkComponent.SetEarlyReflectionsAuxBus Size 16
class FSetEarlyReflectionsAuxBus
{

 public: 
	struct FString AuxBusName;  // Offset: 0 Size: 16



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkComponent.SetEarlyReflectionsVolume Size 4
class FSetEarlyReflectionsVolume
{

 public: 
	float SendVolume;  // Offset: 0 Size: 4



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkComponent.SetGameObjectRadius Size 8
class FSetGameObjectRadius
{

 public: 
	float in_outerRadius;  // Offset: 0 Size: 4
	float in_innerRadius;  // Offset: 4 Size: 4



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkComponent.SetListeners Size 16
class FSetListeners
{

 public: 
	struct TArray<struct UAkComponent*> Listeners;  // Offset: 0 Size: 16



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.SetOutputBusVolume Size 16
class FSetOutputBusVolume
{

 public: 
	float BusVolume;  // Offset: 0 Size: 4
	char pad_4[4];  // Offset: 4 Size: 4
	struct AActor* Actor;  // Offset: 8 Size: 8



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkComponent.SetStopWhenOwnerDestroyed Size 1
class FSetStopWhenOwnerDestroyed
{

 public: 
	char pad_0_1 : 7;  // Offset: 0 Size: 1
	bool bStopWhenOwnerDestroyed : 1;  // Offset: 0 Size: 1



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.SetSwitch Size 32
class FSetSwitch
{

 public: 
	struct UAkSwitchValue* SwitchValue;  // Offset: 0 Size: 8
	struct AActor* Actor;  // Offset: 8 Size: 8
	struct FName SwitchGroup;  // Offset: 16 Size: 8
	struct FName SwitchState;  // Offset: 24 Size: 8



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.UseEarlyReflections Size 48
class FUseEarlyReflections
{

 public: 
	struct AActor* Actor;  // Offset: 0 Size: 8
	struct UAkAuxBus* AuxBus;  // Offset: 8 Size: 8
	int32_t Order;  // Offset: 16 Size: 4
	float BusSendGain;  // Offset: 20 Size: 4
	float MaxPathLength;  // Offset: 24 Size: 4
	char pad_28_1 : 7;  // Offset: 28 Size: 1
	bool SpotReflectors : 1;  // Offset: 28 Size: 1
	char pad_29[3];  // Offset: 29 Size: 3
	struct FString AuxBusName;  // Offset: 32 Size: 16



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.UseReverbVolumes Size 16
class FUseReverbVolumes
{

 public: 
	char pad_0_1 : 7;  // Offset: 0 Size: 1
	bool inUseReverbVolumes : 1;  // Offset: 0 Size: 1
	char pad_1[7];  // Offset: 1 Size: 7
	struct AActor* Actor;  // Offset: 8 Size: 8



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkAudioInputComponent.PostAssociatedAudioInputEvent Size 4
class FPostAssociatedAudioInputEvent
{

 public: 
	int32_t ReturnValue;  // Offset: 0 Size: 4



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkCheckBox.GetAkProperty Size 16
class FGetAkProperty
{

 public: 
	struct FString ReturnValue;  // Offset: 0 Size: 16



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkWaapiJsonManager.GetStringField Size 48
class FGetStringField
{

 public: 
	struct FAkWaapiFieldNames FieldName;  // Offset: 0 Size: 16
	struct FAKWaapiJsonObject Target;  // Offset: 16 Size: 16
	struct FString ReturnValue;  // Offset: 32 Size: 16



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkCheckBox.IsChecked Size 1
class FIsChecked
{

 public: 
	char pad_0_1 : 7;  // Offset: 0 Size: 1
	bool ReturnValue : 1;  // Offset: 0 Size: 1



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkCheckBox.IsPressed Size 1
class FIsPressed
{

 public: 
	char pad_0_1 : 7;  // Offset: 0 Size: 1
	bool ReturnValue : 1;  // Offset: 0 Size: 1



 // Functions 
 public:
}; 
 
 //Function AkAudio.SAkWaapiFieldNamesConv.Conv_FAkWaapiFieldNamesToString Size 32
class FConv_FAkWaapiFieldNamesToString
{

 public: 
	struct FAkWaapiFieldNames INAkWaapiFieldNames;  // Offset: 0 Size: 16
	struct FString ReturnValue;  // Offset: 16 Size: 16



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkCheckBox.SetAkBoolProperty Size 16
class FSetAkBoolProperty
{

 public: 
	struct FString ItemProperty;  // Offset: 0 Size: 16



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkCheckBox.SetAkItemId Size 16
class FSetAkItemId
{

 public: 
	struct FGuid ItemId;  // Offset: 0 Size: 16



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkCheckBox.SetCheckedState Size 1
class FSetCheckedState
{

 public: 
	enum class ECheckBoxState InCheckedState;  // Offset: 0 Size: 1



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkCheckBox.SetIsChecked Size 1
class FSetIsChecked
{

 public: 
	char pad_0_1 : 7;  // Offset: 0 Size: 1
	bool InIsChecked : 1;  // Offset: 0 Size: 1



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.AddOutputCaptureMarker Size 16
class FAddOutputCaptureMarker
{

 public: 
	struct FString MarkerText;  // Offset: 0 Size: 16



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.CancelEventCallback Size 16
class FCancelEventCallback
{

 public: 
	struct FDelegate PostEventCallback;  // Offset: 0 Size: 16



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.ExecuteActionOnPlayingID Size 16
class FExecuteActionOnPlayingID
{

 public: 
	enum class AkActionOnEventType ActionType;  // Offset: 0 Size: 1
	char pad_1[3];  // Offset: 1 Size: 3
	int32_t PlayingID;  // Offset: 4 Size: 4
	int32_t TransitionDuration;  // Offset: 8 Size: 4
	enum class EAkCurveInterpolation FadeCurve;  // Offset: 12 Size: 1
	char pad_13[3];  // Offset: 13 Size: 3



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.GetAkAudioTypeUserData Size 24
class FGetAkAudioTypeUserData
{

 public: 
	struct UAkAudioType* Instance;  // Offset: 0 Size: 8
	UObject* Type;  // Offset: 8 Size: 8
	struct UObject* ReturnValue;  // Offset: 16 Size: 8



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.GetOcclusionScalingFactor Size 4
class FGetOcclusionScalingFactor
{

 public: 
	float ReturnValue;  // Offset: 0 Size: 4



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.GetAkComponent Size 48
class FGetAkComponent
{

 public: 
	struct USceneComponent* AttachToComponent;  // Offset: 0 Size: 8
	char pad_8_1 : 7;  // Offset: 8 Size: 1
	bool ComponentCreated : 1;  // Offset: 8 Size: 1
	char pad_9[3];  // Offset: 9 Size: 3
	struct FName AttachPointName;  // Offset: 12 Size: 8
	struct FVector Location;  // Offset: 20 Size: 12
	enum class EAttachLocation LocationType;  // Offset: 32 Size: 1
	char pad_33[7];  // Offset: 33 Size: 7
	struct UAkComponent* ReturnValue;  // Offset: 40 Size: 8



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.GetAkMediaAssetUserData Size 24
class FGetAkMediaAssetUserData
{

 public: 
	struct UAkMediaAsset* Instance;  // Offset: 0 Size: 8
	UObject* Type;  // Offset: 8 Size: 8
	struct UObject* ReturnValue;  // Offset: 16 Size: 8



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkWaapiJsonManager.SetArrayStringFields Size 64
class FSetArrayStringFields
{

 public: 
	struct FAkWaapiFieldNames FieldName;  // Offset: 0 Size: 16
	struct TArray<struct FString> FieldStringValues;  // Offset: 16 Size: 16
	struct FAKWaapiJsonObject Target;  // Offset: 32 Size: 16
	struct FAKWaapiJsonObject ReturnValue;  // Offset: 48 Size: 16



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.GetCurrentAudioCulture Size 16
class FGetCurrentAudioCulture
{

 public: 
	struct FString ReturnValue;  // Offset: 0 Size: 16



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.GetSourcePlayPosition Size 8
class FGetSourcePlayPosition
{

 public: 
	int32_t PlayingID;  // Offset: 0 Size: 4
	int32_t ReturnValue;  // Offset: 4 Size: 4



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.IsEditor Size 1
class FIsEditor
{

 public: 
	char pad_0_1 : 7;  // Offset: 0 Size: 1
	bool ReturnValue : 1;  // Offset: 0 Size: 1



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.LoadBank Size 56
class FLoadBank
{

 public: 
	struct UAkAudioBank* Bank;  // Offset: 0 Size: 8
	struct FString BankName;  // Offset: 8 Size: 16
	struct FLatentActionInfo LatentInfo;  // Offset: 24 Size: 24
	struct UObject* WorldContextObject;  // Offset: 48 Size: 8



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.LoadBankAsync Size 24
class FLoadBankAsync
{

 public: 
	struct UAkAudioBank* Bank;  // Offset: 0 Size: 8
	struct FDelegate BankLoadedCallback;  // Offset: 8 Size: 16



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.LoadBankByName Size 16
class FLoadBankByName
{

 public: 
	struct FString BankName;  // Offset: 0 Size: 16



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkWaapiJsonManager.GetArrayField Size 48
class FGetArrayField
{

 public: 
	struct FAkWaapiFieldNames FieldName;  // Offset: 0 Size: 16
	struct FAKWaapiJsonObject Target;  // Offset: 16 Size: 16
	struct TArray<struct FAKWaapiJsonObject> ReturnValue;  // Offset: 32 Size: 16



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.LoadBanks Size 24
class FLoadBanks
{

 public: 
	struct TArray<struct UAkAudioBank*> SoundBanks;  // Offset: 0 Size: 16
	char pad_16_1 : 7;  // Offset: 16 Size: 1
	bool SynchronizeSoundBanks : 1;  // Offset: 16 Size: 1
	char pad_17[7];  // Offset: 17 Size: 7



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.PostAndWaitForEndOfEvent Size 88
class FPostAndWaitForEndOfEvent
{

 public: 
	struct UAkAudioEvent* AkEvent;  // Offset: 0 Size: 8
	struct AActor* Actor;  // Offset: 8 Size: 8
	char pad_16_1 : 7;  // Offset: 16 Size: 1
	bool bStopWhenAttachedToDestroyed : 1;  // Offset: 16 Size: 1
	char pad_17[7];  // Offset: 17 Size: 7
	struct TArray<struct FAkExternalSourceInfo> ExternalSources;  // Offset: 24 Size: 16
	struct FString EventName;  // Offset: 40 Size: 16
	struct FLatentActionInfo LatentInfo;  // Offset: 56 Size: 24
	int32_t ReturnValue;  // Offset: 80 Size: 4
	char pad_84[4];  // Offset: 84 Size: 4



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkWaapiUriConv.Conv_FAkWaapiUriToString Size 32
class FConv_FAkWaapiUriToString
{

 public: 
	struct FAkWaapiUri INAkWaapiUri;  // Offset: 0 Size: 16
	struct FString ReturnValue;  // Offset: 16 Size: 16



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.PostAndWaitForEndOfEventAsync Size 64
class FPostAndWaitForEndOfEventAsync
{

 public: 
	struct UAkAudioEvent* AkEvent;  // Offset: 0 Size: 8
	struct AActor* Actor;  // Offset: 8 Size: 8
	int32_t PlayingID;  // Offset: 16 Size: 4
	char pad_20_1 : 7;  // Offset: 20 Size: 1
	bool bStopWhenAttachedToDestroyed : 1;  // Offset: 20 Size: 1
	char pad_21[3];  // Offset: 21 Size: 3
	struct TArray<struct FAkExternalSourceInfo> ExternalSources;  // Offset: 24 Size: 16
	struct FLatentActionInfo LatentInfo;  // Offset: 40 Size: 24



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.PostEventAtLocationByName Size 48
class FPostEventAtLocationByName
{

 public: 
	struct FString EventName;  // Offset: 0 Size: 16
	struct FVector Location;  // Offset: 16 Size: 12
	struct FRotator Orientation;  // Offset: 28 Size: 12
	struct UObject* WorldContextObject;  // Offset: 40 Size: 8



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.PostEventAttached Size 56
class FPostEventAttached
{

 public: 
	struct UAkAudioEvent* AkEvent;  // Offset: 0 Size: 8
	struct AActor* Actor;  // Offset: 8 Size: 8
	struct FName AttachPointName;  // Offset: 16 Size: 8
	char pad_24_1 : 7;  // Offset: 24 Size: 1
	bool bStopWhenAttachedToDestroyed : 1;  // Offset: 24 Size: 1
	char pad_25[7];  // Offset: 25 Size: 7
	struct FString EventName;  // Offset: 32 Size: 16
	int32_t ReturnValue;  // Offset: 48 Size: 4
	char pad_52[4];  // Offset: 52 Size: 4



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.PostEventByName Size 32
class FPostEventByName
{

 public: 
	struct FString EventName;  // Offset: 0 Size: 16
	struct AActor* Actor;  // Offset: 16 Size: 8
	char pad_24_1 : 7;  // Offset: 24 Size: 1
	bool bStopWhenAttachedToDestroyed : 1;  // Offset: 24 Size: 1
	char pad_25[7];  // Offset: 25 Size: 7



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.ReplaceMainOutput Size 24
class FReplaceMainOutput
{

 public: 
	struct FAkOutputSettings MainOutputSettings;  // Offset: 0 Size: 24



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.ResetRTPCValue Size 32
class FResetRTPCValue
{

 public: 
	struct UAkRtpc* RTPCValue;  // Offset: 0 Size: 8
	int32_t InterpolationTimeMs;  // Offset: 8 Size: 4
	char pad_12[4];  // Offset: 12 Size: 4
	struct AActor* Actor;  // Offset: 16 Size: 8
	struct FName RTPC;  // Offset: 24 Size: 8



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.SetCurrentAudioCulture Size 48
class FSetCurrentAudioCulture
{

 public: 
	struct FString AudioCulture;  // Offset: 0 Size: 16
	struct FLatentActionInfo LatentInfo;  // Offset: 16 Size: 24
	struct UObject* WorldContextObject;  // Offset: 40 Size: 8



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.SetCurrentAudioCultureAsync Size 32
class FSetCurrentAudioCultureAsync
{

 public: 
	struct FString AudioCulture;  // Offset: 0 Size: 16
	struct FDelegate Completed;  // Offset: 16 Size: 16



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.SetGameObjectToPortalObstruction Size 24
class FSetGameObjectToPortalObstruction
{

 public: 
	struct UAkComponent* GameObjectAkComponent;  // Offset: 0 Size: 8
	struct UAkPortalComponent* PortalComponent;  // Offset: 8 Size: 8
	float ObstructionValue;  // Offset: 16 Size: 4
	char pad_20[4];  // Offset: 20 Size: 4



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.SetMultipleChannelEmitterPositions Size 48
class FSetMultipleChannelEmitterPositions
{

 public: 
	struct UAkComponent* GameObjectAkComponent;  // Offset: 0 Size: 8
	struct TArray<enum class AkChannelConfiguration> ChannelMasks;  // Offset: 8 Size: 16
	struct TArray<struct FTransform> Positions;  // Offset: 24 Size: 16
	enum class AkMultiPositionType MultiPositionType;  // Offset: 40 Size: 1
	char pad_41[7];  // Offset: 41 Size: 7



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.SetMultipleChannelMaskEmitterPositions Size 48
class FSetMultipleChannelMaskEmitterPositions
{

 public: 
	struct UAkComponent* GameObjectAkComponent;  // Offset: 0 Size: 8
	struct TArray<struct FAkChannelMask> ChannelMasks;  // Offset: 8 Size: 16
	struct TArray<struct FTransform> Positions;  // Offset: 24 Size: 16
	enum class AkMultiPositionType MultiPositionType;  // Offset: 40 Size: 1
	char pad_41[7];  // Offset: 41 Size: 7



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.SetMultiplePositions Size 32
class FSetMultiplePositions
{

 public: 
	struct UAkComponent* GameObjectAkComponent;  // Offset: 0 Size: 8
	struct TArray<struct FTransform> Positions;  // Offset: 8 Size: 16
	enum class AkMultiPositionType MultiPositionType;  // Offset: 24 Size: 1
	char pad_25[7];  // Offset: 25 Size: 7



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.SetOcclusionRefreshInterval Size 16
class FSetOcclusionRefreshInterval
{

 public: 
	float RefreshInterval;  // Offset: 0 Size: 4
	char pad_4[4];  // Offset: 4 Size: 4
	struct AActor* Actor;  // Offset: 8 Size: 8



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.SetOcclusionScalingFactor Size 4
class FSetOcclusionScalingFactor
{

 public: 
	float ScalingFactor;  // Offset: 0 Size: 4



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkWaapiCalls.SubscribeToWaapi Size 80
class FSubscribeToWaapi
{

 public: 
	struct FAkWaapiUri WaapiUri;  // Offset: 0 Size: 16
	struct FAKWaapiJsonObject WaapiOptions;  // Offset: 16 Size: 16
	struct FDelegate Callback;  // Offset: 32 Size: 16
	struct FAkWaapiSubscriptionId SubscriptionId;  // Offset: 48 Size: 8
	char pad_56_1 : 7;  // Offset: 56 Size: 1
	bool SubscriptionDone : 1;  // Offset: 56 Size: 1
	char pad_57[7];  // Offset: 57 Size: 7
	struct FAKWaapiJsonObject ReturnValue;  // Offset: 64 Size: 16



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.SetPanningRule Size 1
class FSetPanningRule
{

 public: 
	enum class PanningRule PanRule;  // Offset: 0 Size: 1



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.SetPortalObstructionAndOcclusion Size 16
class FSetPortalObstructionAndOcclusion
{

 public: 
	struct UAkPortalComponent* PortalComponent;  // Offset: 0 Size: 8
	float ObstructionValue;  // Offset: 8 Size: 4
	float OcclusionValue;  // Offset: 12 Size: 4



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.SetPortalToPortalObstruction Size 24
class FSetPortalToPortalObstruction
{

 public: 
	struct UAkPortalComponent* PortalComponent0;  // Offset: 0 Size: 8
	struct UAkPortalComponent* PortalComponent1;  // Offset: 8 Size: 8
	float ObstructionValue;  // Offset: 16 Size: 4
	char pad_20[4];  // Offset: 20 Size: 4



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.SetReflectionsOrder Size 8
class FSetReflectionsOrder
{

 public: 
	int32_t Order;  // Offset: 0 Size: 4
	char pad_4_1 : 7;  // Offset: 4 Size: 1
	bool RefreshPaths : 1;  // Offset: 4 Size: 1
	char pad_5[3];  // Offset: 5 Size: 3



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.SetState Size 24
class FSetState
{

 public: 
	struct UAkStateValue* StateValue;  // Offset: 0 Size: 8
	struct FName StateGroup;  // Offset: 8 Size: 8
	struct FName State;  // Offset: 16 Size: 8



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.SpawnAkComponentAtLocation Size 80
class FSpawnAkComponentAtLocation
{

 public: 
	struct UObject* WorldContextObject;  // Offset: 0 Size: 8
	struct UAkAudioEvent* AkEvent;  // Offset: 8 Size: 8
	struct FVector Location;  // Offset: 16 Size: 12
	struct FRotator Orientation;  // Offset: 28 Size: 12
	char pad_40_1 : 7;  // Offset: 40 Size: 1
	bool AutoPost : 1;  // Offset: 40 Size: 1
	char pad_41[7];  // Offset: 41 Size: 7
	struct FString EventName;  // Offset: 48 Size: 16
	char pad_64_1 : 7;  // Offset: 64 Size: 1
	bool AutoDestroy : 1;  // Offset: 64 Size: 1
	char pad_65[7];  // Offset: 65 Size: 7
	struct UAkComponent* ReturnValue;  // Offset: 72 Size: 8



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.StartAllAmbientSounds Size 8
class FStartAllAmbientSounds
{

 public: 
	struct UObject* WorldContextObject;  // Offset: 0 Size: 8



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.StartOutputCapture Size 16
class FStartOutputCapture
{

 public: 
	struct FString Filename;  // Offset: 0 Size: 16



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.StartProfilerCapture Size 16
class FStartProfilerCapture
{

 public: 
	struct FString Filename;  // Offset: 0 Size: 16



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.StopAllAmbientSounds Size 8
class FStopAllAmbientSounds
{

 public: 
	struct UObject* WorldContextObject;  // Offset: 0 Size: 8



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.UnloadBankAsync Size 24
class FUnloadBankAsync
{

 public: 
	struct UAkAudioBank* Bank;  // Offset: 0 Size: 8
	struct FDelegate BankUnloadedCallback;  // Offset: 8 Size: 16



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkGameplayStatics.UnloadBankByName Size 16
class FUnloadBankByName
{

 public: 
	struct FString BankName;  // Offset: 0 Size: 16



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkMIDIEventCallbackInfo.GetChannel Size 1
class FGetChannel
{

 public: 
	char ReturnValue;  // Offset: 0 Size: 1



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkMIDIEventCallbackInfo.GetChannelAftertouch Size 4
class FGetChannelAftertouch
{

 public: 
	struct FAkMidiChannelAftertouch AsChannelAftertouch;  // Offset: 0 Size: 3
	char pad_3_1 : 7;  // Offset: 3 Size: 1
	bool ReturnValue : 1;  // Offset: 3 Size: 1



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkSlider.SetStepSize Size 4
class FSetStepSize
{

 public: 
	float InValue;  // Offset: 0 Size: 4



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkMIDIEventCallbackInfo.GetGeneric Size 5
class FGetGeneric
{

 public: 
	struct FAkMidiGeneric AsGeneric;  // Offset: 0 Size: 4
	char pad_4_1 : 7;  // Offset: 4 Size: 1
	bool ReturnValue : 1;  // Offset: 4 Size: 1



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkMIDIEventCallbackInfo.GetNoteAftertouch Size 5
class FGetNoteAftertouch
{

 public: 
	struct FAkMidiNoteAftertouch AsNoteAftertouch;  // Offset: 0 Size: 4
	char pad_4_1 : 7;  // Offset: 4 Size: 1
	bool ReturnValue : 1;  // Offset: 4 Size: 1



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkMIDIEventCallbackInfo.GetNoteOff Size 5
class FGetNoteOff
{

 public: 
	struct FAkMidiNoteOnOff AsNoteOff;  // Offset: 0 Size: 4
	char pad_4_1 : 7;  // Offset: 4 Size: 1
	bool ReturnValue : 1;  // Offset: 4 Size: 1



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkMIDIEventCallbackInfo.GetNoteOn Size 5
class FGetNoteOn
{

 public: 
	struct FAkMidiNoteOnOff AsNoteOn;  // Offset: 0 Size: 4
	char pad_4_1 : 7;  // Offset: 4 Size: 1
	bool ReturnValue : 1;  // Offset: 4 Size: 1



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkMIDIEventCallbackInfo.GetProgramChange Size 4
class FGetProgramChange
{

 public: 
	struct FAkMidiProgramChange AsProgramChange;  // Offset: 0 Size: 3
	char pad_3_1 : 7;  // Offset: 3 Size: 1
	bool ReturnValue : 1;  // Offset: 3 Size: 1



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkMIDIEventCallbackInfo.GetType Size 1
class FGetType
{

 public: 
	enum class EAkMidiEventType ReturnValue;  // Offset: 0 Size: 1



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkItemBoolPropertiesConv.Conv_FAkBoolPropertyToControlToString Size 32
class FConv_FAkBoolPropertyToControlToString
{

 public: 
	struct FAkBoolPropertyToControl INAkBoolPropertyToControl;  // Offset: 0 Size: 16
	struct FString ReturnValue;  // Offset: 16 Size: 16



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkItemBoolPropertiesConv.Conv_FAkBoolPropertyToControlToText Size 40
class FConv_FAkBoolPropertyToControlToText
{

 public: 
	struct FAkBoolPropertyToControl INAkBoolPropertyToControl;  // Offset: 0 Size: 16
	struct FText ReturnValue;  // Offset: 16 Size: 24



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkWwiseTree.GetSearchText Size 16
class FGetSearchText
{

 public: 
	struct FString ReturnValue;  // Offset: 0 Size: 16



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkItemProperties.GetSelectedProperty Size 16
class FGetSelectedProperty
{

 public: 
	struct FString ReturnValue;  // Offset: 0 Size: 16



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkWwiseTree.SetSearchText Size 16
class FSetSearchText
{

 public: 
	struct FString newText;  // Offset: 0 Size: 16



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkItemPropertiesConv.Conv_FAkPropertyToControlToString Size 32
class FConv_FAkPropertyToControlToString
{

 public: 
	struct FAkPropertyToControl INAkPropertyToControl;  // Offset: 0 Size: 16
	struct FString ReturnValue;  // Offset: 16 Size: 16



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkItemPropertiesConv.Conv_FAkPropertyToControlToText Size 40
class FConv_FAkPropertyToControlToText
{

 public: 
	struct FAkPropertyToControl INAkPropertyToControl;  // Offset: 0 Size: 16
	struct FText ReturnValue;  // Offset: 16 Size: 24



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkRoomComponent.SetGeometryComponent Size 8
class FSetGeometryComponent
{

 public: 
	struct UAkAcousticTextureSetComponent* textureSetComponent;  // Offset: 0 Size: 8



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkSlider.GetAkSliderItemId Size 16
class FGetAkSliderItemId
{

 public: 
	struct FGuid ReturnValue;  // Offset: 0 Size: 16



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkSlider.GetAkSliderItemProperty Size 16
class FGetAkSliderItemProperty
{

 public: 
	struct FString ReturnValue;  // Offset: 0 Size: 16



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkSlider.SetAkSliderItemId Size 16
class FSetAkSliderItemId
{

 public: 
	struct FGuid ItemId;  // Offset: 0 Size: 16



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkSlider.SetAkSliderItemProperty Size 16
class FSetAkSliderItemProperty
{

 public: 
	struct FString ItemProperty;  // Offset: 0 Size: 16



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkSlider.SetIndentHandle Size 1
class FSetIndentHandle
{

 public: 
	char pad_0_1 : 7;  // Offset: 0 Size: 1
	bool InValue : 1;  // Offset: 0 Size: 1



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkSlider.SetLocked Size 1
class FSetLocked
{

 public: 
	char pad_0_1 : 7;  // Offset: 0 Size: 1
	bool InValue : 1;  // Offset: 0 Size: 1



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkSlider.SetSliderBarColor Size 16
class FSetSliderBarColor
{

 public: 
	struct FLinearColor InValue;  // Offset: 0 Size: 16



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkSlider.SetValue Size 4
class FSetValue
{

 public: 
	float InValue;  // Offset: 0 Size: 4



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkWaapiCalls.CallWaapi Size 64
class FCallWaapi
{

 public: 
	struct FAkWaapiUri WaapiUri;  // Offset: 0 Size: 16
	struct FAKWaapiJsonObject WaapiArgs;  // Offset: 16 Size: 16
	struct FAKWaapiJsonObject WaapiOptions;  // Offset: 32 Size: 16
	struct FAKWaapiJsonObject ReturnValue;  // Offset: 48 Size: 16



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkWaapiCalls.Conv_FAkWaapiSubscriptionIdToText Size 32
class FConv_FAkWaapiSubscriptionIdToText
{

 public: 
	struct FAkWaapiSubscriptionId INAkWaapiSubscriptionId;  // Offset: 0 Size: 8
	struct FText ReturnValue;  // Offset: 8 Size: 24



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkWaapiCalls.RegisterWaapiConnectionLostCallback Size 20
class FRegisterWaapiConnectionLostCallback
{

 public: 
	struct FDelegate Callback;  // Offset: 0 Size: 16
	char pad_16_1 : 7;  // Offset: 16 Size: 1
	bool ReturnValue : 1;  // Offset: 16 Size: 1
	char pad_17[3];  // Offset: 17 Size: 3



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkWaapiCalls.RegisterWaapiProjectLoadedCallback Size 20
class FRegisterWaapiProjectLoadedCallback
{

 public: 
	struct FDelegate Callback;  // Offset: 0 Size: 16
	char pad_16_1 : 7;  // Offset: 16 Size: 1
	bool ReturnValue : 1;  // Offset: 16 Size: 1
	char pad_17[3];  // Offset: 17 Size: 3



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkWaapiCalls.SetSubscriptionID Size 16
class FSetSubscriptionID
{

 public: 
	struct FAkWaapiSubscriptionId Subscription;  // Offset: 0 Size: 8
	int32_t ID;  // Offset: 8 Size: 4
	char pad_12[4];  // Offset: 12 Size: 4



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkWaapiCalls.Unsubscribe Size 32
class FUnsubscribe
{

 public: 
	struct FAkWaapiSubscriptionId SubscriptionId;  // Offset: 0 Size: 8
	char pad_8_1 : 7;  // Offset: 8 Size: 1
	bool UnsubscriptionDone : 1;  // Offset: 8 Size: 1
	char pad_9[7];  // Offset: 9 Size: 7
	struct FAKWaapiJsonObject ReturnValue;  // Offset: 16 Size: 16



 // Functions 
 public:
}; 
 
 //Function AkAudio.SAkWaapiFieldNamesConv.Conv_FAkWaapiFieldNamesToText Size 40
class FConv_FAkWaapiFieldNamesToText
{

 public: 
	struct FAkWaapiFieldNames INAkWaapiFieldNames;  // Offset: 0 Size: 16
	struct FText ReturnValue;  // Offset: 16 Size: 24



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkWaapiJsonManager.Conv_FAKWaapiJsonObjectToText Size 40
class FConv_FAKWaapiJsonObjectToText
{

 public: 
	struct FAKWaapiJsonObject INAKWaapiJsonObject;  // Offset: 0 Size: 16
	struct FText ReturnValue;  // Offset: 16 Size: 24



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkWaapiJsonManager.GetBoolField Size 40
class FGetBoolField
{

 public: 
	struct FAkWaapiFieldNames FieldName;  // Offset: 0 Size: 16
	struct FAKWaapiJsonObject Target;  // Offset: 16 Size: 16
	char pad_32_1 : 7;  // Offset: 32 Size: 1
	bool ReturnValue : 1;  // Offset: 32 Size: 1
	char pad_33[7];  // Offset: 33 Size: 7



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkWaapiJsonManager.GetObjectField Size 48
class FGetObjectField
{

 public: 
	struct FAkWaapiFieldNames FieldName;  // Offset: 0 Size: 16
	struct FAKWaapiJsonObject Target;  // Offset: 16 Size: 16
	struct FAKWaapiJsonObject ReturnValue;  // Offset: 32 Size: 16



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkWaapiJsonManager.SetArrayObjectFields Size 64
class FSetArrayObjectFields
{

 public: 
	struct FAkWaapiFieldNames FieldName;  // Offset: 0 Size: 16
	struct TArray<struct FAKWaapiJsonObject> FieldObjectValues;  // Offset: 16 Size: 16
	struct FAKWaapiJsonObject Target;  // Offset: 32 Size: 16
	struct FAKWaapiJsonObject ReturnValue;  // Offset: 48 Size: 16



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkWaapiJsonManager.SetBoolField Size 56
class FSetBoolField
{

 public: 
	struct FAkWaapiFieldNames FieldName;  // Offset: 0 Size: 16
	char pad_16_1 : 7;  // Offset: 16 Size: 1
	bool FieldValue : 1;  // Offset: 16 Size: 1
	char pad_17[7];  // Offset: 17 Size: 7
	struct FAKWaapiJsonObject Target;  // Offset: 24 Size: 16
	struct FAKWaapiJsonObject ReturnValue;  // Offset: 40 Size: 16



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkWaapiJsonManager.SetNumberField Size 56
class FSetNumberField
{

 public: 
	struct FAkWaapiFieldNames FieldName;  // Offset: 0 Size: 16
	float FieldValue;  // Offset: 16 Size: 4
	char pad_20[4];  // Offset: 20 Size: 4
	struct FAKWaapiJsonObject Target;  // Offset: 24 Size: 16
	struct FAKWaapiJsonObject ReturnValue;  // Offset: 40 Size: 16



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkWaapiJsonManager.SetStringField Size 64
class FSetStringField
{

 public: 
	struct FAkWaapiFieldNames FieldName;  // Offset: 0 Size: 16
	struct FString FieldValue;  // Offset: 16 Size: 16
	struct FAKWaapiJsonObject Target;  // Offset: 32 Size: 16
	struct FAKWaapiJsonObject ReturnValue;  // Offset: 48 Size: 16



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkWaapiUriConv.Conv_FAkWaapiUriToText Size 40
class FConv_FAkWaapiUriToText
{

 public: 
	struct FAkWaapiUri INAkWaapiUri;  // Offset: 0 Size: 16
	struct FText ReturnValue;  // Offset: 16 Size: 24



 // Functions 
 public:
}; 
 
 //Function AkAudio.AkWwiseTree.GetSelectedItem Size 48
class FGetSelectedItem
{

 public: 
	struct FAkWwiseObjectDetails ReturnValue;  // Offset: 0 Size: 48



 // Functions 
 public:
}; 
 
 //Function AkAudio.PostEventAsync.PostEventAsync Size 80
class FPostEventAsync
{

 public: 
	struct UObject* WorldContextObject;  // Offset: 0 Size: 8
	struct UAkAudioEvent* AkEvent;  // Offset: 8 Size: 8
	struct AActor* Actor;  // Offset: 16 Size: 8
	int32_t CallbackMask;  // Offset: 24 Size: 4
	struct FDelegate PostEventCallback;  // Offset: 28 Size: 16
	char pad_44[4];  // Offset: 44 Size: 4
	struct TArray<struct FAkExternalSourceInfo> ExternalSources;  // Offset: 48 Size: 16
	char pad_64_1 : 7;  // Offset: 64 Size: 1
	bool bStopWhenAttachedToDestroyed : 1;  // Offset: 64 Size: 1
	char pad_65[7];  // Offset: 65 Size: 7
	struct UPostEventAsync* ReturnValue;  // Offset: 72 Size: 8



 // Functions 
 public:
}; 
 
 