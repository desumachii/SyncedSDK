#pragma once 
#include <ArkDeathCrate_BP_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkDeathCrate_BP.ArkDeathCrate_BP_C Size 1640
// Inherited 1616 bytes 
class AArkDeathCrate_BP_C : public AArkDeathCrate
{

 public: 
	struct FPointerToUberGraphFrame UberGraphFrame;  // Offset: 1616 Size: 8
	struct UArkSoftSkeletalMeshComponent* SkeletalMeshSoft;  // Offset: 1624 Size: 8
	struct USceneComponent* MeshRoot;  // Offset: 1632 Size: 8



 // Functions 
 public:
	struct USkeletalMeshComponent* GetPropSkeletalMeshComponent(); // Function ArkDeathCrate_BP.ArkDeathCrate_BP_C.GetPropSkeletalMeshComponent
	void PlaceBagMesh(); // Function ArkDeathCrate_BP.ArkDeathCrate_BP_C.PlaceBagMesh
	void ReceiveBeginPlay(); // Function ArkDeathCrate_BP.ArkDeathCrate_BP_C.ReceiveBeginPlay
	void BP_SetLootMeshEmmisiveColorByQuality(int32_t QualityIndex); // Function ArkDeathCrate_BP.ArkDeathCrate_BP_C.BP_SetLootMeshEmmisiveColorByQuality
	void BP_SetLootMeshTargetColorByQuality(int32_t QualityIndex); // Function ArkDeathCrate_BP.ArkDeathCrate_BP_C.BP_SetLootMeshTargetColorByQuality
	void BP_HideCrateMesh(bool bHide); // Function ArkDeathCrate_BP.ArkDeathCrate_BP_C.BP_HideCrateMesh
	void ExecuteUbergraph_ArkDeathCrate_BP(int32_t EntryPoint); // Function ArkDeathCrate_BP.ArkDeathCrate_BP_C.ExecuteUbergraph_ArkDeathCrate_BP
}; 
 
 


