#pragma once 
#include <SDK_Engine_Objects.h> 
 
 
//Function ABP_Detector_FlyCoat.ABP_Detector_FlyCoat_C.ExecuteUbergraph_ABP_Detector_FlyCoat Size 4
class FExecuteUbergraph_ABP_Detector_FlyCoat
{

 public: 
	int32_t EntryPoint;  // Offset: 0 Size: 4



 // Functions 
 public:
}; 
 
 //Function ABP_Detector_FlyCoat.ABP_Detector_FlyCoat_C.AnimGraph Size 16
class FAnimGraph
{

 public: 
	struct FPoseLink AnimGraph;  // Offset: 0 Size: 16



 // Functions 
 public:
}; 
 
 