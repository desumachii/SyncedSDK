#pragma once 
#include <ArkDamageType_2doTs_Flame_Structs.h>
 
 
 
//BlueprintGeneratedClass ArkDamageType_2doTs_Flame.ArkDamageType_2doTs_Flame_C Size 264
// Inherited 264 bytes 
class UArkDamageType_2doTs_Flame_C : public UArkDamageType_2doTs_C
{

 public: 



 // Functions 
 public:
}; 
 
 


